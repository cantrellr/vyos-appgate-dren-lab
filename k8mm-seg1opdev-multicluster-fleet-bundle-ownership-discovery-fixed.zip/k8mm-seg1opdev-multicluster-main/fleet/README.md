# Fleet bundles

Every child directory containing `fleet.yaml` is an independent Fleet bundle. The bundle label `kmm.dev/bundle` and `dependsOn.selector` define ordering. OCI charts are pulled from `oci://kubeharbor.dev.kube/k8mm-charts` with workspace credentials created by `scripts/management/fleet/03-bootstrap-gitrepos.sh`.

## Active bundles

```text
10-cert-manager
20-metallb
31-contour-segment1
40-trident-operator
41-trident-config
42-trident-protect
50-cnpg-operator
51-postgresql-ha
51-postgresql-replica
52-keycloak-operator
53-keycloak
54-keycloak-secondary
60-istio-base
61-istio-cni
62-istiod
63-eastwest-gateway
64-kiali-operator
65-kiali-server
70-kube-state-metrics
71-elastic-agent
```

The local GitRepo excludes identity bundles. The downstream GitRepo includes them, but their target customizations deploy only to appropriately labeled identity clusters. Kubernetes namespaces and their CIS/PSA labels are created by the runtime preflight and secret-seeding scripts, not by a Fleet Helm release; this avoids Helm ownership conflicts with namespaces created before GitOps reconciliation. External-Helm-only paths include a small `bundle-anchor.yaml` ConfigMap so Fleet consistently generates their Bundle objects.

Publish staged OCI charts with:

```bash
scripts/management/preflight/publish-fleet-charts.sh
```

Runtime Secrets must be seeded before the GitRepos are created. Do not add a plaintext Secret manifest to a bundle. Do not manage the same release with another GitOps controller or normal direct Helm commands.
