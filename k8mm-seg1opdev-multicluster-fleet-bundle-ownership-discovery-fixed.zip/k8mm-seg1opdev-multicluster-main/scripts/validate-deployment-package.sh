#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"

for cmd in find grep tar sha256sum python3; do require_cmd "${cmd}"; done
failures=0

while IFS= read -r -d '' file; do
  bash -n "${file}" || { warn "Shell syntax failed: ${file#${ROOT_DIR}/}"; failures=$((failures + 1)); }
done < <(find "${INSTALL_DIR}" -type f -name '*.sh' -print0)

while IFS= read -r -d '' file; do
  [[ "${file}" == "${SCRIPT_DIR}/validate-deployment-package.sh" ]] && continue
  if grep -Iq . "${file}" && grep -Eq 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|BEGIN PKCS12' "${file}"; then
    warn "Private key material detected: ${file#${ROOT_DIR}/}"
    failures=$((failures + 1))
  fi
done < <(find "${ROOT_DIR}" -type f ! -path '*/.git/*' -print0)

if ! python3 - "${ROOT_DIR}" <<'PY'
import re, sys
from pathlib import Path
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML is required')
root=Path(sys.argv[1]); errors=[]
credential_keys={'bootstrapPassword','password','clientSecret','client-secret','token'}
empty={'','""',"''",'null','Null','NULL','~','{}'}
for path in sorted(root.rglob('*')):
    if path.suffix not in {'.yaml','.yml'} or '.git' in path.parts:
        continue
    text=path.read_text(encoding='utf-8')
    try:
        docs=list(yaml.safe_load_all(text))
    except Exception as exc:
        errors.append(f'invalid YAML {path.relative_to(root)}: {exc}'); continue
    for doc in docs:
        if isinstance(doc,dict) and doc.get('kind')=='Secret':
            errors.append(f'committed Kubernetes Secret manifest: {path.relative_to(root)}')
    for line_no,line in enumerate(text.splitlines(),1):
        m=re.match(r'^\s*([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*?)\s*$',line)
        if not m or m.group(1) not in credential_keys: continue
        value=m.group(2).split(' #',1)[0].strip()
        if value not in empty and not value.startswith(('secret:', '${', '<')):
            errors.append(f'credential-like literal in {path.relative_to(root)}:{line_no}')
if errors:
    print('\n'.join('[WARN] '+x for x in errors),file=sys.stderr); raise SystemExit(1)
PY
then failures=$((failures + 1)); fi

if ! (cd "${ROOT_DIR}/helm" && sha256sum --check SHA256SUMS >/dev/null); then
  warn "Helm package checksum validation failed."
  failures=$((failures + 1))
fi

mapfile -t required_packages < <(grep -Ev '^[[:space:]]*(#|$)' "${ROOT_DIR}/helm/required-packages.txt")
mapfile -t checksum_packages < <(awk '{print $2}' "${ROOT_DIR}/helm/SHA256SUMS" | sed 's#^packages/##' | sort)
mapfile -t sorted_required_packages < <(printf '%s\n' "${required_packages[@]}" | sort)
if [[ "$(printf '%s\n' "${checksum_packages[@]}")" != "$(printf '%s\n' "${sorted_required_packages[@]}")" ]]; then
  warn "SHA256SUMS does not exactly cover required-packages.txt."
  failures=$((failures + 1))
fi
for package in "${required_packages[@]}"; do
  if [[ ! -f "${HELM_PACKAGES_DIR}/${package}" ]]; then
    warn "Missing Helm package: ${package}"; failures=$((failures + 1))
  elif ! tar -tzf "${HELM_PACKAGES_DIR}/${package}" >/dev/null; then
    warn "Invalid Helm archive: ${package}"; failures=$((failures + 1))
  fi
done
extra_packages="$(find "${HELM_PACKAGES_DIR}" -maxdepth 1 -type f -name '*.tgz' -printf '%f\n' | grep -vxFf <(printf '%s\n' "${required_packages[@]}") || true)"
if [[ -n "${extra_packages}" ]]; then
  warn "Unreferenced Helm packages remain:"; printf '%s\n' "${extra_packages}" >&2; failures=$((failures + 1))
fi

if ! python3 - "${ROOT_DIR}" <<'PYCHARTS'
from pathlib import Path
import sys
import tarfile
import yaml

root = Path(sys.argv[1])
package_names = [line.strip() for line in (root/'helm'/'required-packages.txt').read_text().splitlines()
                 if line.strip() and not line.lstrip().startswith('#')]
fleet_package_names = [line.strip() for line in (root/'helm'/'fleet-oci-packages.txt').read_text().splitlines()
                       if line.strip() and not line.lstrip().startswith('#')]
oci_items = {line.strip() for line in (root/'helm'/'required-oci-artifacts.txt').read_text().splitlines()
             if line.strip() and not line.lstrip().startswith('#')}
expected_oci = set()
chart_names = set()
errors = []
for filename in package_names:
    archive = root/'helm'/'packages'/filename
    try:
        with tarfile.open(archive, 'r:gz') as package:
            chart_members = [m for m in package.getmembers()
                             if m.name.count('/') == 1 and m.name.endswith('/Chart.yaml')]
            if len(chart_members) != 1:
                errors.append(f'{filename}: expected one top-level Chart.yaml')
                continue
            chart = yaml.safe_load(package.extractfile(chart_members[0])) or {}
    except Exception as exc:
        errors.append(f'{filename}: unable to read chart metadata: {exc}')
        continue
    name = str(chart.get('name') or '')
    version = str(chart.get('version') or '')
    if not name or not version:
        errors.append(f'{filename}: chart name/version is missing')
        continue
    expected_filename = f'{name}-{version}.tgz'
    if filename != expected_filename:
        errors.append(f'{filename}: metadata expects filename {expected_filename}')
    if name in chart_names:
        errors.append(f'{filename}: duplicate chart name {name}')
    chart_names.add(name)
    if filename in fleet_package_names:
        expected_oci.add(f'oci://kubeharbor.dev.kube/k8mm-charts/{name}:{version}')

unknown_fleet_packages = sorted(set(fleet_package_names) - set(package_names))
if unknown_fleet_packages:
    errors.append(f'Fleet OCI package list contains unknown packages: {unknown_fleet_packages}')
if 'rancher-2.14.2.tgz' in fleet_package_names:
    errors.append('Rancher bootstrap chart must not be in fleet-oci-packages.txt')
if oci_items != expected_oci:
    errors.append(f'OCI inventory mismatch: missing={sorted(expected_oci-oci_items)} extra={sorted(oci_items-expected_oci)}')

fleet_oci = set()
for fleet_file in sorted((root/'fleet'/'bundles').glob('*/fleet.yaml')):
    data = yaml.safe_load(fleet_file.read_text(encoding='utf-8')) or {}
    helm = data.get('helm') or {}
    repo = helm.get('repo')
    version = helm.get('version')
    if repo:
        fleet_oci.add(f'{repo}:{version}')
if fleet_oci != expected_oci:
    errors.append(f'Fleet chart ownership mismatch: missing={sorted(expected_oci-fleet_oci)} extra={sorted(fleet_oci-expected_oci)}')

rancher_installer = (root/'scripts'/'management'/'rancher'/'01-install-rancher.sh').read_text(encoding='utf-8')
if 'rancher-2.14.2.tgz' not in rancher_installer:
    errors.append('Rancher package is not referenced by the management bootstrap installer')

rancher_resources = root/'yaml'/'j64'/'seg1opman-cluster'/'resources'/'rancher-j64manager-resources-v1.yaml'
try:
    resource_docs = list(yaml.safe_load_all(rancher_resources.read_text(encoding='utf-8')))
except Exception as exc:
    errors.append(f'Unable to inspect Rancher resources: {exc}')
else:
    proxies = [item for item in resource_docs
               if isinstance(item, dict) and item.get('kind') == 'HTTPProxy'
               and (item.get('metadata') or {}).get('name') == 'rancher-httpproxy']
    if len(proxies) != 1:
        errors.append('Expected exactly one cattle-system/rancher-httpproxy resource')
    else:
        routes = ((proxies[0].get('spec') or {}).get('routes') or [])
        websocket_route = any(
            route.get('enableWebsockets') is True
            and (route.get('timeoutPolicy') or {}).get('response') == 'infinity'
            and (route.get('timeoutPolicy') or {}).get('idle') == 'infinity'
            and any(condition.get('prefix') == '/' for condition in (route.get('conditions') or []))
            and any(service.get('name') == 'rancher' and service.get('port') == 80
                    for service in (route.get('services') or []))
            for route in routes if isinstance(route, dict)
        )
        if not websocket_route:
            errors.append('Rancher HTTPProxy must enable WebSockets with infinite response/idle timeouts on the / route to rancher:80')

rancher_values = root/'yaml'/'j64'/'seg1opman-cluster'/'values'/'rancher-j64manager-values-v1.yaml'
try:
    values = yaml.safe_load(rancher_values.read_text(encoding='utf-8')) or {}
except Exception as exc:
    errors.append(f'Unable to inspect Rancher values: {exc}')
else:
    fleet_values = values.get('fleet') or ''
    if not isinstance(fleet_values, str) or 'KUBE_FEATURE_WatchListClient' not in fleet_values or 'value: "false"' not in fleet_values:
        errors.append('Rancher values must pass KUBE_FEATURE_WatchListClient=false to the bundled Fleet chart')

if errors:
    print('\n'.join('[WARN] '+error for error in errors), file=sys.stderr)
    raise SystemExit(1)
print(f'Chart metadata, OCI inventory, and ownership checks passed for {len(package_names)} packages.')
PYCHARTS
then failures=$((failures + 1)); fi

if ! grep -q 'validate-rancher-registry.sh" preflight' "${ROOT_DIR}/scripts/management/fleet/00-bootstrap-management.sh"; then
  warn "Management bootstrap does not enforce external Rancher registry validation."
  failures=$((failures + 1))
fi
if ! grep -q '02-validate-rancher-system.sh' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh"; then
  warn "Rancher installer does not validate webhook/Fleet readiness."
  failures=$((failures + 1))
fi
if ! grep -q '00-prepare-rancher-psa.sh' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh"; then
  warn "Rancher installer does not prepare privileged Rancher/Fleet PSA namespaces."
  failures=$((failures + 1))
fi
if ! grep -q '00-prepare-rancher-psa.sh.*--check --all' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate Rancher/Fleet PSA namespaces on all clusters."
  failures=$((failures + 1))
fi
if ! grep -q '04-configure-fleet-watchlist.sh.*--all --check' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate the Kubernetes 1.35 WatchListClient workaround on all clusters."
  failures=$((failures + 1))
fi
if ! grep -q '05-validate-imported-clusters.sh.*--wait' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate Rancher imported-cluster connectivity."
  failures=$((failures + 1))
fi
for token in cattle-system cattle-fleet-system 'pod-security.kubernetes.io/enforce=privileged'; do
  if ! grep -q "${token}" "${ROOT_DIR}/scripts/management/rancher/00-prepare-rancher-psa.sh"; then
    warn "Rancher PSA preparation script is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if ! grep -q 'repair-rancher-psa' "${ROOT_DIR}/scripts/deploy-platform.sh"; then
  warn "deploy-platform.sh does not expose the Rancher/Fleet PSA repair phase."
  failures=$((failures + 1))
fi
for phase in configure-fleet-watchlist validate-rancher-imports repair-rancher-agents; do
  if ! grep -q "${phase}" "${ROOT_DIR}/scripts/deploy-platform.sh"; then
    warn "deploy-platform.sh does not expose required Rancher/Fleet phase: ${phase}"
    failures=$((failures + 1))
  fi
done
for token in KUBE_FEATURE_WatchListClient spec.agentEnvVars fleet-controller fleet-agent; do
  if ! grep -q "${token}" "${ROOT_DIR}/scripts/management/rancher/04-configure-fleet-watchlist.sh"; then
    warn "Fleet WatchList compatibility script is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if ! grep -q 'RANCHER_REGISTRY_ENFORCE=true' "${ROOT_DIR}/config/fleet-bootstrap.example.env"; then
  warn "Example runtime config does not enforce Rancher registry validation."
  failures=$((failures + 1))
fi

if ! grep -q 'FLEET_RECONCILE_TIMEOUT_SECONDS' "${ROOT_DIR}/scripts/management/fleet/04-validate-fleet.sh"; then
  warn "Fleet validation does not wait for GitRepo scanning and Bundle generation."
  failures=$((failures + 1))
fi
if ! grep -q 'forceSyncGeneration' "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh"; then
  warn "Fleet GitRepo bootstrap does not trigger an immediate synchronization."
  failures=$((failures + 1))
fi
for identity_script in \
  scripts/management/fleet/05-enable-identity-secondary.sh \
  scripts/management/fleet/06-validate-identity-ha.sh \
  scripts/management/failover/failover-to-j52.sh \
  scripts/opkeycloak/02-install-oppostgres-cnpg-keycloak-db.sh
do
  if ! grep -q 'clusters.postgresql.cnpg.io' "${ROOT_DIR}/${identity_script}"; then
    warn "Identity script uses ambiguous CNPG Cluster resource shorthand: ${identity_script}"
    failures=$((failures + 1))
  fi
done
if ! grep -q 'effective defaults already match the KMM baseline' "${ROOT_DIR}/scripts/management/preflight/iscsi-multipath-fix.sh"; then
  warn "iSCSI/multipath convergence still rejects semantically equivalent existing configuration."
  failures=$((failures + 1))
fi

for forbidden in build helm/charts apps/istio scripts/management/argocd helm/packages/argo-cd-9.5.20.tgz rancher-airgap scripts/management/preflight/rancher-airgap.sh; do
  [[ ! -e "${ROOT_DIR}/${forbidden}" ]] || { warn "Forbidden legacy/Argo artifact exists: ${forbidden}"; failures=$((failures + 1)); }
done

required=(
  config/fleet-bootstrap.example.env
  helm/required-oci-artifacts.txt
  helm/fleet-oci-packages.txt
  scripts/_lib/runtime-config.sh
  scripts/management/fleet/00-bootstrap-management.sh
  scripts/management/fleet/00-preflight-fleet.sh
  scripts/management/fleet/01-seed-runtime-secrets.sh
  scripts/management/fleet/02-label-fleet-clusters.sh
  scripts/management/fleet/03-bootstrap-gitrepos.sh
  scripts/management/fleet/04-validate-fleet.sh
  scripts/management/preflight/publish-fleet-charts.sh
  scripts/management/preflight/validate-rancher-registry.sh
  scripts/management/rancher/00-prepare-rancher-psa.sh
  scripts/management/rancher/02-validate-rancher-system.sh
  scripts/management/rancher/03-repair-rancher-system.sh
  scripts/management/rancher/04-configure-fleet-watchlist.sh
  scripts/management/rancher/05-validate-imported-clusters.sh
  scripts/validate-fleet-layout.sh
  fleet/bundles/61-istio-cni/fleet.yaml
  fleet/bundles/53-keycloak/fleet.yaml
  fleet/bundles/70-kube-state-metrics/fleet.yaml
  fleet/bundles/71-elastic-agent/fleet.yaml
  scripts/management/preflight/cluster-time.sh
  scripts/management/preflight/iscsi-multipath-fix.sh
  scripts/management/failover/failover-to-j52.sh
  scripts/monitoring/02-validate-elastic-agent.sh
  docs/Deployment-Configuration-Reference.md
  docs/Rancher-Airgap-and-Helm-Operations.md
  docs/Rancher-Fleet-RKE2-1.35-Compatibility.md
  docs/Elastic-Stack-Monitoring.md
  docs/Host-Preflight.md
)
for path in "${required[@]}"; do
  [[ -f "${ROOT_DIR}/${path}" ]] || { warn "Missing Fleet deployment input: ${path}"; failures=$((failures + 1)); }
done


if ! python3 - "${ROOT_DIR}" <<'PYLINK'
from pathlib import Path
from urllib.parse import unquote
import re
import sys
root = Path(sys.argv[1])
errors = []
for path in root.rglob('*.md'):
    if '.git' in path.parts:
        continue
    text = path.read_text(encoding='utf-8')
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', text):
        if target.startswith(('http://', 'https://', '#', 'mailto:')):
            continue
        target = unquote(target.split('#', 1)[0])
        if target and not (path.parent / target).resolve().exists():
            errors.append(f'{path.relative_to(root)}: missing local link target {target}')
if errors:
    print('\n'.join('[WARN] ' + item for item in errors), file=sys.stderr)
    raise SystemExit(1)
PYLINK
then failures=$((failures + 1)); fi

"${SCRIPT_DIR}/validate-fleet-layout.sh" || failures=$((failures + 1))
[[ "${failures}" -eq 0 ]] || die "Deployment package validation failed with ${failures} issue(s)."
log "Deployment package validation passed."
