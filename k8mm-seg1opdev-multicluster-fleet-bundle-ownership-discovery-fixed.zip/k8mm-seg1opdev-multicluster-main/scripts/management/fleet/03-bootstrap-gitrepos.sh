#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"

fleet_git_username="$(read_required_secret_file FLEET_GIT_USERNAME_FILE)"
fleet_git_password="$(read_required_secret_file FLEET_GIT_PASSWORD_FILE)"
fleet_helm_username="$(read_required_secret_file FLEET_HELM_USERNAME_FILE)"
fleet_helm_password="$(read_required_secret_file FLEET_HELM_PASSWORD_FILE)"

for workspace in fleet-local fleet-default; do
  kubectl get namespace "${workspace}" >/dev/null 2>&1 || \
    die "Fleet workspace namespace ${workspace} does not exist. Rancher/Fleet is not ready."
  kubectl -n "${workspace}" create secret generic kmm-git-credentials \
    --type=kubernetes.io/basic-auth \
    --from-literal=username="${fleet_git_username}" \
    --from-literal=password="${fleet_git_password}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n "${workspace}" create secret generic kmm-helm-credentials \
    --from-literal=username="${fleet_helm_username}" \
    --from-literal=password="${fleet_helm_password}" \
    --from-file=cacerts="${FLEET_HELM_CA_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
done

cat <<YAML | kubectl apply -f -
apiVersion: fleet.cattle.io/v1alpha1
kind: GitRepo
metadata:
  name: k8mm-seg1opdev-multicluster-local
  namespace: fleet-local
spec:
  repo: ${FLEET_REPO_URL}
  branch: ${FLEET_REPO_BRANCH}
  pollingInterval: ${FLEET_POLLING_INTERVAL:-60s}
  clientSecretName: kmm-git-credentials
  helmSecretName: kmm-helm-credentials
  helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'
  paths:
    - fleet/bundles/10-cert-manager
    - fleet/bundles/20-metallb
    - fleet/bundles/31-contour-segment1
    - fleet/bundles/40-trident-operator
    - fleet/bundles/41-trident-config
    - fleet/bundles/42-trident-protect
    - fleet/bundles/60-istio-base
    - fleet/bundles/61-istio-cni
    - fleet/bundles/62-istiod
    - fleet/bundles/63-eastwest-gateway
    - fleet/bundles/64-kiali-operator
    - fleet/bundles/65-kiali-server
    - fleet/bundles/70-kube-state-metrics
    - fleet/bundles/71-elastic-agent
  targets:
    - name: management-cluster
      clusterSelector:
        matchLabels:
          kmm.dev/context: j64seg1opman
---
apiVersion: fleet.cattle.io/v1alpha1
kind: GitRepo
metadata:
  name: k8mm-seg1opdev-multicluster-downstream
  namespace: fleet-default
spec:
  repo: ${FLEET_REPO_URL}
  branch: ${FLEET_REPO_BRANCH}
  pollingInterval: ${FLEET_POLLING_INTERVAL:-60s}
  clientSecretName: kmm-git-credentials
  helmSecretName: kmm-helm-credentials
  helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'
  paths:
    - fleet/bundles/10-cert-manager
    - fleet/bundles/20-metallb
    - fleet/bundles/31-contour-segment1
    - fleet/bundles/40-trident-operator
    - fleet/bundles/41-trident-config
    - fleet/bundles/42-trident-protect
    - fleet/bundles/50-cnpg-operator
    - fleet/bundles/51-postgresql-ha
    - fleet/bundles/51-postgresql-replica
    - fleet/bundles/52-keycloak-operator
    - fleet/bundles/53-keycloak
    - fleet/bundles/54-keycloak-secondary
    - fleet/bundles/60-istio-base
    - fleet/bundles/61-istio-cni
    - fleet/bundles/62-istiod
    - fleet/bundles/63-eastwest-gateway
    - fleet/bundles/64-kiali-operator
    - fleet/bundles/65-kiali-server
    - fleet/bundles/70-kube-state-metrics
    - fleet/bundles/71-elastic-agent
  targets:
    - name: seg1opdev-platform
      clusterSelector:
        matchLabels:
          kmm.dev/platform: seg1opdev
YAML

# Increment forceSyncGeneration so credential, branch, and path corrections are
# picked up immediately instead of waiting for the next polling interval.
for repo in \
  fleet-local/k8mm-seg1opdev-multicluster-local \
  fleet-default/k8mm-seg1opdev-multicluster-downstream
do
  namespace="${repo%%/*}"
  name="${repo##*/}"
  current="$(kubectl -n "${namespace}" get gitrepo "${name}" -o jsonpath='{.spec.forceSyncGeneration}' 2>/dev/null || true)"
  current="${current:-0}"
  kubectl -n "${namespace}" patch gitrepo "${name}" --type=merge \
    -p "{\"spec\":{\"forceSyncGeneration\":$((current + 1))}}" >/dev/null
done

unset fleet_git_username fleet_git_password fleet_helm_username fleet_helm_password
log "Fleet GitRepo resources created or updated and queued for immediate synchronization."
