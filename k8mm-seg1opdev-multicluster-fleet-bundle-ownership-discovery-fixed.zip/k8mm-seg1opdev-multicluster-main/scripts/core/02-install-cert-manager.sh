#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"
NAMESPACE="cert-manager"
RELEASE="onprem-cert-manager"
CHART="cert-manager-1.5.14.tgz"
VALUES="bitnami-cert-manager-values-v1514-v1.yaml"
RESOURCES1="cert-manager-resources-v1.yaml"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

log "Creating and CIS-hardening namespace ${NAMESPACE}..."
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"

kubectl -n "${NAMESPACE}" get secret segment1-ca-bundle-secret >/dev/null 2>&1 || \
  die "Missing runtime Segment1 CA secret. Run scripts/core/01-bootstrap-ca-secret.sh first."

helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${YAML_DIR}/values/${VALUES}" \
  --create-namespace

log "Waiting for ${RELEASE} components to be ready..."
wait_for_deployment_available "${NAMESPACE}" "${RELEASE}-controller" "${KUBECTL_TIMEOUT}"
wait_for_deployment_available "${NAMESPACE}" "${RELEASE}-cainjector" "${KUBECTL_TIMEOUT}"
wait_for_deployment_available "${NAMESPACE}" "${RELEASE}-webhook" "${KUBECTL_TIMEOUT}"
log "Applying ${RELEASE} issuer resources..."
apply_file "${YAML_DIR}/resources/${RESOURCES1}"
log "${RELEASE} installed with restricted Pod Security Admission enforcement."
