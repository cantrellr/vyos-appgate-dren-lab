# K8s Mystical Mesh — Segment1 OPDEV Multicluster

**Deployment model:** Rancher Manager + Rancher Fleet + Service Mesh
**Environment:** air-gapped, distributed four-cluster RKE2 platform

```text
██╗  ██╗  █████╗  ███████╗       ███╗   ███╗ ██╗   ██╗ ███████╗ ████████╗ ██╗  ██████╗  █████╗  ██╗
██║ ██╔╝ ██╔══██╗ ██╔════╝       ████╗ ████║ ╚██╗ ██╔╝ ██╔════╝ ╚══██╔══╝ ██║ ██╔════╝ ██╔══██╗ ██║
█████╔╝  ╚█████╔╝ ███████╗       ██╔████╔██║  ╚████╔╝  ███████╗    ██║    ██║ ██║      ███████║ ██║
██╔═██╗  ██╔══██╗ ╚════██║       ██║╚██╔╝██║   ╚██╔╝   ╚════██║    ██║    ██║ ██║      ██╔══██║ ██║
██║  ██╗ ╚█████╔╝ ███████║       ██║ ╚═╝ ██║    ██║    ███████║    ██║    ██║ ╚██████╗ ██║  ██║ ███████╗
╚═╝  ╚═╝  ╚════╝  ╚══════╝       ╚═╝     ╚═╝    ╚═╝    ╚══════╝    ╚═╝    ╚═╝  ╚═════╝ ╚═╝  ╚═╝ ╚══════╝

███╗   ███╗ ███████╗ ███████╗ ██╗  ██╗
████╗ ████║ ██╔════╝ ██╔════╝ ██║  ██║
██╔████╔██║ █████╗   ███████╗ ███████║
██║╚██╔╝██║ ██╔══╝   ╚════██║ ██╔══██║
██║ ╚═╝ ██║ ███████╗ ███████║ ██║  ██║
╚═╝     ╚═╝ ╚══════╝ ╚══════╝ ╚═╝  ╚═╝

production multi-cluster kubernetes platform for mesh, data, and operations
```

**Segment1 Production Environment**  
**Baseline:** v2.3 — September 9, 2026  
**Platform:** four-cluster air-gapped RKE2 environment managed with Rancher Manager and Rancher Fleet  
**Primary design principle:** Rancher owns cluster lifecycle; Fleet owns steady-state Kubernetes delivery from Git and KubeHarbor.

This repository is the deployment and operations source for the Segment1 OPDEV multicluster platform. It covers the management cluster (`j64seg1opman`), three managed application clusters (`j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev`), the Istio service mesh, Segment1 ingress, Longhorn storage, two-site Keycloak/PostgreSQL identity, Elastic Agent monitoring, management-cluster GitLab Runner, and the air-gap controls required to run the platform without Internet access.

## Start here

| Audience | Read first |
| --- | --- |
| Executives, program leadership, customer stakeholders | [Executive Overview](docs/EXECUTIVE-OVERVIEW.md) |
| Architects and systems engineers | [Architecture and Design](docs/ARCHITECTURE-AND-DESIGN.md) |
| Deployment engineers | [Deployment and Configuration](docs/DEPLOYMENT-AND-CONFIGURATION.md) |
| Platform operators and administrators | [Operations and Lifecycle](docs/OPERATIONS-AND-LIFECYCLE.md) |
| Help desk, support technicians, escalation engineers | [Troubleshooting and Support](docs/TROUBLESHOOTING-AND-SUPPORT.md) |

## Platform at a glance

| Cluster | Primary role | Identity role | Segment1 ingress VIP | Istio east-west VIP |
| --- | --- | --- | --- | --- |
| `j64seg1opman` | Rancher/Fleet management and common platform services | none | `1.0.0.205` | `1.0.0.210` |
| `j64seg1opdev` | application cluster | J64 identity site; normally active, can become warm standby | `1.0.0.215` | `1.0.0.220` |
| `j52seg1opdev` | application cluster | J52 identity site; normally warm, can become active | `1.0.0.225` | `1.0.0.230` |
| `r01seg1opdev` | application cluster | none | `1.0.0.235` | `1.0.0.240` |

### Administrative URLs

| Service | Management | j64 application | j52 application | r01 application |
| --- | --- | --- | --- | --- |
| Longhorn | `https://longhorn-man.dev.kube` | `https://longhorn-j64.dev.kube` | `https://longhorn-j52.dev.kube` | `https://longhorn-r01.dev.kube` |
| Kiali | `https://kiali-man.dev.kube` | `https://kiali-j64.dev.kube` | `https://kiali-j52.dev.kube` | `https://kiali-r01.dev.kube` |

Other key endpoints include `https://rancher.dev.kube`, the canonical identity endpoint `https://opkeycloak.dev.jde.cybercom.ic.gov`, KubeHarbor at `kubeharbor.dev.kube`, GitLab at `gitlab001.dev.local`, external Grafana at `https://grafana.dev.kube`, and the configured Elastic Fleet Server (`ELASTIC_FLEET_URL`).

## Overall topology

```mermaid
flowchart TB
  ADMIN[Platform administrators and support teams]
  GITLAB[GitLab\nGit source of truth]
  HARBOR[KubeHarbor\nOCI charts and container images]
  DNS[Private DNS\ndev.kube and enterprise zones]
  NTP[Approved NTP sources]
  CA[Enterprise / Segment1 CA]
  ELASTIC[External Elastic Fleet Server]
  OBS[External Prometheus / Grafana]

  subgraph MGMT[j64seg1opman - Management Cluster]
    RANCHER[Rancher Manager]
    FLEET[Rancher Fleet]
    MESH_M[Istio / Kiali]
    STORAGE_M[Longhorn]
    AGENT_M[Elastic Agent]
    RUNNER[GitLab Runner]
  end

  subgraph J64[j64seg1opdev - Primary Application Cluster]
    MESH_J64[Istio / Kiali]
    STORAGE_J64[Longhorn]
    PG_PRIMARY[CloudNativePG Primary]
    KC_PRIMARY[Keycloak Active]
    AGENT_J64[Elastic Agent]
  end

  subgraph J52[j52seg1opdev - Secondary Identity Cluster]
    MESH_J52[Istio / Kiali]
    STORAGE_J52[Longhorn]
    PG_REPLICA[CloudNativePG Replica]
    KC_STANDBY[Keycloak Standby]
    AGENT_J52[Elastic Agent]
  end

  subgraph R01[r01seg1opdev - Application Cluster]
    MESH_R01[Istio / Kiali]
    STORAGE_R01[Longhorn]
    AGENT_R01[Elastic Agent]
  end

  ADMIN --> RANCHER
  GITLAB --> FLEET
  GITLAB <--> RUNNER
  HARBOR --> FLEET
  HARBOR --> MGMT
  HARBOR --> J64
  HARBOR --> J52
  HARBOR --> R01
  RANCHER --> FLEET
  FLEET --> MESH_M
  FLEET --> MESH_J64
  FLEET --> MESH_J52
  FLEET --> MESH_R01
  FLEET --> STORAGE_J64
  FLEET --> STORAGE_J52
  FLEET --> STORAGE_R01
  FLEET --> PG_PRIMARY
  FLEET --> PG_REPLICA
  FLEET --> KC_PRIMARY
  PG_PRIMARY -. asynchronous WAL replication .-> PG_REPLICA
  MESH_M <--> MESH_J64
  MESH_M <--> MESH_J52
  MESH_M <--> MESH_R01
  AGENT_M --> ELASTIC
  AGENT_J64 --> ELASTIC
  AGENT_J52 --> ELASTIC
  AGENT_R01 --> ELASTIC
  MESH_M --> OBS
  MESH_J64 --> OBS
  MESH_J52 --> OBS
  MESH_R01 --> OBS
  DNS --> MGMT
  DNS --> J64
  DNS --> J52
  DNS --> R01
  NTP --> MGMT
  NTP --> J64
  NTP --> J52
  NTP --> R01
  CA --> MGMT
  CA --> J64
  CA --> J52
  CA --> R01

  classDef external stroke-dasharray: 5 5
  class GITLAB,HARBOR,DNS,NTP,CA,ELASTIC,OBS external
```

Source: [`diagrams/overall-system-topology.mmd`](diagrams/overall-system-topology.mmd)

## Ownership model

| Scope | Lifecycle owner |
| --- | --- |
| VM/OS build, node networking, routes, DNS, host trust | infrastructure / image build process |
| RKE2 cluster creation, upgrades, etcd lifecycle | Rancher Manager and cluster operations |
| Rancher plus its management-cluster prerequisites | imperative bootstrap |
| Kubernetes platform charts and desired-state resources | Rancher Fleet |
| OCI charts and images | KubeHarbor |
| Git source of truth | GitLab |
| Runtime credentials and private CA material | protected files or external secret-management process; never Git |
| Chrony host time and Longhorn worker-storage readiness | controlled preflight scripts |
| Istio remote Secrets and identity promotion/fencing | controlled operational scripts |

A second GitOps controller is intentionally not part of the active design. Avoid direct Helm changes to Fleet-owned releases because they create ownership drift.

## Required external dependencies

The platform is disconnected from the public Internet but is **not self-contained**. It depends on the following services being reachable and trusted from the appropriate networks:

- GitLab repository hosting for Fleet source-of-truth operations.
- KubeHarbor for every promoted platform image and OCI Helm chart.
- Private DNS for `dev.kube`, identity, Rancher, monitoring, and replication names.
- Approved NTP sources for every node. Chrony deployment now fails if the source responds but advertises itself unsynchronized.
- Segment1 certificate authority material used by cert-manager and ingress certificates.
- Protected Keycloak runtime artifacts (`KEYCLOAK_KEYTAB_FILE_001` and `KEYCLOAK_PROVIDER_FILE_001`), seeded as Kubernetes Secrets rather than stored in Git.
- Keycloak controller safety: one Operator replica manages the HA Keycloak server CR; runtime artifact rotation recycles server Pods without patching the Operator-owned StatefulSet.
- External Elastic Fleet Server/ELK.
- GitLab Runner authentication token and GitLab CA material in protected runtime files; the Iron Bank v19.3.1 manager and helper paths plus the approved validation job image must be promoted to KubeHarbor.
- External Prometheus and Grafana used by Kiali.
- Segment1 VLAN/routing and the defined MetalLB address pools.

## Normal deployment command sequence

From the repository root with `KMM_FLEET_CONFIG` pointing to the protected runtime configuration:

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh bootstrap-management
./scripts/deploy-platform.sh prepare-rancher-imports

# Import/provision downstream clusters in Rancher.
./scripts/deploy-platform.sh onboard
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For an already-built environment, the most useful validation entry points are:

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh prepare-longhorn-nodes
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

## Support entry point

When something is red in Rancher/Fleet or a user reports a service problem, **do not start by deleting resources**. Begin with the support workflow in [Troubleshooting and Support](docs/TROUBLESHOOTING-AND-SUPPORT.md). The standard diagnostic collector is:

```bash
./scripts/collect-gitops-logs.sh
```

Fleet errors should be traced back to the Git commit, target labels, dependencies, external OCI registry, or runtime Secret contract before any manual cluster-side correction is attempted.

## Repository layout

```text
.
├── config/        non-secret runtime configuration example
├── diagrams/      Mermaid `.mmd` sources
├── docs/          five consolidated operating documents
├── fleet/         Fleet bundle source of truth
├── helm/          immutable offline chart packages and inventories
├── scripts/       bootstrap, validation, operations, and recovery tools
├── yaml/          source/break-glass configuration kept aligned with Fleet
└── README.md      repository entry point
```

Private credentials, private keys, Elastic enrollment tokens, Istio CA directories, and other secrets belong outside the repository.

## Release and change rules

1. Validate before every commit intended for deployment: `./scripts/deploy-platform.sh validate-package`.
2. Never overwrite an immutable OCI chart version with different bytes.
3. Update Git and KubeHarbor inventories together when adding or upgrading a component.
4. Keep `FLEET_REPO_BRANCH` aligned with the branch intended for deployment; Fleet will faithfully reconcile the configured branch even when the operator is working in another branch.
5. Use Git reverts for Fleet-owned rollback rather than ad-hoc Helm changes.
6. Use the supported Chrony uninstall workflow so the previous host time-service state is restored.
7. Require `verify-database-replication` to pass before any planned identity move; use `switch-identity <j64|j52>` for bidirectional planned switches. `failover-identity` and `failback-identity` remain compatibility aliases. Never start an opposite-direction switch while the previous journal is incomplete; resume it first. Do not hand-edit role labels.


### Identity planned/unplanned failover quick reference

The authoritative runbook is [Operations and Lifecycle — Identity operations](docs/OPERATIONS-AND-LIFECYCLE.md#8-identity-operations). DNS is a manually administered CNAME gate with a 30-second TTL:

```text
J64 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
J52 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
```

Before a switch:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

Start a planned switch without pre-acknowledging DNS:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev   # or j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
./scripts/deploy-platform.sh switch-identity j52  # or j64
```

The controller prepares the target, then stops safely at `status=waiting-external`, `stage=dns-cutover-pending` and prints the required DNS Admin CNAME change. DNS validation uses the configured Segment1 DNS servers (`IDENTITY_DNS_SERVERS`) directly rather than relying on the controller host resolver. After DNS Admins make that change:

```bash
./scripts/deploy-platform.sh identity-dns-status j52   # or j64
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev   # or j64seg1opdev
./scripts/deploy-platform.sh resume-identity-transition
```

Never start the reverse direction until the current journal is terminal. Unplanned promotion additionally requires possible-data-loss acknowledgement and a successful hard-fence hook. It uses the same DNS-admin handoff and ends `complete-degraded`; rebuild the former primary before planned failback.

Only the active site is expected to serve Keycloak. Test `https://opkeycloak.dev.jde.cybercom.ic.gov`; do not use a raw ingress IP as the Keycloak health check.
