#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq

allow_degraded=false
while (($#)); do
  case "$1" in
    --allow-degraded) allow_degraded=true ;;
    -h|--help)
      cat <<'USAGE'
Usage: 06-validate-identity-ha.sh [--allow-degraded]

Default validation is strict: both identity database sites must be reachable,
non-hibernated, and replication must pass. --allow-degraded is an explicit
post-incident mode for validating a fenced/hibernated standby after an
unplanned failover; it never claims full HA is healthy.
USAGE
      exit 0
      ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

management_context="${RANCHER_CONTEXT:-j64seg1opman}"

validate_keycloak() {
  local site="$1" expected="$2" actual
  actual="$(kubectl --context "${site}" -n opkeycloak get keycloak opkeycloak -o jsonpath='{.spec.instances}')"
  [[ "${actual}" == "${expected}" ]] || die "${site}: Keycloak instances=${actual}, Fleet label=${expected}."
}

validate_keycloak_runtime_artifacts() {
  local site="$1" expected_instances="$2"
  kubectl --context "${site}" -n opkeycloak get secret opkeycloak-keytab -o json | \
    jq -e '.data["opkeycloak.keytab"] | type == "string" and length > 0' >/dev/null || \
    die "${site}: opkeycloak-keytab is missing non-empty opkeycloak.keytab data."
  kubectl --context "${site}" -n opkeycloak get secret opkeycloak-provider -o json | \
    jq -e '.data["provider.jar"] | type == "string" and length > 0' >/dev/null || \
    die "${site}: opkeycloak-provider is missing non-empty provider.jar data."
  if (( expected_instances > 0 )); then
    kubectl --context "${site}" -n opkeycloak get statefulset opkeycloak -o json | jq -e '
      (.spec.template.spec.volumes // []) as $v |
      (.spec.template.spec.containers[] | select(.name == "keycloak") | .volumeMounts // []) as $m |
      any($v[]; .name == "opkeycloak-keytab" and .secret.secretName == "opkeycloak-keytab") and
      any($v[]; .name == "opkeycloak-provider" and .secret.secretName == "opkeycloak-provider") and
      any($m[]; .name == "opkeycloak-keytab" and .mountPath == "/etc/keycloak/keytabs") and
      any($m[]; .name == "opkeycloak-provider" and .mountPath == "/opt/keycloak/providers/kc-az-upn-linker.jar" and .subPath == "provider.jar")
    ' >/dev/null || die "${site}: generated Keycloak StatefulSet is missing the keytab/provider mounts."
  fi
}

validate_keycloak_exposure() {
  local site="$1" expected_instances="$2" proxy_status proxy_description cert_ready service_port endpoint_count

  # The Service, Certificate, and HTTPProxy are intentionally pre-staged on both
  # identity sites. DNS determines which site receives canonical traffic. A warm
  # standby therefore has a Valid HTTPProxy but zero Keycloak endpoints until a
  # controlled switchover activates its Keycloak CR.
  service_port="$(kubectl --context "${site}" -n opkeycloak get service opkeycloak-service \
    -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
  [[ "${service_port}" == "8080" ]] || die "${site}: pre-staged Keycloak Service is missing TCP/8080."

  cert_ready="$(kubectl --context "${site}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
  [[ "${cert_ready}" == "True" ]] || die "${site}: Keycloak TLS Certificate is not Ready."

  proxy_status="$(kubectl --context "${site}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
  proxy_description="$(kubectl --context "${site}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.description}' 2>/dev/null || true)"
  [[ "${proxy_status,,}" == "valid" ]] || \
    die "${site}: Keycloak HTTPProxy status=${proxy_status:-missing}: ${proxy_description:-no description}."

  endpoint_count="$(kubectl --context "${site}" -n opkeycloak get endpointslices.discovery.k8s.io \
    -l kubernetes.io/service-name=opkeycloak-service -o json 2>/dev/null | \
    jq -r '[.items[].endpoints[]? | select((.conditions.ready // true) == true)] | length' 2>/dev/null || echo 0)"

  if (( expected_instances > 0 )); then
    (( endpoint_count > 0 )) || die "${site}: active Keycloak has no Ready service endpoints."
  else
    [[ "${endpoint_count}" == "0" ]] || die "${site}: standby Keycloak instances=0 but ${endpoint_count} Ready endpoint(s) remain; possible dual-active exposure."
    log "${site}: standby Keycloak exposure is pre-staged (Service/TLS/HTTPProxy Ready) and dark with zero endpoints."
  fi
}
validate_replication_service_ip() {
  local site="$1" expected="$2" actual
  actual="$(kubectl --context "${site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get service oppostgres-replication-lb \
    -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  [[ "${actual}" == "${expected}" ]] || \
    die "${site}: PostgreSQL replication LoadBalancer IP=${actual:-unset}, expected ${expected}."
  [[ "${actual}" == 1.0.0.* || "${actual}" == 1.0.1.* ]] || \
    die "${site}: PostgreSQL replication IP ${actual} is outside Segment1 1.0.0.0/23."
}

validate_distributed_spec() {
  local site="$1" expected_primary="$2" expected_source cluster_json
  expected_source="$(identity_peer_site "${site}")"
  cluster_json="$(kubectl --context "${site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o json)"
  [[ "$(jq -r '.spec.replica.self // ""' <<<"${cluster_json}")" == "${site}" ]] || \
    die "${site}: CloudNativePG replica.self is not ${site}."
  [[ "$(jq -r '.spec.replica.primary // ""' <<<"${cluster_json}")" == "${expected_primary}" ]] || \
    die "${site}: CloudNativePG replica.primary does not match ${expected_primary}."
  [[ "$(jq -r '.spec.replica.source // ""' <<<"${cluster_json}")" == "${expected_source}" ]] || \
    die "${site}: CloudNativePG replica.source does not match ${expected_source}."
}

j64_json="$(fleet_cluster_json fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" "${management_context}")"
j52_json="$(fleet_cluster_json fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${management_context}")"
active_count="$(jq -n --argjson a "${j64_json}" --argjson b "${j52_json}" \
  '[ $a, $b ] | map(select(.metadata.labels["kmm.dev/identity-active"] == "true")) | length')"
[[ "${active_count}" == "1" ]] || die "Expected exactly one active identity site; found ${active_count}."

j64_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j64_json}")"
j52_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j52_json}")"
[[ -n "${j64_primary}" && "${j64_primary}" == "${j52_primary}" ]] || \
  die "Identity Fleet clusters disagree on kmm.dev/postgres-primary-site."
active_site="$(jq -n -r --argjson a "${j64_json}" --argjson b "${j52_json}" \
  '[ $a, $b ] | map(select(.metadata.labels["kmm.dev/identity-active"] == "true")) | .[0].metadata.labels["kmm.dev/context"]')"
[[ "${active_site}" == "${j64_primary}" ]] || \
  die "Active Keycloak site ${active_site} does not match writable PostgreSQL site ${j64_primary}."
standby_site="$(identity_peer_site "${active_site}")"

for site in j64seg1opdev j52seg1opdev; do
  if [[ "${site}" == "j64seg1opdev" ]]; then
    site_json="${j64_json}"
  else
    site_json="${j52_json}"
  fi
  topology="$(jq -r '.metadata.labels["kmm.dev/postgres-distributed-topology"] // ""' <<<"${site_json}")"
  [[ "${topology}" == "true" ]] || die "${site}: distributed PostgreSQL topology is not enabled."
  expected_instances="$(jq -r '.metadata.labels["kmm.dev/keycloak-instances"]' <<<"${site_json}")"
  hibernation="$(jq -r '.metadata.labels["kmm.dev/postgres-hibernation"]' <<<"${site_json}")"
  replication_ip="$(jq -r '.metadata.labels["kmm.dev/postgres-replication-lb-ip"]' <<<"${site_json}")"

  if ! kubectl --context "${site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
    [[ "${site}" == "${standby_site}" && "${hibernation}" == "on" && "${expected_instances}" == "0" ]] || \
      die "${site}: database is unavailable without valid standby fence labels."
    [[ "${allow_degraded}" == true ]] || \
      die "${site}: standby is unreachable/hibernated; strict HA validation requires both sites. Re-run with --allow-degraded only for an acknowledged post-incident state."
    warn "${site}: unreachable hibernated standby accepted only because --allow-degraded was specified."
    continue
  fi

  validate_keycloak "${site}" "${expected_instances}"
  validate_keycloak_runtime_artifacts "${site}" "${expected_instances}"
  validate_keycloak_exposure "${site}" "${expected_instances}"
  validate_replication_service_ip "${site}" "${replication_ip}"
  validate_distributed_spec "${site}" "${active_site}"

  if [[ "${hibernation}" == "on" ]]; then
    pod_count="$(kubectl --context "${site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get pods \
      -l "cnpg.io/cluster=${IDENTITY_POSTGRES_CLUSTER}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${pod_count}" == "0" ]] || die "${site}: labeled hibernated but ${pod_count} PostgreSQL pod(s) remain."
  elif [[ "${site}" == "${active_site}" ]]; then
    [[ "$(identity_sql "${site}" 'select pg_is_in_recovery()')" == "f" ]] || die "${site}: active database is read-only."
  else
    [[ "$(identity_sql "${site}" 'select pg_is_in_recovery()')" == "t" ]] || die "${site}: standby database is writable."
  fi
done

standby_hibernation="$(if [[ "${standby_site}" == "j64seg1opdev" ]]; then jq -r '.metadata.labels["kmm.dev/postgres-hibernation"]' <<<"${j64_json}"; else jq -r '.metadata.labels["kmm.dev/postgres-hibernation"]' <<<"${j52_json}"; fi)"
if [[ "${standby_hibernation}" == "off" ]]; then
  "${SCRIPT_DIR}/../failover/verify-database-replication.sh" "${active_site}" "${standby_site}"
  log "Identity HA validation passed: active Keycloak and writable PostgreSQL agree on ${active_site}; both sites are online and distributed replication is healthy."
else
  [[ "${allow_degraded}" == true ]] || \
    die "${standby_site}: standby is hibernated; strict HA validation does not permit replication to be skipped."
  warn "DEGRADED identity validation passed: ${active_site} is active, but ${standby_site} remains intentionally hibernated and HA/replication is not restored."
fi
