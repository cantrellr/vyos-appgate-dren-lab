# Fleet bundles

Every child directory containing `fleet.yaml` is an independent Fleet bundle. The bundle label `kmm.dev/bundle` and `dependsOn.selector` define ordering. OCI charts are pulled from `oci://kubeharbor.dev.kube/k8mm-charts` with workspace credentials created by `scripts/management/fleet/03-bootstrap-gitrepos.sh`.

## Active bundles

```text
10-cert-manager
11-cert-manager-config
20-metallb
21-metallb-config
31-contour-segment1
40-longhorn
41-longhorn-config
50-cnpg-operator
51-postgresql-ha
51-postgresql-replica
52-keycloak-operator
53-keycloak
54-keycloak-secondary
60-istio-base
61-istio-cni
62-istiod
63-eastwest-gateway
64-kiali-operator
65-kiali-server
70-kube-state-metrics
71-elastic-agent
```

The two cert-manager entries above are the real downstream bundles. The
management workspace does not consume those paths. Instead it uses:

```text
local-bundles/10-bootstrap-cert-manager-ready
local-bundles/11-bootstrap-cert-manager-config-ready
```

These local bundles publish dependency labels only; they do not install or
adopt cert-manager.

The local GitRepo excludes identity bundles and the real cert-manager chart/configuration bundles. `bootstrap-management` is the sole owner of cert-manager on `j64seg1opman`; the GitRepo bootstrap validates that release, its CRDs, CA Secret, webhook, and ClusterIssuer before registering the two local readiness-contract bundles. The downstream GitRepo includes the real cert-manager bundles and identity bundles, with identity target customizations deploying only to appropriately labeled clusters. Kubernetes namespaces and their CIS/PSA labels are created by the runtime preflight and secret-seeding scripts, not by a Fleet Helm release; this avoids Helm ownership conflicts with namespaces created before GitOps reconciliation. On downstream clusters, the cert-manager chart and `ClusterIssuer` remain separate so CRDs and the webhook are established before custom resources are rendered. MetalLB follows the same pattern: `20-metallb` installs the controller, speaker, and CRDs, while `21-metallb-config` applies the Segment1 `IPAddressPool` and `L2Advertisement` only after those CRDs exist. The configuration bundle is a small local Helm adapter: Fleet resolves `kmm.dev/segment1-pool` in `fleet-values.yaml`, then Helm renders the MetalLB custom resources from that concrete per-cluster value. External OCI charts are declared with `helm.chart`, not an OCI-only `helm.repo`, because the Rancher-bundled Fleet `v0.15.2` resource reader loads remote charts only when `helm.chart` is non-empty. Temporary bundle-anchor ConfigMaps are not used; every Helm Bundle must contain the actual downloaded chart resources so readiness reflects the real workload.

Publish staged OCI charts with:

```bash
scripts/management/preflight/publish-fleet-charts.sh
```

Runtime Secrets must be seeded before the GitRepos are created. Do not add a plaintext Secret manifest to a bundle. Do not manage the same release with another GitOps controller or normal direct Helm commands.
