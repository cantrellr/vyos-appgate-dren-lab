# Deploy the K8s Mystical Mesh multicluster platform

## 1. Scope

This procedure deploys the repository baseline to:

- `j64seg1opman` — Rancher/Fleet management;
- `j64seg1opdev` — application and active identity site;
- `j52seg1opdev` — application and warm identity site;
- `r01seg1opdev` — application site.

Fleet owns every post-bootstrap platform chart. Argo CD is not used. Elastic monitoring is deployed to all four clusters.

## 2. Prerequisites

On the deployment host, install Bash, Python 3 with PyYAML, `kubectl`, `helm`, `jq`, `openssl`, `sha256sum`, `tar`, Git, and OpenSSH. Configure the four kubeconfig contexts with the exact names above.

Prepare:

- KubeHarbor OCI project `k8mm-charts` and all required images;
- a Git repository reachable from Rancher/Fleet;
- protected files referenced by `config/fleet-bootstrap.example.env`;
- four Elastic Fleet policies/tokens, one per cluster;
- a complete Istio CA directory for each context;
- DNS/routing for Segment1 VIPs and external services;
- SSH key access and passwordless `sudo` to every node;
- Longhorn worker storage mounted at `/mnt/k8sdata`;
- external Prometheus and Grafana services for Kiali.

## 3. Validate and publish air-gap artifacts

```bash
scripts/deploy-platform.sh validate-package

export HELM_REGISTRY_USERNAME_FILE="$HOME/.config/k8mm-seg1opdev-multicluster/secrets/kubeharbor-username"
export HELM_REGISTRY_PASSWORD_FILE="$HOME/.config/k8mm-seg1opdev-multicluster/secrets/kubeharbor-token"
export HELM_REGISTRY_CA_FILE="$HOME/.config/k8mm-seg1opdev-multicluster/pki/segment1-devlocal-ca.crt"
scripts/management/preflight/publish-fleet-charts.sh
```

The publisher uses `helm/required-packages.txt`; do not maintain a second package list.

## 4. Create protected runtime configuration

```bash
install -d -m 700 "$HOME/.config/k8mm-seg1opdev-multicluster"
cp config/fleet-bootstrap.example.env \
  "$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev-v2.15.0.env"
chmod 600 "$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev-v2.15.0.env"
export KMM_FLEET_CONFIG="$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev-v2.15.0.env"
```

Edit only paths and non-secret values in that file. Put credentials/tokens in separate mode-`600` files.

## 5. Bootstrap management

```bash
scripts/deploy-platform.sh bootstrap-management
```

This performs only the dependency chain needed to start Rancher on `j64seg1opman`: registry Secret, CoreDNS patch, CA Secret, cert-manager, MetalLB, Segment1 Contour, and Rancher.

Provision or import `j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev` in Rancher. Confirm each appears in Fleet.

## 6. Onboard all clusters

```bash
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"
export SSH_STRICT_HOST_KEY_CHECKING=yes
export NTP_SERVERS='1.0.0.1 1.0.0.2'

scripts/deploy-platform.sh onboard
```

The phase executes in this order:

1. validate contexts, protected inputs, CA files, and Istio CA directories;
2. seed registry, cert-manager, Kiali, identity, Istio, and Elastic Secrets;
3. install the privileged Chrony DaemonSet on every cluster;
4. validate Longhorn packages and `/mnt/k8sdata` on every worker node;
5. apply Fleet cluster labels and the local/downstream GitRepo resources.

The workflow never formats the data disk and stops if the mounted filesystem or capacity differs from the approved contract.

## 7. Enable the warm identity site

Wait for j64 PostgreSQL and Keycloak to become healthy, then run:

```bash
scripts/deploy-platform.sh enable-identity-secondary
scripts/deploy-platform.sh validate-identity-ha
```

The enablement workflow transfers the CNPG replication client certificate to j52 without committing private material, then changes Fleet labels so the replica and zero-instance Keycloak resource reconcile.

## 8. Configure Istio cross-cluster discovery

Fleet installs Istio and the east-west gateways. After all gateways are Ready, create/rotate the remote-cluster Secrets through:

```bash
scripts/istio/03-configure-istio-multicluster-secrets.sh
scripts/istio/04-check-istio-system.sh
```

Remote kubeconfig Secrets are operational credentials and remain outside Git.

## 9. Acceptance checks

```bash
scripts/deploy-platform.sh validate
scripts/deploy-platform.sh validate-identity-ha
scripts/deploy-platform.sh validate-monitoring
scripts/security/01-verify-cis-readiness.sh --all
scripts/istio/05-audit-namespace-injection.sh --all
```

Also verify in Kibana/Fleet that one Agent policy is associated with each cluster and that the cluster identity/data-stream namespace is unique.

## 10. Reconciliation and rollback

Change Fleet-managed resources in Git, validate the package, push the branch, and observe Fleet. Do not run direct Helm changes against a Fleet-owned release. The imperative installers under `scripts/core`, `scripts/istio`, `scripts/opkeycloak`, and `scripts/monitoring` are bootstrap or break-glass tools; release names are aligned with Fleet to minimize ownership drift.

For a failed Git change, revert the commit. For a failed runtime Secret rotation, restore the protected input and rerun `seed-secrets`. For identity promotion, follow the two-site HA runbook; do not reverse labels manually.
