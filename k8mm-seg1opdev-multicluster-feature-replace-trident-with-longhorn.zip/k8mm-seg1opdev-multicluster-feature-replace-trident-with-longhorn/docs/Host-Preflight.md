# Host preflight

Host preflight prepares operating-system dependencies that cannot be managed safely by Fleet.

## Run

```bash
scripts/deploy-platform.sh host-preflight
# or only the storage phase
scripts/management/preflight/longhorn-storage-preflight.sh --all
```

Use `--context <name>` to target one cluster, `--skip-package-install` when packages are pre-provisioned, and `--continue-on-error` to audit every worker in one run.

## Longhorn worker validation

For each non-control-plane worker, the script:

1. resolves the node's InternalIP from Kubernetes and connects with strict SSH host-key checking;
2. installs or verifies `open-iscsi`, `nfs-common`, `cryptsetup`, `dmsetup`, and `xfsprogs`;
3. loads `iscsi_tcp` and enables `iscsid`;
4. disables active `multipathd` service/socket units because multipath can claim Longhorn devices;
5. verifies that `/mnt/k8sdata` is a read-write XFS mount with at least 240 GiB and that root mount propagation is shared;
6. verifies write access without retaining test data; and
7. labels the passing node `node.longhorn.io/create-default-disk=true`.

The script does not format, partition, mount, unmount, or erase storage. It preserves any multipath package and configuration even when the service is disabled.

Configuration overrides are `LONGHORN_DATA_PATH`, `LONGHORN_DATA_FILESYSTEM`, `LONGHORN_MIN_DISK_GIB`, and `LONGHORN_INSTALL_PACKAGES`.

## Ordering

`onboard` and `all` run Chrony and Longhorn storage preflight before Fleet registration. This prevents Longhorn and persistent workloads from reconciling before worker storage is ready.
