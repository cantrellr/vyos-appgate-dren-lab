# RKE2 CIS profile and namespace readiness

RKE2 CIS mode does not make third-party charts automatically compliant. This repository explicitly labels namespaces, disables unwanted service-account token mounting, and documents privileged exceptions.

## Namespace baseline

| Namespace | PSA enforcement | Reason |
| --- | --- | --- |
| `cert-manager` | restricted | certificate controllers/webhooks |
| `segment1` | restricted | Contour/Envoy hardened chart configuration |
| `elastic-monitoring` | restricted | kube-state-metrics |
| `oppostgres` | restricted | PostgreSQL/CNPG data tier |
| `opkeycloak` | restricted | Keycloak/operator |
| `metallb-system` | privileged | speaker networking |
| `longhorn-system` | privileged | CSI, host mounts, device and storage controller access |
| `istio-system` | privileged | Istio CNI and gateway requirements |
| `elastic-agent-system` | privileged | host logs, metrics, networking, and persistence |
| `cattle-system` | privileged | Rancher cluster agent, webhook, and Helm operation workloads |
| `cattle-fleet-system` | privileged | Fleet agent/controller workloads managed by Rancher |
| `cattle-fleet-local-system` | privileged | management-cluster Fleet local agent |
| `cattle-fleet-clusters-system` | privileged | Rancher/Fleet cluster-system workloads |

Automatic Istio injection is disabled in all platform namespaces. Application namespaces opt in separately under the injection contract.

## Rancher/Fleet preparation

Rancher-generated agents are not guaranteed to satisfy the RKE2 CIS default `restricted` profile. Prepare these namespaces before applying Rancher import manifests:

```bash
./scripts/deploy-platform.sh prepare-rancher-imports
```

To repair clusters that are already imported and showing PodSecurity `forbidden` events:

```bash
./scripts/deploy-platform.sh repair-rancher-psa
```

The repair command reapplies the namespace labels and restarts existing `cattle-cluster-agent` and `fleet-agent` Deployments. After import, use `./scripts/deploy-platform.sh repair-rancher-agents` to combine the PSA repair with the Fleet Kubernetes 1.35 WatchList workaround and Rancher connectivity validation. Rancher/Fleet own their system service accounts, so the generic default-ServiceAccount hardening check is intentionally not applied to these namespaces.

## Validation

```bash
scripts/management/rancher/00-prepare-rancher-psa.sh --check --all
scripts/management/rancher/04-configure-fleet-watchlist.sh --all --check
scripts/management/rancher/05-validate-imported-clusters.sh --wait
scripts/security/01-verify-cis-readiness.sh --all
scripts/istio/05-audit-namespace-injection.sh --all
```

Review chart upgrades for new capabilities, host mounts, service-account permissions, seccomp settings, and root requirements before changing a namespace profile. Do not solve an individual pod failure by broadly labeling an unrelated namespace privileged.

## Documented exceptions

Chrony is deployed in `kube-system` as a privileged host-time agent. Elastic Agent and Rancher/Fleet system namespaces are privileged by design. These exceptions should be included in the platform security plan and monitored for unexpected workloads. Do not deploy application workloads into Rancher/Fleet system namespaces.
