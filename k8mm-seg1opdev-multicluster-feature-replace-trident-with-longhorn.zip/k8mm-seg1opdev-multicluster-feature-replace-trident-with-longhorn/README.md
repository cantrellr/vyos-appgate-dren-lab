# K8s Mystical Mesh — Segment1 OPDEV Multicluster

**Deployment model:** Rancher Manager + Rancher Fleet + Service Mesh
**Environment:** air-gapped, distributed four-cluster RKE2 platform

```text
██╗  ██╗  █████╗  ███████╗       ███╗   ███╗ ██╗   ██╗ ███████╗ ████████╗ ██╗  ██████╗  █████╗  ██╗
██║ ██╔╝ ██╔══██╗ ██╔════╝       ████╗ ████║ ╚██╗ ██╔╝ ██╔════╝ ╚══██╔══╝ ██║ ██╔════╝ ██╔══██╗ ██║
█████╔╝  ╚█████╔╝ ███████╗       ██╔████╔██║  ╚████╔╝  ███████╗    ██║    ██║ ██║      ███████║ ██║
██╔═██╗  ██╔══██╗ ╚════██║       ██║╚██╔╝██║   ╚██╔╝   ╚════██║    ██║    ██║ ██║      ██╔══██║ ██║
██║  ██╗ ╚█████╔╝ ███████║       ██║ ╚═╝ ██║    ██║    ███████║    ██║    ██║ ╚██████╗ ██║  ██║ ███████╗
╚═╝  ╚═╝  ╚════╝  ╚══════╝       ╚═╝     ╚═╝    ╚═╝    ╚══════╝    ╚═╝    ╚═╝  ╚═════╝ ╚═╝  ╚═╝ ╚══════╝

███╗   ███╗ ███████╗ ███████╗ ██╗  ██╗
████╗ ████║ ██╔════╝ ██╔════╝ ██║  ██║
██╔████╔██║ █████╗   ███████╗ ███████║
██║╚██╔╝██║ ██╔══╝   ╚════██║ ██╔══██║
██║ ╚═╝ ██║ ███████╗ ███████║ ██║  ██║
╚═╝     ╚═╝ ╚══════╝ ╚══════╝ ╚═╝  ╚═╝

production multi-cluster kubernetes platform for mesh, data, and operations
```

**Segment1 Production Environment**  
**Version:** 2.0 
**Date:** July 30, 2026
**Configuration baseline:** July 30, 2026

This repository manages a four-cluster air-gapped Kubernetes platform across `j64seg1opman`, `j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev`. It includes the service mesh, ingress segmentation, data services, enterprise monitoring, application platforms, and security hardening needed to run disconnected platform workloads from a secure registry.

## Cluster Topology

| Cluster | Role |
| --- | --- |
| `j64seg1opman` | Management/control-plane workloads, central Prometheus, Grafana, Alertmanager, Kiali integration, Rancher, and Argo CD. |
| `j64seg1opdev` | Application/domain workloads, devlocal Keycloak, and related domain services. |
| `j52seg1opdev` | Application/domain workloads. |
| `r01seg1opdev` | Application/domain workloads. |

## KubeHarbor Registry Contract

All managed images now pull from the secure password-protected registry:

```text
kubeharbor.dev.kube
```

## Identity tier

The identity tier is deployed as a **two-site primary/warm-secondary service**:

- `j64seg1opdev` — active Keycloak site, three Keycloak replicas, three-node CloudNativePG cluster, and three PgBouncer replicas.
- `j52seg1opdev` — warm site, three-node streaming CloudNativePG replica and three PgBouncer replicas; the Keycloak custom resource is present but starts at zero replicas.
- `r01seg1opdev` — consumes the canonical identity endpoint but does not host an identity database.

Only one PostgreSQL site is writable and only one Keycloak site serves traffic at a time. Promotion is controlled and fences the former primary.

## Platform topology

| Context | Role | Identity role | Segment1 pool | Ingress VIP | PostgreSQL replication VIP | Istio east-west VIP |
| --- | --- | --- | --- | --- | --- | --- |
| `j64seg1opman` | Rancher/Fleet management | none | `1.0.0.201-1.0.0.210` | `1.0.0.205` | — | `1.0.0.210` |
| `j64seg1opdev` | application cluster | active primary | `1.0.0.211-1.0.0.220` | `1.0.0.215` | `1.0.0.216` | `1.0.0.220` |
| `j52seg1opdev` | application cluster | warm secondary | `1.0.0.221-1.0.0.230` | `1.0.0.225` | `1.0.0.226` | `1.0.0.230` |
| `r01seg1opdev` | application cluster | none | `1.0.0.231-1.0.0.240` | `1.0.0.235` | — | `1.0.0.240` |

The only non-storage LoadBalancer address pool is Segment1 (`1.0.0.0/23`). Storage data interfaces remain outside MetalLB.

## Ownership model

| Scope | Owner |
| --- | --- |
| VM/OS preparation, DNS, routes, host trust | infrastructure bootstrap |
| RKE2 creation, upgrades, etcd lifecycle | Rancher Manager |
| Initial management-cluster dependencies and Rancher | imperative bootstrap |
| Platform charts and Kubernetes resources | Rancher Fleet |
| Runtime credentials, CA private material, Fleet enrollment tokens | protected bootstrap files or external secret manager |
| Host Chrony and Longhorn storage validation | preflight scripts |
| Istio remote Secrets and identity promotion | controlled operational scripts |

## Fleet-managed stack

Fleet deploys cert-manager in separate chart/configuration stages on downstream clusters, plus MetalLB, one Segment1 Contour ingress plane, Longhorn, CloudNativePG, Keycloak, Istio CNI/control plane/east-west gateway, Kiali, kube-state-metrics, and Elastic Agent. On `j64seg1opman`, `bootstrap-management` remains the sole owner of cert-manager, MetalLB/Segment1 pool configuration, and the Segment1 Contour ingress release; the `fleet-local` GitRepo publishes lightweight readiness-contract bundles with the same dependency labels instead of reinstalling or adopting those bootstrap prerequisites. Identity bundles target only the two application clusters carrying identity labels.

Rancher is not Fleet-managed because Rancher must exist before Fleet can reconcile. CoreDNS forwarding, runtime Secrets, Chrony, Longhorn worker-storage preflight, Istio cross-cluster Secrets, and identity failover also remain controlled bootstrap/operations tasks.

## Elastic monitoring and token count

The default monitoring topology is one Fleet-managed Elastic Agent DaemonSet per cluster plus one kube-state-metrics Deployment per cluster. Use **four Fleet enrollment tokens total—one policy/token for each cluster**. This isolates policy changes, revocation, and data-stream identity by cluster.

An optional split node/cluster-wide Agent topology would require two policies per cluster and therefore eight tokens. The split topology is retained only as a source values file and is not deployed by Fleet.

## Required external services

- Helm `4.0.0` or newer on the deployment host. The shared wrapper uses `--rollback-on-failure`; Helm 3 is not supported by this package.
- KubeHarbor: `kubeharbor.dev.kube`, including the `k8mm-charts` OCI project and every image referenced by the bundles.
- Git repository reachable by Rancher/Fleet.
- Fleet Server/ELK reachable at `ELASTIC_FLEET_URL`, with the configured CA chain.
- Longhorn worker disk path, filesystem, capacity, and host package policy.
- Existing Prometheus and Grafana endpoints configured in the Kiali values. This repository does not deploy those external services.
- DNS records for ingress, east-west, identity, PostgreSQL replication, Rancher, Kiali, and Fleet endpoints.

## Deployment

This runbook assumes that all four RKE2 clusters and the external KubeHarbor registry already exist, their kubeconfig contexts are available to `k8admin`, and KubeHarbor is reachable from the management host and cluster nodes.

### 0. Prepare and RKE2nodeInit the golden image

Add image process here.

if not already done, create SSH key as the k8admin-cluster-admin

on the cloned deployment image VM, edit settings to match deployment node config file number of NICs and change to required portgroup

copy the k8mm-cluster-admin.pub SSH key to authorized users file on deplyment image
enable k8admin sudo NOPASSWD:ALL
create kubeharbor username/token files
copy deployment configuration files from rke2image to rke2-vms repo
copy deployment boot-iso files to datastore



### 1. Prepare the deployment environment

```bash
# Change to the repository root.
cd /home/k8admin/k8mm-seg1opdev-multicluster/

# Protect the runtime configuration file. The file should contain paths to
# protected credential files, not plaintext credential values committed to Git.
chmod 600 \
  "$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev.env"

# Tell the deployment scripts which runtime configuration file to load.
export KMM_FLEET_CONFIG="$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev.env"

# Configure the SSH account used for Longhorn worker-storage validation.
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"

# Use the approved NTP source for every cluster node.
export NTP_SERVERS='1.0.1.34' # dev.local RODC
```

Confirm the SSH key and noninteractive sudo work before deployment:

```bash
ssh -i "$SSH_IDENTITY_FILE" k8admin@NODE_IP \
  'hostname && sudo -n true && echo "Passwordless sudo: OK"'
```

### 2. Validate the deployment package

Run the static repository, Helm package, checksum, YAML, security, and Fleet-layout checks before changing any cluster:

```bash
./scripts/deploy-platform.sh validate-package
```

Do not proceed until this command passes.

### 3. Promote and validate Rancher images

Rancher image acquisition and promotion are owned by `cantrellr/k8s-airgap-images`. Use that repository on the connected and disconnected sides to pull, retag, and push the Rancher v2.15.0 image list into `kubeharbor.dev.kube`.

Set `RANCHER_IMAGE_LIST_FILE` in `fleet-bootstrap-seg1opdev-v2.15.0.env` to the staged Rancher image list, then validate Harbor and every management-cluster node:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
```

The seg1opdev repository performs validation only; it contains no Rancher image download, archive, load, or push implementation. Do not bootstrap Rancher until this command passes. See [Rancher registry validation and Helm operation recovery](docs/Rancher-Airgap-and-Helm-Operations.md).

### 4. Publish the Fleet Helm charts

KubeHarbor must already be operational. Publish the Fleet-owned staged Helm packages before Fleet GitRepos are created:

```bash
./scripts/management/preflight/publish-fleet-charts.sh
```

This command authenticates with the protected registry credential files referenced by `KMM_FLEET_CONFIG`, validates the Helm package checksums, and pushes only the Fleet-owned charts to the configured OCI project. The Rancher bootstrap chart remains local.

### 5. Bootstrap the management platform

Install the minimum management-cluster services, Rancher, and Fleet prerequisites:

```bash
./scripts/deploy-platform.sh bootstrap-management
```

During this phase, the bootstrap process creates `kube-system/regcred-kubeharbor` on `j64seg1opman` before installing management-cluster workloads that pull images from KubeHarbor. It renders the RKE2 CoreDNS private-zone forwarders from `DEV_KUBE_DNS_SERVERS`, `JDE_DNS_SERVERS`, and `JCP_DNS_SERVERS`, then proves that a cluster Pod can resolve `kubeharbor.dev.kube`. Rancher is installed with the Fleet Kubernetes 1.35 WatchListClient workaround, supplemental GitJob event RBAC, and a Contour route that enables long-lived WebSocket connections with infinite response and idle timeouts.

### 6. Provision or import downstream clusters

Before applying any Rancher import manifest, pre-create the Rancher/Fleet system namespaces on every cluster with the privileged Pod Security Admission labels required by the Rancher cluster agent and Fleet agent:

```bash
./scripts/deploy-platform.sh prepare-rancher-imports
```

This is mandatory for the RKE2 CIS profile. Without it, `cattle-cluster-agent` or `cattle-fleet-system/fleet-agent` can remain at zero pods with `forbidden: violates PodSecurity "restricted:latest"` errors.

Using Rancher, provision or import the remaining clusters and confirm that all four kubeconfig contexts are reachable from the management host:

```bash
kubectl config get-contexts

for context in \
  j64seg1opman \
  j64seg1opdev \
  j52seg1opdev \
  r01seg1opdev; do
  kubectl --context "$context" get nodes
done
```

All nodes must be `Ready` before continuing.

### 7. Onboard all clusters

Run the coordinated onboarding workflow:

```bash
./scripts/deploy-platform.sh onboard
```

`onboard` performs the following operations in dependency order:

1. Re-renders and validates management-cluster private DNS, including Pod resolution of `kubeharbor.dev.kube`.
2. Applies the supplemental GitJob event-writer RBAC.
3. Reapplies privileged PSA labels to Rancher/Fleet system namespaces and restarts existing agents.
4. Sets `KUBE_FEATURE_WatchListClient=false` on the Fleet controller and all local/downstream Fleet agents, using Fleet Cluster `spec.agentEnvVars` as the downstream source of truth.
5. Waits for all imported clusters to report connected in Rancher and verifies each `cattle-cluster-agent` Deployment is available.
6. Validates all cluster contexts, protected runtime inputs, and in-cluster Harbor DNS/TLS/authentication from a Fleet-system Pod.
7. Seeds runtime Secrets on all four clusters, including `kube-system/regcred-kubeharbor`.
8. Seeds the Keycloak, PostgreSQL, Istio, Kiali, and Elastic Agent Secrets in their required namespaces.
9. Installs the Chrony DaemonSet after the KubeHarbor pull Secret exists.
10. Validates Longhorn prerequisites and /mnt/k8sdata on every worker node over SSH.
11. Labels the Fleet clusters.
12. Creates the Fleet GitRepo resources and starts bundle reconciliation.

The Longhorn storage phase validates the existing mount and never formats or erases it. Active multipathd units are disabled because they can claim Longhorn devices.

Use that override only after reviewing and backing up the existing configuration.

Verify the registry Secret exists on every cluster after secret seeding:

```bash
for context in \
  j64seg1opman \
  j64seg1opdev \
  j52seg1opdev \
  r01seg1opdev; do
  printf '\n%s: ' "$context"
  kubectl --context "$context" \
    -n kube-system \
    get secret regcred-kubeharbor \
    -o jsonpath='{.type}{"\n"}'
done
```

Expected Secret type:

```text
kubernetes.io/dockerconfigjson
```

### 8. Validate the primary deployment

Allow Fleet to reconcile, then validate GitRepos and BundleDeployments before enabling the secondary identity site:

```bash
./scripts/deploy-platform.sh validate
```

The primary PostgreSQL and Keycloak deployment must be healthy before proceeding.

### 9. Enable the warm identity-secondary site

After the primary identity site is healthy, copy the required CloudNativePG replication material and enable the secondary identity bundles:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
```

### 10. Run specialized validation

Validate identity HA and Elastic monitoring:

```bash
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

### 11. Run final comprehensive validation

Finish with another complete Fleet validation to confirm the entire platform converged after the identity-secondary and monitoring deployments:

```bash
./scripts/deploy-platform.sh validate
```

## Recommended command sequence

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster/

chmod 600 \
  "$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev.env"
export KMM_FLEET_CONFIG="$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev.env"
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"
export NTP_SERVERS='1.0.1.34'

./scripts/deploy-platform.sh validate-package
./scripts/management/preflight/publish-fleet-charts.sh
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh bootstrap-management

# Prepare namespaces, then provision or import the downstream clusters in Rancher.
./scripts/deploy-platform.sh prepare-rancher-imports
# Apply the Rancher-generated import manifests here.

./scripts/deploy-platform.sh onboard
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
./scripts/deploy-platform.sh validate
```

## Expanded onboarding sequence

Use this only when the onboarding phases need to be run and observed individually. Do not run both this sequence and the combined `onboard` command unless intentionally reconverging the environment.

```bash
./scripts/deploy-platform.sh repair-rancher-agents
./scripts/deploy-platform.sh preflight-fleet
./scripts/deploy-platform.sh seed-secrets
./scripts/deploy-platform.sh install-cluster-time
./scripts/deploy-platform.sh prepare-longhorn-nodes
./scripts/deploy-platform.sh fleet
```

The important ordering constraint is that Longhorn worker preflight completes before Fleet registration, so persistent workloads cannot reconcile onto unvalidated storage.

## Repository map

- `fleet/bundles/` — Fleet-owned desired state.
- `scripts/management/fleet/` — Rancher/Fleet bootstrap and validation.
- `scripts/management/rancher/` — Rancher ingress, CIS namespace preparation, Fleet Kubernetes 1.35 compatibility, repair, and imported-cluster validation.
- `scripts/management/preflight/` — Fleet chart publishing, external registry validation, Chrony, and host storage preparation.
- `scripts/management/failover/` — controlled identity failover.
- `scripts/monitoring/` — Elastic break-glass install and validation.
- `yaml/` — source manifests and imperative/break-glass values.
- `helm/packages/` — immutable air-gap chart packages.
- `config/` — non-secret runtime configuration examples.
- `docs/` — architecture, configuration, deployment, and operations.

Start with [the deployment guide](docs/How-to-deploy-a-K8s-Mystical-Mesh%20multicluster.md), [the configuration reference](docs/Deployment-Configuration-Reference.md), [Rancher/Fleet RKE2 1.35 compatibility](docs/Rancher-Fleet-RKE2-1.35-Compatibility.md), and [Fleet operations](docs/Fleet-Operations.md).


### Bootstrap network ownership migration

The management cluster must not have two Helm lifecycle owners for MetalLB or Segment1 Contour. `bootstrap-management` owns those releases because they are prerequisites for Rancher. During upgrade from older layouts, `03-bootstrap-gitrepos.sh` retires the legacy `fleet-local` BundleDeployments with `keepResources` before replacing them with readiness-contract markers. Downstream clusters remain fully Fleet-managed. The downstream Contour bundle disables Fleet values preprocessing, pins each approved Segment1 load-balancer IP through `targetCustomizations`, and forces `global.security.allowInsecureImages: true` at Helm override precedence for the approved private Harbor mirror.


See [Longhorn storage](docs/Longhorn-Storage.md) for disk, storage-class, snapshot, and air-gap artifact contracts.
