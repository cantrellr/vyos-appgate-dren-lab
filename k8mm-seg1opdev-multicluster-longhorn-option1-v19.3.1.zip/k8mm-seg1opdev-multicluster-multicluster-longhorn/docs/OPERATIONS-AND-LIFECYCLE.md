# Operations and Lifecycle

> **Baseline:** v2.2 — August 28, 2026  
> **Audience:** platform operators, systems administrators, SRE/operations personnel, and escalation engineers.

## 1. Operating model

Normal steady-state changes follow this loop:

1. change the intended Git branch;
2. run `validate-package`;
3. push to GitLab;
4. allow Fleet to reconcile;
5. validate BundleDeployment readiness and service-specific health;
6. revert Git if the change is not acceptable.

Do not treat Rancher UI red states as a reason to manually delete Bundles. First identify the failing dependency and the Git commit/branch Fleet is actually reconciling.

## 2. Daily health checks

Recommended daily/shift checks:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For storage-sensitive operations also run:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

`prepare-longhorn-nodes` is non-destructive and verifies the host storage contract.

## 3. Rancher and Fleet operations

### Fleet readiness

Healthy steady state means the intended GitRepos are Ready and all intended BundleDeployments are Active. Bundle dependencies are expressed by `kmm.dev/bundle` labels.

Inspect GitRepos:

```bash
kubectl --context j64seg1opman -A get gitrepos.fleet.cattle.io
```

Inspect bundles by workspace:

```bash
kubectl --context j64seg1opman -n fleet-local get bundles.fleet.cattle.io
kubectl --context j64seg1opman -n fleet-default get bundles.fleet.cattle.io
```

Inspect the actual branch/commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

### Kubernetes 1.35 Fleet compatibility

The baseline requires `KUBE_FEATURE_WatchListClient=false` on Fleet controllers and agents. Apply/verify with:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Do not remove this control until the pinned Rancher/Fleet combination is upgraded and the replacement has been validated against RKE2/Kubernetes 1.35 behavior.

### Rancher system repair

Use:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow validates the registry, refreshes CoreDNS/registry credentials, restores Rancher ingress, repairs PSA namespace labels, applies GitJob RBAC, enforces the WatchListClient compatibility setting, waits for Rancher/Fleet components, and forces GitRepo rescan. It intentionally avoids deleting healthy Rancher/Fleet resources.

## 4. GitOps deployment flow

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

Operational principle: correct the **source of truth** or the external dependency causing reconciliation failure. Direct changes to Fleet-owned resources are break-glass actions and may be reverted automatically.

## 5. Chrony operations

Chrony owns the host clock while deployed. It runs as a privileged DaemonSet and records the prior `systemd-timesyncd` state under `/var/lib/k8mm/chrony`.

Validate all clusters:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target one cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

View compact telemetry:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=50
```

A healthy node reports a selected source, positive stratum, and `Leap status: Normal`. The installer emits detailed `tracking`, `sources`, `ntpdata`, log, and event information when synchronization fails.

Supported removal:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

Do not delete the DaemonSet manually as the standard removal method; the supported command restores the saved host time-service state.

## 6. Longhorn operations

### Host contract

Default worker contract:

- path: `/mnt/k8sdata`;
- filesystem: XFS;
- minimum capacity: `240 GiB`;
- iSCSI available and active;
- shared root mount propagation;
- multipath disabled where it can claim Longhorn devices.

Validate:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

### Kubernetes checks

```bash
kubectl --context j64seg1opdev -n longhorn-system get pods -o wide
kubectl --context j64seg1opdev get storageclass
kubectl --context j64seg1opdev get pvc -A
```

The stateful identity workloads use `longhorn-xfs-retain`.

### Longhorn UI

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://longhorn-man.dev.kube` |
| `j64seg1opdev` | `https://longhorn-j64.dev.kube` |
| `j52seg1opdev` | `https://longhorn-j52.dev.kube` |
| `r01seg1opdev` | `https://longhorn-r01.dev.kube` |

Fleet creates the HTTPProxy/certificate. The proxy allows only source addresses in `1.0.0.0/23` and sends traffic to `longhorn-frontend:80`.

Use Longhorn snapshots/replicas for in-cluster operational recovery, but maintain a separately approved disaster-recovery/backup strategy if off-cluster recovery is required.

## 7. Istio and Kiali operations

Validate mesh components and namespace injection:

```bash
./scripts/istio/04-check-istio-system.sh --all
./scripts/istio/05-audit-namespace-injection.sh --all
```

Kiali URLs:

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://kiali-man.dev.kube` |
| `j64seg1opdev` | `https://kiali-j64.dev.kube` |
| `j52seg1opdev` | `https://kiali-j52.dev.kube` |
| `r01seg1opdev` | `https://kiali-r01.dev.kube` |

Kiali depends on the external Prometheus and Grafana endpoints configured in its values. A healthy Kiali pod can therefore still show degraded metrics if those external services or the Grafana credential Secret are unavailable.

Istio webhook CA fields are controller-managed runtime data. Fleet comparison rules intentionally ignore only the expected `caBundle` mutation rather than suppressing entire webhook objects.

## 8. Identity operations

The normal role is J64 writable/active and J52 streaming/standby. Both databases remain members of one CloudNativePG distributed topology, so a planned move can be reversed without rebuilding the former primary. Only one database site is writable and only that site's Keycloak has three instances and a published HTTPProxy.

### Replication gate

Run the automated check before and after maintenance and before every planned role transition:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

The first command derives the active and standby sites from Fleet labels, then requires all of the following:

| Check | Healthy result |
| --- | --- |
| source/target role | source `pg_is_in_recovery()=f`; target `t` |
| receiver status | `streaming` |
| sender identity | configured source replication DNS name or VIP |
| receiver message age | no more than `IDENTITY_MAX_REPLICATION_MESSAGE_AGE_SECONDS` |
| source-to-replay lag | no more than `IDENTITY_MAX_REPLICATION_LAG_BYTES` |
| receive-to-replay queue | no more than the same byte threshold |

Defaults are 30 seconds and 16 MiB. The check polls for up to five minutes so a transient backlog can drain. `enable-identity-secondary`, `validate-identity-ha`, planned failover, and planned failback all invoke this gate automatically.

For manual evidence, inspect the standby receiver:

```bash
STANDBY=j52seg1opdev # use j64seg1opdev after failover
STANDBY_POD="$(kubectl --context "$STANDBY" -n oppostgres get pods \
  -l 'cnpg.io/cluster=oppostgres-opkeycloak-db,role=primary' \
  -o jsonpath='{.items[0].metadata.name}')"
kubectl --context "$STANDBY" -n oppostgres exec "$STANDBY_POD" -- \
  psql -U postgres -d postgres -P pager=off -x -c '
SELECT pg_is_in_recovery(), pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn();
SELECT status, sender_host, sender_port, slot_name,
       clock_timestamp() - last_msg_receipt_time AS message_age
FROM pg_stat_wal_receiver;'
```

### Planned J64 to J52 test

Ensure the replication gate passes, schedule the outage, and set the explicit confirmation:

```bash
./scripts/deploy-platform.sh verify-database-replication
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
./scripts/deploy-platform.sh failover-identity
unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
```

The workflow pauses Fleet, scales source Keycloak to zero, invokes the optional `fence-source` hook, prevents new application-database connections, catches J52 up to the final J64 WAL position, obtains the J64 demotion token, promotes J52 with that token, changes the durable Fleet role labels, starts J52 Keycloak, invokes the `activate-target` hook, unpauses Fleet, and verifies the reversed J52→J64 stream. If no activation hook is configured, update the canonical DNS record to the J52 ingress VIP when instructed.

Confirm application behavior and roles:

```bash
./scripts/deploy-platform.sh validate-identity-ha
kubectl --context j52seg1opdev -n opkeycloak get keycloak,pods,httpproxy
```

### Planned J52 to J64 return

Do not return traffic until the reverse replication gate passes:

```bash
./scripts/deploy-platform.sh verify-database-replication
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
./scripts/deploy-platform.sh failback-identity
unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
./scripts/deploy-platform.sh validate-identity-ha
```

This is the same token-protected switchover in the opposite direction. No `replica.enabled=false` patch is used.

### Unplanned failover

An unplanned promotion can lose acknowledged transactions because cross-site replication is asynchronous. It requires both `IDENTITY_ALLOW_UNPLANNED_FAILOVER=true` and an executable `IDENTITY_SWITCHOVER_HOOK` that conclusively fences the unreachable source during `IDENTITY_SWITCHOVER_PHASE=fence-source`. The old source remains hibernated; rebuild or rejoin it as a replica and prove the new-primary-to-old-site stream before attempting failback.

If a transition aborts after Fleet is paused, do not unpause blindly. Read the error, verify which database is writable, check the durable Fleet labels and external fencing, then resume from the documented state. Never promote either site with ad-hoc `replica.enabled`, DNS, or label patches.

## 9. Elastic observability operations

The default model uses one Elastic Agent DaemonSet and one kube-state-metrics Deployment per cluster, with one Fleet enrollment policy/token per cluster.

Validate:

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If enrollment fails, confirm Fleet Server URL, CA/SAN correctness, token-to-policy mapping, network reachability, and the `elastic-agent` Secret seeded on the affected cluster.

## 10. GitLab Runner operations

The Runner is Fleet-owned in `gitlab-runner-system` on `j64seg1opman`.

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get pods
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

Rotate the runner authentication token or GitLab CA by updating the protected input file and rerunning `./scripts/deploy-platform.sh seed-secrets`. Do not commit the `glrt-*` token. GitLab controls the runner tag, protected status, locking, and project/group scope; the cluster bundle controls runtime version, executor policy, and Harbor-only image allowlists.

## 11. Certificate operations

cert-manager uses the Segment1 ClusterIssuer seeded through the protected CA material. Check certificate status:

```bash
kubectl --context j64seg1opman get certificates -A
kubectl --context j64seg1opman get clusterissuer
```

Repeat for the affected cluster. Do not disable TLS verification to work around CA-chain failures; fix trust or certificate identity.

## 12. Ingress and HTTPProxy operations

List Contour proxies:

```bash
kubectl --context j64seg1opdev get httpproxy -A
```

Inspect a proxy:

```bash
kubectl --context j64seg1opdev -n <namespace> describe httpproxy <name>
```

An `invalid` HTTPProxy usually indicates a missing backend Service/port, missing TLS Secret, invalid route definition, or ingress-class/dependency problem. Resolve the underlying reference rather than deleting the proxy.

## 13. CIS/PodSecurity lifecycle

Rancher/Fleet and several platform components require scoped privileged PSA namespaces. Keep exceptions limited to system namespaces and prepare Rancher/Fleet namespaces before cluster import. Application namespaces should remain restricted unless a reviewed workload requirement says otherwise.

## 14. Upgrade lifecycle

For every component upgrade:

1. confirm RKE2/Rancher/Fleet compatibility;
2. obtain/promote images through the approved air-gap workflow;
3. stage the exact Helm chart archive;
4. update the package allowlist, OCI inventory, and checksums;
5. review chart defaults for newly introduced transitive images;
6. update values and compatibility controls;
7. run `validate-package`;
8. publish immutable OCI charts;
9. deploy through Git/Fleet;
10. validate all service-specific gates.

The shared Helm wrapper requires Helm 4 and uses `--rollback-on-failure`; the deprecated `--atomic` CLI alias is not part of the supported wrapper path.

## 15. Backup and recovery boundaries

- GitLab: back up repository data and branch history according to GitLab operations policy.
- KubeHarbor: preserve registry projects/artifacts and CA configuration.
- Rancher/Fleet: preserve Rancher state according to the management-cluster recovery plan.
- RKE2: maintain the approved etcd snapshot/recovery process outside this repository.
- Longhorn: snapshots/replicas are in-cluster; define off-cluster backup separately where required.
- Identity: preserve PostgreSQL recovery capability and understand asynchronous replication RPO.
- protected configuration: securely back up credential files, CA material, and Istio CA directories outside Git.

## 16. Change-management evidence

For significant changes retain:

- Git commit and branch deployed;
- `validate-package` output;
- Fleet GitRepo commit and bundle state;
- relevant Rancher/Fleet/Longhorn/identity validation output;
- diagnostic bundle for failed changes;
- security/exception review when privileged namespace or certificate behavior changes.
