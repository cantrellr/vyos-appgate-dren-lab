# GitLab GitOps Protected-Branch Policy

> **Baseline:** v2.2 — August 28, 2026  
> **Audience:** program leadership, upper-level management, customer leadership, security stakeholders, and technical decision-makers.

## Purpose

Protect the Fleet-watched `multicluster-longhorn` branch so every deployment-affecting change follows this path:

`feature/fix branch -> merge request -> validation pipeline -> review/approval -> merge -> Fleet polling/reconciliation`

CI is a validation gate only. Rancher Fleet remains the sole GitOps deployment/reconciliation controller.

## Required branch rule

Configure an exact branch rule for:

- Branch: `multicluster-longhorn`
- Allowed to merge: `Maintainers`
- Allowed to push and merge: `No one`
- Force push: disabled
- Code Owner approval: enabled if your GitLab tier supports it and a CODEOWNERS policy is in place

Do not leave **Allowed to push and merge** blank. Explicitly select **No one** so direct pushes cannot bypass merge requests.

Before saving the rule, check for wildcard/group branch rules such as `*`, `multi*`, or similar. GitLab combines matching protection rules, and a more permissive matching rule can weaken the exact rule.

## Required merge checks

In **Settings -> Merge requests -> Merge checks**:

- Enable **Pipelines must succeed**.
- Enable **All discussions must be resolved**.
- Keep **Skipped pipelines are considered successful** disabled. The supplied `.gitlab-ci.yml` deliberately creates a merge-request pipeline for every MR targeting `multicluster-longhorn`.

Recommended merge method:

- **Merge commit with semi-linear history**.

This keeps an auditable merge-request boundary while requiring the source branch to be current with the target before merge.

## Approval policy

If the GitLab tier supports required approvals, use:

- Rule name: `GitOps Production Change`
- Target branch: `multicluster-longhorn` (or All protected branches if this is the only production GitOps branch)
- Required approvals: `1` minimum
- Approvers: platform/Kubernetes Maintainers or a dedicated platform-reviewers group
- Prevent approval by the merge-request author: enabled
- Reset approvals when new commits are pushed: enabled
- Prevent editing approval rules inside merge requests: enabled

If only one Maintainer currently exists, do not create a governance deadlock. Start with pipeline + protected-branch enforcement and add independent approval when a second qualified reviewer is available.

## Runner security policy

Use the Fleet-managed GitLab Runner on `j64seg1opman`, tagged in GitLab as:

`gitops-validation`

The bundle uses the non-privileged Kubernetes executor. The manager and helper are Iron Bank v19.3.1 images promoted from Registry1 with their complete repository hierarchy retained in KubeHarbor. Validation jobs use the pinned Iron Bank Ansible image. Runner authentication uses a protected `glrt-*` token seeded outside Git.

The validation job image provides:

- `bash`
- `find`
- `grep`
- `tar`
- `sha256sum`
- one executable Python interpreter with the `PyYAML` API; the pipeline discovers the Iron Bank Ansible virtual-environment interpreter and exposes it as `python3`

The validation runner must **not** receive:

- Kubernetes kubeconfigs
- cluster-admin credentials
- Rancher API credentials
- Harbor push credentials
- `KEYCLOAK_KEYTAB_FILE_*` contents
- Keycloak provider JARs from protected runtime storage
- `CA_KEY_FILE`
- Fleet runtime Secret files

The pipeline should never call deployment commands such as `kubectl apply`, `helm upgrade`, `deploy-platform.sh fleet`, or `deploy-platform.sh seed-secrets`.

## GitLab GUI configuration

### 1. Add `.gitlab-ci.yml`

Copy the supplied `.gitlab-ci.yml` to the repository root on a feature branch and create a merge request targeting `multicluster-longhorn`.

Before enabling **Pipelines must succeed**, make sure the `gitops-validation` runner is online; otherwise merge requests will correctly remain blocked waiting for a pipeline.

### 2. Configure the runner

1. Open the project in GitLab.
2. Go to **Settings -> CI/CD**.
3. Expand **Runners**.
4. Create or assign a project/group runner.
5. Configure the runner with the `gitops-validation` tag.
6. Select the `gitops-validation` tag, disable untagged jobs, mark the runner protected, and lock it to the intended project/group scope.
7. Save the `glrt-*` authentication token to the protected file configured by `GITLAB_RUNNER_TOKEN_FILE`.
8. Promote the pinned runner, helper, and Ansible validation images to KubeHarbor.
9. Run `./scripts/deploy-platform.sh seed-secrets`, bootstrap/reconcile Fleet, and then run `./scripts/deploy-platform.sh validate`.
10. Do not grant this runner kubeconfigs, deployment credentials, or protected platform runtime Secrets.

### 3. Protect the GitOps branch

1. Go to **Settings -> Repository**.
2. Expand **Branch rules**.
3. Add a branch rule, or open the existing rule, for `multicluster-longhorn`.
4. Set **Allowed to merge** to **Maintainers**.
5. Set **Allowed to push and merge** to **No one**.
6. Ensure force push is disabled.
7. If available and configured, enable **Require approval from code owners**.
8. Save the rule.
9. Review other exact/wildcard/group branch rules and ensure none grants broader push/merge access to `multicluster-longhorn`.

### 4. Require successful validation

1. Go to **Settings -> Merge requests**.
2. Find **Merge checks**.
3. Enable **Pipelines must succeed**.
4. Enable **All discussions must be resolved**.
5. Leave **Skipped pipelines are considered successful** disabled.
6. Save changes.

### 5. Configure approvals, if available

1. Remain in **Settings -> Merge requests**.
2. Open **Merge request approvals / Approval rules**.
3. Add `GitOps Production Change`.
4. Target `multicluster-longhorn`.
5. Require at least one independent approval.
6. Select the platform/Kubernetes Maintainer group or named reviewers.
7. Enable the settings that prevent author self-approval, reset approvals after new commits, and prevent MR authors from weakening approval rules where your GitLab edition exposes them.
8. Save changes.

### 6. Test the policy

Create a test feature branch that changes a harmless documentation line and open an MR targeting `multicluster-longhorn`.

Expected behavior:

1. A merge-request pipeline starts automatically.
2. `validate:gitops-package` runs `./scripts/deploy-platform.sh validate-package`.
3. Merge is blocked while the pipeline is running or failed.
4. After validation and required review/approval, the MR can be merged.
5. A second branch pipeline validates the resulting commit on `multicluster-longhorn`.
6. Fleet detects the new branch HEAD through its normal polling loop and performs deployment reconciliation.

## Operational ownership

| Capability | Owner |
|---|---|
| Repository validation | GitLab CI |
| Merge governance | GitLab protected branch / MR rules |
| GitOps source of truth | `multicluster-longhorn` |
| Deployment/reconciliation | Rancher Fleet |
| Runtime Secret/artifact seeding | Administrative controller / `seed-secrets` |
| Workload reconciliation | Kubernetes Operators/controllers |

Do not add a GitLab deployment job that performs direct Helm or kubectl deployment against Fleet-owned resources.
