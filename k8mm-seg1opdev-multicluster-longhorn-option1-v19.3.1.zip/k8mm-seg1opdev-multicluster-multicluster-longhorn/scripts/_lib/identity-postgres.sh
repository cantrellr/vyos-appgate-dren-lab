#!/usr/bin/env bash
# shellcheck shell=bash

IDENTITY_POSTGRES_NAMESPACE=oppostgres
IDENTITY_POSTGRES_CLUSTER=oppostgres-opkeycloak-db
IDENTITY_CNPG_RESOURCE=clusters.postgresql.cnpg.io

identity_peer_site() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' j52seg1opdev ;;
    j52seg1opdev) printf '%s\n' j64seg1opdev ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_context() {
  case "${1:?identity site is required}" in
    j64seg1opdev|j52seg1opdev) printf '%s\n' "$1" ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_display_name() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' "${FLEET_J64_APP_DISPLAY_NAME}" ;;
    j52seg1opdev) printf '%s\n' "${FLEET_J52_APP_DISPLAY_NAME}" ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_replication_host() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' "${IDENTITY_PRIMARY_REPLICATION_HOST}" ;;
    j52seg1opdev) printf '%s\n' "${IDENTITY_SECONDARY_REPLICATION_HOST}" ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_replication_ip() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' "${IDENTITY_PRIMARY_REPLICATION_IP}" ;;
    j52seg1opdev) printf '%s\n' "${IDENTITY_SECONDARY_REPLICATION_IP}" ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_ingress_ip() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' "${IDENTITY_PRIMARY_INGRESS_IP:-1.0.0.215}" ;;
    j52seg1opdev) printf '%s\n' "${IDENTITY_SECONDARY_INGRESS_IP:-1.0.0.225}" ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_secret_site_code() {
  case "${1:?identity site is required}" in
    j64seg1opdev) printf '%s\n' j64 ;;
    j52seg1opdev) printf '%s\n' j52 ;;
    *) die "Unsupported identity site: $1" ;;
  esac
}

identity_primary_pod() {
  local site="${1:?identity site is required}" context pod
  context="$(identity_context "${site}")"
  pod="$(kubectl --context "${context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get pods \
    -l "cnpg.io/cluster=${IDENTITY_POSTGRES_CLUSTER},role=primary" \
    -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)"
  [[ -n "${pod}" ]] || return 1
  printf '%s\n' "${pod}"
}

identity_sql() {
  local site="${1:?identity site is required}" sql="${2:?SQL is required}" context pod
  context="$(identity_context "${site}")"
  pod="$(identity_primary_pod "${site}")" || return 1
  kubectl --context "${context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" exec "${pod}" -- \
    psql -U postgres -d postgres -v ON_ERROR_STOP=1 -Atqc "${sql}"
}

identity_wait_cluster_ready() {
  local site="${1:?identity site is required}" timeout="${2:-15m}"
  kubectl --context "$(identity_context "${site}")" -n "${IDENTITY_POSTGRES_NAMESPACE}" wait \
    --for=condition=Ready "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" \
    --timeout="${timeout}"
}

identity_sync_replication_tls() (
  set -Eeuo pipefail
  local source_site="${1:?source site is required}" target_site="${2:?target site is required}"
  local source_context target_context alias tmp_dir
  source_context="$(identity_context "${source_site}")"
  target_context="$(identity_context "${target_site}")"
  alias="$(identity_secret_site_code "${source_site}")"
  tmp_dir="$(mktemp -d)"
  chmod 700 "${tmp_dir}"
  trap 'rm -rf "${tmp_dir}"' EXIT

  kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    secret "${IDENTITY_POSTGRES_CLUSTER}-ca" -o jsonpath='{.data.ca\.crt}' | base64 -d >"${tmp_dir}/ca.crt"
  kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    secret "${IDENTITY_POSTGRES_CLUSTER}-replication" -o jsonpath='{.data.tls\.crt}' | base64 -d >"${tmp_dir}/tls.crt"
  kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    secret "${IDENTITY_POSTGRES_CLUSTER}-replication" -o jsonpath='{.data.tls\.key}' | base64 -d >"${tmp_dir}/tls.key"
  chmod 600 "${tmp_dir}"/*

  kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" create secret generic \
    "oppostgres-${alias}-ca" --from-file=ca.crt="${tmp_dir}/ca.crt" --dry-run=client -o yaml | \
    kubectl --context "${target_context}" apply -f - >/dev/null
  kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" create secret tls \
    "oppostgres-${alias}-replication" --cert="${tmp_dir}/tls.crt" --key="${tmp_dir}/tls.key" \
    --dry-run=client -o yaml | kubectl --context "${target_context}" apply -f - >/dev/null

  log "Synchronized ${source_site} replication trust material to ${target_site}."
)
