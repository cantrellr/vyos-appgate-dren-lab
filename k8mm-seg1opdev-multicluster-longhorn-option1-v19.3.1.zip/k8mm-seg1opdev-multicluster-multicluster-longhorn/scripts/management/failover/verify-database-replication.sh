#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq

source_site="${1:-}"
target_site="${2:-}"

if [[ -z "${source_site}" && -z "${target_site}" ]]; then
  j64_json="$(fleet_cluster_json fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
  j52_json="$(fleet_cluster_json fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
  j64_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j64_json}")"
  j52_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j52_json}")"
  [[ -n "${j64_primary}" && "${j64_primary}" == "${j52_primary}" ]] || \
    die "Fleet identity sites do not agree on kmm.dev/postgres-primary-site."
  source_site="${j64_primary}"
  target_site="$(identity_peer_site "${source_site}")"
elif [[ -z "${source_site}" || -z "${target_site}" ]]; then
  die "Specify both source and target sites, or neither for Fleet-label discovery."
fi

[[ "$(identity_peer_site "${source_site}")" == "${target_site}" ]] || \
  die "Source ${source_site} and target ${target_site} are not the supported identity-site pair."

max_lag_bytes="${IDENTITY_MAX_REPLICATION_LAG_BYTES:-16777216}"
max_message_age="${IDENTITY_MAX_REPLICATION_MESSAGE_AGE_SECONDS:-30}"
wait_seconds="${IDENTITY_REPLICATION_VERIFY_TIMEOUT_SECONDS:-300}"
poll_seconds="${IDENTITY_REPLICATION_VERIFY_POLL_SECONDS:-5}"
for value_name in max_lag_bytes max_message_age wait_seconds poll_seconds; do
  value="${!value_name}"
  [[ "${value}" =~ ^[0-9]+$ ]] || die "${value_name} must be a non-negative integer; found ${value}."
done

expected_host="$(identity_replication_host "${source_site}")"
expected_ip="$(identity_replication_ip "${source_site}")"
deadline=$((SECONDS + wait_seconds))
last_reason="initializing"

while (( SECONDS < deadline )); do
  source_recovery="$(identity_sql "${source_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"
  target_recovery="$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"
  if [[ "${source_recovery}" != "f" || "${target_recovery}" != "t" ]]; then
    last_reason="role state source=${source_recovery:-unavailable} target=${target_recovery:-unavailable}"
    sleep "${poll_seconds}"
    continue
  fi

  receiver="$(identity_sql "${target_site}" \
    "select concat_ws('|', status, sender_host, sender_port::text, coalesce(extract(epoch from (clock_timestamp()-last_msg_receipt_time))::bigint,999999)::text) from pg_stat_wal_receiver" \
    2>/dev/null || true)"
  IFS='|' read -r receiver_status sender_host sender_port message_age <<<"${receiver}"
  if [[ "${receiver_status}" != "streaming" ]]; then
    last_reason="target WAL receiver status=${receiver_status:-missing}"
    sleep "${poll_seconds}"
    continue
  fi
  if [[ "${sender_host}" != "${expected_host}" && "${sender_host}" != "${expected_ip}" ]]; then
    last_reason="target WAL receiver sender=${sender_host:-missing}, expected ${expected_host} or ${expected_ip}"
    sleep "${poll_seconds}"
    continue
  fi
  if [[ ! "${message_age}" =~ ^[0-9]+$ ]] || (( message_age > max_message_age )); then
    last_reason="WAL receiver message age=${message_age:-invalid}s, maximum ${max_message_age}s"
    sleep "${poll_seconds}"
    continue
  fi

  source_lsn="$(identity_sql "${source_site}" 'select pg_current_wal_lsn()' 2>/dev/null || true)"
  target_receive_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_receive_lsn()' 2>/dev/null || true)"
  target_replay_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_replay_lsn()' 2>/dev/null || true)"
  if [[ ! "${source_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ || \
        ! "${target_receive_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ || \
        ! "${target_replay_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ ]]; then
    last_reason="one or more WAL LSN values are unavailable"
    sleep "${poll_seconds}"
    continue
  fi

  source_lag_bytes="$(identity_sql "${source_site}" \
    "select greatest(pg_wal_lsn_diff('${source_lsn}'::pg_lsn,'${target_replay_lsn}'::pg_lsn),0)::bigint" 2>/dev/null || true)"
  replay_queue_bytes="$(identity_sql "${target_site}" \
    "select greatest(pg_wal_lsn_diff('${target_receive_lsn}'::pg_lsn,'${target_replay_lsn}'::pg_lsn),0)::bigint" 2>/dev/null || true)"
  if [[ ! "${source_lag_bytes}" =~ ^[0-9]+$ || ! "${replay_queue_bytes}" =~ ^[0-9]+$ ]]; then
    last_reason="unable to calculate replication lag"
    sleep "${poll_seconds}"
    continue
  fi
  if (( source_lag_bytes > max_lag_bytes || replay_queue_bytes > max_lag_bytes )); then
    last_reason="lag source-to-replay=${source_lag_bytes}B local-replay-queue=${replay_queue_bytes}B, maximum ${max_lag_bytes}B"
    sleep "${poll_seconds}"
    continue
  fi

  log "Database replication verified: ${source_site} -> ${target_site}, status=streaming, sender=${sender_host}:${sender_port}, source-to-replay=${source_lag_bytes}B, local-replay-queue=${replay_queue_bytes}B, message-age=${message_age}s."
  exit 0
done

die "Database replication verification timed out for ${source_site} -> ${target_site}: ${last_reason}."
