#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq

target_site="${1:-}"
[[ "${target_site}" == "j64seg1opdev" || "${target_site}" == "j52seg1opdev" ]] || \
  die "Usage: $0 <j64seg1opdev|j52seg1opdev>"
source_site="$(identity_peer_site "${target_site}")"
target_context="$(identity_context "${target_site}")"
source_context="$(identity_context "${source_site}")"
management_context="${RANCHER_CONTEXT:-j64seg1opman}"
gitrepo_name=k8mm-seg1opdev-multicluster-downstream

[[ "${IDENTITY_SWITCHOVER_CONFIRM:-}" == "${target_site}" ]] || \
  die "Set IDENTITY_SWITCHOVER_CONFIRM=${target_site} to acknowledge this identity role transition."

pause_fleet() {
  kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p '{"spec":{"paused":true}}' >/dev/null
}

unpause_fleet() {
  kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p '{"spec":{"paused":false}}' >/dev/null
}

wait_for_no_pods() {
  local context="$1" namespace="$2" selector="$3" deadline=$((SECONDS + 600)) count
  while :; do
    count="$(kubectl --context "${context}" -n "${namespace}" get pods -l "${selector}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${count}" == "0" ]] && return 0
    (( SECONDS < deadline )) || die "Timed out waiting for ${context}/${namespace} pods to stop (${selector})."
    sleep 5
  done
}

run_switchover_hook() {
  local phase="$1" legacy_phase
  case "${phase}" in
    fence-source) legacy_phase=fence-primary ;;
    activate-target) legacy_phase=activate-secondary ;;
    *) die "Unsupported switchover hook phase: ${phase}" ;;
  esac
  if [[ -z "${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}" ]]; then
    [[ "${mode}" != "unplanned" || "${phase}" != "fence-source" ]] || \
      die "Unplanned failover requires IDENTITY_SWITCHOVER_HOOK to fence the old site before promotion."
    return 0
  fi
  hook="${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK}}"
  [[ -x "${hook}" ]] || die "Identity switchover hook is not executable: ${hook}"
  IDENTITY_SWITCHOVER_PHASE="${phase}" \
  IDENTITY_FAILOVER_PHASE="${legacy_phase}" \
  IDENTITY_SWITCHOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_FAILOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_SWITCHOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_FAILOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_SWITCHOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_FAILOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_SWITCHOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_FAILOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_SWITCHOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST:-opkeycloak.dev.jde.cybercom.ic.gov}" \
  IDENTITY_FAILOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST:-opkeycloak.dev.jde.cybercom.ic.gov}" \
    "${hook}"
}

source_available=false
if kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
  source_available=true
fi

mode="${IDENTITY_SWITCHOVER_MODE:-${IDENTITY_FAILOVER_MODE:-auto}}"
if [[ "${mode}" == "auto" ]]; then
  [[ "${source_available}" == "true" ]] && mode=planned || mode=unplanned
fi
[[ "${mode}" == "planned" || "${mode}" == "unplanned" ]] || \
  die "IDENTITY_SWITCHOVER_MODE must be auto, planned, or unplanned."
[[ "${mode}" != "planned" || "${source_available}" == "true" ]] || \
  die "Planned switchover requires the current primary site to be reachable."
if [[ "${mode}" == "unplanned" && "${IDENTITY_ALLOW_UNPLANNED_FAILOVER:-false}" != "true" ]]; then
  die "Unplanned failover can lose transactions. Set IDENTITY_ALLOW_UNPLANNED_FAILOVER=true to proceed."
fi

source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${management_context}")"
target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${management_context}")"
for resource in "${source_resource}" "${target_resource}"; do
  topology="$(kubectl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/postgres-distributed-topology}')"
  [[ "${topology}" == "true" ]] || die "Fleet cluster ${resource} is not enrolled in the distributed PostgreSQL topology."
done

target_primary="$(kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}')"
if [[ "${target_primary}" == "${target_site}" && "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == "f" ]]; then
  die "${target_site} is already the writable identity database site."
fi
[[ "${target_primary}" == "${source_site}" ]] || \
  die "Target database reports distributed primary ${target_primary:-unset}; expected ${source_site}."

if [[ "${mode}" == "planned" ]]; then
  "${SCRIPT_DIR}/verify-database-replication.sh" "${source_site}" "${target_site}"
  identity_sync_replication_tls "${target_site}" "${source_site}"
fi

paused=false
completed=false
cleanup() {
  if [[ "${completed}" != "true" && "${paused}" == "true" ]]; then
    warn "Switchover did not complete. Fleet remains paused at fleet-default/${gitrepo_name}; resolve the failure before unpausing."
  fi
}
trap cleanup EXIT

pause_fleet
paused=true
log "Fleet downstream reconciliation paused for the ${source_site} -> ${target_site} identity transition."

if [[ "${source_available}" == "true" ]]; then
  kubectl --context "${source_context}" -n opkeycloak patch keycloak opkeycloak \
    --type merge -p '{"spec":{"instances":0}}' >/dev/null || true
  wait_for_no_pods "${source_context}" opkeycloak 'app.kubernetes.io/instance=opkeycloak'
fi

run_switchover_hook fence-source

promotion_patch=''
if [[ "${mode}" == "planned" ]]; then
  identity_sql "${source_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS false'
  identity_sql "${source_site}" \
    "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='opkeycloak' AND pid <> pg_backend_pid()"
  identity_sql "${source_site}" 'CHECKPOINT'
  target_lsn="$(identity_sql "${source_site}" 'select pg_current_wal_lsn()')"
  deadline=$((SECONDS + 900))
  until [[ "$(identity_sql "${target_site}" "select pg_wal_lsn_diff(pg_last_wal_replay_lsn(), '${target_lsn}'::pg_lsn) >= 0" 2>/dev/null || true)" == "t" ]]; do
    (( SECONDS < deadline )) || die "Target did not replay through ${target_lsn} before timeout."
    sleep 5
  done
  log "Target replay reached the fenced source WAL position ${target_lsn}."

  kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge \
    -p "{\"spec\":{\"replica\":{\"self\":\"${source_site}\",\"primary\":\"${target_site}\",\"source\":\"${target_site}\"}}}" >/dev/null
  deadline=$((SECONDS + 900))
  demotion_token=''
  until [[ -n "${demotion_token}" ]]; do
    demotion_token="$(kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
      "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.demotionToken}' 2>/dev/null || true)"
    (( SECONDS < deadline )) || die "Timed out waiting for the source demotion token."
    [[ -n "${demotion_token}" ]] || sleep 5
  done
  promotion_patch="{\"spec\":{\"replica\":{\"self\":\"${target_site}\",\"primary\":\"${target_site}\",\"source\":\"${source_site}\",\"promotionToken\":\"${demotion_token}\"}}}"
else
  promotion_patch="{\"spec\":{\"replica\":{\"self\":\"${target_site}\",\"primary\":\"${target_site}\",\"source\":\"${source_site}\"}}}"
fi

kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
  "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge -p "${promotion_patch}" >/dev/null

deadline=$((SECONDS + 900))
until [[ "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == "f" ]]; do
  (( SECONDS < deadline )) || die "Timed out waiting for ${target_site} PostgreSQL promotion."
  sleep 5
done
identity_sql "${target_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true'

source_hibernation=off
if [[ "${mode}" == "unplanned" ]]; then
  source_hibernation=on
fi
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${source_resource}" --overwrite \
  kmm.dev/identity-active=false \
  kmm.dev/keycloak-instances=0 \
  kmm.dev/postgres-hibernation="${source_hibernation}" \
  kmm.dev/postgres-primary-site="${target_site}" \
  kmm.dev/postgres-distributed-topology=true >/dev/null
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${target_resource}" --overwrite \
  kmm.dev/identity-active=true \
  kmm.dev/keycloak-instances=3 \
  kmm.dev/postgres-hibernation=off \
  kmm.dev/postgres-primary-site="${target_site}" \
  kmm.dev/postgres-distributed-topology=true >/dev/null

kubectl --context "${target_context}" -n opkeycloak patch keycloak opkeycloak \
  --type merge -p '{"spec":{"instances":3}}' >/dev/null
kubectl --context "${target_context}" -n opkeycloak wait --for=condition=Ready keycloak/opkeycloak --timeout=15m

run_switchover_hook activate-target
if [[ -z "${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}" ]]; then
  log "Direct ${IDENTITY_CANONICAL_HOST:-opkeycloak.dev.jde.cybercom.ic.gov} to $(identity_ingress_ip "${target_site}")."
fi

unpause_fleet
paused=false

if [[ "${mode}" == "planned" ]]; then
  identity_wait_cluster_ready "${source_site}" 15m
  "${SCRIPT_DIR}/verify-database-replication.sh" "${target_site}" "${source_site}"
else
  warn "The unreachable source remains hibernated. Rebuild it as a replica before attempting a return transition."
fi

completed=true
log "Identity transition completed: ${target_site} is writable and active; ${source_site} is the warm replica."
