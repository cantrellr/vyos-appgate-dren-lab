#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"

require_cmd kubectl
require_cmd jq
require_cmd openssl
require_cmd stat
validate_context_access "${RANCHER_CONTEXT:-j64seg1opman}"
for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do validate_context_access "${context}"; done

log "Validating Rancher/Fleet Pod Security Admission namespace profiles on all clusters..."
"${INSTALL_DIR}/management/rancher/00-prepare-rancher-psa.sh" --check --all

log "Validating Rancher imported-cluster connectivity..."
"${INSTALL_DIR}/management/rancher/05-validate-imported-clusters.sh" --wait

log "Validating the Fleet Kubernetes 1.35 WatchListClient compatibility configuration..."
"${INSTALL_DIR}/management/rancher/04-configure-fleet-watchlist.sh" --all --check

for fleet_cluster in \
  "fleet-local:${FLEET_LOCAL_CLUSTER_DISPLAY_NAME}" \
  "fleet-default:${FLEET_J64_APP_DISPLAY_NAME}" \
  "fleet-default:${FLEET_J52_APP_DISPLAY_NAME}" \
  "fleet-default:${FLEET_R01_APP_DISPLAY_NAME}"; do
  fleet_namespace="${fleet_cluster%%:*}"
  fleet_display_name="${fleet_cluster#*:}"
  fleet_cluster_resource \
    "${fleet_namespace}" "${fleet_display_name}" "${RANCHER_CONTEXT:-j64seg1opman}" >/dev/null
done
unset fleet_cluster fleet_namespace fleet_display_name

for variable in \
  FLEET_GIT_USERNAME_FILE FLEET_GIT_PASSWORD_FILE \
  FLEET_HELM_USERNAME_FILE FLEET_HELM_PASSWORD_FILE \
  REGISTRY_USERNAME_FILE REGISTRY_PASSWORD_FILE \
  KIALI_GRAFANA_TOKEN_FILE POSTGRES_APP_USERNAME_FILE POSTGRES_APP_PASSWORD_FILE \
  KEYCLOAK_BOOTSTRAP_USERNAME_FILE KEYCLOAK_BOOTSTRAP_PASSWORD_FILE \
  ELASTIC_FLEET_TOKEN_J64SEG1OPMAN_FILE ELASTIC_FLEET_TOKEN_J64SEG1OPDEV_FILE \
  ELASTIC_FLEET_TOKEN_J52SEG1OPDEV_FILE ELASTIC_FLEET_TOKEN_R01SEG1OPDEV_FILE; do
  read_required_secret_file "${variable}" >/dev/null
done

for variable in FLEET_HELM_CA_FILE RANCHER_CA_FILE CA_CERT_FILE CA_KEY_FILE ELASTIC_FLEET_CA_FILE \
  KEYCLOAK_KEYTAB_FILE_001 KEYCLOAK_PROVIDER_FILE_001; do
  require_runtime_file "${variable}"
done

log "Validating in-cluster DNS, TLS trust, and authentication for the Fleet OCI registry..."
"${INSTALL_DIR}/management/fleet/02-validate-fleet-oci.sh"

for variable in FLEET_REPO_URL FLEET_REPO_BRANCH ELASTIC_FLEET_URL LONGHORN_DATA_PATH LONGHORN_DATA_FILESYSTEM LONGHORN_MIN_DISK_GIB IDENTITY_CANONICAL_HOST \
  IDENTITY_PRIMARY_REPLICATION_HOST IDENTITY_PRIMARY_REPLICATION_IP \
  IDENTITY_SECONDARY_REPLICATION_HOST IDENTITY_SECONDARY_REPLICATION_IP; do
  [[ -n "${!variable:-}" ]] || die "Set ${variable}."
done

if [[ -n "${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}" ]]; then
  identity_hook="${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK}}"
  [[ -x "${identity_hook}" ]] || die "Identity switchover hook is not executable: ${identity_hook}"
fi

for variable in IDENTITY_MAX_REPLICATION_LAG_BYTES IDENTITY_MAX_REPLICATION_MESSAGE_AGE_SECONDS \
  IDENTITY_REPLICATION_VERIFY_TIMEOUT_SECONDS IDENTITY_REPLICATION_VERIFY_POLL_SECONDS; do
  [[ "${!variable:-}" =~ ^[0-9]+$ ]] || die "${variable} must be a non-negative integer."
done

[[ -d "${ISTIO_CACERTS_DIR:-}" ]] || die "ISTIO_CACERTS_DIR is missing: ${ISTIO_CACERTS_DIR:-unset}"
for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do
  for file in ca-cert.pem ca-key.pem root-cert.pem cert-chain.pem; do
    ensure_file "${ISTIO_CACERTS_DIR}/${context}/${file}"
  done
done

log "Fleet, Elastic monitoring, and two-site identity preflight passed. Credential values were not printed."
