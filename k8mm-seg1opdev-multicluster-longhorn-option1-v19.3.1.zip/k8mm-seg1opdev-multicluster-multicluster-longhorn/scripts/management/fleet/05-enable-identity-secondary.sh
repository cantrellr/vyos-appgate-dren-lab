#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd base64

management_context="${RANCHER_CONTEXT:-j64seg1opman}"
primary_site=j64seg1opdev
secondary_site=j52seg1opdev

validate_context_access "${primary_site}"
validate_context_access "${secondary_site}"
identity_wait_cluster_ready "${primary_site}" 15m

primary_lb="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get service oppostgres-replication-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
expected_primary_lb="$(identity_replication_ip "${primary_site}")"
[[ "${primary_lb}" == "${expected_primary_lb}" ]] || \
  die "Primary PostgreSQL replication Service has IP '${primary_lb:-unset}', expected ${expected_primary_lb}."

identity_sync_replication_tls "${primary_site}" "${secondary_site}"

primary_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${primary_site}")" "${management_context}")"
secondary_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${secondary_site}")" "${management_context}")"

# Bootstrap j52 from j64 before enabling the bidirectional topology. This keeps
# the primary chart from referring to j52 TLS Secrets before they exist.
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${primary_resource}" --overwrite \
  kmm.dev/postgres-primary-site="${primary_site}" \
  kmm.dev/postgres-distributed-topology=false >/dev/null
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${secondary_resource}" --overwrite \
  kmm.dev/identity=secondary \
  kmm.dev/identity-active=false \
  kmm.dev/keycloak-instances=0 \
  kmm.dev/postgres-hibernation=off \
  kmm.dev/postgres-primary-site="${primary_site}" \
  kmm.dev/postgres-distributed-topology=false >/dev/null

log "Replication trust copied to ${secondary_site}; waiting for its initial base backup and WAL stream."
deadline=$((SECONDS + 300))
until kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; do
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to create the j52 PostgreSQL replica."
  sleep 5
done
identity_wait_cluster_ready "${secondary_site}" 30m
[[ "$(identity_sql "${secondary_site}" 'select pg_is_in_recovery()')" == "t" ]] || \
  die "Secondary PostgreSQL is not in recovery mode."

# Copy j52's generated certificate back to j64, then enroll both existing
# clusters in CloudNativePG's distributed topology. No database is recreated.
identity_sync_replication_tls "${secondary_site}" "${primary_site}"
for resource in "${primary_resource}" "${secondary_resource}"; do
  kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${resource}" --overwrite \
    kmm.dev/postgres-primary-site="${primary_site}" \
    kmm.dev/postgres-distributed-topology=true >/dev/null
done

deadline=$((SECONDS + 900))
while :; do
  j64_self="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j64_primary="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  j52_self="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j52_primary="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  [[ "${j64_self}" == "${primary_site}" && "${j52_self}" == "${secondary_site}" && \
     "${j64_primary}" == "${primary_site}" && "${j52_primary}" == "${primary_site}" ]] && break
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to enroll both PostgreSQL clusters in the distributed topology."
  sleep 5
done

identity_wait_cluster_ready "${primary_site}" 15m
identity_wait_cluster_ready "${secondary_site}" 15m
"${SCRIPT_DIR}/../failover/verify-database-replication.sh" "${primary_site}" "${secondary_site}"
log "Warm identity secondary is Ready on ${secondary_site}; distributed replication is healthy and Keycloak remains scaled to zero."
