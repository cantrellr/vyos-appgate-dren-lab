#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"
require_cmd jq

label_cluster() {
  local namespace="$1" display="$2" context="$3" site="$4" role="$5" identity_default="$6"
  local segment_pool="$7" segment_ip="$8" eastwest_ip="$9"
  local identity_site="${10}" identity_active_default="${11}" keycloak_instances_default="${12}"
  local postgres_hibernation_default="${13}" postgres_replication_ip="${14}"
  local resource cluster_json key value
  local -a labels defaults
  resource="$(fleet_cluster_resource "${namespace}" "${display}" "${RANCHER_CONTEXT:-j64seg1opman}")"

  labels=(
    kmm.dev/platform=seg1opdev
    kmm.dev/context="${context}"
    kmm.dev/site="${site}"
    kmm.dev/role="${role}"
    kmm.dev/identity-site="${identity_site}"
    kmm.dev/segment1-pool="${segment_pool}"
    kmm.dev/segment1-lb-ip="${segment_ip}"
    kmm.dev/eastwest-lb-ip="${eastwest_ip}"
    kmm.dev/istio-network="${context}-net1"
  )

  if [[ "${identity_site}" == "true" ]]; then
    cluster_json="$(kubectl -n "${namespace}" get cluster.fleet.cattle.io "${resource}" -o json)"
    defaults=(
      kmm.dev/identity="${identity_default}"
      kmm.dev/identity-active="${identity_active_default}"
      kmm.dev/keycloak-instances="${keycloak_instances_default}"
      kmm.dev/postgres-hibernation="${postgres_hibernation_default}"
      kmm.dev/postgres-primary-site=j64seg1opdev
      kmm.dev/postgres-distributed-topology=false
    )
    for pair in "${defaults[@]}"; do
      key="${pair%%=*}"
      value="$(jq -r --arg key "${key}" '.metadata.labels[$key] // empty' <<<"${cluster_json}")"
      [[ -n "${value}" ]] || labels+=("${pair}")
    done
    labels+=(kmm.dev/postgres-replication-lb-ip="${postgres_replication_ip}")
  else
    labels+=(kmm.dev/identity="${identity_default}")
  fi

  kubectl -n "${namespace}" label cluster.fleet.cattle.io "${resource}" --overwrite "${labels[@]}" >/dev/null
  # The legacy one-way-replica label must not be allowed to reintroduce the
  # irreversible replica.enabled=false failover mechanism.
  kubectl -n "${namespace}" label cluster.fleet.cattle.io "${resource}" \
    kmm.dev/postgres-replica-enabled- >/dev/null 2>&1 || true
  log "Labeled ${namespace}/${resource} as ${context}; existing dynamic identity-role labels were preserved."
}

# All non-storage VIPs are allocated from each cluster's existing Segment1 pool.
label_cluster fleet-local "${FLEET_LOCAL_CLUSTER_DISPLAY_NAME}" \
  j64seg1opman j64 management none \
  1.0.0.201-1.0.0.210 1.0.0.205 1.0.0.210 \
  false false 0 off ""

label_cluster fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" \
  j64seg1opdev j64 application primary \
  1.0.0.211-1.0.0.220 1.0.0.215 1.0.0.220 \
  true true 3 off 1.0.0.216

label_cluster fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" \
  j52seg1opdev j52 application secondary-pending \
  1.0.0.221-1.0.0.230 1.0.0.225 1.0.0.230 \
  true false 0 off 1.0.0.226

label_cluster fleet-default "${FLEET_R01_APP_DISPLAY_NAME}" \
  r01seg1opdev r01 application none \
  1.0.0.231-1.0.0.240 1.0.0.235 1.0.0.240 \
  false false 0 off ""
