# Rancher registry validation and Helm operation recovery

## Why `helm-operation-*` pods matter

Rancher uses temporary `helm-operation-*` pods in `cattle-system` to install and upgrade Rancher-managed system charts. The pod normally contains a Helm container and a proxy sidecar. A `1/2 Error` result usually means the Helm command failed while the proxy sidecar remained available.

For this deployment, the critical Rancher-managed releases are Rancher Webhook and Fleet. Rancher is not considered ready until all of the following exist and are available:

- `cattle-system/rancher-webhook`;
- `cattle-fleet-system/fleet-controller`;
- `cattle-fleet-system/gitjob` (the workload name remains `gitjob`, but Fleet v0.10+ runs it from the `rancher/fleet` image; no separate `rancher/gitjob` image is required);
- `cattle-fleet-local-system/fleet-agent`;
- Fleet cluster, GitRepo, and BundleDeployment CRDs;
- `fleet-local/local`.

## Artifact ownership

The seg1opdev repository contains the local `rancher-2.14.2.tgz` bootstrap chart and all deployment/repair logic. It does not download, save, load, retag, or push Rancher container images.

Rancher image acquisition and promotion are owned by `cantrellr/k8s-airgap-images`. That repository must provide a Rancher image list containing the complete v2.14.2 inventory and promote the images into `kubeharbor.dev.kube` using strip-registry mapping.

Configure the staged list path:

```bash
RANCHER_IMAGE_LIST_FILE=/home/k8admin/k8s-airgap-images/source-lists/rancher-images.list
RANCHER_REGISTRY_ENFORCE=true
RANCHER_REGISTRY_VALIDATE_MODE=all
```

The validator rejects undersized lists and requires the Rancher, shell, Fleet, Fleet Agent, GitJob, Rancher Agent, and Rancher Webhook image families.

## Registry and node validation

Every `j64seg1opman` node must trust and authenticate to KubeHarbor through `/etc/rancher/rke2/registries.yaml`. A Kubernetes image pull Secret alone is not sufficient for every Rancher-created system workload.

Run:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
```

This command:

1. validates the external image list;
2. checks the selected image manifests in KubeHarbor;
3. creates a temporary DaemonSet with `imagePullPolicy: Always` and no Kubernetes pull Secret;
4. confirms every management node can pull a Rancher image using node-level RKE2 registry configuration;
5. removes the temporary namespace.

## Rancher Helm chart ownership

The Rancher chart is installed directly from:

```text
helm/packages/rancher-2.14.2.tgz
```

It is listed in `helm/required-packages.txt` for package integrity, but excluded from `helm/fleet-oci-packages.txt`. `publish-fleet-charts.sh` therefore does not push the Rancher bootstrap chart. Fleet-owned application charts are still published to `oci://kubeharbor.dev.kube/k8mm-charts`.

Rancher's bundled system charts are delivered by Rancher Manager after installation. Their container images must already exist in KubeHarbor.

## Rancher ingress and downstream-cluster WebSockets

Rancher downstream cluster agents use the remotedialer WebSocket endpoint at:

```text
wss://rancher.dev.kube/v3/connect/register
```

The Contour `HTTPProxy` in
`yaml/j64/seg1opman-cluster/resources/rancher-j64manager-resources-v1.yaml`
must enable WebSockets on the root route to the Rancher service:

```yaml
routes:
  - conditions:
      - prefix: /
    enableWebsockets: true
    timeoutPolicy:
      response: infinity
      idle: infinity
    services:
      - name: rancher
        port: 80
```

Without this setting, the Rancher UI and `/ping` endpoint can remain reachable while
`cattle-cluster-agent` repeatedly fails registration with:

```text
403 Forbidden
websocket: bad handshake
```

The Rancher installer applies this manifest during bootstrap. The repair workflow
reapplies it for an existing installation, and Rancher system validation fails when
the route is missing, invalid, not WebSocket-enabled, or lacks the infinite response
and idle timeout policy required for persistent agent tunnels.

## RKE2 CIS PodSecurity and Fleet agents

The RKE2 CIS profile defaults unexempted namespaces to `restricted`. Rancher-generated `cattle-cluster-agent` and `fleet-agent` pods are system workloads and can be rejected before a pod is created. Typical events include:

```text
pods "fleet-agent-..." is forbidden: violates PodSecurity "restricted:latest": seccompProfile ...
```

The WebSocket fix alone does not resolve this condition. Prepare the namespaces before importing downstream clusters:

```bash
./scripts/deploy-platform.sh prepare-rancher-imports
```

For clusters that are already imported, repair and restart the agents:

```bash
./scripts/deploy-platform.sh repair-rancher-psa
```

The repository applies `enforce`, `audit`, and `warn` at `privileged:latest` to `cattle-system` and `cattle-fleet-system` on every cluster. It also applies the same profile to `cattle-fleet-local-system` and `cattle-fleet-clusters-system` on the management cluster. These are scoped Rancher/Fleet system exceptions, not a relaxation of application namespaces.


## Fleet Kubernetes 1.35 WatchListClient compatibility

Fleet `v0.15.2` uses `client-go` `v0.35.x`. On RKE2/Kubernetes 1.35, Fleet controller and agent watches can repeatedly terminate with messages such as:

```text
unable to decode an event from the watch stream
stream error: stream ID ...; NO_ERROR; received from peer
```

The resulting cache-sync failures can leave bundles in `WaitApplied`. This repository sets `KUBE_FEATURE_WatchListClient=false` in two places:

1. the Rancher Helm `fleet` values block for the management `fleet-controller`;
2. every Fleet Cluster resource at `spec.agentEnvVars` for the local and downstream `fleet-agent` Deployments.

Apply and validate the setting across all imported clusters:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

The configuration script preserves unrelated existing `agentEnvVars`, patches current Deployments for immediate convergence, and waits for rollouts. Fleet Cluster resources remain the downstream source of truth so Rancher/Fleet reconciliation does not silently discard the workaround.

## Repair an existing failed installation

After the image inventory is present and node pulls pass, run:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow:

1. reruns external image-list, Harbor, and node-pull validation;
2. refreshes `regcred-kubeharbor` in existing Rancher namespaces;
3. attaches the pull Secret to existing Rancher/Fleet service accounts as a fallback;
4. removes failed temporary Helm operation pods/resources;
5. reapplies the Rancher certificate and long-lived WebSocket-enabled Contour `HTTPProxy`;
6. applies privileged PSA labels to Rancher/Fleet system namespaces on all clusters;
7. restarts existing Rancher, webhook, Fleet controller, GitJob, cluster-agent, and Fleet-agent Deployments;
8. sets `KUBE_FEATURE_WatchListClient=false` on every currently present Fleet controller/agent and writes it to Fleet Cluster `spec.agentEnvVars`;
9. waits for the Rancher route, Webhook, Fleet, GitJob, the local agent, Fleet CRDs, and `fleet-local/local`.

Do not delete healthy Rancher/Fleet resources manually. The repair command removes only failed temporary Helm operations and lets Rancher reconcile desired state.

## Validation and diagnostics

```bash
./scripts/deploy-platform.sh validate-rancher-system
```

Validation also confirms that `cattle-system/rancher-httpproxy` is valid, enables WebSockets on the root route to `rancher:80`, and sets infinite response/idle timeouts. It also verifies the Fleet WatchListClient workaround on the management controller and local agent. When validation fails, it prints Rancher/Fleet workload state, the full `HTTPProxy` state, waiting and terminated container reasons, Helm logs from failed `helm-operation-*` pods, and recent Rancher system-chart errors.

The `fleet` phase runs this validation before attempting to label Fleet clusters. This prevents a missing Fleet installation from being misreported as a display-name lookup problem.

## Version alignment

The deployment remains pinned to Rancher `2.14.2` and RKE2 `v1.35.6+rke2r1`. The Rancher chart declares Kubernetes `<1.36.0-0`, so RKE2 1.35.6 satisfies that chart constraint. Helm 3.18 or newer is enforced by the installer.
