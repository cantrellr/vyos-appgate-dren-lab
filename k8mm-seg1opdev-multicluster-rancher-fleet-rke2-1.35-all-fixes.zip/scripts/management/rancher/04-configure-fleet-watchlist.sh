#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
FLEET_WATCHLIST_ENV_NAME="${FLEET_WATCHLIST_ENV_NAME:-KUBE_FEATURE_WatchListClient}"
FLEET_WATCHLIST_ENV_VALUE="${FLEET_WATCHLIST_ENV_VALUE:-false}"
FLEET_WATCHLIST_TIMEOUT_SECONDS="${FLEET_WATCHLIST_TIMEOUT_SECONDS:-900}"

MODE="management"
CHECK_ONLY=false
WAIT_FOR_RESOURCES=false
SKIP_MISSING=false

usage() {
  cat <<USAGE
Usage:
  $0 --management-only [--check] [--wait]
  $0 --all [--check] [--wait]
  $0 --existing [--check]

Configure the Fleet Kubernetes 1.35 WatchListClient compatibility workaround.
The authoritative downstream setting is written to each Fleet Cluster resource
at spec.agentEnvVars, and existing Fleet Deployments are reconciled immediately.

  --management-only  Configure fleet-controller and the fleet-local agent.
  --all              Require and configure all four Fleet Cluster resources.
  --existing         Configure every currently present target and skip missing imports.
  --check            Validate without changing resources.
  --wait             Wait for expected Fleet resources and Deployments to appear.
USAGE
}

while (($#)); do
  case "$1" in
    --management-only) MODE="management" ;;
    --all) MODE="all" ;;
    --existing) MODE="all"; SKIP_MISSING=true ;;
    --check) CHECK_ONLY=true ;;
    --wait) WAIT_FOR_RESOURCES=true ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

require_cmd kubectl
require_cmd jq
validate_context_access "${RANCHER_CONTEXT}"

FLEET_LOCAL_CLUSTER_DISPLAY_NAME="${FLEET_LOCAL_CLUSTER_DISPLAY_NAME:-j64seg1opman}"
FLEET_J64_APP_DISPLAY_NAME="${FLEET_J64_APP_DISPLAY_NAME:-j64seg1opdev}"
FLEET_J52_APP_DISPLAY_NAME="${FLEET_J52_APP_DISPLAY_NAME:-j52seg1opdev}"
FLEET_R01_APP_DISPLAY_NAME="${FLEET_R01_APP_DISPLAY_NAME:-r01seg1opdev}"

deployment_exists() {
  local context="$1" namespace="$2" deployment="$3"
  kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" >/dev/null 2>&1
}

wait_for_deployment() {
  local context="$1" namespace="$2" deployment="$3"
  local deadline=$((SECONDS + FLEET_WATCHLIST_TIMEOUT_SECONDS))
  until deployment_exists "${context}" "${namespace}" "${deployment}"; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
}

deployment_has_workaround() {
  local context="$1" namespace="$2" deployment="$3"
  kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" -o json | jq -e \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      (.spec.template.spec.containers | length) > 0 and
      all(.spec.template.spec.containers[];
        any((.env // [])[]?; .name == $name and .value == $value)
      )
    ' >/dev/null
}

configure_deployment() {
  local context="$1" namespace="$2" deployment="$3"

  if ! deployment_exists "${context}" "${namespace}" "${deployment}"; then
    if [[ "${WAIT_FOR_RESOURCES}" == true ]]; then
      wait_for_deployment "${context}" "${namespace}" "${deployment}" || {
        warn "${context}: timed out waiting for ${namespace}/${deployment}."
        return 1
      }
    elif [[ "${SKIP_MISSING}" == true ]]; then
      warn "${context}: skipping missing ${namespace}/${deployment}."
      return 0
    else
      warn "${context}: required Deployment is missing: ${namespace}/${deployment}"
      return 1
    fi
  fi

  if [[ "${CHECK_ONLY}" == true ]]; then
    if deployment_has_workaround "${context}" "${namespace}" "${deployment}"; then
      printf '[PASS] %s/%s/%s sets %s=%s on every container\n' \
        "${context}" "${namespace}" "${deployment}" \
        "${FLEET_WATCHLIST_ENV_NAME}" "${FLEET_WATCHLIST_ENV_VALUE}"
      return 0
    fi
    warn "${context}: ${namespace}/${deployment} does not set ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE} on every container."
    return 1
  fi

  log "${context}: configuring ${namespace}/${deployment} with ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}..."
  kubectl --context "${context}" -n "${namespace}" set env \
    deployment/"${deployment}" --containers='*' \
    "${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}" >/dev/null

  kubectl --context "${context}" -n "${namespace}" rollout status \
    deployment/"${deployment}" --timeout="${FLEET_WATCHLIST_TIMEOUT_SECONDS}s" >/dev/null
}

resolve_fleet_cluster() {
  local namespace="$1" display_name="$2"
  local deadline=$((SECONDS + FLEET_WATCHLIST_TIMEOUT_SECONDS))
  local resource=""

  while true; do
    if resource="$(fleet_cluster_resource "${namespace}" "${display_name}" "${RANCHER_CONTEXT}" 2>/dev/null)"; then
      printf '%s\n' "${resource}"
      return 0
    fi
    [[ "${WAIT_FOR_RESOURCES}" == true ]] || return 1
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
}

fleet_cluster_has_workaround() {
  local namespace="$1" resource="$2"
  kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" \
    get cluster.fleet.cattle.io "${resource}" -o json | jq -e \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      any((.spec.agentEnvVars // [])[]?; .name == $name and .value == $value)
    ' >/dev/null
}

configure_fleet_cluster() {
  local namespace="$1" display_name="$2" downstream_context="$3" agent_namespace="$4"
  local resource="" cluster_json="" env_json="" patch_json=""

  if ! resource="$(resolve_fleet_cluster "${namespace}" "${display_name}")"; then
    if [[ "${SKIP_MISSING}" == true ]]; then
      warn "Skipping Fleet Cluster ${namespace}/${display_name}; it has not been created/imported yet."
      return 0
    fi
    fleet_cluster_inventory "${RANCHER_CONTEXT}"
    warn "Required Fleet Cluster is missing: ${namespace}/${display_name}"
    return 1
  fi

  if [[ "${CHECK_ONLY}" == true ]]; then
    if fleet_cluster_has_workaround "${namespace}" "${resource}"; then
      printf '[PASS] %s/%s propagates %s=%s to its Fleet agent\n' \
        "${namespace}" "${resource}" \
        "${FLEET_WATCHLIST_ENV_NAME}" "${FLEET_WATCHLIST_ENV_VALUE}"
    else
      warn "${namespace}/${resource} does not propagate ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE} through spec.agentEnvVars."
      return 1
    fi
  else
    cluster_json="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" \
      get cluster.fleet.cattle.io "${resource}" -o json)"
    env_json="$(jq -c \
      --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
      --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
        ((.spec.agentEnvVars // []) | map(select(.name != $name))) +
        [{"name": $name, "value": $value}]
      ' <<<"${cluster_json}")"
    patch_json="$(jq -cn --argjson env "${env_json}" '{spec:{agentEnvVars:$env}}')"

    log "Configuring Fleet Cluster ${namespace}/${resource} to propagate ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}..."
    kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" patch \
      cluster.fleet.cattle.io "${resource}" --type=merge -p "${patch_json}" >/dev/null
  fi

  validate_context_access "${downstream_context}"
  configure_deployment "${downstream_context}" "${agent_namespace}" fleet-agent
}

failures=0

configure_deployment "${RANCHER_CONTEXT}" cattle-fleet-system fleet-controller || failures=$((failures + 1))
configure_fleet_cluster fleet-local "${FLEET_LOCAL_CLUSTER_DISPLAY_NAME}" j64seg1opman cattle-fleet-local-system || failures=$((failures + 1))

if [[ "${MODE}" == "all" ]]; then
  configure_fleet_cluster fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" j64seg1opdev cattle-fleet-system || failures=$((failures + 1))
  configure_fleet_cluster fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" j52seg1opdev cattle-fleet-system || failures=$((failures + 1))
  configure_fleet_cluster fleet-default "${FLEET_R01_APP_DISPLAY_NAME}" r01seg1opdev cattle-fleet-system || failures=$((failures + 1))
fi

(( failures == 0 )) || die "Fleet WatchListClient compatibility configuration failed with ${failures} issue(s)."
if [[ "${CHECK_ONLY}" == true ]]; then
  log "Fleet WatchListClient compatibility validation passed."
else
  log "Fleet controllers and agents are configured to use standard List+Watch behavior."
fi
