# Repository layout

> Documentation baseline: v2.1 — August 19, 2026.

```text
.
├── config/                       # non-secret runtime configuration examples
├── diagrams/                     # Mermaid architecture sources
├── docs/                         # deployment and operating documentation
├── fleet/
│   └── bundles/                  # ordered steady-state Fleet bundles
├── host-packages/                 # offline golden-image package manifests and archives
├── helm/
│   ├── packages/                 # immutable chart archives
│   ├── required-packages.txt     # package allowlist
│   ├── required-oci-artifacts.txt
│   └── SHA256SUMS
├── scripts/
│   ├── _lib/                     # shared Bash runtime/CIS helpers
│   ├── core/                     # management bootstrap and break-glass core installers
│   ├── istio/                    # mesh credential/configuration operations
│   ├── management/
│   │   ├── failover/             # controlled identity promotion
│   │   ├── fleet/                # Fleet bootstrap/onboarding/validation
│   │   ├── preflight/            # host readiness and chart publishing
│   │   └── rancher/              # Rancher bootstrap
│   ├── monitoring/               # Elastic break-glass installer and validator
│   ├── opkeycloak/               # identity break-glass installers/verification
│   └── security/                 # CIS/PSA validation
└── yaml/
    ├── monitoring/               # source Elastic/KSM values and policies
    ├── resources/                # common source manifests
    ├── values/                   # common imperative values
    ├── j64/                      # j64 cluster-specific source configuration
    ├── j52/                      # j52 cluster-specific source configuration
    └── r01/                      # r01 cluster-specific source configuration
```

## Source-of-truth rules

- Normal Kubernetes desired state belongs under `fleet/bundles`.
- `yaml` retains source/break-glass configuration and must remain aligned with the Fleet copy.
- Cross-cluster credentials and private material never belong in either directory.
- Host package archives are built on the connected side, checksum-verified, and installed into the golden image without apt or repository access.
- Every Fleet chart must have an immutable package in `helm/packages`, an allowlist entry, a checksum, an OCI inventory entry, and a validation rule.
- Every new application gets its own numbered Fleet bundle, dependency selectors, target guard, runtime Secret contract, image inventory, operational validation, and documentation.
- Do not add another GitOps controller.

## Naming

The exact supported context names are `j64seg1opman`, `j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev`. Helm release names are environment-neutral because Fleet selects the target cluster; cluster identity comes from labels and resource values, not release-name variations.
