# Rancher Manager and Fleet architecture

> Documentation baseline: v2.1 — August 19, 2026.

## Decision

Rancher Manager owns cluster lifecycle and Fleet owns steady-state platform/application delivery. A second GitOps engine is not deployed because overlapping reconcilers create ambiguous ownership and rollback behavior.

## Bootstrap boundary

The management cluster must exist before Rancher can manage anything. `scripts/management/fleet/00-bootstrap-management.sh` therefore installs the minimum chain imperatively on `j64seg1opman`:

1. KubeHarbor pull Secret;
2. external Rancher v2.15.0 image-list, Harbor inventory, and per-node pull validation;
3. CoreDNS forwarding patch;
4. cert-manager CA Secret;
5. cert-manager;
6. MetalLB and Segment1 address pool;
7. Segment1 Contour release `ingress-segment1`;
8. Rancher release `rancher`;
9. Rancher Webhook and Fleet system-component validation.

Once Rancher/Fleet is available, the common platform is represented by Fleet bundles, except for the management-cluster certificate and ingress/network prerequisites. `bootstrap-management` remains the sole lifecycle owner of cert-manager, the MetalLB release and Segment1 pool/L2 configuration, and the Segment1 Contour release because Rancher depends on that substrate before Fleet exists. The local GitRepo publishes readiness-contract bundles only after those bootstrap-owned runtime contracts have been validated. Downstream clusters use the real cert-manager chart/configuration, MetalLB chart/configuration, and Contour bundles. Downstream MetalLB keeps the chart/config boundary: the chart establishes controller, speaker, and CRDs before the configuration adapter renders the per-cluster Segment1 pool.

## Fleet workspaces

`fleet-local` targets the Rancher local cluster. It uses management bootstrap-contract paths for cert-manager, MetalLB/configuration, and Segment1 Contour, plus Fleet-owned common bundles that are safe to install after Rancher exists. `fleet-default` targets downstream clusters and uses the real cert-manager chart/configuration paths plus the identity bundles. Both workspaces use the same Git repository, Git credentials, OCI credentials, and CA trust.

## Cluster-label contract

| Label | Purpose |
| --- | --- |
| `kmm.dev/context` | exact kubeconfig/environment identity |
| `kmm.dev/site` | physical/logical site |
| `kmm.dev/role` | management or application |
| `kmm.dev/platform=seg1opdev` | downstream platform target |
| `kmm.dev/identity` | primary, secondary, secondary-pending, or none |
| `kmm.dev/identity-site` | operator placement guard |
| `kmm.dev/segment1-pool` | MetalLB range |
| `kmm.dev/segment1-lb-ip` | Contour VIP |
| `kmm.dev/eastwest-lb-ip` | Istio gateway VIP |
| `kmm.dev/istio-network` | mesh network name |
| `node.longhorn.io/create-default-disk` | preflight-approved Longhorn worker disk |
| `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-*` | durable identity role state |

Static topology labels do not change during identity failover. Dynamic role labels do, which prevents Fleet from reverting the promoted state.

## What Fleet intentionally does not own

- Rancher bootstrap and cluster provisioning;
- host package/service preparation;
- private runtime Secret generation;
- Kubernetes namespace creation and CIS/PSA labeling;
- CoreDNS bootstrap patch;
- Chrony host-time agent;
- Istio remote Secrets;
- CNPG replication certificate transfer;
- identity promotion/fencing hooks.

These are dependency, credential, or cross-cluster control operations rather than ordinary desired-state objects.

## Availability

Fleet itself is hosted with Rancher on `j64seg1opman`. A management outage does not immediately stop running workloads, but it prevents reconciliation, new deployments, and centralized lifecycle actions. Back up Rancher and Fleet state and preserve Git/KubeHarbor availability as control-plane dependencies.


### Bootstrap network ownership migration

The management cluster must not have two Helm lifecycle owners for MetalLB or Segment1 Contour. `bootstrap-management` owns those releases because they are prerequisites for Rancher. During upgrade from older layouts, `03-bootstrap-gitrepos.sh` retires the legacy `fleet-local` BundleDeployments with `keepResources` before replacing them with readiness-contract markers. Downstream clusters remain fully Fleet-managed. The downstream Contour bundle disables Fleet values preprocessing, pins each approved Segment1 load-balancer IP through `targetCustomizations`, and forces `global.security.allowInsecureImages: true` at Helm override precedence for the approved private Harbor mirror.
