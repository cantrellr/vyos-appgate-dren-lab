# Documentation index

**Baseline:** v2.1 — August 19, 2026

1. [Deployment guide](How-to-deploy-a-K8s-Mystical-Mesh%20multicluster.md) — end-to-end sequence and acceptance gates.
2. [Deployment configuration reference](Deployment-Configuration-Reference.md) — clusters, VIPs, versions, labels, Secrets, and dependencies.
3. [System design](System-Design-Document.md) — architecture, ownership, data flows, and failure domains.
4. [Rancher and Fleet architecture](Rancher-Fleet-Architecture.md) — bootstrap versus steady-state control.
5. [Fleet operations](Fleet-Operations.md) — reconciliation, validation, drift, and rollback.
6. [Elastic Stack monitoring](Elastic-Stack-Monitoring.md) — four-cluster Agent topology and token model.
7. [Longhorn storage](Longhorn-Storage.md) — CSI, disk, storage-class, snapshot, and air-gap contracts.
8. [Host preflight](Host-Preflight.md) — golden-image offline package installation, Chrony, and validation-only Longhorn worker procedures.
8. [KubeHarbor and install framework](KubeHarbor-Registry-and-Install-Framework.md) — disconnected artifacts and publishing.
9. [RKE2 CIS and namespace readiness](RKE2-CIS-Profile-and-Namespace-Readiness.md) — PSA and namespace exceptions.
10. [Segment1 restricted ingress](Segment1-Restricted-Domain-Policy.md) — ingress and NetworkPolicy contract.
11. [Istio namespace injection](Istio-Namespace-Injection-Contract.md) — mesh enrollment rules.
12. [OPKeycloak PostgreSQL HA](OPKeycloak-PostgreSQL-HA.md) — in-cluster data tier.
13. [OPKeycloak two-site HA](OPKeycloak-Two-Site-HA.md) — primary/warm-secondary state and failover.
14. [Repository layout](Repository-Layout.md) — directory ownership and extension rules.
15. [Deployment assessment](Deployment-Assessment.md) — corrected blockers, residual risks, and validation boundary.
- [Rancher registry validation and Helm operation recovery](Rancher-Airgap-and-Helm-Operations.md)
