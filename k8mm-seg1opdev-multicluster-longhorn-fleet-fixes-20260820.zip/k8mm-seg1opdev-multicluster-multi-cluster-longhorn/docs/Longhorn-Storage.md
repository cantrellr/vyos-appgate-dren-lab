# Longhorn storage

> Documentation baseline: v2.1 — August 19, 2026.

## Scope

Longhorn 1.12.1 is the CSI provider on all four clusters. This is a clean replacement: no Trident or ONTAP objects, credentials, backends, storage classes, or migration jobs remain in the active deployment.

Each cluster is an independent Longhorn failure domain. Replicas and snapshots do not cross cluster boundaries.

## Worker disk contract

Every worker node must provide an existing, read-write XFS mount at `/mnt/k8sdata` with at least 240 GiB visible capacity. The v2.1 offline bundle installs `open-iscsi`, `nfs-common`, `cryptsetup`, `dmsetup`, `xfsprogs`, and their non-base dependencies in the Ubuntu 24.04 amd64 golden image. Deployed-node preflight performs validation only; it loads `iscsi_tcp`, enables `iscsid`, and disables active `multipathd` services.

Neither the offline installer nor preflight partitions, formats, mounts, unmounts, or erases a disk. Preflight contains no apt call. Only nodes that pass are labeled `node.longhorn.io/create-default-disk=true`.

## Production defaults

| Setting | Value |
| --- | --- |
| Data engine | V1 |
| Default replica count | 3 |
| Default data path | `/mnt/k8sdata` |
| Overprovisioning | 100% |
| Minimum free space | 25% |
| Reserved space on default disk | 5% |
| Replica node/zone anti-affinity | soft |
| Replica disk anti-affinity | hard |
| Automatic replica balancing | best-effort |
| Automatic salvage | enabled |
| Usage metrics / upgrade checks | disabled |
| Longhorn UI | ClusterIP only |

V1 is intentional because the approved storage is a mounted filesystem. Longhorn V2 requires a separately approved raw-block/hugepage design.

## Storage classes

| Name | Default | Filesystem | Reclaim | Binding | Use |
| --- | --- | --- | --- | --- | --- |
| `longhorn` | yes | ext4 | Delete | WaitForFirstConsumer | general workloads |
| `longhorn-retain` | no | ext4 | Retain | WaitForFirstConsumer | retained general data |
| `longhorn-xfs-retain` | no | XFS | Retain | WaitForFirstConsumer | CNPG data and WAL |

All classes use three replicas, expansion, the V1 data engine, and the `snapshot-default` recurring-job group. RWX volumes are supported by Longhorn's share manager and require the NFSv4 client installed by host preflight.

## Snapshots and backup boundary

The `longhorn-snapshot` VolumeSnapshotClass creates native snapshots. The `snapshot-daily` recurring job runs at 02:00 UTC and retains seven snapshots.

Snapshots share the cluster's Longhorn storage failure domain. They are not off-cluster backups and do not satisfy site-loss recovery. S3-compatible backup-target configuration is intentionally deferred until credentials, endpoint, bucket, retention, and recovery objectives are approved.

## Air-gap artifacts

The immutable chart is `helm/packages/longhorn-1.12.1.tgz`, published as `oci://kubeharbor.dev.kube/k8mm-charts/longhorn:1.12.1`.

The host artifact is `host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz` with SHA-256 `d76bc98aec3404f33f6e8996d1c86ce4c19dbd95bcddaac4281be1d11d805c5a`.

The authoritative image lists are:

- `helm/longhorn-images.txt` — upstream image names and versions;
- `helm/longhorn-kubeharbor-images.txt` — exact Harbor-qualified mirror targets.

Preserve the `longhornio` repository namespace when mirroring.

## Operations

Install the offline package archive on the golden image before cloning nodes. Validate and label all deployed worker nodes before Fleet registration:

```bash
scripts/management/preflight/longhorn-storage-preflight.sh --all
```

Inspect Longhorn without exposing its UI:

```bash
kubectl --context <context> -n longhorn-system get pods
kubectl --context <context> -n longhorn-system get volumes.longhorn.io
kubectl --context <context> -n longhorn-system port-forward svc/longhorn-frontend 8080:80
```
## Fleet reconciliation after the Trident replacement

The Fleet control plane must consume a Git commit that contains `40-longhorn`, `41-longhorn-config`, and the `oppostgres-operator -> longhorn-config` dependency. If Rancher still shows `trident-config`, the runtime is serving an older Git commit; changing local files alone does not change Fleet's source of truth. Commit and push the repository, run `./scripts/deploy-platform.sh fleet`, then run `./scripts/deploy-platform.sh validate`. The runtime validator now fails immediately if Longhorn bundles are missing or any retired Trident dependency remains.

Istio mutates its validating webhook after installation by injecting the serving CA bundle. Fleet compare patches on `istio-base` and `istiod` ignore only that controller-owned `caBundle` field so the expected mutation does not keep the dependency chain in `Modified` state. Other webhook drift remains visible.

