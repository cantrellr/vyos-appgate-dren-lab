# Istio namespace injection contract

> Documentation baseline: v2.1 — August 19, 2026.

## Default rule

Platform namespaces do not receive automatic sidecars. `istio-injection=disabled` is applied to cert-manager, Segment1 ingress, MetalLB, Longhorn, Istio itself, identity namespaces, and Elastic monitoring namespaces.

Application namespaces join the mesh only through an explicit reviewed label, preferably an Istio revision label when revision-based upgrades are introduced.

## Why

Automatic injection into controllers, CSI components, databases, ingress gateways, or host-monitoring agents can create startup ordering failures, unexpected network capture, and unsupported traffic paths. Mesh participation must be intentional.

## Audit

```bash
scripts/istio/05-audit-namespace-injection.sh --all
```

Use the script's enforcement mode only after reviewing application namespaces. A namespace that is both a Segment1 backend and an Istio application requires both its ingress backend label and its approved mesh label.

## Cross-cluster configuration

Fleet installs Istio CNI, istiod, and one east-west gateway per cluster. The east-west VIPs are `.210`, `.220`, `.230`, and `.240` for management, j64 app, j52 app, and r01 app respectively. Remote-cluster Secrets remain an operational credential workflow and are created by `scripts/istio/03-configure-istio-multicluster-secrets.sh` after gateways are Ready.
