#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"
NAMESPACE="longhorn-system"
RELEASE="longhorn"
CHART="longhorn-1.12.1.tgz"
VALUES="longhorn-values-v1.yaml"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

ensure_cis_namespace "${NAMESPACE}" false privileged
ensure_registry_secret "${NAMESPACE}"
helm_upgrade_install   "${RELEASE}"   "${HELM_PACKAGES_DIR}/${CHART}"   "${NAMESPACE}"   "${YAML_DIR}/values/${VALUES}"

log "Waiting for Longhorn manager and driver deployment..."
kubectl -n "${NAMESPACE}" rollout status daemonset/longhorn-manager --timeout="${KUBECTL_TIMEOUT}"
wait_for_deployment_rollout "${NAMESPACE}" "longhorn-driver-deployer" "${KUBECTL_TIMEOUT}"
log "Longhorn ${RELEASE} installed."
