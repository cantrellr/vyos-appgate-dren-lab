# Architecture and Design

> **Baseline:** v2.2 — August 28, 2026  
> **Audience:** architects, systems engineers, security engineers, platform engineers, and senior support staff.

## 1. Architectural principles

The platform is a four-cluster, air-gapped RKE2 environment with these design rules:

1. Rancher Manager owns cluster lifecycle; Rancher Fleet owns steady-state Kubernetes desired state.
2. GitLab is the source of truth for Fleet configuration; KubeHarbor is the source for approved OCI charts and container images.
3. No second GitOps controller is active. Overlapping reconcilers are intentionally avoided.
4. Runtime secrets, private keys, Istio CA directories, and enrollment tokens are not stored in Git.
5. Platform namespaces do not receive automatic Istio sidecars. Mesh participation is explicit.
6. Segment1 is the only MetalLB LoadBalancer address domain for the platform; storage data networks remain outside MetalLB.
7. Host-level prerequisites such as time and Longhorn disks are validated outside Fleet because they are node concerns, not ordinary Kubernetes desired state.

## 2. Overall system topology

```mermaid
flowchart TB
  ADMIN[Platform administrators and support teams]
  GITLAB[GitLab\nGit source of truth]
  HARBOR[KubeHarbor\nOCI charts and container images]
  DNS[Private DNS\ndev.kube and enterprise zones]
  NTP[Approved NTP sources]
  CA[Enterprise / Segment1 CA]
  ELASTIC[External Elastic Fleet Server]
  OBS[External Prometheus / Grafana]

  subgraph MGMT[j64seg1opman - Management Cluster]
    RANCHER[Rancher Manager]
    FLEET[Rancher Fleet]
    MESH_M[Istio / Kiali]
    STORAGE_M[Longhorn]
    AGENT_M[Elastic Agent]
    RUNNER[GitLab Runner]
  end

  subgraph J64[j64seg1opdev - Primary Application Cluster]
    MESH_J64[Istio / Kiali]
    STORAGE_J64[Longhorn]
    PG_PRIMARY[CloudNativePG Primary]
    KC_PRIMARY[Keycloak Active]
    AGENT_J64[Elastic Agent]
  end

  subgraph J52[j52seg1opdev - Secondary Identity Cluster]
    MESH_J52[Istio / Kiali]
    STORAGE_J52[Longhorn]
    PG_REPLICA[CloudNativePG Replica]
    KC_STANDBY[Keycloak Standby]
    AGENT_J52[Elastic Agent]
  end

  subgraph R01[r01seg1opdev - Application Cluster]
    MESH_R01[Istio / Kiali]
    STORAGE_R01[Longhorn]
    AGENT_R01[Elastic Agent]
  end

  ADMIN --> RANCHER
  GITLAB --> FLEET
  GITLAB <--> RUNNER
  HARBOR --> FLEET
  HARBOR --> MGMT
  HARBOR --> J64
  HARBOR --> J52
  HARBOR --> R01
  RANCHER --> FLEET
  FLEET --> MESH_M
  FLEET --> MESH_J64
  FLEET --> MESH_J52
  FLEET --> MESH_R01
  FLEET --> STORAGE_J64
  FLEET --> STORAGE_J52
  FLEET --> STORAGE_R01
  FLEET --> PG_PRIMARY
  FLEET --> PG_REPLICA
  FLEET --> KC_PRIMARY
  PG_PRIMARY -. asynchronous WAL replication .-> PG_REPLICA
  MESH_M <--> MESH_J64
  MESH_M <--> MESH_J52
  MESH_M <--> MESH_R01
  AGENT_M --> ELASTIC
  AGENT_J64 --> ELASTIC
  AGENT_J52 --> ELASTIC
  AGENT_R01 --> ELASTIC
  MESH_M --> OBS
  MESH_J64 --> OBS
  MESH_J52 --> OBS
  MESH_R01 --> OBS
  DNS --> MGMT
  DNS --> J64
  DNS --> J52
  DNS --> R01
  NTP --> MGMT
  NTP --> J64
  NTP --> J52
  NTP --> R01
  CA --> MGMT
  CA --> J64
  CA --> J52
  CA --> R01

  classDef external stroke-dasharray: 5 5
  class GITLAB,HARBOR,DNS,NTP,CA,ELASTIC,OBS external
```

### External dependencies

| Dependency | Function | Failure impact |
| --- | --- | --- |
| GitLab (`gitlab001.dev.local`) | Fleet Git source of truth | no new reconciliation or Git-driven recovery |
| KubeHarbor (`kubeharbor.dev.kube`) | images and OCI charts | new pods/charts may fail to pull; upgrades blocked |
| private DNS | resolution for Harbor, Rancher, UIs, identity, replication, monitoring | widespread connection and certificate failures |
| approved NTP | node clock discipline | TLS, logs, distributed systems, and deployment gates affected |
| Segment1 CA | cert-manager issuer and service TLS | certificate issuance/renewal and TLS validation affected |
| Elastic Fleet/ELK | agent enrollment and telemetry | monitoring/log visibility degraded |
| Prometheus/Grafana | Kiali external metrics/dashboard integration | Kiali metrics/graph integrations degraded |
| Segment1 network | ingress VIPs, east-west mesh, identity replication | service and multicluster communication failures |

## 3. Cluster topology and addressing

* Note: IP addresses are examples and may not be the actual IPs used for production deployment

| Context | Role | Identity role | MetalLB pool | Ingress VIP | PostgreSQL replication VIP | Istio east-west VIP |
| --- | --- | --- | --- | --- | --- | --- |
| `j64seg1opman` | management | none | `1.0.0.201-1.0.0.210` | `1.0.0.205` | — | `1.0.0.210` |
| `j64seg1opdev` | application | primary | `1.0.0.211-1.0.0.220` | `1.0.0.215` | `1.0.0.216` | `1.0.0.220` |
| `j52seg1opdev` | application | warm secondary | `1.0.0.221-1.0.0.230` | `1.0.0.225` | `1.0.0.226` | `1.0.0.230` |
| `r01seg1opdev` | application | none | `1.0.0.231-1.0.0.240` | `1.0.0.235` | — | `1.0.0.240` |

All platform LoadBalancer addresses are within Segment1 (`1.0.0.0/23`).

## 4. GitOps architecture and ownership

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  CI[Validation pipeline]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
    RUNNER[GitLab Runner]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> CI
  RUNNER <--> CI
  CI -->|pass and merge| JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

### Bootstrap boundary

`j64seg1opman` must exist before Rancher/Fleet can manage anything. The management bootstrap therefore installs the minimum dependency chain imperatively: KubeHarbor pull credentials, private DNS forwarding, cert-manager/CA, MetalLB and Segment1 pool, Contour/Envoy, Rancher, and Rancher/Fleet compatibility controls.

After Rancher is available, Fleet delivers common services. On the management cluster, bootstrap remains the lifecycle owner of cert-manager, MetalLB/configuration, and Segment1 Contour because Rancher itself depends on that substrate. Fleet publishes readiness-contract bundles for those local prerequisites instead of attempting to reinstall or adopt them.

Downstream clusters receive the actual Fleet-owned cert-manager, MetalLB, Contour, Longhorn, identity, Istio, Kiali, and monitoring bundles.

### Cluster label contract

Key Fleet labels include:

| Label | Purpose |
| --- | --- |
| `kmm.dev/context` | exact supported cluster identity |
| `kmm.dev/site` | site/location selector |
| `kmm.dev/role` | management or application |
| `kmm.dev/platform=seg1opdev` | platform target guard |
| `kmm.dev/identity` | primary, secondary, secondary-pending, or none |
| `kmm.dev/identity-site` | identity operator placement |
| `kmm.dev/segment1-pool` | per-cluster MetalLB address range |
| `kmm.dev/segment1-lb-ip` | Contour VIP |
| `kmm.dev/eastwest-lb-ip` | Istio east-west VIP |
| `kmm.dev/istio-network` | Istio network identity |
| `kmm.dev/identity-active`, `kmm.dev/keycloak-instances` | durable Keycloak traffic/replica role state |
| `kmm.dev/postgres-primary-site` | distributed-topology writable site (`j64seg1opdev` or `j52seg1opdev`) |
| `kmm.dev/postgres-distributed-topology` | enrollment gate used during initial J52 bootstrap |
| `kmm.dev/postgres-hibernation`, `kmm.dev/postgres-replication-lb-ip` | database fencing and site replication VIP state |
| `node.longhorn.io/create-default-disk=true` | worker passed Longhorn preflight |

Dynamic identity labels change during controlled failover; static topology labels do not.

## 5. Fleet bundle sequence

The active bundle chain is organized by numbered directories and dependency labels rather than relying only on lexical ordering:

- `10/11` cert-manager and CA configuration;
- `20/21` MetalLB and Segment1 address pools;
- `31/32` Contour ingress and Segment1 policies;
- `40/41/42` Longhorn, storage configuration, and Longhorn UI exposure;
- `50/51/52/53/54` CloudNativePG and Keycloak identity stack;
- `60-66` Istio base/CNI/istiod/east-west and Kiali;
- `70/71` kube-state-metrics and Elastic Agent;
- `72` management-cluster GitLab Runner.

The exact package/version allowlist is in `helm/required-oci-artifacts.txt`, and validation enforces that staged charts, checksums, Fleet definitions, and OCI references remain aligned.

## 6. Air-gap artifact architecture

Fleet chart references use the pattern:

```text
oci://kubeharbor.dev.kube/k8mm-charts/<chart>:<version>
```

The deployment host and cluster nodes trust the KubeHarbor issuing CA. Workloads use namespace-local `regcred-kubeharbor`; Fleet workspaces use OCI credentials and CA material seeded into the Fleet namespaces.

Rancher image acquisition/promotion is intentionally owned by the separate air-gap image workflow. This repository validates the externally staged Rancher image list and node-level pull capability; it does not download public images.

## 7. Ingress and administrative endpoints

Every cluster uses the `segment1` Contour ingress class and its assigned Segment1 Envoy VIP. Backend authorization is namespace-based: namespaces intentionally reachable from Segment1 Envoy carry `segment1.ingress/allow-backend=true`, and the Envoy egress policy limits traffic to approved backend ports. Service-to-pod translation is accounted for explicitly; for example, the Longhorn frontend Service port 80 reaches the UI pods on TCP/8000.

Identity NetworkPolicies also preserve controller and database bootstrap reachability. CloudNativePG operator traffic to each database instance-manager status endpoint on TCP/8000 is explicitly allowed. Before the primary PostgreSQL Cluster bundle starts, the prerequisite resources bundle also permits local CNPG cluster members—including replica join jobs and PgBouncer—to reach cluster members on TCP/5432; this prevents an ingress-policy isolation deadlock during creation of replicas 2 and 3. Cross-site replication remains separately restricted to the approved Segment1 CIDR. Default-deny selectors are scoped to application/database workloads rather than namespace-wide selectors that would also isolate the Keycloak or CloudNativePG operators. PgBouncer selectors use CNPG-owned labels (`cnpg.io/poolerName` / `cnpg.io/podRole`) rather than standard application labels that CNPG normalizes on generated pods.

Administrative naming is standardized:

| Context | Longhorn | Kiali |
| --- | --- | --- |
| `j64seg1opman` | `longhorn-man.dev.kube` | `kiali-man.dev.kube` |
| `j64seg1opdev` | `longhorn-j64.dev.kube` | `kiali-j64.dev.kube` |
| `j52seg1opdev` | `longhorn-j52.dev.kube` | `kiali-j52.dev.kube` |
| `r01seg1opdev` | `longhorn-r01.dev.kube` | `kiali-r01.dev.kube` |

Longhorn remains a ClusterIP service internally. Fleet creates a cert-manager `Certificate` and Contour `HTTPProxy` per cluster. The Longhorn proxy has an `ipAllowPolicy` permitting only `1.0.0.0/23` and routes to `longhorn-frontend:80`.

Kiali routes use the same naming convention and are served at the hostname root (`/`). External Prometheus is `https://j64seg1opman-prometheus.dev.kube`; external Grafana is `https://grafana.dev.kube`.

Rancher is exposed as `https://rancher.dev.kube` with a long-lived WebSocket-capable HTTPProxy because cluster agents use `wss://rancher.dev.kube/v3/connect/register`.

## 8. Service mesh design

Fleet installs Istio base, CNI, istiod, one east-west gateway per cluster, and Kiali. The environment shares the Istio trust material supplied outside Git. East-west VIPs are `.210`, `.220`, `.230`, and `.240` for management, j64, j52, and r01 respectively.

Automatic sidecar injection is disabled for platform/control namespaces including cert-manager, Segment1 ingress, MetalLB, Longhorn, Istio, identity, and monitoring. Application namespaces join the mesh only through an explicit reviewed label. This avoids accidentally intercepting controller, CSI, database, ingress, or host-agent traffic.

Istio remote Secrets are created after gateways are Ready by the controlled multicluster-secret workflow; they are not committed to Git.

## 9. Longhorn storage design

Longhorn uses validated worker storage at `/mnt/k8sdata`, expected to be a read/write XFS mount with at least `240 GiB` by default. The golden image contains the required Ubuntu 24.04 amd64 host dependencies. The runtime preflight is non-destructive: it verifies packages, iSCSI, filesystem, capacity, mount propagation, and a temporary write probe; it does not format or repartition disks.

The production storage class used by stateful workloads is `longhorn-xfs-retain`. CloudNativePG data and WAL volumes use Longhorn. `multipathd` is disabled where active because multipath can claim Longhorn devices.

Longhorn provides in-cluster volume replication and snapshots. Disaster recovery or off-cluster backup remains a separate operational requirement.

## 10. Identity high availability

```mermaid
flowchart LR
  USERS[Users and relying applications]
  DNS[Canonical identity FQDN]
  J64VIP[J64 ingress VIP\n1.0.0.215]
  J52VIP[J52 ingress VIP\n1.0.0.225]

  subgraph J64[j64seg1opdev]
    KC64[Keycloak\n3 when active / 0 when standby]
    PG64[CloudNativePG\nprimary or replica]
  end

  subgraph J52[j52seg1opdev]
    KC52[Keycloak\n3 when active / 0 when standby]
    PG52[CloudNativePG\nprimary or replica]
  end

  USERS --> DNS
  DNS -. active target .-> J64VIP
  DNS -. active target .-> J52VIP
  J64VIP --> KC64 --> PG64
  J52VIP --> KC52 --> PG52

  PG64 <-. asynchronous WAL; direction follows active primary .-> PG52

  SW[Journaled switch-identity workflow]
  SW --> PRE[Verify replication / exposure]
  PRE --> FENCE[Quiesce or hard-fence source]
  FENCE --> ROLE[Demote/promote database]
  ROLE --> FLEET[Switch runtime Fleet labels and reconcile]
  FLEET --> KC[Start target Keycloak and verify SNI/OIDC]
  KC --> CUT[Move canonical traffic]
  CUT --> VERIFY[Verify reverse replication / HA]
```

The canonical identity hostname is `opkeycloak.dev.jde.cybercom.ic.gov`.

J64 is the normal/home identity site and J52 is the normal/home warm site, but **runtime ownership is reversible**. After a successful planned switchover, either site may be the writable PostgreSQL primary and active Keycloak site. Only one site is writable and only one Keycloak site has serving endpoints at a time.

The physical `kmm.dev/identity=primary|secondary` label selects site-specific Fleet bundle families and does not represent the runtime active role. Runtime state is carried by `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-primary-site`, `kmm.dev/postgres-hibernation`, and the CloudNativePG distributed-topology fields.

The Keycloak `Certificate` and `HTTPProxy` are intentionally pre-staged on **both** sites, even when a site's `keycloak-instances=0`. This removes certificate issuance and HTTPProxy construction from the outage-critical path. The warm site can still return `no healthy upstream` because it intentionally has no Keycloak endpoints until promotion.

Both PostgreSQL clusters use CloudNativePG's distributed-topology fields (`replica.self`, `replica.primary`, and `replica.source`). A planned switchover demotes the current primary, transfers its demotion token to the target as a promotion token, and leaves the old site streaming from the new primary. It does not create two independent writable databases.

Cross-site PostgreSQL replication is asynchronous. Planned switchover fences application writes and waits for the target to replay the final source WAL position before demotion/promotion, minimizing RPO exposure. Unplanned failover may lose the most recent acknowledged writes and therefore requires an explicit RPO acknowledgement plus an external hard fence of the old source before promotion. The former primary remains hibernated/fenced until rebuilt from the surviving site.

Contour `HTTPProxy` routing uses the canonical FQDN/SNI, not a raw IP Host header. Direct site validation therefore uses `curl --resolve` with the canonical hostname and each site's ingress VIP. External DNS or hosts-file cutover is a separate final traffic step and can be controller-managed (`dns`) or explicitly operator-confirmed (`manual`).

The authoritative operator procedure for both planned directions, interrupted transitions, unplanned promotion, and standby rebuild is in [Operations and Lifecycle](OPERATIONS-AND-LIFECYCLE.md#8-identity-operations).

## 11. Observability architecture

Each cluster runs a Fleet-managed Elastic Agent DaemonSet and kube-state-metrics Deployment. The default design uses **four Elastic Fleet enrollment tokens**, one policy/token per cluster. This isolates policy, revocation, and data-stream identity by cluster.

Kiali is configured to use external Prometheus/Grafana rather than deploying another monitoring stack in this repository.

## 12. Time architecture

Chrony is a privileged `kube-system/chrony-client` DaemonSet because it adjusts the host clock. It is deliberately outside Fleet. Deployment succeeds only when every node has a selected source, positive stratum, and `Leap status: Normal`.

The implementation distinguishes network reachability from server correctness. An NTP server can answer UDP/123 but still be unusable if it advertises `LI=3`/unsynchronized or stratum 0.

## 13. RKE2 CIS and PodSecurity design

RKE2 CIS mode uses restricted defaults, but infrastructure components cannot all operate under the restricted profile. The repository therefore creates scoped privileged PSA exceptions for Rancher/Fleet system namespaces and the infrastructure namespaces that require host/network access. Application namespaces remain restricted unless explicitly approved.

Service-account token mounting is disabled where charts permit it, and namespace/mesh controls are validated before onboarding.

## 14. Rancher/Fleet compatibility controls

The baseline is pinned to Rancher `2.15.0`, bundled Fleet `0.15.2`, RKE2 `v1.35.6+rke2r1`, and Helm `4.0.0` or newer.

Required compatibility controls include:

- long-lived Rancher WebSocket route through Contour;
- scoped privileged PSA labels for Rancher/Fleet system namespaces;
- `KUBE_FEATURE_WatchListClient=false` on Fleet controllers/agents to avoid Kubernetes 1.35 watch-stream instability;
- private OCI registry DNS, CA trust, authentication, and GitJob RBAC;
- Fleet 0.15.2 OCI chart-source compatibility using `chart: oci://kubeharbor.dev.kube/k8mm-charts/<chart>`; validation **rejects bundle-anchor workarounds** used by older layouts.

## 15. GitLab Runner design

Fleet deploys GitLab Runner only to `j64seg1opman` through the `fleet-local` GitRepo. The official `gitlab-runner` chart is pinned to `0.92.1`, which maps to Runner `19.3.1`. The manager is `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner:v19.3.1`; the helper is `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1`; and validation jobs use the pinned Iron Bank Ansible image. Registry1's complete `ironbank/gitlab/gitlab-runner/...` hierarchy is retained in KubeHarbor.

The Iron Bank manager and helper security contexts use UID/GID `1001`. The manager uses `/usr/local/bin/tini`, global concurrency is limited to four, and each registered runner has request concurrency four.

The runner is non-privileged, namespace-scoped, restricted to KubeHarbor job/service images, and does not receive kubeconfigs or platform runtime Secrets. Its `glrt-*` authentication token and GitLab CA are seeded from protected files. GitLab remains the policy authority for runner tags, protection, locking, and project/group scope.

## 16. Failure domains

A failure should be classified before remediation:

- **management/control:** Rancher, Fleet, GitJob, management ingress;
- **supply chain:** GitLab, KubeHarbor, OCI/chart/image inventory;
- **network/name/trust:** DNS, routing, NTP, CA, TLS;
- **cluster runtime:** RKE2, CNI, node pressure, PSA;
- **mesh/ingress:** Istio, east-west gateway, Contour/Envoy, HTTPProxy;
- **storage:** Longhorn node/disk/CSI/volume;
- **identity/data:** CloudNativePG, Keycloak, replication, failover state;
- **monitoring:** Elastic Agent/Fleet, kube-state-metrics, external Prometheus/Grafana.

The troubleshooting document maps these failure domains to help-desk and engineering escalation procedures.

### Keycloak-to-PostgreSQL policy contract

Keycloak reaches CloudNativePG through `oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432`. NetworkPolicy authorization uses Keycloak Operator-owned pod labels (`app=keycloak`, `app.kubernetes.io/instance=opkeycloak`, `app.kubernetes.io/managed-by=keycloak-operator`) rather than unsupported custom label overrides. The PostgreSQL-side ingress authorization is deployed in the prerequisite PostgreSQL resources bundle so it is present before Keycloak starts.

With `cache=ispn` and `cache-stack=jdbc-ping`, PostgreSQL provides node discovery but does not replace direct Keycloak-to-Keycloak transport. The repository therefore explicitly permits only Keycloak server pods to exchange JGroups/Infinispan traffic on TCP/7800 (cluster transport) and TCP/57800 (FD_SOCK2 failure detection). These rules exist in both the primary and secondary Keycloak bundles because the application default-deny policy otherwise isolates those ports and can cause the three replicas to flap between Ready and NotReady/restart states.
