# Operations and Lifecycle

> **Baseline:** v2.2 — August 28, 2026  
> **Audience:** platform operators, systems administrators, SRE/operations personnel, and escalation engineers.

## 1. Operating model

Normal steady-state changes follow this loop:

1. change the intended Git branch;
2. run `validate-package`;
3. push to GitLab;
4. allow Fleet to reconcile;
5. validate BundleDeployment readiness and service-specific health;
6. revert Git if the change is not acceptable.

Do not treat Rancher UI red states as a reason to manually delete Bundles. First identify the failing dependency and the Git commit/branch Fleet is actually reconciling.

## 2. Daily health checks

Recommended daily/shift checks:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For storage-sensitive operations also run:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

`prepare-longhorn-nodes` is non-destructive and verifies the host storage contract.

## 3. Rancher and Fleet operations

### Fleet readiness

Healthy steady state means the intended GitRepos are Ready and all intended BundleDeployments are Active. Bundle dependencies are expressed by `kmm.dev/bundle` labels.

Inspect GitRepos:

```bash
kubectl --context j64seg1opman -A get gitrepos.fleet.cattle.io
```

Inspect bundles by workspace:

```bash
kubectl --context j64seg1opman -n fleet-local get bundles.fleet.cattle.io
kubectl --context j64seg1opman -n fleet-default get bundles.fleet.cattle.io
```

Inspect the actual branch/commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

### Kubernetes 1.35 Fleet compatibility

The baseline requires `KUBE_FEATURE_WatchListClient=false` on Fleet controllers and agents. Apply/verify with:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Do not remove this control until the pinned Rancher/Fleet combination is upgraded and the replacement has been validated against RKE2/Kubernetes 1.35 behavior.

### Rancher system repair

Use:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow validates the registry, refreshes CoreDNS/registry credentials, restores Rancher ingress, repairs PSA namespace labels, applies GitJob RBAC, enforces the WatchListClient compatibility setting, waits for Rancher/Fleet components, and forces GitRepo rescan. It intentionally avoids deleting healthy Rancher/Fleet resources.

## 4. GitOps deployment flow

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

Operational principle: correct the **source of truth** or the external dependency causing reconciliation failure. Direct changes to Fleet-owned resources are break-glass actions and may be reverted automatically.

## 5. Chrony operations

Chrony owns the host clock while deployed. It runs as a privileged DaemonSet and records the prior `systemd-timesyncd` state under `/var/lib/k8mm/chrony`.

Validate all clusters:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target one cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

View compact telemetry:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=50
```

A healthy node reports a selected source, positive stratum, and `Leap status: Normal`. The installer emits detailed `tracking`, `sources`, `ntpdata`, log, and event information when synchronization fails.

Supported removal:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

Do not delete the DaemonSet manually as the standard removal method; the supported command restores the saved host time-service state.

## 6. Longhorn operations

### Host contract

Default worker contract:

- path: `/mnt/k8sdata`;
- filesystem: XFS;
- minimum capacity: `240 GiB`;
- iSCSI available and active;
- shared root mount propagation;
- multipath disabled where it can claim Longhorn devices.

Validate:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

### Kubernetes checks

```bash
kubectl --context j64seg1opdev -n longhorn-system get pods -o wide
kubectl --context j64seg1opdev get storageclass
kubectl --context j64seg1opdev get pvc -A
```

The stateful identity workloads use `longhorn-xfs-retain`.

### Longhorn UI

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://longhorn-man.dev.kube` |
| `j64seg1opdev` | `https://longhorn-j64.dev.kube` |
| `j52seg1opdev` | `https://longhorn-j52.dev.kube` |
| `r01seg1opdev` | `https://longhorn-r01.dev.kube` |

Fleet creates the HTTPProxy/certificate. The proxy allows only source addresses in `1.0.0.0/23` and sends traffic to `longhorn-frontend:80`.

Use Longhorn snapshots/replicas for in-cluster operational recovery, but maintain a separately approved disaster-recovery/backup strategy if off-cluster recovery is required.

## 7. Istio and Kiali operations

Validate mesh components and namespace injection:

```bash
./scripts/istio/04-check-istio-system.sh --all
./scripts/istio/05-audit-namespace-injection.sh --all
```

Kiali URLs:

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://kiali-man.dev.kube` |
| `j64seg1opdev` | `https://kiali-j64.dev.kube` |
| `j52seg1opdev` | `https://kiali-j52.dev.kube` |
| `r01seg1opdev` | `https://kiali-r01.dev.kube` |

Kiali depends on the external Prometheus and Grafana endpoints configured in its values. A healthy Kiali pod can therefore still show degraded metrics if those external services or the Grafana credential Secret are unavailable.

Istio webhook CA fields are controller-managed runtime data. Fleet comparison rules intentionally ignore only the expected `caBundle` mutation rather than suppressing entire webhook objects.

## 8. Identity operations

### Identity HA operating model

The identity service is **bidirectional active/warm-standby** across J64 and J52. Either site can be the active site after a successful planned switchover. Only one PostgreSQL site is writable and only one Keycloak site serves user traffic at a time.

| Site | Segment1 ingress VIP | PostgreSQL replication VIP | Normal/home role | Runtime role after switchover |
| --- | --- | --- | --- | --- |
| `j64seg1opdev` | `1.0.0.215` | `1.0.0.216` | J64 identity site | active or warm standby |
| `j52seg1opdev` | `1.0.0.225` | `1.0.0.226` | J52 identity site | active or warm standby |

The static Fleet label `kmm.dev/identity=primary|secondary` is a **physical site/bundle-family selector** and is not swapped. Runtime ownership is controlled by `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-primary-site`, and the CloudNativePG distributed-topology fields.

The canonical user endpoint is:

```text
https://opkeycloak.dev.jde.cybercom.ic.gov
```

Contour routes this endpoint by FQDN/SNI. A raw request to `https://1.0.0.215` or `https://1.0.0.225` is not a valid Keycloak health test. The inactive site normally has zero Keycloak endpoints and may return `no healthy upstream`; that is expected. Use the canonical hostname or `identity-exposure-status`, which performs an SNI-aware direct OIDC probe.

The canonical Keycloak `Certificate` and `HTTPProxy` are pre-staged on **both** sites, including the warm site. Keycloak server replicas remain `0` on the standby until it becomes the switchover target.

### Command quick reference

```bash
# Discover current role and exposure state
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-transition-status

# Prove database replication and strict HA readiness
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha

# Planned bidirectional switch
./scripts/deploy-platform.sh switch-identity j64
./scripts/deploy-platform.sh switch-identity j52

# Recover an interrupted transition
./scripts/deploy-platform.sh resume-identity-transition
./scripts/deploy-platform.sh rollback-identity-transition   # planned, pre-demotion only

# Disaster recovery after an unplanned promotion
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
./scripts/deploy-platform.sh rebuild-identity-standby <site>
```

`failover-identity` and `failback-identity` remain compatibility commands, but new operations should use `switch-identity j64|j52` so the intended target is explicit.

### Preflight before every planned switchover

Do not begin with an incomplete journal. Run:

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

Required conditions:

1. `identity-transition-status` is absent or terminal (`complete`, `complete-degraded`, or `rolled-back`). A `running` or `failed` non-terminal journal must be resumed before any opposite-direction switch.
2. Fleet is active and reconciled. A planned transition will refuse to start if the downstream GitRepo was already paused.
3. The current source PostgreSQL site is reachable and writable.
4. The target PostgreSQL site is in recovery and streaming from the source within the configured lag/message-age thresholds.
5. Both sites are enrolled in the distributed CloudNativePG topology.
6. The target Keycloak Service, Certificate, and HTTPProxy already exist and are valid. The warm site may still have zero Keycloak endpoints before cutover.

If distributed-topology enrollment is missing during the initial J64 to J52 setup, run:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate-identity-ha
```

The J64-to-J52 planned path may auto-enroll this initial state when `IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY=true`. A later reverse switch assumes the former primary has already become a healthy distributed standby; if not, repair/rebuild the standby first.

### Traffic cutover modes

The database/Keycloak transition and external client traffic cutover are deliberately separated.

**DNS mode (default / production):** the controller running the script must resolve `opkeycloak.dev.jde.cybercom.ic.gov` only to the target site ingress VIP before the transition completes. Use authoritative DNS automation or `IDENTITY_ACTIVATE_TARGET_HOOK` when available.

**Manual mode (lab / externally managed hosts files):** use this when DNS or a Windows/Linux hosts file is changed outside `k8admin01`. Manual mode still requires the target SNI/TLS/OIDC probe to pass; it only stops treating the controller's local resolver as authoritative.

```bash
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<target-site>
```

For a local hosts-file test, map the canonical FQDN to the **active target** only:

```text
# J64 active
1.0.0.215 opkeycloak.dev.jde.cybercom.ic.gov

# J52 active
1.0.0.225 opkeycloak.dev.jde.cybercom.ic.gov
```

After editing a client hosts file, test the canonical URL, not the IP address:

```text
https://opkeycloak.dev.jde.cybercom.ic.gov
```

### Planned switchover: J64 to J52

Use this when `identity-active-site` reports `j64seg1opdev` and J52 replication/HA preflight is healthy.

**DNS-managed traffic:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned

./scripts/deploy-platform.sh switch-identity j52

unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
```

When the controller reaches the traffic-activation gate, update the canonical identity DNS record to `1.0.0.225` or let the configured activation hook do so. The workflow waits for the canonical route to converge before completing.

**Externally managed DNS/hosts:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev

./scripts/deploy-platform.sh switch-identity j52

unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
unset IDENTITY_TRAFFIC_CUTOVER_MODE IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

During the cutover, change the external/client mapping of the canonical FQDN to `1.0.0.225` after the target exposure probe is healthy.

Expected steady state after completion:

- J52: PostgreSQL writable; Keycloak `3` instances; canonical Keycloak endpoint healthy on `1.0.0.225`.
- J64: PostgreSQL streaming replica; Keycloak `0` instances; raw/canonical traffic to J64 may report `no healthy upstream` while it is standby.
- Journal: `status=complete`, `stage=complete`.

### Planned switchover: J52 back to J64

Do not start the reverse direction until the previous J64-to-J52 journal is terminal and `verify-database-replication` proves reverse replication from J52 to J64.

**DNS-managed traffic:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned

./scripts/deploy-platform.sh switch-identity j64

unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
```

Update the canonical identity DNS record to `1.0.0.215` when the target traffic gate is reached.

**Externally managed DNS/hosts:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j64seg1opdev

./scripts/deploy-platform.sh switch-identity j64

unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
unset IDENTITY_TRAFFIC_CUTOVER_MODE IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

Expected steady state after completion:

- J64: PostgreSQL writable; Keycloak `3` instances; canonical Keycloak endpoint healthy on `1.0.0.215`.
- J52: PostgreSQL streaming replica; Keycloak `0` instances.
- Journal: `status=complete`, `stage=complete`.

### What the planned workflow does

A planned switchover is transactional and journaled in `fleet-default/kmm-identity-transition-journal`; a Kubernetes Lease prevents competing transitions. The high-level sequence is:

1. Verify replication and distributed-topology readiness.
2. Verify the target's pre-staged Service/Certificate/HTTPProxy.
3. Pause downstream Fleet and record the original pause state.
4. Quiesce source Keycloak traffic and scale source Keycloak to zero.
5. Disable source database connections, terminate application sessions, checkpoint, and wait for the target to replay the final source WAL LSN.
6. Demote the source and obtain the CloudNativePG demotion token.
7. Promote the target using the token.
8. Switch runtime Fleet role labels.
9. Restore Fleet and wait for the post-promotion identity bundles to reconcile (`fleet-target-reconciled`).
10. Start target Keycloak, wait for Certificate/HTTPProxy health, and run the direct SNI/OIDC target probe.
11. Activate canonical client traffic using DNS mode or explicit manual confirmation.
12. Verify reverse PostgreSQL replication and strict identity HA.
13. Mark the journal `complete` and release the transition Lease.

Supported optional external hooks are:

- `IDENTITY_QUIESCE_SOURCE_HOOK`
- `IDENTITY_HARD_FENCE_SOURCE_HOOK`
- `IDENTITY_ACTIVATE_TARGET_HOOK`
- `IDENTITY_RESTORE_SOURCE_HOOK`

`IDENTITY_SWITCHOVER_HOOK` and `IDENTITY_FAILOVER_HOOK` are compatibility aliases.

### Interrupted planned transition: resume versus rollback

Never start a second transition while the journal is non-terminal. Inspect it:

```bash
./scripts/deploy-platform.sh identity-transition-status
```

Resume the **recorded target**, not the direction you eventually want:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
unset IDENTITY_SWITCHOVER_CONFIRM
```

If the journal is waiting at or after `target-keycloak-ready` and external DNS/hosts is managed outside the controller, use manual traffic confirmation while resuming:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<recorded-target-site>

./scripts/deploy-platform.sh resume-identity-transition

unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_TRAFFIC_CUTOVER_MODE IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

Automatic rollback is supported only for a **planned** transition before source database demotion:

```bash
./scripts/deploy-platform.sh rollback-identity-transition
```

At or after `source-demoted` / `target-promoted`, do not manually reverse CNPG replica fields, Fleet role labels, Fleet pause state, or traffic. Resume the journal and let the recorded stage drive recovery.

### Post-planned-switchover validation

Run all of the following after either direction:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate
```

The active site's `identity-exposure-status` should show ready endpoints, `certificateReady=True`, a valid HTTPProxy on that site's ingress VIP, and `directOIDC=healthy`. The standby site is expected to have zero Keycloak endpoints.

### Unplanned failover: source site unavailable

Use unplanned mode only when the current writable site is unavailable or cannot be trusted to participate in a planned demotion. Cross-site PostgreSQL replication is asynchronous, so unplanned promotion can lose the most recent acknowledged transactions. The workflow therefore requires an explicit RPO acknowledgement and **hard fencing of the old source** to prevent split brain.

The supported unplanned workflow still requires `j64seg1opman`/Rancher-Fleet management access plus connectivity to the surviving target cluster because the controller reads/writes Fleet role labels, the transition journal, and the Kubernetes Lease from the management cluster. If the management cluster is unavailable, restore the management control plane first; this repository does not define a management-less direct database promotion procedure.

Before promotion:

1. Determine the surviving target site.
2. Confirm the old source is truly unavailable or unsafe.
3. Review the target's last replay/receiver evidence. The workflow records the target replay LSN before promotion.
4. Establish a real hard-fence action for the old source. Examples include a controlled network isolation, workload/cluster power fence, or another approved mechanism that prevents the old primary from accepting client/database traffic if it comes back. The fence hook must be executable and must succeed before target promotion.
5. If there is an existing non-terminal journal, **resume that journal instead of starting a new failover**.

Example: J64 is lost and J52 must be promoted:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/approved/path/fence-j64.sh

# Use manual traffic mode when DNS/hosts is managed outside the controller.
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev

./scripts/deploy-platform.sh switch-identity j52

unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
unset IDENTITY_ALLOW_UNPLANNED_FAILOVER IDENTITY_UNPLANNED_RPO_ACK
unset IDENTITY_HARD_FENCE_SOURCE_HOOK
unset IDENTITY_TRAFFIC_CUTOVER_MODE IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

Example: J52 is lost while active and J64 must be promoted:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/approved/path/fence-j52.sh
export IDENTITY_TRAFFIC_CUTOVER_MODE=manual
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j64seg1opdev

./scripts/deploy-platform.sh switch-identity j64
```

A successful unplanned promotion intentionally ends in:

```text
status=complete-degraded
stage=complete-degraded
```

The old source is left fenced/hibernated. Do **not** reconnect it as a peer and do not attempt a planned failback yet.

Validate the surviving service in degraded mode:

```bash
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
```

Move canonical traffic to the surviving active site only after its direct OIDC exposure is healthy.

### Rebuild the former primary after an unplanned promotion

The former primary may contain a divergent timeline and must not simply be brought back as a writable/streaming peer. Rebuild it from the surviving active site using the supported destructive workflow.

The rebuild deletes/recreates the old CNPG Cluster/PVC objects but intentionally leaves Longhorn `Retain` PV data as a recovery artifact. It requires two explicit gates:

```bash
export IDENTITY_REBUILD_CONFIRM=<former-primary-site>
export IDENTITY_REBUILD_DELETE_STORAGE=true

./scripts/deploy-platform.sh rebuild-identity-standby <former-primary-site>

unset IDENTITY_REBUILD_CONFIRM IDENTITY_REBUILD_DELETE_STORAGE
```

The rebuild workflow proves the peer is writable, synchronizes replication TLS, uses `pg_basebackup`, recreates a read-only standby, exchanges fresh replication trust material, re-enrolls distributed topology, and does not succeed until replication and strict HA validation pass.

After rebuild:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh identity-exposure-status all
```

Only after these strict checks pass should another planned `switch-identity` be attempted.

### Operational rules that prevent split brain or accidental outage

- Never run an opposite-direction `switch-identity` while a non-terminal transition journal exists.
- Never manually delete the transition Lease or journal merely to bypass a failed stage.
- Never manually swap `kmm.dev/identity=primary|secondary`; those are physical site selectors.
- Never manually patch CNPG `replica.primary`, `replica.self`, promotion tokens, or demotion tokens during an active journal.
- Never unpause Fleet during an interrupted transition unless the recorded workflow does it; the controller preserves the original Fleet pause state.
- A raw ingress IP is not a Keycloak health check; use the canonical FQDN/SNI path.
- `no healthy upstream` on the warm site is expected when Keycloak instances are `0`.
- An unplanned failover requires a proven hard fence before promotion. If the old writable site can return and accept writes, do not promote the peer.
- After an unplanned promotion, rebuild the former primary before any failback.

## 9. Elastic observability operations

The default model uses one Elastic Agent DaemonSet and one kube-state-metrics Deployment per cluster, with one Fleet enrollment policy/token per cluster. A compatibility `ExternalName` Service named `kube-state-metrics` is placed in `elastic-agent-system` so the Elastic Kubernetes integration's short-name scrape target resolves to `kube-state-metrics.elastic-monitoring.svc.cluster.local`. kube-state-metrics explicitly collects `endpointslices` instead of the deprecated core/v1 `endpoints` resource on Kubernetes v1.33+.

Validate:

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If enrollment fails, confirm Fleet Server URL, CA/SAN correctness, token-to-policy mapping, network reachability, and the `elastic-agent` Secret seeded on the affected cluster.

## 10. GitLab Runner operations

The Runner is Fleet-owned in `gitlab-runner-system` on `j64seg1opman`.

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get pods
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

Rotate the runner authentication token or GitLab CA by updating the protected input file and rerunning `./scripts/deploy-platform.sh seed-secrets`. Do not commit the `glrt-*` token. GitLab controls the runner tag, protected status, locking, and project/group scope; the cluster bundle controls runtime version, executor policy, and the exact approved Harbor job-image allowlist.

Every pipeline now starts with `runner:canary`. That job intentionally proves the Kubernetes executor path rather than only manager registration: job Pod admission, helper pull, approved Ansible image pull, repository clone, restricted security context/RBAC, and artifact upload must all work before `validate:gitops-package` runs. Validation selects a Python interpreter by importing the required PyYAML APIs in isolated mode, wraps that exact runtime as the job-local `python3`, and then executes repository Python checks with safe-path isolation; a shadow `yaml` module in the checkout must not be accepted.

## 11. Certificate operations

cert-manager uses the Segment1 ClusterIssuer seeded through the protected CA material. Check certificate status:

```bash
kubectl --context j64seg1opman get certificates -A
kubectl --context j64seg1opman get clusterissuer
```

Repeat for the affected cluster. Do not disable TLS verification to work around CA-chain failures; fix trust or certificate identity.

Cross-site PostgreSQL replication certificates are also an operational lifecycle item. `verify-database-replication` compares the generated source certificate/CA fingerprints with the copied peer Secrets and rejects certificates inside the configured minimum-validity window. Rotate the source certificate through the approved certificate process, rerun the identity Secret synchronization/enablement path, and prove fingerprint agreement plus bidirectional replication before a maintenance window. Do not wait for switchover day to discover an expired replication certificate.

## 12. Ingress and HTTPProxy operations

List Contour proxies:

```bash
kubectl --context j64seg1opdev get httpproxy -A
```

Inspect a proxy:

```bash
kubectl --context j64seg1opdev -n <namespace> describe httpproxy <name>
```

An `invalid` HTTPProxy usually indicates a missing backend Service/port, missing TLS Secret, invalid route definition, or ingress-class/dependency problem. Resolve the underlying reference rather than deleting the proxy.

## 13. CIS/PodSecurity lifecycle

Rancher/Fleet and several platform components require scoped privileged PSA namespaces. Keep exceptions limited to system namespaces and prepare Rancher/Fleet namespaces before cluster import. Application namespaces should remain restricted unless a reviewed workload requirement says otherwise.

## 14. Upgrade lifecycle

For every component upgrade:

1. confirm RKE2/Rancher/Fleet compatibility;
2. obtain/promote images through the approved air-gap workflow;
3. stage the exact Helm chart archive;
4. update the package allowlist, OCI inventory, and checksums;
5. review chart defaults for newly introduced transitive images;
6. update values and compatibility controls;
7. run `validate-package`;
8. publish immutable OCI charts;
9. deploy through Git/Fleet;
10. validate all service-specific gates.

The shared Helm wrapper requires Helm 4 and uses `--rollback-on-failure`; the deprecated `--atomic` CLI alias is not part of the supported wrapper path.

## 15. Backup and recovery boundaries

- GitLab: back up repository data and branch history according to GitLab operations policy.
- KubeHarbor: preserve registry projects/artifacts and CA configuration.
- Rancher/Fleet: preserve Rancher state according to the management-cluster recovery plan.
- RKE2: maintain the approved etcd snapshot/recovery process outside this repository.
- Longhorn: snapshots/replicas are in-cluster; define off-cluster backup separately where required.
- Identity: cross-site replication and Longhorn are **not** substitutes for off-cluster backup/PITR. This repository does not invent an object-store target or credentials; production authorization requires an approved off-cluster CloudNativePG backup destination, retention policy, restore test, and documented PITR RPO/RTO. Until that is supplied, this remains an explicit recovery-control gap rather than a silently fabricated configuration.
- protected configuration: securely back up credential files, CA material, and Istio CA directories outside Git.

## 16. Change-management evidence

For significant changes retain:

- Git commit and branch deployed;
- `validate-package` output;
- Fleet GitRepo commit and bundle state;
- relevant Rancher/Fleet/Longhorn/identity validation output;
- diagnostic bundle for failed changes;
- security/exception review when privileged namespace or certificate behavior changes.
