#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"
PHASE="${1:-help}"
if (($#)); then shift; fi
FLEET_DIR="${SCRIPT_DIR}/management/fleet"

run_step(){ local label="$1"; shift; echo; log "--- ${label} ---"; "$@"; }
validate_package(){ run_step "Package and Fleet layout validation" "${SCRIPT_DIR}/validate-deployment-package.sh"; }
bootstrap_management(){ run_step "Bootstrap management cluster and Rancher" "${FLEET_DIR}/00-bootstrap-management.sh"; }
preflight_fleet(){ run_step "Fleet runtime and downstream-cluster preflight" "${FLEET_DIR}/00-preflight-fleet.sh"; }
seed_secrets(){ run_step "Seed runtime Secrets and Istio CA material" "${FLEET_DIR}/01-seed-runtime-secrets.sh"; }
validate_rancher_system(){ run_step "Validate Rancher ingress and Fleet system components" "${SCRIPT_DIR}/management/rancher/02-validate-rancher-system.sh"; }
repair_rancher_system(){ run_step "Repair Rancher/Fleet system components" "${SCRIPT_DIR}/management/rancher/03-repair-rancher-system.sh"; }
prepare_rancher_imports(){ run_step "Prepare Rancher/Fleet PSA namespaces on all clusters" "${SCRIPT_DIR}/management/rancher/00-prepare-rancher-psa.sh" --all; }
repair_rancher_psa(){ run_step "Repair Rancher/Fleet PSA namespaces and restart agents" "${SCRIPT_DIR}/management/rancher/00-prepare-rancher-psa.sh" --all --restart; }
apply_rancher_connectivity(){ run_step "Apply Rancher long-lived WebSocket route" kubectl --context j64seg1opman apply -f "${ROOT_DIR}/yaml/j64/seg1opman-cluster/resources/rancher-j64manager-resources-v1.yaml"; }
configure_fleet_watchlist(){ run_step "Configure Fleet Kubernetes 1.35 WatchList compatibility" "${SCRIPT_DIR}/management/rancher/04-configure-fleet-watchlist.sh" --all --wait; }
validate_rancher_imports(){ run_step "Validate imported Rancher cluster connectivity" "${SCRIPT_DIR}/management/rancher/05-validate-imported-clusters.sh" --wait; }
repair_rancher_agents(){ configure_management_dns; apply_fleet_gitjob_rbac; apply_rancher_connectivity; repair_rancher_psa; configure_fleet_watchlist; validate_rancher_imports; }
validate_rancher_registry(){ run_step "Validate external Rancher image inventory and node pulls" "${SCRIPT_DIR}/management/preflight/validate-rancher-registry.sh" preflight; }
configure_management_dns(){ run_step "Configure and validate management-cluster private DNS" "${SCRIPT_DIR}/core/01-patch-coredns.sh" j64 seg1opman; }
apply_fleet_gitjob_rbac(){ run_step "Apply Fleet GitJob event-writer RBAC" kubectl --context j64seg1opman apply -f "${ROOT_DIR}/yaml/resources/fleet-gitjob-events-rbac-v1.yaml"; }
validate_fleet_oci(){ run_step "Validate Fleet in-cluster OCI registry access" "${FLEET_DIR}/02-validate-fleet-oci.sh"; }
register_fleet(){ validate_rancher_system; run_step "Label Fleet clusters" "${FLEET_DIR}/02-label-fleet-clusters.sh"; run_step "Register Fleet GitRepos" "${FLEET_DIR}/03-bootstrap-gitrepos.sh"; }
enable_identity_secondary(){ run_step "Enable warm identity secondary" "${FLEET_DIR}/05-enable-identity-secondary.sh"; }
validate_fleet(){ run_step "Validate Fleet reconciliation" "${FLEET_DIR}/04-validate-fleet.sh"; }
validate_identity_ha(){ run_step "Validate two-site identity state" "${FLEET_DIR}/06-validate-identity-ha.sh" "$@"; }
verify_database_replication(){ run_step "Verify identity database replication" "${SCRIPT_DIR}/management/failover/verify-database-replication.sh" "$@"; }
switch_identity(){
  local target="${1:-${IDENTITY_SWITCHOVER_CONFIRM:-}}"
  case "${target}" in
    j64) target=j64seg1opdev ;;
    j52) target=j52seg1opdev ;;
  esac
  [[ "${target}" == j64seg1opdev || "${target}" == j52seg1opdev ]] || \
    die "Specify identity target j64seg1opdev or j52seg1opdev (or set IDENTITY_SWITCHOVER_CONFIRM to that target)."
  run_step "Switch identity to ${target}" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" "${target}"
}
failover_identity(){
  # Compatibility entry point. Historically this always meant J64->J52.
  # When a target/confirmation is supplied, honor it so operators can use one
  # command for either planned direction without silently forcing J52.
  local target="${1:-${IDENTITY_SWITCHOVER_CONFIRM:-j52seg1opdev}}"
  switch_identity "${target}"
}
failback_identity(){ run_step "Switch identity to j64seg1opdev" "${SCRIPT_DIR}/management/failover/failback-to-j64.sh" "$@"; }
identity_active_site(){ run_step "Show active identity site" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" active; }
identity_exposure_status(){ run_step "Show identity exposure state" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" exposure "${1:-all}"; }
identity_transition_status(){ run_step "Show identity transition journal" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" status; }
resume_identity_transition(){ run_step "Resume identity transition" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" resume; }
rollback_identity_transition(){ run_step "Rollback pre-demotion identity transition" "${SCRIPT_DIR}/management/failover/switchover-identity.sh" rollback; }
rebuild_identity_standby(){ run_step "Rebuild identity standby from active site" "${SCRIPT_DIR}/management/failover/rebuild-identity-standby.sh" "$@"; }
install_cluster_time(){ run_step "Install and validate Chrony across all clusters" "${SCRIPT_DIR}/management/preflight/cluster-time.sh" --all; }
validate_cluster_time(){ run_step "Validate Chrony synchronization across all clusters" "${SCRIPT_DIR}/management/preflight/cluster-time.sh" --all --verify-only; }
uninstall_cluster_time(){ run_step "Remove Chrony and restore host time service across all clusters" "${SCRIPT_DIR}/management/preflight/cluster-time.sh" --all --uninstall; }
prepare_longhorn_nodes(){ run_step "Validate Longhorn storage on all worker nodes" "${SCRIPT_DIR}/management/preflight/longhorn-storage-preflight.sh" --all; }
validate_monitoring(){ run_step "Validate Elastic Agent across all clusters" "${SCRIPT_DIR}/monitoring/02-validate-elastic-agent.sh" --all; }

case "${PHASE}" in
  validate-package) validate_package ;;
  bootstrap-management) validate_package; bootstrap_management ;;
  preflight-fleet) preflight_fleet ;;
  validate-rancher-registry) validate_rancher_registry ;;
  configure-management-dns) configure_management_dns ;;
  validate-fleet-oci) validate_fleet_oci ;;
  validate-rancher-system) validate_rancher_system ;;
  repair-rancher-system) repair_rancher_system ;;
  prepare-rancher-imports) prepare_rancher_imports ;;
  repair-rancher-psa) repair_rancher_psa ;;
  configure-fleet-watchlist) configure_fleet_watchlist ;;
  validate-rancher-imports) validate_rancher_imports ;;
  repair-rancher-agents) repair_rancher_agents ;;
  seed-secrets) seed_secrets ;;
  fleet) register_fleet ;;
  enable-identity-secondary) enable_identity_secondary ;;
  validate) validate_fleet ;;
  validate-identity-ha) validate_identity_ha "$@" ;;
  verify-database-replication) verify_database_replication "$@" ;;
  switch-identity) switch_identity "$@" ;;
  failover-identity) failover_identity "$@" ;;
  failback-identity) failback_identity "$@" ;;
  identity-active-site) identity_active_site ;;
  identity-exposure-status) identity_exposure_status "$@" ;;
  identity-transition-status) identity_transition_status ;;
  resume-identity-transition) resume_identity_transition ;;
  rollback-identity-transition) rollback_identity_transition ;;
  rebuild-identity-standby) rebuild_identity_standby "$@" ;;
  install-cluster-time) install_cluster_time ;;
  validate-cluster-time) validate_cluster_time ;;
  uninstall-cluster-time) uninstall_cluster_time ;;
  prepare-longhorn-nodes) prepare_longhorn_nodes ;;
  validate-monitoring) validate_monitoring ;;
  host-preflight) install_cluster_time; prepare_longhorn_nodes ;;
  onboard) repair_rancher_agents; preflight_fleet; seed_secrets; install_cluster_time; prepare_longhorn_nodes; register_fleet ;;
  all) validate_package; bootstrap_management; repair_rancher_agents; preflight_fleet; seed_secrets; install_cluster_time; prepare_longhorn_nodes; register_fleet; validate_fleet; enable_identity_secondary; validate_fleet; validate_identity_ha; validate_monitoring ;;
  help|-h|--help)
    cat <<USAGE
Usage: $0 <phase>

  validate-package           Static repository/package validation
  bootstrap-management      Install management prerequisites and Rancher on j64seg1opman
  preflight-fleet            Validate all contexts and protected runtime inputs
  validate-rancher-registry  Validate the external v2.15.0 image list in Harbor and node pulls
  configure-management-dns   Render CoreDNS private-zone forwarders and validate Harbor DNS from a Pod
  validate-fleet-oci         Validate Fleet Pod DNS, Harbor CA trust, and OCI authentication
  validate-rancher-system    Validate Rancher WebSockets, webhook, Fleet, GitJob, CRDs, and local object
  repair-rancher-system      Repair registry, ingress, PSA namespaces, agents, and Helm operations
  prepare-rancher-imports    Pre-create privileged Rancher/Fleet namespaces on all clusters
  repair-rancher-psa         Relabel Rancher/Fleet namespaces and restart existing agents
  configure-fleet-watchlist  Set KUBE_FEATURE_WatchListClient=false on Fleet controllers/agents
  validate-rancher-imports   Wait for imported clusters and cattle-cluster-agent connectivity
  repair-rancher-agents      Apply ingress, PSA, Fleet WatchList, and connectivity fixes
  seed-secrets               Seed runtime Secrets on both identity sites and Istio cacerts
  fleet                      Validate Rancher/Fleet, then label clusters and create GitRepos
  enable-identity-secondary  Copy CNPG replication TLS and enable j52 warm standby
  validate                   Validate GitRepo and BundleDeployment readiness
  validate-identity-ha [--allow-degraded]
                             Strictly validate Keycloak/PostgreSQL HA; degraded mode is explicit
  verify-database-replication [source target]
                             Verify DNS/VIP, TLS certificates, WAL receiver/sender, age, and byte lag
  switch-identity <j64|j52|site>
                             Bidirectional planned identity switch to J64 or J52
  failover-identity [target] Compatibility alias; defaults to J52 but honors target/IDENTITY_SWITCHOVER_CONFIRM
  failback-identity          Compatibility alias for switching to J64
  identity-active-site       Show Fleet-declared active and standby identity sites
  identity-exposure-status [all|j64|j52]
                             Show Keycloak Service/endpoints/cert/proxy/direct-OIDC state per site
  identity-transition-status Show the persistent switchover journal and next safe action
  resume-identity-transition Resume the last incomplete switchover from its recorded stage
  rollback-identity-transition
                             Roll back a planned transition only before source database demotion
  rebuild-identity-standby <site>
                             Destructively re-clone a fenced former primary using pg_basebackup
  install-cluster-time       Deploy Chrony and require synchronized time on all four clusters
  validate-cluster-time      Validate Chrony source/stratum/leap state without changing it
  uninstall-cluster-time     Remove Chrony and restore the saved host time-service state
  prepare-longhorn-nodes     Validate Longhorn prerequisites and /mnt/k8sdata on worker nodes
  validate-monitoring        Validate Elastic Agent and kube-state-metrics on all clusters
  host-preflight             Install Chrony and validate Longhorn storage on worker nodes
  onboard                    Repair Rancher/Fleet agents, preflight, seed Secrets, host preflight, and register Fleet
  all                        Run the complete workflow; requires all four clusters already reachable
USAGE
    ;;
  *) die "Unknown phase: ${PHASE}. Run $0 help." ;;
esac
