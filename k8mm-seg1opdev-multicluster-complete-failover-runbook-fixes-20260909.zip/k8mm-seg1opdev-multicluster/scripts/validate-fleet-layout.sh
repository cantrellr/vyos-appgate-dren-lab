#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"
require_cmd python3

python3 -P - "${ROOT_DIR}" <<'PY2'
from pathlib import Path
import ipaddress
import re
import sys
import tarfile
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML is required for Fleet layout validation')

root = Path(sys.argv[1])
bundle_root = root / 'fleet' / 'bundles'
local_bundle_root = root / 'fleet' / 'local-bundles'
fleet_files = sorted(bundle_root.glob('*/fleet.yaml'))
local_fleet_files = sorted(local_bundle_root.glob('*/fleet.yaml'))
expected = {
    'cert-manager', 'cert-manager-config', 'metallb', 'metallb-config',
    'contour-segment1', 'contour-segment1-policies',
    'longhorn', 'longhorn-config', 'longhorn-ui',
    'oppostgres-operator', 'oppostgres', 'oppostgres-resources', 'oppostgres-replica',
    'opkeycloak-operator', 'opkeycloak', 'opkeycloak-secondary',
    'istio-base', 'istio-cni', 'istiod', 'istio-eastwestgateway', 'istio-eastwestgateway-config',
    'kiali-operator', 'kiali', 'kiali-resources',
    'kube-state-metrics', 'kube-state-metrics-alias', 'elastic-agent', 'gitlab-runner',
}
if len(fleet_files) != len(expected):
    raise SystemExit(f'Expected {len(expected)} downstream/common Fleet bundles; found {len(fleet_files)}')

local_expected = {
    'bootstrap-cert-manager-ready',
    'bootstrap-cert-manager-config-ready',
    'bootstrap-metallb-ready',
    'bootstrap-metallb-config-ready',
    'bootstrap-contour-segment1-ready',
}

# Rancher v2.15.0 bundles Fleet v0.15.2. In that implementation, the
# bundlereader queues a remote chart only when HelmOptions.Chart is non-empty.
# Keep the OCI URL under helm.chart for this pinned runtime even though newer
# Fleet documentation prefers helm.repo for OCI sources.
expected_oci_charts = {
    '10-cert-manager': ('oci://kubeharbor.dev.kube/k8mm-charts/cert-manager', '1.5.14'),
    '20-metallb': ('oci://kubeharbor.dev.kube/k8mm-charts/metallb', '0.15.2'),
    '31-contour-segment1': ('oci://kubeharbor.dev.kube/k8mm-charts/contour', '21.1.4'),
    '40-longhorn': ('oci://kubeharbor.dev.kube/k8mm-charts/longhorn', '1.12.1'),
    '50-cnpg-operator': ('oci://kubeharbor.dev.kube/k8mm-charts/cloudnative-pg', '0.29.0'),
    '60-istio-base': ('oci://kubeharbor.dev.kube/k8mm-charts/base', '1.30.1'),
    '61-istio-cni': ('oci://kubeharbor.dev.kube/k8mm-charts/cni', '1.30.1'),
    '62-istiod': ('oci://kubeharbor.dev.kube/k8mm-charts/istiod', '1.30.1'),
    '63-eastwest-gateway': ('oci://kubeharbor.dev.kube/k8mm-charts/gateway', '1.30.1'),
    '64-kiali-operator': ('oci://kubeharbor.dev.kube/k8mm-charts/kiali-operator', '2.27.0'),
    '65-kiali-server': ('oci://kubeharbor.dev.kube/k8mm-charts/kiali-server', '2.27.0'),
    '70-kube-state-metrics': ('oci://kubeharbor.dev.kube/k8mm-charts/kube-state-metrics', '6.1.0'),
    '71-elastic-agent': ('oci://kubeharbor.dev.kube/k8mm-charts/elastic-agent', '9.4.2'),
    '72-gitlab-runner': ('oci://kubeharbor.dev.kube/k8mm-charts/gitlab-runner', '0.92.1'),
}
if len(local_fleet_files) != len(local_expected):
    raise SystemExit(
        f'Expected {len(local_expected)} management bootstrap-contract bundles; '
        f'found {len(local_fleet_files)}'
    )

bundle_labels = set()
bundle_names = set()
parsed = {}
for path in list((root/'fleet').rglob('*.yaml')) + list((root/'fleet').rglob('*.yml')):
    # Helm templates are Go-template sources and are not valid standalone YAML
    # until Helm renders them. Validate all Fleet/config/value YAML separately.
    if 'templates' in path.parts and 'chart' in path.parts:
        continue
    try:
        list(yaml.safe_load_all(path.read_text(encoding='utf-8')))
    except Exception as exc:
        raise SystemExit(f'Invalid YAML {path.relative_to(root)}: {exc}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    parsed[path.parent.name] = data
    name = data.get('name')
    label = (data.get('labels') or {}).get('kmm.dev/bundle')
    if not name or not label:
        raise SystemExit(f'{path.relative_to(root)}: missing bundle name or kmm.dev/bundle label')
    if 'overrideTargets' in data:
        raise SystemExit(f'{path.relative_to(root)}: overrideTargets is not a Fleet field; use targetCustomizations')
    if '${ get .ClusterLabels' in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{path.relative_to(root)}: cluster-label templates belong in values/manifests, not fleet.yaml fields')
    bundle_names.add(name)
    bundle_labels.add(label)
    helm = data.get('helm') or {}
    repo = helm.get('repo')
    chart = helm.get('chart')
    if repo:
        raise SystemExit(
            f'{path.relative_to(root)}: helm.repo is prohibited for this Fleet v0.15.2 baseline; '
            'use the approved OCI URL in helm.chart so the remote chart is actually loaded'
        )
    if path.parent.name in expected_oci_charts:
        expected_chart, expected_version = expected_oci_charts[path.parent.name]
        if chart != expected_chart:
            raise SystemExit(
                f'{path.relative_to(root)}: expected helm.chart {expected_chart!r}; found {chart!r}'
            )
        if str(helm.get('version')) != expected_version:
            raise SystemExit(
                f'{path.relative_to(root)}: expected chart version {expected_version!r}; '
                f'found {helm.get("version")!r}'
            )
        if not helm.get('releaseName'):
            raise SystemExit(f'{path.relative_to(root)}: external OCI bundle is missing helm.releaseName')
        if helm.get('valuesFiles') != ['values.yaml']:
            raise SystemExit(
                f'{path.relative_to(root)}: external OCI bundle must reference only values.yaml; '
                f'found {helm.get("valuesFiles")!r}'
            )
    elif chart and str(chart).startswith('oci://'):
        raise SystemExit(f'{path.relative_to(root)}: unexpected OCI chart bundle {chart}')

if bundle_names != expected:
    raise SystemExit(f'Fleet bundle name mismatch. Missing={sorted(expected-bundle_names)} extra={sorted(bundle_names-expected)}')

local_names = set()
local_labels = set()
local_parsed = {}
for path in local_fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    local_parsed[path.parent.name] = data
    name = data.get('name')
    label = (data.get('labels') or {}).get('kmm.dev/bundle')
    if not name or not label:
        raise SystemExit(f'{path.relative_to(root)}: missing bundle name or kmm.dev/bundle label')
    local_names.add(name)
    local_labels.add(label)

if local_names != local_expected:
    raise SystemExit(
        f'Management bootstrap-contract bundle mismatch. '
        f'Missing={sorted(local_expected-local_names)} extra={sorted(local_names-local_expected)}'
    )
expected_local_labels = {'cert-manager', 'cert-manager-config', 'metallb', 'metallb-config', 'contour-segment1'}
if local_labels != expected_local_labels:
    raise SystemExit(f'Management bootstrap-contract labels are incorrect: {sorted(local_labels)}')

for path in local_fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    for dep in data.get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if not label or label not in local_labels:
            raise SystemExit(f'{path.relative_to(root)}: unresolved local dependsOn label {label!r}')

local_contracts = {
    '10-bootstrap-cert-manager-ready': {
        'name': 'kmm-bootstrap-contract-cert-manager', 'label': 'cert-manager', 'namespace': 'cert-manager',
        'tokens': ('owner: bootstrap-management', 'helmRelease: onprem-cert-manager'),
    },
    '11-bootstrap-cert-manager-config-ready': {
        'name': 'kmm-bootstrap-contract-cert-manager-config', 'label': 'cert-manager-config', 'namespace': 'cert-manager',
        'tokens': ('owner: bootstrap-management', 'clusterIssuer: segment1-ca-clusterissuer'),
    },
    '20-bootstrap-metallb-ready': {
        'name': 'kmm-bootstrap-contract-metallb', 'label': 'metallb', 'namespace': 'metallb-system',
        'tokens': ('owner: bootstrap-management', 'helmRelease: metallb'),
    },
    '21-bootstrap-metallb-config-ready': {
        'name': 'kmm-bootstrap-contract-metallb-config', 'label': 'metallb-config', 'namespace': 'metallb-system',
        'tokens': ('owner: bootstrap-management', 'ipAddressPool: segment1', 'l2Advertisement: platform'),
    },
    '31-bootstrap-contour-segment1-ready': {
        'name': 'kmm-bootstrap-contract-contour-segment1', 'label': 'contour-segment1', 'namespace': 'segment1',
        'tokens': ('owner: bootstrap-management', 'helmRelease: ingress-segment1', 'service: segment1-envoy'),
    },
}
for directory, contract in local_contracts.items():
    manifest = local_bundle_root/directory/'contract.yaml'
    if not manifest.is_file():
        raise SystemExit(f'{manifest.relative_to(root)} is missing')
    manifest_text = manifest.read_text(encoding='utf-8')
    for token in (
        f"name: {contract['name']}",
        'app.kubernetes.io/managed-by: Fleet',
        f"kmm.dev/bootstrap-contract: {contract['label']}",
        *contract['tokens'],
    ):
        if token not in manifest_text:
            raise SystemExit(f'{manifest.relative_to(root)} is missing token: {token}')
    fleet_text = (local_bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    for token in (
        f"kmm.dev/bundle: {contract['label']}",
        f"name: {contract['name']}",
        f"namespace: {contract['namespace']}",
        'path: /metadata/labels/app.kubernetes.io~1managed-by',
    ):
        if token not in fleet_text:
            raise SystemExit(f'{directory}/fleet.yaml is missing bootstrap-contract token: {token}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    for dep in data.get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if not label or label not in bundle_labels:
            raise SystemExit(f'{path.relative_to(root)}: unresolved dependsOn label {label!r}')

def has_target(directory, key, value):
    custom = parsed[directory].get('targetCustomizations') or []
    return any((((x.get('clusterSelector') or {}).get('matchLabels') or {}).get(key) == value) for x in custom)

def has_deny(directory):
    custom = parsed[directory].get('targetCustomizations') or []
    return any(x.get('clusterSelector') == {} and x.get('doNotDeploy') is True for x in custom)

for directory in ('50-cnpg-operator', '52-keycloak-operator'):
    if not (has_target(directory, 'kmm.dev/identity-site', 'true') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: dual-site operator guard is incomplete')
for directory in ('51-postgresql-ha', '51-postgresql-ha-resources', '53-keycloak'):
    if not (has_target(directory, 'kmm.dev/identity', 'primary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: primary identity guard is incomplete')
if not (has_target('72-gitlab-runner', 'kmm.dev/context', 'j64seg1opman') and has_deny('72-gitlab-runner')):
    raise SystemExit('72-gitlab-runner/fleet.yaml: management-cluster target guard is incomplete')

runner_values = (bundle_root/'72-gitlab-runner'/'values.yaml').read_text(encoding='utf-8')
runner_config = yaml.safe_load(runner_values) or {}
if runner_config.get('useTini') is not True:
    raise SystemExit(
        '72-gitlab-runner/values.yaml: Iron Bank manager image requires useTini=true and '
        '/usr/local/bin/tini'
    )
for token in (
    'kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner',
    'tag: v19.3.1',
    'kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1',
    'kubeharbor.dev.kube/ironbank/opensource/ansible/ansible:14.3.1',
    'concurrent: 4',
    'run_as_user = 1001',
    'secret: gitlab-runner-auth',
    'certsSecretName: gitlab-runner-certs',
    'privileged = false',
    'allow_privilege_escalation = false',
):
    if token not in runner_values:
        raise SystemExit(f'72-gitlab-runner/values.yaml is missing required token: {token}')
if 'kubeharbor.dev.kube/*' in runner_values:
    raise SystemExit('72-gitlab-runner/values.yaml must not use depth-limited wildcard image allowlists')
for token in (
    'allowed_images = [',
    '"kubeharbor.dev.kube/ironbank/opensource/ansible/ansible:14.3.1"',
    'allowed_services = []',
):
    if token not in runner_values:
        raise SystemExit(f'72-gitlab-runner/values.yaml is missing exact runner image-policy token: {token}')

ci_text = (root/'.gitlab-ci.yml').read_text(encoding='utf-8')
for token in (
    'runner:canary:',
    'KMM_CI_PYTHON',
    "printf 'exec %q -I \"$@\"\\n'",
    'PYTHONSAFEPATH: "1"',
    'artifacts: false',
    'when: on_success',
):
    if token not in ci_text:
        raise SystemExit(f'.gitlab-ci.yml is missing runner-validation token: {token}')
if 'ln -sf "${pyyaml_python}"' in ci_text:
    raise SystemExit('.gitlab-ci.yml must wrap the exact validated PyYAML interpreter rather than symlinking it as python3')
if 'after_script:' in ci_text and 'GITOPS_VALIDATED_COMMIT' in ci_text.split('after_script:', 1)[1]:
    raise SystemExit('.gitlab-ci.yml must not publish GITOPS_VALIDATED_COMMIT from after_script')

runner_chart = root/'helm'/'packages'/'gitlab-runner-0.92.1.tgz'
try:
    with tarfile.open(runner_chart, 'r:gz') as package:
        deployment = package.extractfile('gitlab-runner/templates/deployment.yaml').read().decode('utf-8')
except Exception as exc:
    raise SystemExit(f'Unable to inspect {runner_chart.relative_to(root)}: {exc}')
if 'command: ["/usr/local/bin/tini", "--", "/bin/bash", "/configmaps/entrypoint"]' not in deployment:
    raise SystemExit(
        'helm/packages/gitlab-runner-0.92.1.tgz does not map useTini=true to the expected '
        '/usr/local/bin/tini manager command'
    )

for directory in ('51-postgresql-replica', '54-keycloak-secondary'):
    if not (has_target(directory, 'kmm.dev/identity', 'secondary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: secondary identity guard is incomplete')

# The primary CNPG status NetworkPolicy must exist before the Cluster is allowed
# to gate Fleet readiness. Otherwise the resources bundle waits on the Cluster,
# while the Cluster waits on operator -> instance-manager TCP/8000: a deadlock.
def dependency_labels(directory):
    labels = []
    for dep in parsed[directory].get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if label:
            labels.append(label)
    return labels

primary_resource_deps = dependency_labels('51-postgresql-ha-resources')
if 'postgresql-ha' in primary_resource_deps:
    raise SystemExit('51-postgresql-ha-resources must not depend on postgresql-ha; the CNPG TCP/8000 policy must pre-apply')
for required_dep in ('cnpg-operator', 'metallb-config'):
    if required_dep not in primary_resource_deps:
        raise SystemExit(f'51-postgresql-ha-resources must depend on {required_dep}')
if 'postgresql-ha-resources' not in dependency_labels('51-postgresql-ha'):
    raise SystemExit('51-postgresql-ha must depend on postgresql-ha-resources so the CNPG status policy exists before Cluster readiness')

primary_values = (bundle_root/'51-postgresql-ha'/'fleet-values.yaml').read_text(encoding='utf-8')
primary_cluster = (bundle_root/'51-postgresql-ha'/'chart'/'templates'/'cluster.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-hibernation', 'kmm.dev/postgres-primary-site', 'kmm.dev/postgres-distributed-topology', 'kmm.dev/postgres-bootstrap-mode'):
    if token not in primary_values:
        raise SystemExit(f'Primary PostgreSQL Fleet values missing distributed-topology token: {token}')
for token in (
    'postgresBootstrapMode', 'pg_basebackup:', 'self: j64seg1opdev', 'source: j52seg1opdev',
    'j64seg1opdev-postgres-repl.dev.kube', 'j52seg1opdev-postgres-repl.dev.kube',
    'oppostgres-opkeycloak-db-replication', 'oppostgres-j52-replication',
    'enabled: true', 'dataDurability: required', 'failoverQuorum: true',
):
    if token not in primary_cluster:
        raise SystemExit(f'Primary PostgreSQL Helm template missing HA token: {token}')

def topology_external_members(template_text):
    if 'externalClusters:' not in template_text:
        return set()
    external_section = template_text.split('externalClusters:', 1)[1]
    return set(re.findall(r'^\s*-\s+name:\s+(j64seg1opdev|j52seg1opdev)\s*$', external_section, re.MULTILINE))

required_topology_members = {'j64seg1opdev', 'j52seg1opdev'}
if topology_external_members(primary_cluster) != required_topology_members:
    raise SystemExit(
        'Primary PostgreSQL distributed topology must declare both j64seg1opdev and '
        'j52seg1opdev in externalClusters; replica.self/replica.primary are validated '
        'against those names by the CloudNativePG admission webhook'
    )
if (parsed['51-postgresql-ha'].get('helm') or {}).get('chart') != './chart':
    raise SystemExit('51-postgresql-ha must use the local distributed-topology adapter chart')
primary_replication_service = (bundle_root/'51-postgresql-ha-resources'/'external-service.yaml').read_text(encoding='utf-8')
if '1.0.0.216' not in primary_replication_service or '${ get .ClusterLabels' in primary_replication_service:
    raise SystemExit('Primary PostgreSQL replication Service must render the approved j64 Segment1 IP without a raw Fleet expression')

# Any ingress OR egress NetworkPolicy selecting CNPG database/bootstrap pods
# isolates the selected direction. The prerequisite resources bundle must allow
# local CNPG cluster members on both halves of the TCP/5432 path before the
# PostgreSQL Cluster bundle starts. Token counting is insufficient here: the
# outage that prompted this check had the correct local ingress rule but no
# local egress rule, so validate the NetworkPolicy semantically.
primary_pg_policy_path = bundle_root/'51-postgresql-ha-resources'/'replication-networkpolicy.yaml'
primary_pg_policy = yaml.safe_load(primary_pg_policy_path.read_text(encoding='utf-8')) or {}
if primary_pg_policy.get('kind') != 'NetworkPolicy':
    raise SystemExit('Primary PostgreSQL prerequisite replication policy is not a NetworkPolicy')
if (primary_pg_policy.get('metadata') or {}).get('name') != 'oppostgres-allow-local-and-cross-cluster-postgresql':
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy has the wrong metadata.name')
policy_spec = primary_pg_policy.get('spec') or {}
cluster_selector = {'cnpg.io/cluster': 'oppostgres-opkeycloak-db'}
if ((policy_spec.get('podSelector') or {}).get('matchLabels') or {}) != cluster_selector:
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy must select the CNPG cluster pods')
policy_types = set(policy_spec.get('policyTypes') or [])
if not {'Ingress', 'Egress'}.issubset(policy_types):
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy must isolate/authorize both Ingress and Egress')

def _has_local_pg_rule(rules, peer_key):
    for rule in rules or []:
        ports = rule.get('ports') or []
        if not any((port or {}).get('protocol', 'TCP') == 'TCP' and (port or {}).get('port') == 5432 for port in ports):
            continue
        for peer in rule.get(peer_key) or []:
            selector = ((peer or {}).get('podSelector') or {}).get('matchLabels') or {}
            if selector == cluster_selector:
                return True
    return False

if not _has_local_pg_rule(policy_spec.get('ingress'), 'from'):
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy must allow same-cluster CNPG ingress on TCP/5432')
if not _has_local_pg_rule(policy_spec.get('egress'), 'to'):
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy must allow same-cluster CNPG egress on TCP/5432')

cross_site_ok = False
for rule in policy_spec.get('ingress') or []:
    ports = rule.get('ports') or []
    if not any((port or {}).get('protocol', 'TCP') == 'TCP' and (port or {}).get('port') == 5432 for port in ports):
        continue
    for peer in rule.get('from') or []:
        if ((peer or {}).get('ipBlock') or {}).get('cidr') == '1.0.0.0/23':
            cross_site_ok = True
if not cross_site_ok:
    raise SystemExit('Primary PostgreSQL prerequisite NetworkPolicy must retain Segment1 cross-site ingress on TCP/5432')

secondary_values = (bundle_root/'51-postgresql-replica'/'fleet-values.yaml').read_text(encoding='utf-8')
secondary_cluster = (bundle_root/'51-postgresql-replica'/'chart'/'templates'/'cluster.yaml').read_text(encoding='utf-8')
secondary_services = (bundle_root/'51-postgresql-replica'/'chart'/'templates'/'services.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-distributed-topology', 'kmm.dev/postgres-primary-site', 'kmm.dev/postgres-hibernation', 'kmm.dev/postgres-replication-lb-ip'):
    if token not in secondary_values:
        raise SystemExit(f'Secondary PostgreSQL Fleet values missing token: {token}')
for token in (
    'j64seg1opdev-postgres-repl.dev.kube', 'j52seg1opdev-postgres-repl.dev.kube',
    'pg_basebackup:', 'streaming_replica', 'self: j52seg1opdev',
    'primary: {{ $primarySite }}', 'oppostgres-j64-replication',
    'oppostgres-opkeycloak-db-replication',
):
    if token not in secondary_cluster:
        raise SystemExit(f'Secondary PostgreSQL Helm template missing token: {token}')
if topology_external_members(secondary_cluster) != required_topology_members:
    raise SystemExit(
        'Secondary PostgreSQL distributed topology must declare both j64seg1opdev and '
        'j52seg1opdev in externalClusters; replica.self/replica.primary are validated '
        'against those names by the CloudNativePG admission webhook'
    )
if 'pg_basebackup:\n      source: j64seg1opdev\n      database:' in secondary_cluster:
    raise SystemExit('Secondary PostgreSQL pg_basebackup must not contain initdb-only database fields')
for token in ('{{- $hibernation = "on" -}}', '{{- $hibernation = "off" -}}'):
    if token not in secondary_cluster:
        raise SystemExit(f'Secondary PostgreSQL Helm template must assign the outer hibernation variable: {token}')
for invalid_token in ('{{- $hibernation := "on" -}}', '{{- $hibernation := "off" -}}'):
    if invalid_token in secondary_cluster:
        raise SystemExit(f'Secondary PostgreSQL Helm template shadows the hibernation variable: {invalid_token}')
if '.Values.postgresReplicationLBIP' not in secondary_services:
    raise SystemExit('Secondary PostgreSQL Service template does not consume the rendered replication LB IP')
if (parsed['51-postgresql-replica'].get('helm') or {}).get('chart') != './chart':
    raise SystemExit('51-postgresql-replica must use the local dynamic-resource adapter chart')

for directory in ('53-keycloak', '54-keycloak-secondary'):
    values_path = bundle_root/directory/'fleet-values.yaml'
    template_path = bundle_root/directory/'chart'/'templates'/'keycloak.yaml'
    resources_path = bundle_root/directory/'chart'/'templates'/'resources.yaml'
    if 'kmm.dev/keycloak-instances' not in values_path.read_text(encoding='utf-8'):
        raise SystemExit(f'{values_path.relative_to(root)} does not derive instances from the Fleet cluster label')
    if '.Values.keycloakInstances' not in template_path.read_text(encoding='utf-8'):
        raise SystemExit(f'{template_path.relative_to(root)} does not consume keycloakInstances')
    resources_text = resources_path.read_text(encoding='utf-8')
    for token in (
        'kind: Certificate',
        'kind: HTTPProxy',
        'name: opkeycloak-service',
        'port: 8080',
    ):
        if token not in resources_text:
            raise SystemExit(f'{resources_path.relative_to(root)} is missing standby-ready exposure token: {token}')
    if '{{- if gt (int .Values.keycloakInstances) 0 }}' in resources_text:
        raise SystemExit(f'{resources_path.relative_to(root)} must pre-stage Certificate/HTTPProxy even when Keycloak instances=0')
    if (parsed[directory].get('helm') or {}).get('chart') != './chart':
        raise SystemExit(f'{directory} must use the local dynamic-resource adapter chart')

# Local adapter bundles must keep their static resources inside chart/templates;
# sibling raw YAML is intentionally avoided so one Fleet bundle has one rendering path.
required_local_templates = {
    '41-longhorn-config': ('storageclasses.yaml', 'snapshotclass.yaml', 'recurringjob.yaml'),
    '51-postgresql-replica': ('cluster.yaml', 'services.yaml', 'pooler.yaml', 'networkpolicies.yaml', 'monitoring-networkpolicy.yaml', 'pgbouncer-pdb.yaml'),
    '53-keycloak': ('keycloak.yaml', 'resources.yaml'),
    '54-keycloak-secondary': ('keycloak.yaml', 'resources.yaml', 'networkpolicies.yaml'),
}
for directory, names in required_local_templates.items():
    template_dir = bundle_root/directory/'chart'/'templates'
    missing = [name for name in names if not (template_dir/name).is_file()]
    if missing:
        raise SystemExit(f'{directory} local adapter is missing chart templates: {missing}')
    allowed_root = {'fleet.yaml', 'fleet-values.yaml'}
    sibling_yaml = sorted(
        path.name for path in (bundle_root/directory).iterdir()
        if path.is_file() and path.suffix in {'.yaml', '.yml'} and path.name not in allowed_root
    )
    if sibling_yaml:
        raise SystemExit(f'{directory} has sibling raw YAML outside its local chart: {sibling_yaml}')

cni_values_path = bundle_root/'61-istio-cni'/'values.yaml'
cni_values = cni_values_path.read_text(encoding='utf-8')
for token in ('/opt/cni/bin', '/etc/cni/net.d'):
    if token not in cni_values:
        raise SystemExit(f'Istio CNI values missing RKE2 path: {token}')
cni_values_data = yaml.safe_load(cni_values) or {}
cni_profile = cni_values_data.get('profile')
if cni_profile:
    cni_package = root/'helm'/'packages'/'cni-1.30.1.tgz'
    if not cni_package.is_file():
        raise SystemExit('helm/packages/cni-1.30.1.tgz is missing; cannot validate Istio CNI profile')
    profile_member = f'cni/files/profile-{cni_profile}.yaml'
    with tarfile.open(cni_package, 'r:gz') as archive:
        if profile_member not in archive.getnames():
            raise SystemExit(
                f'61-istio-cni/values.yaml selects unsupported Istio profile {cni_profile!r}; '
                f'{profile_member} is not present in cni-1.30.1.tgz. Omit profile to use chart defaults.'
            )
istiod_values_path = bundle_root/'62-istiod'/'values.yaml'
istiod_values = istiod_values_path.read_text(encoding='utf-8')
istiod_values_data = yaml.safe_load(istiod_values) or {}
if '_internal_defaults_do_not_set' in istiod_values_data:
    raise SystemExit('62-istiod/values.yaml must not set Istio reserved _internal_defaults_do_not_set')
if ((istiod_values_data.get('cni') or {}).get('enabled')) is not True:
    raise SystemExit('62-istiod/values.yaml must set root cni.enabled: true for the Istio chart')
if 'pilot:' in istiod_values_data and isinstance(istiod_values_data.get('pilot'), dict) and 'cni' in istiod_values_data.get('pilot', {}):
    raise SystemExit('62-istiod/values.yaml has obsolete pilot.cni; Istio expects root cni.enabled')
for address in ('1.0.0.210', '1.0.0.220', '1.0.0.230', '1.0.0.240'):
    if address not in istiod_values:
        raise SystemExit(f'Istiod meshNetworks missing Segment1 east-west address: {address}')
istiod_pull_secrets = ((istiod_values_data.get('global') or {}).get('imagePullSecrets') or [])
if istiod_pull_secrets != ['regcred-kubeharbor'] or not all(isinstance(x, str) for x in istiod_pull_secrets):
    raise SystemExit(
        '62-istiod/values.yaml global.imagePullSecrets must be a list of secret-name strings; '
        'Istiod 1.30.1 rejects LocalObjectReference maps while parsing injector values'
    )

longhorn_dir = bundle_root/'40-longhorn'
longhorn_values = yaml.safe_load((longhorn_dir/'values.yaml').read_text(encoding='utf-8')) or {}
longhorn_global = longhorn_values.get('global') or {}
longhorn_defaults = longhorn_values.get('defaultSettings') or {}
if longhorn_global.get('imageRegistry') != 'kubeharbor.dev.kube':
    raise SystemExit('40-longhorn must use the KubeHarbor image registry')
if longhorn_global.get('imagePullSecrets') != ['regcred-kubeharbor']:
    raise SystemExit('40-longhorn must use regcred-kubeharbor')
expected_defaults = {
    'createDefaultDiskLabeledNodes': True,
    'defaultDataPath': '/mnt/k8sdata',
    'storageOverProvisioningPercentage': 100,
    'storageMinimalAvailablePercentage': 25,
    'replicaSoftAntiAffinity': True,
    'replicaAutoBalance': 'best-effort',
    'autoSalvage': True,
    'v1DataEngine': True,
    'v2DataEngine': False,
}
for key, expected_value in expected_defaults.items():
    if longhorn_defaults.get(key) != expected_value:
        raise SystemExit(f'40-longhorn defaultSettings.{key} must be {expected_value!r}')

longhorn_config_dir = bundle_root/'41-longhorn-config'
longhorn_config_fleet = parsed['41-longhorn-config'].get('helm') or {}
if longhorn_config_fleet.get('chart') != './chart':
    raise SystemExit('41-longhorn-config must use its local policy chart')


longhorn_ui_dir = bundle_root/'42-longhorn-ui'
longhorn_ui_fleet = parsed['42-longhorn-ui']
longhorn_ui_helm = longhorn_ui_fleet.get('helm') or {}
if longhorn_ui_helm.get('chart') != './chart':
    raise SystemExit('42-longhorn-ui must use its local exposure chart')
longhorn_ui_fleet_text = (longhorn_ui_dir/'fleet.yaml').read_text(encoding='utf-8')
for dependency in ('longhorn-config', 'contour-segment1', 'cert-manager-config'):
    if f'kmm.dev/bundle: {dependency}' not in longhorn_ui_fleet_text:
        raise SystemExit(f'42-longhorn-ui must depend on {dependency}')
expected_longhorn_hosts = {
    'j64seg1opman': 'longhorn-man.dev.kube',
    'j64seg1opdev': 'longhorn-j64.dev.kube',
    'j52seg1opdev': 'longhorn-j52.dev.kube',
    'r01seg1opdev': 'longhorn-r01.dev.kube',
}
seen_longhorn_hosts = {}
for customization in longhorn_ui_fleet.get('targetCustomizations') or []:
    labels = ((customization.get('clusterSelector') or {}).get('matchLabels') or {})
    context = labels.get('kmm.dev/context')
    if not context:
        continue
    hostname = (((customization.get('helm') or {}).get('values') or {}).get('hostname'))
    if hostname:
        seen_longhorn_hosts[context] = hostname
if seen_longhorn_hosts != expected_longhorn_hosts:
    raise SystemExit(f'42-longhorn-ui hostname mapping mismatch: {seen_longhorn_hosts!r}')

legacy_kiali_hostnames = {
    'yaml/j64/seg1opman-cluster/resources/istio-kiali-server-resources-v1.yaml': 'kiali-man.dev.kube',
    'yaml/j64/seg1opdev-cluster/resources/istio-kiali-server-resources-v1.yaml': 'kiali-j64.dev.kube',
    'yaml/j52/seg1opdev-cluster/resources/istio-kiali-server-resources-v1.yaml': 'kiali-j52.dev.kube',
    'yaml/r01/seg1opdev-cluster/resources/istio-kiali-server-resources-v1.yaml': 'kiali-r01.dev.kube',
}
for rel, expected_hostname in legacy_kiali_hostnames.items():
    text = (root/rel).read_text(encoding='utf-8')
    if expected_hostname not in text:
        raise SystemExit(f'{rel} does not contain expected Kiali hostname {expected_hostname}')
    if re.search(r'(?:j64seg1opman|j64seg1opdev|j52seg1opdev|r01seg1opdev)-kiali\.dev\.kube', text):
        raise SystemExit(f'{rel} still contains a retired Kiali hostname')
longhorn_ui_values = (longhorn_ui_dir/'chart'/'values.yaml').read_text(encoding='utf-8')
longhorn_ui_template = (longhorn_ui_dir/'chart'/'templates'/'exposure.yaml').read_text(encoding='utf-8')
for token in (
    'kind: Certificate', 'kind: HTTPProxy', 'ipAllowPolicy:',
    'name: longhorn-frontend', 'port: 80',
    'kind: NetworkPolicy', 'longhorn-ui-allow-segment1-envoy',
    'kubernetes.io/metadata.name: segment1', 'app.kubernetes.io/component: envoy',
):
    if token not in longhorn_ui_template:
        raise SystemExit(f'42-longhorn-ui exposure template is missing token: {token}')
for token in ('segment1-ca-clusterissuer', 'ingressClassName: segment1', '1.0.0.0/23'):
    if token not in longhorn_ui_values:
        raise SystemExit(f'42-longhorn-ui values are missing token: {token}')
storage_text = (longhorn_config_dir/'chart'/'templates'/'storageclasses.yaml').read_text(encoding='utf-8')
for token in ('name: longhorn', 'name: longhorn-retain', 'name: longhorn-xfs-retain',
              'driver.longhorn.io', 'numberOfReplicas: "3"', 'WaitForFirstConsumer'):
    if token not in storage_text:
        raise SystemExit(f'Longhorn storage-class policy is missing token: {token}')
recurring_text = (longhorn_config_dir/'chart'/'templates'/'recurringjob.yaml').read_text(encoding='utf-8')
for token in ('task: snapshot', 'snapshot-default', 'retain: 7'):
    if token not in recurring_text:
        raise SystemExit(f'Longhorn recurring snapshot policy is missing token: {token}')
for retired in ('40-trident-operator', '41-trident-config', '42-trident-protect'):
    if (bundle_root/retired).exists():
        raise SystemExit(f'Retired storage bundle still exists: {retired}')

# The upstream Keycloak Operator is a singleton controller. Multiple replicas of
# the same Deployment reconcile the same CR and cause 409 status-update conflicts.
for operator_path, expected_name in (
    (bundle_root/'52-keycloak-operator'/'operator.yaml', 'opkeycloak-operator'),
    (root/'yaml'/'opkeycloak'/'resources'/'opkeycloak-seg1opdev-operator-source-v1.yaml', 'keycloak-operator'),
):
    deployments = [
        doc for doc in yaml.safe_load_all(operator_path.read_text(encoding='utf-8'))
        if isinstance(doc, dict) and doc.get('kind') == 'Deployment'
        and ((doc.get('metadata') or {}).get('name') == expected_name)
    ]
    if len(deployments) != 1 or ((deployments[0].get('spec') or {}).get('replicas')) != 1:
        raise SystemExit(f'{operator_path.relative_to(root)} must deploy exactly one Keycloak Operator replica')

operator_renderer = (root/'scripts'/'security'/'render-keycloak-operator-cis.py').read_text(encoding='utf-8')
if 'doc["spec"]["replicas"] = 1' not in operator_renderer or 'doc["spec"]["replicas"] = 3' in operator_renderer:
    raise SystemExit('render-keycloak-operator-cis.py must preserve the Keycloak Operator singleton replica model')

keycloak_cr_paths = (
    bundle_root/'53-keycloak'/'chart'/'templates'/'keycloak.yaml',
    bundle_root/'54-keycloak-secondary'/'chart'/'templates'/'keycloak.yaml',
    root/'yaml'/'opkeycloak'/'resources'/'opkeycloak-seg1opdev-cr-v1.yaml',
)
for keycloak_path in keycloak_cr_paths:
    keycloak_template = keycloak_path.read_text(encoding='utf-8')
    for required_probe in ('startupProbe:', 'periodSeconds: 5', 'failureThreshold: 120'):
        if required_probe not in keycloak_template:
            raise SystemExit(f'{keycloak_path.relative_to(root)} must define the supported Keycloak startup probe tuning: {required_probe}')
    pod_template_tail = keycloak_template.split('unsupported:', 1)[-1]
    if '- name: keycloak' in pod_template_tail or 'args: [start]' in pod_template_tail:
        raise SystemExit(f'{keycloak_path.relative_to(root)} must not override the Operator-owned Keycloak container name or args in unsupported.podTemplate')

# Keycloak Operator 26.5.5 starts both Keycloak and KeycloakRealmImport informers.
for crd_path in (
    bundle_root/'52-keycloak-operator'/'crds.yaml',
    root/'yaml'/'opkeycloak'/'resources'/'opkeycloak-seg1opdev-crds-v1.yaml',
):
    crd_names = {
        ((doc or {}).get('metadata') or {}).get('name')
        for doc in yaml.safe_load_all(crd_path.read_text(encoding='utf-8'))
        if isinstance(doc, dict) and doc.get('kind') == 'CustomResourceDefinition'
    }
    for required_crd in ('keycloaks.k8s.keycloak.org', 'keycloakrealmimports.k8s.keycloak.org'):
        if required_crd not in crd_names:
            raise SystemExit(f'{crd_path.relative_to(root)} is missing required Keycloak CRD {required_crd}')

# Dynamic cluster data must not remain in raw Kubernetes manifests for this pinned
# Fleet v0.15.2 deployment. The observed runtime left those expressions literal.
for directory, data in parsed.items():
    allowed_values = set(((data.get('helm') or {}).get('valuesFiles') or []))
    bundle_dir = bundle_root/directory
    for manifest in list(bundle_dir.rglob('*.yaml')) + list(bundle_dir.rglob('*.yml')):
        if manifest.name == 'fleet.yaml' or ('chart' in manifest.parts and 'templates' in manifest.parts):
            continue
        text = manifest.read_text(encoding='utf-8')
        if '${ get .ClusterLabels' in text and manifest.name not in allowed_values:
            raise SystemExit(
                f'{manifest.relative_to(root)} contains a raw ClusterLabels template; '
                'move cluster-specific data into a Fleet valuesFile or an explicit target overlay'
            )

gateway_values_data = yaml.safe_load((bundle_root/'63-eastwest-gateway'/'values.yaml').read_text(encoding='utf-8')) or {}
if '_internal_defaults_do_not_set' in gateway_values_data:
    raise SystemExit('63-eastwest-gateway/values.yaml must use supported root Gateway chart values')
for retired_key in ('hub', 'tag'):
    if retired_key in gateway_values_data:
        raise SystemExit(
            f'63-eastwest-gateway/values.yaml sets unsupported Istio Gateway 1.30.1 root key {retired_key!r}; '
            'the gateway proxy image is injected by Istiod using global hub/tag from 62-istiod/values.yaml'
        )
if not gateway_values_data.get('name') or not (gateway_values_data.get('service') or {}).get('loadBalancerIP'):
    raise SystemExit('63-eastwest-gateway root values are incomplete')

# Istiod mutates two validating-webhook fields after startup: it injects caBundle and
# transitions failurePolicy from Ignore to Fail once validation is healthy. jsonPointers
# tolerate the optional caBundle lifecycle and keep these controller-owned mutations from
# holding Fleet Bundles in Modified while preserving drift detection for all other fields.
for directory, webhook_name in (
    ('60-istio-base', 'istiod-default-validator'),
    ('62-istiod', 'istio-validator-stable-istio-system'),
):
    data = parsed[directory]
    patches = (((data.get('diff') or {}).get('comparePatches')) or [])
    match = next((x for x in patches if x.get('apiVersion') == 'admissionregistration.k8s.io/v1'
                  and x.get('kind') == 'ValidatingWebhookConfiguration'
                  and x.get('name') == webhook_name), None)
    pointers = set((match or {}).get('jsonPointers') or [])
    required_pointers = {'/webhooks/0/clientConfig/caBundle', '/webhooks/0/failurePolicy'}
    missing_pointers = required_pointers - pointers
    if not match or missing_pointers:
        raise SystemExit(
            f'{directory}/fleet.yaml must ignore Istiod-owned validating webhook fields with jsonPointers; '
            f'missing: {sorted(missing_pointers)}'
        )
    if match.get('operations'):
        raise SystemExit(f'{directory}/fleet.yaml must not use JSON Patch operations for Istiod-owned webhook fields')

# Fleet deploys the vendor Keycloak operator manifest through Helm, which normalizes
# the top-level managed-by label to Helm. Keep the pod-template's Quarkus label intact
# and ignore only the three top-level ownership-label diffs that Fleet reports.
keycloak_operator = parsed['52-keycloak-operator']
keycloak_patches = (((keycloak_operator.get('diff') or {}).get('comparePatches')) or [])
for api_version, kind in (('v1','ServiceAccount'), ('v1','Service'), ('apps/v1','Deployment')):
    match = next((x for x in keycloak_patches if x.get('apiVersion') == api_version
                  and x.get('kind') == kind
                  and x.get('name') == 'opkeycloak-operator'
                  and x.get('namespace') == 'opkeycloak'), None)
    if not match or '/metadata/labels/app.kubernetes.io~1managed-by' not in (match.get('jsonPointers') or []):
        raise SystemExit(f'52-keycloak-operator/fleet.yaml must ignore Fleet/Helm managed-by normalization for {kind}')

# Fleet v0.15.2 did not apply sibling raw YAML from the observed external OCI Helm
# bundles. Keep the external chart bundle pure and put adjunct resources in an
# explicit raw bundle or a local adapter chart with Fleet-preprocessed values.
for directory in expected_oci_charts:
    external_dir = bundle_root/directory
    extras = sorted(
        x.name for x in external_dir.iterdir()
        if x.is_file() and x.suffix in {'.yaml', '.yml'} and x.name not in {'fleet.yaml', 'values.yaml'}
    )
    if extras:
        raise SystemExit(
            f'{directory} mixes an external OCI chart with sibling raw YAML {extras}; '
            'split adjunct resources into an explicit bundle/local adapter chart'
        )

for directory in ('32-contour-segment1-policies', '51-postgresql-ha-resources', '70-kube-state-metrics-alias'):
    helm = parsed[directory].get('helm') or {}
    if helm.get('takeOwnership') is not True or not helm.get('releaseName'):
        raise SystemExit(f'{directory} must use an explicit Helm release with takeOwnership for safe migration of adjunct resources')

for directory, values_token, template_rel, template_token in (
    ('63-eastwest-gateway-config', 'kmm.dev/context', 'chart/templates/gateway.yaml', '.Values.gatewayName'),
):
    helm = parsed[directory].get('helm') or {}
    if helm.get('chart') != './chart' or helm.get('valuesFiles') != ['fleet-values.yaml']:
        raise SystemExit(f'{directory} must use ./chart with fleet-values.yaml for per-cluster rendering')
    values_text = (bundle_root/directory/'fleet-values.yaml').read_text(encoding='utf-8')
    if '${ get .ClusterLabels' not in values_text or values_token not in values_text:
        raise SystemExit(f'{directory}/fleet-values.yaml is missing the required Fleet cluster-label rendering')
    template_text = (bundle_root/directory/template_rel).read_text(encoding='utf-8')
    if template_token not in template_text:
        raise SystemExit(f'{directory}/{template_rel} is missing {template_token}')
    if '${ get .ClusterLabels' in template_text:
        raise SystemExit(f'{directory}/{template_rel} must not contain raw Fleet ClusterLabels expressions')

kiali_dir = bundle_root/'66-kiali-resources'
kiali_fleet = parsed['66-kiali-resources']
kiali_helm = kiali_fleet.get('helm') or {}
if kiali_helm.get('chart') != './chart' or kiali_helm.get('valuesFiles'):
    raise SystemExit('66-kiali-resources must use ./chart with targetCustomizations, not a Fleet-preprocessed values file')
expected_kiali_hosts = {
    'j64seg1opman': 'kiali-man.dev.kube',
    'j64seg1opdev': 'kiali-j64.dev.kube',
    'j52seg1opdev': 'kiali-j52.dev.kube',
    'r01seg1opdev': 'kiali-r01.dev.kube',
}
seen_kiali_hosts = {}
for customization in kiali_fleet.get('targetCustomizations') or []:
    labels = ((customization.get('clusterSelector') or {}).get('matchLabels') or {})
    context = labels.get('kmm.dev/context')
    if not context:
        continue
    hostname = (((customization.get('helm') or {}).get('values') or {}).get('kialiHost'))
    if hostname:
        seen_kiali_hosts[context] = hostname
if seen_kiali_hosts != expected_kiali_hosts:
    raise SystemExit(f'66-kiali-resources hostname mapping mismatch: {seen_kiali_hosts!r}')
if not any(x.get('clusterSelector') == {} and x.get('doNotDeploy') is True for x in kiali_fleet.get('targetCustomizations') or []):
    raise SystemExit('66-kiali-resources needs a final doNotDeploy guard for unconfigured clusters')
kiali_template_text = (kiali_dir/'chart'/'templates'/'exposure.yaml').read_text(encoding='utf-8')
for token in ('.Values.kialiHost', 'kind: Certificate', 'kind: Ingress', 'ingressClassName: segment1', 'path: /'):
    if token not in kiali_template_text:
        raise SystemExit(f'66-kiali-resources exposure template is missing token: {token}')
if (kiali_dir/'fleet-values.yaml').exists():
    raise SystemExit('66-kiali-resources/fleet-values.yaml is obsolete after the explicit hostname mapping')

pool_template_path = bundle_root/'21-metallb-config'/'chart'/'templates'/'address-pools.yaml'
if not pool_template_path.is_file():
    raise SystemExit('MetalLB config Helm template is missing')
pool_manifest = pool_template_path.read_text(encoding='utf-8')
if pool_manifest.count('kind: IPAddressPool') != 1 or 'name: segment1' not in pool_manifest:
    raise SystemExit('MetalLB must expose exactly one Segment1 IPAddressPool')
if 'name: regular' in pool_manifest or 'metallb-' + 'regular-pool' in pool_manifest:
    raise SystemExit('A non-Segment1 MetalLB pool remains in the Fleet bundle')

segment_dir = bundle_root/'31-contour-segment1'
segment_values = (segment_dir/'values.yaml').read_text(encoding='utf-8')
for token in ('manageCRDs: true', 'name: segment1', 'default: true'):
    if token not in segment_values:
        raise SystemExit(f'Segment1 Contour values missing single-ingress token: {token}')
if '${ get .ClusterLabels' in segment_values:
    raise SystemExit('Segment1 Contour values must not contain Fleet preprocessing expressions')
segment_fleet = parsed['31-contour-segment1']
segment_helm = segment_fleet.get('helm') or {}
if segment_helm.get('disablePreProcess') is not True:
    raise SystemExit('31-contour-segment1 must set helm.disablePreProcess: true')
if ((((segment_helm.get('values') or {}).get('global') or {}).get('security') or {}).get('allowInsecureImages')) is not True:
    raise SystemExit('31-contour-segment1 must force global.security.allowInsecureImages=true for the approved private mirror')
expected_contour_ips = {
    'j64seg1opman': '1.0.0.205', 'j64seg1opdev': '1.0.0.215',
    'j52seg1opdev': '1.0.0.225', 'r01seg1opdev': '1.0.0.235',
}
seen_contour_ips = {}
for custom in segment_fleet.get('targetCustomizations') or []:
    labels = ((custom.get('clusterSelector') or {}).get('matchLabels') or {})
    context = labels.get('kmm.dev/context')
    if not context:
        continue
    values = (((custom.get('helm') or {}).get('values') or {}).get('envoy') or {}).get('service') or {}
    seen_contour_ips[context] = str(values.get('loadBalancerIP') or '')
    if context == 'j64seg1opman' and custom.get('keepResources') is not True:
        raise SystemExit('Contour management customization must set keepResources: true for bootstrap ownership migration')
if seen_contour_ips != expected_contour_ips:
    raise SystemExit(f'Contour target loadBalancerIP map mismatch: {seen_contour_ips}')
if not any(x.get('clusterSelector') == {} and x.get('doNotDeploy') is True for x in segment_fleet.get('targetCustomizations') or []):
    raise SystemExit('Contour target customizations need a final doNotDeploy guard for unconfigured clusters')
contour_policy_dir = bundle_root/'32-contour-segment1-policies'
if not (contour_policy_dir/'backend-egress.yaml').is_file():
    raise SystemExit('Segment1 backend egress policy is missing from 32-contour-segment1-policies')
if 'kmm.dev/bundle: contour-segment1' not in (contour_policy_dir/'fleet.yaml').read_text(encoding='utf-8'):
    raise SystemExit('32-contour-segment1-policies must depend on contour-segment1')

monitoring_values_path = bundle_root/'71-elastic-agent'/'values.yaml'
monitoring_values = monitoring_values_path.read_text(encoding='utf-8')
monitoring_values_data = yaml.safe_load(monitoring_values) or {}
per_node = (((monitoring_values_data.get('agent') or {}).get('presets') or {}).get('perNode') or {})
providers = per_node.get('providers') or {}
if 'kubernetes' in providers:
    raise SystemExit(
        '71-elastic-agent/values.yaml must not override presets.perNode.providers.kubernetes. '
        'The packaged Elastic Agent chart already provides node: ${NODE_NAME}; copying that token into a '
        'Fleet valuesFile makes Fleet v0.15.2 interpret NODE_NAME as a template function.'
    )
for token in (
    'kubeharbor.dev.kube/elastic-agent/elastic-agent',
    'elastic-agent-fleet-enrollment',
    'devlocal-ca-bundle-secret',
    'preset: perNode',
    'kubernetes_leaderelection:',
    'enabled: true',
    'kube-state-metrics:',
):
    if token not in monitoring_values:
        raise SystemExit(f'Elastic Agent values missing token: {token}')
ksm_values = (bundle_root/'70-kube-state-metrics'/'values.yaml').read_text(encoding='utf-8')
for token in ('kubeharbor.dev.kube', 'kube-state-metrics/kube-state-metrics', 'tag: v2.16.0', 'collectors:', '- endpointslices'):
    if token not in ksm_values:
        raise SystemExit(f'kube-state-metrics values missing token: {token}')
if re.search(r'^\s*-\s+endpoints\s*$', ksm_values, re.MULTILINE):
    raise SystemExit('kube-state-metrics collectors must use endpointslices, not deprecated core/v1 endpoints')
ksm_alias = bundle_root/'70-kube-state-metrics-alias'/'service.yaml'
ksm_alias_text = ksm_alias.read_text(encoding='utf-8') if ksm_alias.is_file() else ''
if 'name: kube-state-metrics' not in ksm_alias_text or 'namespace: elastic-agent-system' not in ksm_alias_text:
    raise SystemExit('70-kube-state-metrics-alias/service.yaml must create the kube-state-metrics alias in elastic-agent-system')
ksm_alias_fleet = (bundle_root/'70-kube-state-metrics-alias'/'fleet.yaml').read_text(encoding='utf-8')
if 'defaultNamespace: elastic-agent-system' not in ksm_alias_fleet:
    raise SystemExit('70-kube-state-metrics-alias must target elastic-agent-system')
agent_fleet = (bundle_root/'71-elastic-agent'/'fleet.yaml').read_text(encoding='utf-8')
if 'kmm.dev/bundle: kube-state-metrics-alias' not in agent_fleet:
    raise SystemExit('71-elastic-agent must depend on kube-state-metrics-alias before agents start')
if (bundle_root/'00-namespaces').exists():
    raise SystemExit('fleet/bundles/00-namespaces must not exist; runtime preflight owns namespace lifecycle and PSA labels')

seed_script = (root/'scripts'/'management'/'fleet'/'01-seed-runtime-secrets.sh').read_text(encoding='utf-8')
for token in (
    'cert-manager segment1 metallb-system longhorn-system istio-system elastic-agent-system elastic-monitoring',
    'for namespace in oppostgres opkeycloak',
    'k8mm.dev/monitoring-agent=true',
    'rollout restart daemonset/agent-pernode-elastic-agent-node',
    'restart_keycloak_pods_ordered',
    'delete pod "${pod}"',
):
    if token not in seed_script:
        raise SystemExit(f'Runtime namespace provisioning is missing required token: {token}')

if 'rollout restart statefulset/opkeycloak' in seed_script:
    raise SystemExit('Runtime artifact rotation must not patch the Keycloak Operator-owned StatefulSet')

anchor_files = sorted(bundle_root.rglob('bundle-anchor.yaml'))
if anchor_files:
    raise SystemExit(
        'Bundle-anchor workarounds are prohibited. Fleet v0.15.2 must package the real OCI charts via '
        'helm.chart. Remove: ' + ', '.join(str(p.relative_to(root)) for p in anchor_files)
    )
for fleet_path in fleet_files:
    fleet_text = fleet_path.read_text(encoding='utf-8')
    for retired_token in ('kmm-fleet-anchor-', 'kmm.dev/fleet-bundle-anchor'):
        if retired_token in fleet_text:
            raise SystemExit(f'{fleet_path.relative_to(root)} contains retired anchor token {retired_token}')

for path in (
    bundle_root/'32-contour-segment1-policies'/'monitoring-networkpolicy.yaml',
    bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-ha-resources'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-replica'/'chart'/'templates'/'monitoring-networkpolicy.yaml',
):
    text = path.read_text(encoding='utf-8')
    if 'k8mm.dev/monitoring-agent' not in text:
        raise SystemExit(f'{path.relative_to(root)} lacks the monitoring namespace selector')

# Fleet v0.15.2 preprocesses files referenced by helm.valuesFiles and treats ${ ... }
# as Fleet Go templates. Reject shell/application-style ${NAME} tokens in external
# values files; keep those in packaged chart defaults or explicitly disable preprocessing.
for directory, data in parsed.items():
    helm = data.get('helm') or {}
    for values_name in helm.get('valuesFiles') or []:
        values_path = bundle_root/directory/values_name
        values_text = values_path.read_text(encoding='utf-8')
        for expression in re.findall(r'\$\{([^{}]+)\}', values_text):
            expression = expression.strip()
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', expression):
                raise SystemExit(
                    f'{values_path.relative_to(root)} contains bare ${{{expression}}}, which Fleet v0.15.2 '
                    'will parse as a Fleet template. Keep runtime env placeholders in the packaged chart '
                    'defaults or disable/escape Fleet preprocessing deliberately.'
                )

secret_prep_text = (root/'scripts'/'opkeycloak'/'00-prepare-opkeycloak-runtime-secrets.sh').read_text(encoding='utf-8')
if 'get cluster "${CLUSTER_NAME}"' in secret_prep_text:
    raise SystemExit('Runtime secret preparation must use the fully-qualified CNPG Cluster resource to avoid Rancher cluster CRD ambiguity')
if 'clusters.postgresql.cnpg.io/${CLUSTER_NAME}' not in secret_prep_text:
    raise SystemExit('Runtime secret preparation is missing the fully-qualified CNPG Cluster resource')

monitoring_source_pairs = (
    (root/'yaml'/'monitoring'/'elastic-agent-per-node-9.4.2-values.yaml', bundle_root/'71-elastic-agent'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-6.1.0-values.yaml', bundle_root/'70-kube-state-metrics'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-agent-alias.yaml', bundle_root/'70-kube-state-metrics-alias'/'service.yaml'),
    (root/'yaml'/'monitoring'/'segment1-elastic-agent-networkpolicy.yaml', bundle_root/'32-contour-segment1-policies'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'opkeycloak-ingress-from-monitoring.yaml', bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-ha-resources'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-replica'/'chart'/'templates'/'monitoring-networkpolicy.yaml'),
)
for source, managed in monitoring_source_pairs:
    if source.read_text(encoding='utf-8') != managed.read_text(encoding='utf-8'):
        raise SystemExit(f'Monitoring source drift: {source.relative_to(root)} != {managed.relative_to(root)}')

failover_script = (root/'scripts'/'management'/'failover'/'switchover-identity.sh').read_text(encoding='utf-8')
for token in (
    '../../_lib/common.sh', '../../_lib/runtime-config.sh', 'status.demotionToken',
    'promotionToken', 'verify-database-replication.sh', 'coordination.k8s.io',
    'kmm-identity-transition-journal', 'IDENTITY_QUIESCE_SOURCE_HOOK',
    'IDENTITY_HARD_FENCE_SOURCE_HOOK', 'IDENTITY_ACTIVATE_TARGET_HOOK',
    'IDENTITY_UNPLANNED_RPO_ACK', 'I_ACCEPT_POSSIBLE_DATA_LOSS',
    'IDENTITY_OIDC_HEALTH_PATH', 'IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY',
    '05-enable-identity-secondary.sh', 'select(.type == "Ready")', 'k8s_microtime_now',
    '%Y-%m-%dT%H:%M:%S.000000Z', 'fleet-target-reconciled',
    'wait_for_target_exposure', 'wait_for_target_https_health',
    '--resolve "${IDENTITY_CANONICAL_HOST}:443:${expected_ip}"',
    'Planned switchover requires downstream Fleet to be active',
    'normalize_identity_site', 'fleet_active_site', 'guard_new_operation_against_journal',
    'identity_ready_endpoint_count', 'identity_direct_https_health', 'show_exposure_status',
    'IDENTITY_TRAFFIC_CUTOVER_MODE', 'IDENTITY_TRAFFIC_CUTOVER_CONFIRM',
    'nextAction=resume', 'controllerResolves=', 'directTargetOIDC=', 'manualResume=',
    'active', 'exposure', 'status', 'resume', 'rollback',
):
    if token not in failover_script:
        raise SystemExit(f'Identity switchover script is missing required token: {token}')
if '.status.display.state' in failover_script:
    raise SystemExit('Identity switchover must use Fleet Ready conditions rather than .status.display.state')
if 'acquireTime: "$(date -u +%Y-%m-%dT%H:%M:%SZ)"' in failover_script or \
   'renewTime: "$(date -u +%Y-%m-%dT%H:%M:%SZ)"' in failover_script:
    raise SystemExit('Identity switchover Lease timestamps must use Kubernetes MicroTime with six fractional digits')
if 'local phase="$1" hook="" legacy_phase="${phase}"' in failover_script:
    raise SystemExit('Identity switchover run_phase_hook has a set -u unsafe dependent local declaration')
for token in (
    'local phase="$1"',
    'local hook=""',
    'local legacy_phase="${phase}"',
):
    if token not in failover_script:
        raise SystemExit(f'Identity switchover run_phase_hook is missing nounset-safe declaration: {token}')
if 'Cannot start a new identity switch to ${requested_target}' not in failover_script:
    raise SystemExit('Identity switchover must block a new opposite-direction operation while a journal is incomplete')
if 'journal_status_is_terminal' not in failover_script:
    raise SystemExit('Identity switchover must distinguish terminal and incomplete operation journals')
if 'Controller resolution is ${resolved:-unresolved}' not in failover_script:
    raise SystemExit('Identity traffic cutover timeout must report controller-side canonical DNS resolution')
if 'Manual traffic cutover requires IDENTITY_TRAFFIC_CUTOVER_CONFIRM=${target_site}' not in failover_script:
    raise SystemExit('Identity switchover manual traffic mode must require an explicit per-target confirmation')
if 'Raw-IP browser requests are not valid HTTPProxy tests' not in failover_script:
    raise SystemExit('Identity status must warn that raw ingress-IP browsing is not a valid Keycloak HTTPProxy test')
if 'kmm.dev/identity=' in failover_script:
    raise SystemExit('Identity switchover must not mutate static physical-site kmm.dev/identity bundle selectors')
fleet_reconcile_pos = failover_script.find('if (( rank < $(stage_rank fleet-target-reconciled) ))')
target_ready_pos = failover_script.find('if (( rank < $(stage_rank target-keycloak-ready) ))')
if fleet_reconcile_pos < 0 or target_ready_pos < 0 or fleet_reconcile_pos > target_ready_pos:
    raise SystemExit('Identity switchover must reconcile Fleet after role-label switch and before target Keycloak/exposure validation')
for token in (
    'restore_fleet_pause_state',
    'wait_for_fleet_identity_reconciliation',
    'wait_for_target_exposure',
    'wait_for_target_https_health',
):
    section = failover_script[fleet_reconcile_pos:target_ready_pos + 2000]
    if token not in section:
        raise SystemExit(f'Identity switchover post-promotion reconciliation path is missing required token: {token}')
verify_script = (root/'scripts'/'management'/'failover'/'verify-database-replication.sh').read_text(encoding='utf-8')
for token in (
    'identity_resolve_ipv4', 'identity_pg_isready', 'pg_stat_wal_receiver',
    'pg_stat_replication', 'IDENTITY_REPLICATION_CERT_MIN_VALIDITY_SECONDS',
    'identity_secret_cert_fingerprint', 'identity_secret_cert_valid_for',
    'planned-switchover topology is not yet enrolled', 'postgres-distributed-topology',
):
    if token not in verify_script:
        raise SystemExit(f'Replication verifier is missing required validation token: {token}')
rebuild_script = (root/'scripts'/'management'/'failover'/'rebuild-identity-standby.sh').read_text(encoding='utf-8')
for token in (
    'IDENTITY_REBUILD_CONFIRM', 'IDENTITY_REBUILD_DELETE_STORAGE',
    'kmm.dev/postgres-bootstrap-mode=pg_basebackup', 'sslmode=verify-ca',
    'verify-database-replication.sh', '06-validate-identity-ha.sh',
):
    if token not in rebuild_script:
        raise SystemExit(f'Identity standby rebuild workflow is missing required token: {token}')
label_script = (root/'scripts'/'management'/'fleet'/'02-label-fleet-clusters.sh').read_text(encoding='utf-8')
if 'kmm.dev/postgres-bootstrap-mode' not in label_script:
    raise SystemExit('Fleet cluster labeler must preserve/default kmm.dev/postgres-bootstrap-mode')
enable_secondary_script = (root/'scripts'/'management'/'fleet'/'05-enable-identity-secondary.sh').read_text(encoding='utf-8')
for token in ('Fleet enrollment labels were verified/repaired', 'kmm.dev/postgres-distributed-topology=true'):
    if token not in enable_secondary_script:
        raise SystemExit(f'Identity secondary enrollment is missing label-drift repair token: {token}')
fleet_validate_script = (root/'scripts'/'management'/'fleet'/'04-validate-fleet.sh').read_text(encoding='utf-8')
if '.status.display.state' in fleet_validate_script:
    raise SystemExit('Fleet validator diagnostics must use Ready conditions rather than .status.display.state')

deploy_script = (root/'scripts'/'deploy-platform.sh').read_text(encoding='utf-8')
for wrapper in (
    root/'scripts'/'management'/'failover'/'failover-to-j52.sh',
    root/'scripts'/'management'/'failover'/'failback-to-j64.sh',
):
    if not wrapper.exists():
        raise SystemExit(f'Identity compatibility wrapper is missing: {wrapper.relative_to(root)}')
for token in (
    'management/failover/failback-to-j64.sh',
    'management/failover/verify-database-replication.sh',
    'management/failover/rebuild-identity-standby.sh', 'switch-identity',
    'identity-active-site', 'identity-exposure-status', 'identity-transition-status',
    'resume-identity-transition', 'rollback-identity-transition',
):
    if token not in deploy_script:
        raise SystemExit(f'Deployment orchestrator does not reference {token}')
if 'local target="${1:-${IDENTITY_SWITCHOVER_CONFIRM:-j52seg1opdev}}"' not in deploy_script:
    raise SystemExit('failover-identity compatibility entry point must honor an explicit/confirmed J64 or J52 target')
if 'switch_identity "$@"' not in deploy_script:
    raise SystemExit('Deployment orchestrator is missing the generic bidirectional switch-identity dispatch')

preflight_script = (root/'scripts'/'management'/'fleet'/'00-preflight-fleet.sh').read_text(encoding='utf-8')
for token in ('04-configure-fleet-watchlist.sh', '--all --check', 'repair-rancher-agents'):
    if token not in preflight_script:
        raise SystemExit(f'Fleet preflight is missing WatchList remediation token: {token}')
watchlist_script = (root/'scripts'/'management'/'rancher'/'04-configure-fleet-watchlist.sh').read_text(encoding='utf-8')
for token in ('KUBE_FEATURE_WatchListClient', 'spec.agentEnvVars', 'cluster.fleet.cattle.io', '--type=merge'):
    if token not in watchlist_script:
        raise SystemExit(f'Fleet WatchList configurator is missing downstream propagation token: {token}')

gitrepo_script = (root/'scripts'/'management'/'fleet'/'03-bootstrap-gitrepos.sh').read_text(encoding='utf-8')
def gitrepo_path_count(bundle_path):
    return sum(line.strip() == f'- {bundle_path}' for line in gitrepo_script.splitlines())
if 'fleet/bundles/00-namespaces' in gitrepo_script:
    raise SystemExit('GitRepo bootstrap still references the retired namespace bundle')
for bundle_path in ('fleet/bundles/10-cert-manager', 'fleet/bundles/11-cert-manager-config'):
    if gitrepo_path_count(bundle_path) != 1:
        raise SystemExit(
            f'GitRepo bootstrap must include {bundle_path} only in fleet-default; '
            'bootstrap-management owns cert-manager on fleet-local'
        )
for bundle_path in (
    'fleet/local-bundles/10-bootstrap-cert-manager-ready',
    'fleet/local-bundles/11-bootstrap-cert-manager-config-ready',
    'fleet/local-bundles/20-bootstrap-metallb-ready',
    'fleet/local-bundles/21-bootstrap-metallb-config-ready',
    'fleet/local-bundles/31-bootstrap-contour-segment1-ready',
):
    if gitrepo_path_count(bundle_path) != 1:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} exactly once in fleet-local')
for bundle_path in ('fleet/bundles/20-metallb', 'fleet/bundles/21-metallb-config', 'fleet/bundles/31-contour-segment1'):
    if gitrepo_path_count(bundle_path) != 1:
        raise SystemExit(
            f'GitRepo bootstrap must include {bundle_path} only in fleet-default; '
            'bootstrap-management owns the management network substrate'
        )
for token in (
    '02-validate-cert-manager-bootstrap.sh" j64 seg1opman',
    '05-validate-network-bootstrap.sh" j64 seg1opman',
    'preserve_bootstrap_owned_network_from_legacy_fleet',
    '"options":{"keepResources":true}',
    'delete bundledeployment.fleet.cattle.io',
):
    if token not in gitrepo_script:
        raise SystemExit(f'GitRepo bootstrap is missing management ownership migration/validation token: {token}')
for token in (
    r"helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'",
    'helmSecretName: kmm-helm-credentials',
):
    if gitrepo_script.count(token) != 2:
        raise SystemExit(f'Both managed GitRepos must contain the OCI authentication control: {token}')

cert_install_script = (root/'scripts'/'core'/'02-install-cert-manager.sh').read_text(encoding='utf-8')
for token in (
    'Waiting for cert-manager CRDs to become established',
    'clusterissuers.cert-manager.io',
    '02-validate-cert-manager-bootstrap.sh',
):
    if token not in cert_install_script:
        raise SystemExit(f'cert-manager bootstrap installer is missing sequencing/validation token: {token}')

cert_contract_validator = root/'scripts'/'core'/'02-validate-cert-manager-bootstrap.sh'
if not cert_contract_validator.is_file():
    raise SystemExit('scripts/core/02-validate-cert-manager-bootstrap.sh is missing')
contract_validator_text = cert_contract_validator.read_text(encoding='utf-8')
for token in (
    'helm -n "${NAMESPACE}" status "${RELEASE}"',
    'clusterissuer/${ISSUER}',
    '--for=condition=Ready',
    'dump_cert_manager_diagnostics',
):
    if token not in contract_validator_text:
        raise SystemExit(f'cert-manager bootstrap validator is missing token: {token}')

network_contract_validator = root/'scripts'/'core'/'05-validate-network-bootstrap.sh'
if not network_contract_validator.is_file():
    raise SystemExit('scripts/core/05-validate-network-bootstrap.sh is missing')
network_validator_text = network_contract_validator.read_text(encoding='utf-8')
for token in (
    'helm -n "${METALLB_NAMESPACE}" status "${METALLB_RELEASE}"',
    'ipaddresspool "${METALLB_POOL}"',
    'l2advertisement "${METALLB_L2}"',
    'helm -n "${CONTOUR_NAMESPACE}" status "${CONTOUR_RELEASE}"',
    'CONTOUR_SERVICE="segment1-envoy"',
    'network_bootstrap_diagnostics',
):
    if token not in network_validator_text:
        raise SystemExit(f'network bootstrap validator is missing token: {token}')

cert_chart_dir = bundle_root/'10-cert-manager'
cert_values_data = yaml.safe_load((cert_chart_dir/'values.yaml').read_text(encoding='utf-8')) or {}
if cert_values_data.get('installCRDs') is not True:
    raise SystemExit('10-cert-manager/values.yaml must set installCRDs: true before cert-manager-config is applied')
for candidate in cert_chart_dir.glob('*.yaml'):
    if candidate.name in {'fleet.yaml', 'values.yaml'}:
        continue
    text = candidate.read_text(encoding='utf-8')
    if 'apiVersion: cert-manager.io/' in text:
        raise SystemExit(f'{candidate.relative_to(root)} must not contain cert-manager custom resources; use 11-cert-manager-config')
config_fleet = (bundle_root/'11-cert-manager-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: cert-manager-config',
    'kmm.dev/bundle: cert-manager',
    'releaseName: cert-manager-config',
    'takeOwnership: true',
):
    if token not in config_fleet:
        raise SystemExit(f'11-cert-manager-config/fleet.yaml is missing token: {token}')
issuer_manifest = bundle_root/'11-cert-manager-config'/'segment1-ca-clusterissuer.yaml'
if not issuer_manifest.is_file():
    raise SystemExit('11-cert-manager-config/segment1-ca-clusterissuer.yaml is missing')
issuer_text = issuer_manifest.read_text(encoding='utf-8')
for token in ('kind: ClusterIssuer', 'name: segment1-ca-clusterissuer', 'secretName: segment1-ca-bundle-secret'):
    if token not in issuer_text:
        raise SystemExit(f'cert-manager config manifest is missing token: {token}')

metallb_chart_dir = bundle_root/'20-metallb'
metallb_values_data = yaml.safe_load((metallb_chart_dir/'values.yaml').read_text(encoding='utf-8')) or {}
if ((metallb_values_data.get('crds') or {}).get('enabled')) is not True:
    raise SystemExit('20-metallb/values.yaml must set crds.enabled: true before metallb-config is applied')
if (metallb_chart_dir/'address-pools.yaml').exists():
    raise SystemExit('20-metallb must contain only the external chart definition; move MetalLB custom resources to 21-metallb-config')
for directory in ('20-metallb', '21-metallb-config'):
    custom = parsed[directory].get('targetCustomizations') or []
    if not any(
        (((x.get('clusterSelector') or {}).get('matchLabels') or {}).get('kmm.dev/context') == 'j64seg1opman')
        and x.get('keepResources') is True
        for x in custom
    ):
        raise SystemExit(f'{directory}/fleet.yaml must preserve bootstrap-owned management resources during legacy Fleet retirement')
metallb_config_fleet = (bundle_root/'21-metallb-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: metallb-config',
    'kmm.dev/bundle: metallb',
    'releaseName: metallb-config',
    'takeOwnership: true',
):
    if token not in metallb_config_fleet:
        raise SystemExit(f'21-metallb-config/fleet.yaml is missing token: {token}')
metallb_config_dir = bundle_root/'21-metallb-config'
metallb_config_data = yaml.safe_load((metallb_config_dir/'fleet.yaml').read_text(encoding='utf-8')) or {}
metallb_helm = metallb_config_data.get('helm') or {}
if metallb_helm.get('chart') != './chart':
    raise SystemExit('21-metallb-config must use its local ./chart adapter so cluster-specific values are rendered by Helm')
if metallb_helm.get('valuesFiles') != ['fleet-values.yaml']:
    raise SystemExit('21-metallb-config must use fleet-values.yaml for per-cluster Fleet preprocessing')
metallb_fleet_values = metallb_config_dir/'fleet-values.yaml'
if not metallb_fleet_values.is_file():
    raise SystemExit('21-metallb-config/fleet-values.yaml is missing')
fleet_values_text = metallb_fleet_values.read_text(encoding='utf-8')
if 'segment1Pool:' not in fleet_values_text or 'kmm.dev/segment1-pool' not in fleet_values_text or '${ get .ClusterLabels' not in fleet_values_text:
    raise SystemExit('21-metallb-config/fleet-values.yaml must resolve segment1Pool from the Fleet cluster label')
chart_yaml = metallb_config_dir/'chart'/'Chart.yaml'
chart_values = metallb_config_dir/'chart'/'values.yaml'
metallb_config_manifest = metallb_config_dir/'chart'/'templates'/'address-pools.yaml'
for required_path in (chart_yaml, chart_values, metallb_config_manifest):
    if not required_path.is_file():
        raise SystemExit(f'MetalLB config local Helm chart is missing {required_path.relative_to(metallb_config_dir)}')
manifest_text = metallb_config_manifest.read_text(encoding='utf-8')
for token in ('kind: IPAddressPool', 'name: segment1', 'kind: L2Advertisement', 'name: platform', '.Values.segment1Pool'):
    if token not in manifest_text:
        raise SystemExit(f'MetalLB config chart template is missing token: {token}')
if '${ get .ClusterLabels' in manifest_text:
    raise SystemExit('MetalLB chart template must not contain Fleet cluster-label expressions; keep them in fleet-values.yaml')
for directory in ('31-contour-segment1', '63-eastwest-gateway'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: metallb-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on metallb-config')
for directory in ('53-keycloak', '54-keycloak-secondary', '62-istiod', '65-kiali-server', '66-kiali-resources'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: cert-manager-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on cert-manager-config')
for bundle_path in (
    'fleet/bundles/32-contour-segment1-policies',
    'fleet/bundles/40-longhorn',
    'fleet/bundles/41-longhorn-config',
    'fleet/bundles/42-longhorn-ui',
    'fleet/bundles/60-istio-base',
    'fleet/bundles/61-istio-cni',
    'fleet/bundles/62-istiod',
    'fleet/bundles/63-eastwest-gateway',
    'fleet/bundles/63-eastwest-gateway-config',
    'fleet/bundles/64-kiali-operator',
    'fleet/bundles/65-kiali-server',
    'fleet/bundles/66-kiali-resources',
    'fleet/bundles/70-kube-state-metrics',
    'fleet/bundles/70-kube-state-metrics-alias',
    'fleet/bundles/71-elastic-agent',
):
    if gitrepo_path_count(bundle_path) != 2:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} in local and downstream scopes')
for bundle_path in (
    'fleet/bundles/50-cnpg-operator',
    'fleet/bundles/51-postgresql-ha',
    'fleet/bundles/51-postgresql-ha-resources',
    'fleet/bundles/51-postgresql-replica',
    'fleet/bundles/52-keycloak-operator',
    'fleet/bundles/53-keycloak',
    'fleet/bundles/54-keycloak-secondary',
):
    if gitrepo_path_count(bundle_path) != 1:
        raise SystemExit(f'GitRepo bootstrap must include identity bundle {bundle_path} only in fleet-default')


seed_runtime_text = (root/'scripts'/'management'/'fleet'/'01-seed-runtime-secrets.sh').read_text(encoding='utf-8')
longhorn_install_text = (root/'scripts'/'core'/'04-install-longhorn.sh').read_text(encoding='utf-8')
for source_name, source_text in (
    ('01-seed-runtime-secrets.sh', seed_runtime_text),
    ('04-install-longhorn.sh', longhorn_install_text),
):
    if 'segment1.ingress/allow-backend=true' not in source_text:
        raise SystemExit(f'{source_name} must label longhorn-system as an approved Segment1 backend')

# Segment1 Envoy egress is authorized by namespace label. Keycloak therefore
# needs the label on opkeycloak itself; a similarly named pod label is not enough.
keycloak_prepare_text = (root/'scripts'/'opkeycloak'/'00-prepare-opkeycloak-runtime-secrets.sh').read_text(encoding='utf-8')
for source_name, source_text in (
    ('01-seed-runtime-secrets.sh', seed_runtime_text),
    ('00-prepare-opkeycloak-runtime-secrets.sh', keycloak_prepare_text),
):
    if 'segment1.ingress/allow-backend=true' not in source_text or 'opkeycloak' not in source_text:
        raise SystemExit(f'{source_name} must label the opkeycloak namespace as an approved Segment1 backend')

for rel in (
    'fleet/bundles/53-keycloak/chart/templates/keycloak.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/keycloak.yaml',
    'yaml/opkeycloak/resources/opkeycloak-seg1opdev-cr-v1.yaml',
):
    if 'segment1.ingress/allow-backend' in (root/rel).read_text(encoding='utf-8'):
        raise SystemExit(f'{rel} must not use the Segment1 backend namespace label as a Keycloak pod label')

# Envoy connects to the Longhorn Service on port 80, but the translated pod
# destination is TCP/8000. Both Envoy egress and Longhorn ingress must allow it.
longhorn_exposure_text = (bundle_root/'42-longhorn-ui'/'chart'/'templates'/'exposure.yaml').read_text(encoding='utf-8')
segment1_backend_egress_text = (bundle_root/'32-contour-segment1-policies'/'backend-egress.yaml').read_text(encoding='utf-8')
common_text = (root/'scripts'/'_lib'/'common.sh').read_text(encoding='utf-8')
for source_name, source_text in (
    ('42-longhorn-ui/chart/templates/exposure.yaml', longhorn_exposure_text),
    ('32-contour-segment1-policies/backend-egress.yaml', segment1_backend_egress_text),
    ('scripts/_lib/common.sh', common_text),
):
    if 'port: 8000' not in source_text:
        raise SystemExit(f'{source_name} must allow the Longhorn UI/backend translated TCP/8000 path')

# Kiali is exposed at the hostname root. Keep the Kiali server web root and the
# custom Segment1 Ingress path aligned so https://kiali-*.dev.kube/ does not 404.
kiali_values_text = (bundle_root/'65-kiali-server'/'values.yaml').read_text(encoding='utf-8')
kiali_exposure_text = (bundle_root/'66-kiali-resources'/'chart'/'templates'/'exposure.yaml').read_text(encoding='utf-8')
if "web_root: '/'" not in kiali_values_text:
    raise SystemExit("65-kiali-server/values.yaml must set server.web_root to '/'")
if '            path: /\n' not in kiali_exposure_text:
    raise SystemExit('66-kiali-resources exposure must route the hostname root path / to Kiali')
if 'path: /kiali' in kiali_exposure_text:
    raise SystemExit('66-kiali-resources exposure must not retain the obsolete /kiali-only route')

# Kiali 2.x expects pull-secret names as strings. Supplying Helm/YAML maps such
# as {name: regcred-kubeharbor} is stringified by Kiali into the literal pod
# imagePullSecret name "map[name:regcred-kubeharbor]", causing persistent
# FailedToRetrieveImagePullSecret events even though the real Secret exists.
kiali_operator_values = yaml.safe_load((bundle_root/'64-kiali-operator'/'values.yaml').read_text(encoding='utf-8')) or {}
kiali_server_values = yaml.safe_load((bundle_root/'65-kiali-server'/'values.yaml').read_text(encoding='utf-8')) or {}
operator_pull_secrets = ((kiali_operator_values.get('image') or {}).get('pullSecrets') or [])
server_pull_secrets = ((kiali_server_values.get('deployment') or {}).get('image_pull_secrets') or [])
for label, values in (
    ('64-kiali-operator image.pullSecrets', operator_pull_secrets),
    ('65-kiali-server deployment.image_pull_secrets', server_pull_secrets),
):
    if values != ['regcred-kubeharbor'] or not all(isinstance(value, str) for value in values):
        raise SystemExit(f'{label} must be a string list containing only regcred-kubeharbor; mapping values create invalid map[name:...] pod secret names')

for site_rel in (
    'yaml/j64/seg1opman-cluster/values/istio-kiali-operator-values-v1.yaml',
    'yaml/j64/seg1opdev-cluster/values/istio-kiali-operator-values-v1.yaml',
    'yaml/j52/seg1opdev-cluster/values/istio-kiali-operator-values-v1.yaml',
    'yaml/r01/seg1opdev-cluster/values/istio-kiali-operator-values-v1.yaml',
):
    values = yaml.safe_load((root/site_rel).read_text(encoding='utf-8')) or {}
    pull_secrets = ((values.get('image') or {}).get('pullSecrets') or [])
    if pull_secrets != ['regcred-kubeharbor'] or not all(isinstance(value, str) for value in pull_secrets):
        raise SystemExit(f'{site_rel}: image.pullSecrets must be [regcred-kubeharbor] as strings')
for site_rel in (
    'yaml/j64/seg1opman-cluster/values/istio-kiali-server-values-v1.yaml',
    'yaml/j64/seg1opdev-cluster/values/istio-kiali-server-values-v1.yaml',
    'yaml/j52/seg1opdev-cluster/values/istio-kiali-server-values-v1.yaml',
    'yaml/r01/seg1opdev-cluster/values/istio-kiali-server-values-v1.yaml',
):
    values = yaml.safe_load((root/site_rel).read_text(encoding='utf-8')) or {}
    pull_secrets = ((values.get('deployment') or {}).get('image_pull_secrets') or [])
    if pull_secrets != ['regcred-kubeharbor'] or not all(isinstance(value, str) for value in pull_secrets):
        raise SystemExit(f'{site_rel}: deployment.image_pull_secrets must be [regcred-kubeharbor] as strings')

# CloudNativePG operator polls each instance-manager HTTPS status endpoint on
# TCP/8000. Keep that explicit in both the primary and warm-secondary policies.
cnpg_primary_status = bundle_root/'51-postgresql-ha-resources'/'operator-status-networkpolicy.yaml'
cnpg_replica_policies = bundle_root/'51-postgresql-replica'/'chart'/'templates'/'networkpolicies.yaml'
if not cnpg_primary_status.is_file():
    raise SystemExit('51-postgresql-ha-resources/operator-status-networkpolicy.yaml is missing')
for source_name, source_text in (
    ('51-postgresql-ha-resources/operator-status-networkpolicy.yaml', cnpg_primary_status.read_text(encoding='utf-8')),
    ('51-postgresql-replica/chart/templates/networkpolicies.yaml', cnpg_replica_policies.read_text(encoding='utf-8')),
):
    for token in ('oppostgres-allow-cnpg-operator-status', 'app.kubernetes.io/name: cloudnative-pg',
                  'app.kubernetes.io/instance: oppostgres-operator', 'port: 8000'):
        if token not in source_text:
            raise SystemExit(f'{source_name} is missing CloudNativePG operator status-path token: {token}')

# CNPG-generated instance managers also initiate authenticated HTTPS calls to
# their owning Cluster/Pooler resources. Default-deny egress must retain the
# per-cluster Kubernetes service path or fresh database/bootstrap/Pooler pods
# fail before PostgreSQL or PgBouncer starts.
cnpg_primary_api = bundle_root/'51-postgresql-ha-resources'/'kubernetes-api-networkpolicy.yaml'
if not cnpg_primary_api.is_file():
    raise SystemExit('51-postgresql-ha-resources/kubernetes-api-networkpolicy.yaml is missing')
for source_name, source_text, service_ip, endpoint_ips in (
    ('51-postgresql-ha-resources/kubernetes-api-networkpolicy.yaml',
     cnpg_primary_api.read_text(encoding='utf-8'), '10.94.0.1/32',
     ('1.0.0.141/32', '1.0.0.142/32', '1.0.0.143/32')),
    ('51-postgresql-replica/chart/templates/networkpolicies.yaml',
     cnpg_replica_policies.read_text(encoding='utf-8'), '10.96.0.1/32',
     ('1.0.0.161/32', '1.0.0.162/32', '1.0.0.163/32')),
):
    for token in (
        'name: oppostgres-allow-kubernetes-api',
        'app.kubernetes.io/managed-by: cloudnative-pg',
        f'cidr: {service_ip}',
        'port: 443',
        'port: 6443',
        *(f'cidr: {endpoint_ip}' for endpoint_ip in endpoint_ips),
    ):
        if token not in source_text:
            raise SystemExit(f'{source_name} is missing CNPG Kubernetes API egress token: {token}')

# Operators share namespaces with their workloads. Application default-deny
# policies must not use podSelector: {}, which would also isolate the operators.
for rel in (
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/00-default-deny.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/networkpolicies.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/networkpolicies.yaml',
):
    text = (root/rel).read_text(encoding='utf-8')
    if 'podSelector: {}' in text:
        raise SystemExit(f'{rel} contains a namespace-wide podSelector default deny that can isolate a shared operator')

# CNPG rewrites reserved app.kubernetes.io labels on generated Pooler pods.
# Select Pooler pods with CNPG-owned labels so PDBs and NetworkPolicies actually match.
for rel in (
    'fleet/bundles/51-postgresql-ha/chart/templates/pooler.yaml',
    'fleet/bundles/51-postgresql-ha-resources/pgbouncer-pdb.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/pooler.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/pgbouncer-pdb.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/networkpolicies.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/01-opkeycloak-egress.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/03-oppostgres-path.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/networkpolicies.yaml',
):
    text = (root/rel).read_text(encoding='utf-8')
    if 'app.kubernetes.io/name: oppostgres-opkeycloak-db-pgbouncer' in text or 'app.kubernetes.io/component: connection-pooler' in text:
        raise SystemExit(f'{rel} uses a Pooler selector label that CloudNativePG overwrites on generated pods')

for rel in (
    'fleet/bundles/51-postgresql-ha-resources/pgbouncer-pdb.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/pgbouncer-pdb.yaml',
):
    if 'cnpg.io/poolerName: oppostgres-opkeycloak-db-pooler-rw' not in (root/rel).read_text(encoding='utf-8'):
        raise SystemExit(f'{rel} must select the generated Pooler pods by cnpg.io/poolerName')

for rel in (
    'fleet/bundles/51-postgresql-replica/chart/templates/networkpolicies.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/01-opkeycloak-egress.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/03-oppostgres-path.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/networkpolicies.yaml',
):
    text = (root/rel).read_text(encoding='utf-8')
    if 'cnpg.io/podRole: pooler' not in text:
        raise SystemExit(f'{rel} must select PgBouncer using CNPG-owned pooler labels')

# Keycloak Operator owns the stable server labels. NetworkPolicies must not rely
# on an unsupported podTemplate override of the reserved `app` label because
# the generated StatefulSet uses app=keycloak. A mismatch silently drops the
# Keycloak -> PgBouncer JDBC path at the PostgreSQL ingress policy.
keycloak_selector_files = (
    'fleet/bundles/52-keycloak-operator/monitoring-networkpolicy.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/00-default-deny.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/01-opkeycloak-egress.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/02-segment1-to-opkeycloak.yaml',
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/04-opkeycloak-cluster.yaml',
    'fleet/bundles/51-postgresql-ha-resources/keycloak-client-networkpolicy.yaml',
    'fleet/bundles/51-postgresql-replica/chart/templates/networkpolicies.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/networkpolicies.yaml',
)
for rel in keycloak_selector_files:
    text = (root/rel).read_text(encoding='utf-8')
    if 'app: opkeycloak' in text:
        raise SystemExit(f'{rel} must not select Keycloak pods with app=opkeycloak; the operator-owned label is app=keycloak')
    for token in ('app: keycloak', 'app.kubernetes.io/instance: opkeycloak', 'app.kubernetes.io/managed-by: keycloak-operator'):
        if token not in text:
            raise SystemExit(f'{rel} missing stable Keycloak Operator selector token: {token}')

for rel in (
    'fleet/bundles/53-keycloak/chart/templates/keycloak.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/keycloak.yaml',
):
    text = (root/rel).read_text(encoding='utf-8')
    if 'networkPolicy:\n    enabled: false' not in text:
        raise SystemExit(f'{rel} must disable the operator-generated NetworkPolicy because repository-managed policies own ingress/egress')
    if 'app: opkeycloak' in text:
        raise SystemExit(f'{rel} must not override the Keycloak Operator reserved app label')
    for token in (
        'secretName: opkeycloak-keytab',
        'secretName: opkeycloak-provider',
        'mountPath: /etc/keycloak/keytabs',
        'mountPath: /opt/keycloak/providers/kc-az-upn-linker.jar',
        'subPath: provider.jar',
    ):
        if token not in text:
            raise SystemExit(f'{rel} missing Keycloak runtime artifact mount token: {token}')

for token in (
    'KEYCLOAK_KEYTAB_FILE_001',
    'KEYCLOAK_PROVIDER_FILE_001',
    'opkeycloak-keytab',
    'opkeycloak-provider',
    'restart_keycloak_pods_ordered',
    'delete pod "${pod}"',
):
    if token not in seed_runtime_text:
        raise SystemExit(f'01-seed-runtime-secrets.sh missing Keycloak runtime artifact lifecycle token: {token}')


# Keycloak uses PostgreSQL/JDBC_PING2 for discovery, but JGroups/Infinispan
# still needs direct pod-to-pod TCP transport and failure-detection traffic.
# Repository-managed default-deny policies therefore require an explicit
# same-Keycloak-pod policy for both documented jdbc-ping cluster ports.
for rel in (
    'fleet/bundles/53-keycloak/chart/templates/networkpolicies/04-opkeycloak-cluster.yaml',
    'fleet/bundles/54-keycloak-secondary/chart/templates/networkpolicies.yaml',
):
    text = (root/rel).read_text(encoding='utf-8')
    for token in (
        'name: opkeycloak-allow-cluster',
        'policyTypes: [Ingress, Egress]',
        'app: keycloak',
        'app.kubernetes.io/instance: opkeycloak',
        'app.kubernetes.io/managed-by: keycloak-operator',
        'port: 7800',
        'port: 57800',
    ):
        if token not in text:
            raise SystemExit(f'{rel} missing required Keycloak intra-cluster NetworkPolicy token: {token}')

jdbc_policy = (bundle_root/'51-postgresql-ha-resources'/'keycloak-client-networkpolicy.yaml').read_text(encoding='utf-8')
for token in ('cnpg.io/podRole: pooler', 'kubernetes.io/metadata.name: opkeycloak', 'app: keycloak', 'port: 5432'):
    if token not in jdbc_policy:
        raise SystemExit(f'PostgreSQL prerequisite Keycloak JDBC NetworkPolicy missing token: {token}')

collector_text = (root/'scripts'/'collect-gitops-logs.sh').read_text(encoding='utf-8')
for token in (
    'all-networkpolicies.yaml', 'namespaces-labels.txt', 'networkpolicies.yaml',
    'DIAGNOSTICS_SCRIPT_REVISION="2026-09-09.1"',
    '.status.conditions[]?', 'select(.type == "Ready")',
    '($ready.status // "Unknown") != "True"',
    'endpointslices.discovery.k8s.io',
    'diagnostics-script-revision.txt',
    'Fleet GitRepo pause state', 'PAUSED:.spec.paused',
    'Identity transition journal', 'kmm-identity-transition-journal',
    'Identity transition lock', 'kmm-identity-transition-lock',
    'originalFleetPaused',
):
    if token not in collector_text:
        raise SystemExit(f'collect-gitops-logs.sh is missing required diagnostics contract token: {token}')
if '.status.display.state' in collector_text:
    raise SystemExit('collect-gitops-logs.sh must not use Fleet .status.display.state for Bundle readiness')
if 'get svc,ingress,endpoints -o wide' in collector_text:
    raise SystemExit('collect-gitops-logs.sh must capture EndpointSlice rather than deprecated core/v1 Endpoints')
if 'grep -RniE' in collector_text:
    raise SystemExit('collect-gitops-logs.sh must not recursively grep the full diagnostics tree for error-index generation')
for token in ('High-signal operational error index', "-name '*.current.log'", "-name 'all-events.txt'", 'ERROR_INDEX_LOG_LINES_PER_FILE', 'Previous-container logs and object YAML/JSON are intentionally excluded'):
    if token not in collector_text:
        raise SystemExit(f'collect-gitops-logs.sh missing high-signal error-index contract token: {token}')

monitor_validator = (root/'scripts'/'monitoring'/'02-validate-elastic-agent.sh').read_text(encoding='utf-8')
for token in (
    'MONITORING_VALIDATION_REVISION="2026-09-08.4"',
    'ELASTIC_AGENT_LOG_SINCE:-2m',
    'endpointslices',
    '(^|,)endpoints(,|$)',
    'kube-state-metrics alias is correct',
    'extract_agent_messages',
    'fromjson',
    'Agent message fields',
    'print_matches',
):
    if token not in monitor_validator:
        raise SystemExit(f'Elastic monitoring validator is missing required contract token: {token}')
if 'kube-state-metrics.*(no such host|server misbehaving)' in monitor_validator:
    raise SystemExit('Elastic monitoring validator must not scan raw aggregate Agent log lines for kube-state-metrics DNS failures')

label_script = (root/'scripts'/'management'/'fleet'/'02-label-fleet-clusters.sh').read_text(encoding='utf-8')
required_network_tokens = (
    '1.0.0.201-1.0.0.210', '1.0.0.205', '1.0.0.210',
    '1.0.0.211-1.0.0.220', '1.0.0.215', '1.0.0.216', '1.0.0.220',
    '1.0.0.221-1.0.0.230', '1.0.0.225', '1.0.0.226', '1.0.0.230',
    '1.0.0.231-1.0.0.240', '1.0.0.235', '1.0.0.240',
)
for token in required_network_tokens:
    if token not in label_script:
        raise SystemExit(f'Fleet label script missing Segment1 allocation: {token}')

# MetalLB requires a CIDR or a complete startIP-endIP range. Reject shorthand
# such as 1.0.0.211-220 before it reaches the validating webhook.
short_range = re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}-\d{1,3}(?!\.)\b', label_script)
if short_range:
    raise SystemExit(
        f'Fleet label script contains invalid abbreviated MetalLB range: {short_range.group(0)}; '
        'use full start-end IP notation'
    )
segment_network = ipaddress.ip_network('1.0.0.0/23')
range_literals = set(re.findall(r'\b((?:\d{1,3}\.){3}\d{1,3})-((?:\d{1,3}\.){3}\d{1,3})\b', label_script))
for start_literal, end_literal in range_literals:
    start = ipaddress.ip_address(start_literal)
    end = ipaddress.ip_address(end_literal)
    if start not in segment_network or end not in segment_network:
        raise SystemExit(f'Fleet label script contains a MetalLB range outside Segment1: {start_literal}-{end_literal}')
    if int(start) > int(end):
        raise SystemExit(f'Fleet label script contains a reversed MetalLB range: {start_literal}-{end_literal}')
for literal in set(re.findall(r'\b1\.0\.[01]\.\d{1,3}\b', label_script)):
    if ipaddress.ip_address(literal) not in segment_network:
        raise SystemExit(f'Fleet label script contains an address outside Segment1: {literal}')

forbidden_patterns = (
    re.compile(r'\b10\.0\.4\.'),
    re.compile(r'kmm\.dev/metallb-regular-pool', re.IGNORECASE),
    re.compile(r'\b(devlocal-argocd|contour-devlocal|ingress-devlocal)\b', re.IGNORECASE),
)
for relative in ('config', 'fleet', 'scripts', 'yaml'):
    directory = root / relative
    if not directory.exists():
        continue
    for path in directory.rglob('*'):
        if path == root/'scripts'/'validate-fleet-layout.sh':
            continue
        if not path.is_file() or path.suffix in {'.tgz', '.gz', '.zip'}:
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        for pattern in forbidden_patterns:
            if pattern.search(text):
                raise SystemExit(f'{path.relative_to(root)} contains retired deployment token matching {pattern.pattern}')

for context, address in {'j64seg1opman':'1.0.0.210','j64seg1opdev':'1.0.0.220','j52seg1opdev':'1.0.0.230','r01seg1opdev':'1.0.0.240'}.items():
    site = context[:3]
    cluster = context[3:]
    source = root/'yaml'/site/f'{cluster}-cluster'/'values'/'istio-istiod-values-v1.yaml'
    text = source.read_text(encoding='utf-8')
    data = yaml.safe_load(text) or {}
    if address not in text or 'segment1-ca-clusterissuer' not in text:
        raise SystemExit(f'{source.relative_to(root)} is not aligned with Segment1 mesh addressing and CA')
    if '_internal_defaults_do_not_set' in data or ((data.get('cni') or {}).get('enabled')) is not True:
        raise SystemExit(f'{source.relative_to(root)} must use supported root Istiod values with cni.enabled=true')
    pull_secrets = ((data.get('global') or {}).get('imagePullSecrets') or [])
    if pull_secrets != ['regcred-kubeharbor'] or not all(isinstance(x, str) for x in pull_secrets):
        raise SystemExit(f'{source.relative_to(root)} must use string-valued global.imagePullSecrets')
    gateway_source = source.parent/'istio-eastwest-gateway-values-v1.yaml'
    gateway_data = yaml.safe_load(gateway_source.read_text(encoding='utf-8')) or {}
    if '_internal_defaults_do_not_set' in gateway_data:
        raise SystemExit(f'{gateway_source.relative_to(root)} must use supported root Gateway chart values')
    for retired_key in ('hub', 'tag'):
        if retired_key in gateway_data:
            raise SystemExit(
                f'{gateway_source.relative_to(root)} sets unsupported Istio Gateway 1.30.1 root key {retired_key!r}'
            )

print('Fleet YAML, dependencies, monitoring, two-site identity, RKE2 CNI, and Segment1-only network checks passed.')
PY2

if grep -RIl --exclude='*.md' -i 'argocd' \
  "${ROOT_DIR}/fleet" "${ROOT_DIR}/scripts/deploy-platform.sh" "${ROOT_DIR}/scripts/management/fleet"; then
  die "Argo CD references remain in active Fleet code."
fi

log "Fleet layout validation passed."
