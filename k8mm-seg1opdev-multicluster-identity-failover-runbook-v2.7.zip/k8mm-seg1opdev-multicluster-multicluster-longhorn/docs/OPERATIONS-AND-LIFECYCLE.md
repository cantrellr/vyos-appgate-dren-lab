# Operations and Lifecycle

> **Baseline:** v2.7 — September 10, 2026  
> **Audience:** platform operators, systems administrators, SRE/operations personnel, and escalation engineers.

## 1. Operating model

Normal steady-state changes follow this loop:

1. change the intended Git branch;
2. run `validate-package`;
3. push to GitLab;
4. allow Fleet to reconcile;
5. validate BundleDeployment readiness and service-specific health;
6. revert Git if the change is not acceptable.

Do not treat Rancher UI red states as a reason to manually delete Bundles. First identify the failing dependency and the Git commit/branch Fleet is actually reconciling.

## 2. Daily health checks

Recommended daily/shift checks:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For storage-sensitive operations also run:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

`prepare-longhorn-nodes` is non-destructive and verifies the host storage contract.

## 3. Rancher and Fleet operations

### Fleet readiness

Healthy steady state means the intended GitRepos are Ready and all intended BundleDeployments are Active. Bundle dependencies are expressed by `kmm.dev/bundle` labels.

Inspect GitRepos:

```bash
kubectl --context j64seg1opman -A get gitrepos.fleet.cattle.io
```

Inspect bundles by workspace:

```bash
kubectl --context j64seg1opman -n fleet-local get bundles.fleet.cattle.io
kubectl --context j64seg1opman -n fleet-default get bundles.fleet.cattle.io
```

Inspect the actual branch/commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

### Kubernetes 1.35 Fleet compatibility

The baseline requires `KUBE_FEATURE_WatchListClient=false` on Fleet controllers and agents. Apply/verify with:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Do not remove this control until the pinned Rancher/Fleet combination is upgraded and the replacement has been validated against RKE2/Kubernetes 1.35 behavior.

### Rancher system repair

Use:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow validates the registry, refreshes CoreDNS/registry credentials, restores Rancher ingress, repairs PSA namespace labels, applies GitJob RBAC, enforces the WatchListClient compatibility setting, waits for Rancher/Fleet components, and forces GitRepo rescan. It intentionally avoids deleting healthy Rancher/Fleet resources.

## 4. GitOps deployment flow

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

Operational principle: correct the **source of truth** or the external dependency causing reconciliation failure. Direct changes to Fleet-owned resources are break-glass actions and may be reverted automatically.

## 5. Chrony operations

Chrony owns the host clock while deployed. It runs as a privileged DaemonSet and records the prior `systemd-timesyncd` state under `/var/lib/k8mm/chrony`.

Validate all clusters:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target one cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

View compact telemetry:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=50
```

A healthy node reports a selected source, positive stratum, and `Leap status: Normal`. The installer emits detailed `tracking`, `sources`, `ntpdata`, log, and event information when synchronization fails.

Supported removal:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

Do not delete the DaemonSet manually as the standard removal method; the supported command restores the saved host time-service state.

## 6. Longhorn operations

### Host contract

Default worker contract:

- path: `/mnt/k8sdata`;
- filesystem: XFS;
- minimum capacity: `240 GiB`;
- iSCSI available and active;
- shared root mount propagation;
- multipath disabled where it can claim Longhorn devices.

Validate:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

### Kubernetes checks

```bash
kubectl --context j64seg1opdev -n longhorn-system get pods -o wide
kubectl --context j64seg1opdev get storageclass
kubectl --context j64seg1opdev get pvc -A
```

The stateful identity workloads use `longhorn-xfs-retain`.

### Longhorn UI

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://longhorn-man.dev.kube` |
| `j64seg1opdev` | `https://longhorn-j64.dev.kube` |
| `j52seg1opdev` | `https://longhorn-j52.dev.kube` |
| `r01seg1opdev` | `https://longhorn-r01.dev.kube` |

Fleet creates the HTTPProxy/certificate. The proxy allows only source addresses in `1.0.0.0/23` and sends traffic to `longhorn-frontend:80`.

Use Longhorn snapshots/replicas for in-cluster operational recovery, but maintain a separately approved disaster-recovery/backup strategy if off-cluster recovery is required.

## 7. Istio and Kiali operations

Validate mesh components and namespace injection:

```bash
./scripts/istio/04-check-istio-system.sh --all
./scripts/istio/05-audit-namespace-injection.sh --all
```

Kiali URLs:

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://kiali-man.dev.kube` |
| `j64seg1opdev` | `https://kiali-j64.dev.kube` |
| `j52seg1opdev` | `https://kiali-j52.dev.kube` |
| `r01seg1opdev` | `https://kiali-r01.dev.kube` |

Kiali depends on the external Prometheus and Grafana endpoints configured in its values. A healthy Kiali pod can therefore still show degraded metrics if those external services or the Grafana credential Secret are unavailable.

Istio webhook CA fields are controller-managed runtime data. Fleet comparison rules intentionally ignore only the expected `caBundle` mutation rather than suppressing entire webhook objects.

## 8. Identity operations

### 8.1 Purpose and operating model

The identity tier is a **bidirectional active/warm-standby** service across `j64seg1opdev` and `j52seg1opdev`. The operational objective is simple: exactly one site is writable and serves Keycloak traffic at any point in time. The peer site is a read-only PostgreSQL replica with Keycloak scaled to zero, while its Service, TLS Certificate, and HTTPProxy remain pre-staged so that certificate issuance and route construction are not on the failover critical path.

| Site | Segment1 ingress VIP | DNS ingress alias | PostgreSQL replication VIP | Runtime role |
| --- | --- | --- | --- | --- |
| `j64seg1opdev` | `1.0.0.215` | `j64seg1opdev-ingress` | `1.0.0.216` | active or warm standby |
| `j52seg1opdev` | `1.0.0.225` | `j52seg1opdev-ingress` | `1.0.0.226` | active or warm standby |

Canonical user endpoint:

```text
https://opkeycloak.dev.jde.cybercom.ic.gov
```

Authoritative DNS is a **manual external control**. The failover scripts do not edit DNS. DNS Admins switch the canonical CNAME between the two ingress aliases:

```text
J64 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
J52 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
TTL: 30 seconds
Segment1 DNS validation servers: 1.0.1.30 and 1.0.1.31
```

The controller validates those DNS servers directly. The deployment controller's local resolver is diagnostic only and is not authoritative for the production failover gate.

The static Fleet label `kmm.dev/identity=primary|secondary` is a **physical site/bundle-family selector** and is never swapped. Runtime identity ownership is carried by `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-primary-site`, `kmm.dev/postgres-hibernation`, and the CloudNativePG distributed-topology fields.

### 8.2 Planned versus unplanned: choose the correct path

Use an explicit mode during an operator-controlled change. Although the implementation supports `IDENTITY_SWITCHOVER_MODE=auto`, production procedures should set `planned` or `unplanned` so that the operator is making the availability/RPO decision rather than allowing reachability alone to choose it.

| Situation | Mode | RPO expectation | Old source action | Terminal state |
| --- | --- | --- | --- | --- |
| Both sites reachable and current primary can participate | `planned` | Final WAL is replayed before role transfer; designed for zero transaction loss at the database cutover gate | Keycloak quiesced, writes fenced, CNPG cleanly demoted | `complete` |
| Current primary/site is unavailable or cannot be trusted to demote | `unplanned` | **Non-zero RPO**; latest acknowledged transactions may not have reached the replica | Old source must be hard-fenced externally before target promotion | `complete-degraded` |
| Management cluster `j64seg1opman` unavailable | Neither | N/A | Restore management first | No supported management-less promotion in this repository |
| Non-terminal transition journal already exists | Resume existing mode | Depends on recorded mode | Follow recorded stage | Do not start another transition |

### 8.3 Identity command quick reference

```bash
# Role, exposure, DNS, and transition state
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics

# Database and HA validation
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded

# Planned bidirectional switch
./scripts/deploy-platform.sh switch-identity j64
./scripts/deploy-platform.sh switch-identity j52

# Continue or abandon an interrupted planned transition
./scripts/deploy-platform.sh resume-identity-transition
./scripts/deploy-platform.sh rollback-identity-transition   # planned + before source-demoted only

# Recovery after unplanned promotion
./scripts/deploy-platform.sh rebuild-identity-standby <j64seg1opdev|j52seg1opdev>
```

`failover-identity` and `failback-identity` remain compatibility aliases. New operational procedures should use `switch-identity <target>` so the destination site is explicit.

### 8.4 Required runtime configuration

The protected runtime file selected by `KMM_FLEET_CONFIG` should contain the production identity settings. Baseline values are:

```bash
IDENTITY_TRAFFIC_CUTOVER_MODE=dns-admin
IDENTITY_PRIMARY_INGRESS_CNAME=j64seg1opdev-ingress
IDENTITY_SECONDARY_INGRESS_CNAME=j52seg1opdev-ingress
IDENTITY_PRIMARY_INGRESS_IP=1.0.0.215
IDENTITY_SECONDARY_INGRESS_IP=1.0.0.225
IDENTITY_PRIMARY_REPLICATION_IP=1.0.0.216
IDENTITY_SECONDARY_REPLICATION_IP=1.0.0.226
IDENTITY_DNS_TTL_SECONDS=30
IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS=90
IDENTITY_DNS_SERVERS="1.0.1.30 1.0.1.31"
IDENTITY_DNS_REQUIRE_ALL_SERVERS=true
IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS=180
IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS=600
```

Before a maintenance or DR window, verify the runtime file actually being consumed:

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster

echo "KMM_FLEET_CONFIG=${KMM_FLEET_CONFIG:-<unset>}"
test -n "${KMM_FLEET_CONFIG:-}" && test -r "$KMM_FLEET_CONFIG"
grep -nE '^(IDENTITY_(DNS_SERVERS|DNS_REQUIRE_ALL_SERVERS|TRAFFIC_CUTOVER_MODE|PRIMARY_INGRESS|SECONDARY_INGRESS|PRIMARY_REPLICATION|SECONDARY_REPLICATION)|JDE_DNS_SERVERS|DEV_KUBE_DNS_SERVERS)=' "$KMM_FLEET_CONFIG"
```

For this Segment1 deployment, identity DNS validation should show `1.0.1.30,1.0.1.31`. Do not change an NTP setting such as `NTP_SERVERS=1.0.1.34` when correcting identity DNS.

### 8.5 Transition journal and lock model

Every transition is journaled in:

```text
namespace: fleet-default
ConfigMap: kmm-identity-transition-journal
Lease:     kmm-identity-transition-lock
```

Important stages, in order, are:

```text
initialized
fleet-paused
source-traffic-quiesced
source-wal-fenced       # planned only
source-hard-fenced      # unplanned only
source-demoted          # planned only
target-promoted
fleet-labels-switched
fleet-target-reconciled
target-keycloak-ready
dns-cutover-pending
traffic-activated
fleet-restored
verified
complete | complete-degraded | rolled-back
```

The journal is the recovery control point. Never delete it to make an error disappear. A non-terminal journal means **resume the recorded transition**, not start an opposite transition.

### 8.6 Planned failover decision flow

```mermaid
flowchart TD
  A[Maintenance window approved] --> B[Load protected runtime config]
  B --> C[Run preflight and HA validation]
  C --> D{Journal terminal or absent?}
  D -- No --> E[Resume recorded transition]
  D -- Yes --> F{Source reachable and replication healthy?}
  F -- No --> G[Do not use planned mode; evaluate unplanned runbook]
  F -- Yes --> H[Set planned mode and target confirmation]
  H --> I[switch-identity target]
  I --> J[Quiesce Keycloak and database writes]
  J --> K[Replay final WAL on target]
  K --> L[CNPG demotion token and target promotion]
  L --> M[Fleet role reconciliation]
  M --> N[Target Keycloak + direct OIDC healthy]
  N --> O[dns-cutover-pending / waiting-external]
  O --> P[DNS Admin changes CNAME]
  P --> Q[Validate 1.0.1.30 and 1.0.1.31]
  Q --> R[Set traffic confirmation and resume]
  R --> S[Reverse replication + strict HA validation]
  S --> T[complete]
```

Canonical source: `diagrams/identity-planned-failover-runbook.mmd`.

### 8.7 Planned failover preflight — run every time

Run these commands **before** starting a new planned switch:

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster

./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

Proceed only when all of the following are true:

1. `identity-transition-status` reports no journal or a terminal journal (`complete`, `complete-degraded`, or `rolled-back`). If it is non-terminal, follow **8.12 Interrupted transition recovery** instead.
2. `identity-active-site` identifies exactly one active site.
3. The current primary database is reachable and writable.
4. The standby is in recovery and replication is streaming within the configured thresholds.
5. Both sites are enrolled in the CloudNativePG distributed topology.
6. Neither site has a steady-state `spec.replica.promotionToken` residue.
7. The target site's Keycloak Service, Certificate, and HTTPProxy are present and valid. Zero ready Keycloak endpoints on the standby are expected before activation.
8. Fleet is not already paused.
9. DNS Admins are available to change the CNAME when the workflow reaches `dns-cutover-pending`.

If the initial J64 -> J52 topology has not yet been enrolled:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh verify-database-replication
```

### 8.8 Planned J64 -> J52 failover — complete operator runbook

Use this procedure when `identity-active-site` reports `activeSite=j64seg1opdev`.

**Step 1 — confirm the source/target and capture pre-change evidence.**

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster

./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh identity-transition-diagnostics
```

**Step 2 — start the planned transition.** Do **not** pre-set the DNS traffic confirmation.

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM

./scripts/deploy-platform.sh switch-identity j52

unset IDENTITY_SWITCHOVER_MODE
```

The script performs the database/Keycloak role transfer and intentionally returns after reaching the external DNS gate. Expected output includes:

```text
stage=dns-cutover-pending
status=waiting-external
DNS ADMIN ACTION REQUIRED
Change CNAME from: j64seg1opdev-ingress
Change CNAME to  : j52seg1opdev-ingress
Target ingress   : 1.0.0.225
```

**Step 3 — verify the journal before asking for DNS.**

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-exposure-status j52
./scripts/deploy-platform.sh identity-dns-status j52
```

J52 must have ready Keycloak endpoints, a Ready certificate, valid HTTPProxy, and `directOIDC=healthy`. DNS may still show J64 at this point; that is expected.

**Step 4 — DNS Admin changes the canonical CNAME.**

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
```

Do not point the canonical record directly at `1.0.0.225`. The operational contract is CNAME-to-ingress-alias.

**Step 5 — independently validate both Segment1 DNS servers.**

```bash
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov A +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov A +short

./scripts/deploy-platform.sh identity-dns-status j52
```

Required end state:

```text
expectedCNAME=j52seg1opdev-ingress
expectedIngressIP=1.0.0.225
dnsServer=1.0.1.30 ... cnameMatch=match ingressIPMatch=match status=match
dnsServer=1.0.1.31 ... cnameMatch=match ingressIPMatch=match status=match
segment1DnsConsensus=match
directTargetOIDC=healthy
controllerResolverGate=false
```

**Step 6 — acknowledge traffic cutover and resume the same journal.**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev

./scripts/deploy-platform.sh resume-identity-transition

unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

**Step 7 — run complete post-failover validation.**

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate
```

Required steady state:

```text
activeSite=j52seg1opdev
J52: PostgreSQL writable, Keycloak 3, direct/canonical OIDC healthy
J64: PostgreSQL read-only streaming replica, Keycloak 0
journal: status=complete stage=complete
Segment1 DNS: both 1.0.1.30 and 1.0.1.31 resolve only to J52 ingress
```

### 8.9 Planned J52 -> J64 failback — complete operator runbook

Do not start until the previous J64 -> J52 journal is terminal and J52 -> J64 replication is healthy.

**Step 1 — preflight.**

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster

./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

**Step 2 — start the planned switch to J64.**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM

./scripts/deploy-platform.sh switch-identity j64

unset IDENTITY_SWITCHOVER_MODE
```

Wait for:

```text
stage=dns-cutover-pending
status=waiting-external
```

**Step 3 — DNS Admin changes the canonical CNAME.**

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
```

**Step 4 — validate both Segment1 resolvers.**

```bash
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov A +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov A +short

./scripts/deploy-platform.sh identity-dns-status j64
```

Both resolvers must report the J64 alias and `1.0.0.215`.

**Step 5 — resume and complete.**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j64seg1opdev

./scripts/deploy-platform.sh resume-identity-transition

unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

**Step 6 — validate the restored home state.**

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate
```

Required steady state:

```text
activeSite=j64seg1opdev
J64: PostgreSQL writable, Keycloak 3
J52: PostgreSQL read-only streaming replica, Keycloak 0
journal: status=complete stage=complete
no stale spec.replica.promotionToken on either site
```

For rebuilt environments, the HA release test should include the full **J64 -> J52 -> J64** round trip. The first move proves promotion; the reverse move proves one-shot promotion-token cleanup, reverse replication, Fleet role reversal, DNS cutback, and reusable journal logic.

### 8.10 What the planned workflow does internally

The planned workflow is journaled and serialized with the transition Lease. In order, it:

1. verifies live source-to-target replication and distributed-topology readiness;
2. validates target pre-staged Service/Certificate/HTTPProxy;
3. pauses downstream Fleet and records its original pause state;
4. quiesces source Keycloak and scales source Keycloak to zero;
5. disables new `opkeycloak` database connections, terminates existing sessions, checkpoints PostgreSQL, captures the final source WAL LSN, and waits for target replay through that exact LSN;
6. demotes the source and obtains the CloudNativePG demotion token while atomically removing any stale consumed `spec.replica.promotionToken` from the source spec;
7. promotes the target with that one-shot token, waits for PostgreSQL writable state and matching `status.lastPromotionToken`, then removes the consumed token from the target spec;
8. switches runtime Fleet labels and restores Fleet so target resources reconcile;
9. starts three target Keycloak instances and validates endpoints, certificate, HTTPProxy, and direct canonical-SNI OIDC health;
10. records `dns-cutover-pending`, releases the transition lock, and returns control to the operator/DNS Admin;
11. after explicit traffic confirmation, validates the canonical CNAME/A chain against each configured Segment1 DNS server plus direct target OIDC health;
12. verifies reverse PostgreSQL replication and strict HA, then records `complete`.

### 8.11 Unplanned identity failover — complete disaster runbook

Use this procedure only when the current writable identity site is unavailable or cannot safely participate in a planned demotion. Cross-site replication is asynchronous. An unplanned promotion may lose transactions that were acknowledged by the failed source but had not yet been replayed by the standby.

**Hard rule:** do not promote the surviving replica until the old writable site is **hard-fenced** so it cannot return and accept writes. The repository requires an executable fence hook and will not perform an unplanned promotion without it.

```mermaid
flowchart TD
  A[Primary identity site suddenly unavailable] --> B{Management cluster j64seg1opman reachable?}
  B -- No --> C[Restore management plane first]
  B -- Yes --> D[Check transition journal and declared active site]
  D --> E{Non-terminal journal exists?}
  E -- Yes --> F[Resume recorded transition; do not start another]
  E -- No --> G[Inspect surviving replica replay LSN and WAL receiver evidence]
  G --> H[Accept non-zero RPO]
  H --> I[Hard-fence failed source and verify isolation]
  I --> J[Set unplanned confirmations and run switch-identity target]
  J --> K[Promote surviving PostgreSQL without demotion token]
  K --> L[Fleet marks old source hibernated and starts target Keycloak]
  L --> M[Direct target OIDC healthy]
  M --> N[dns-cutover-pending / waiting-external]
  N --> O[DNS Admin changes CNAME]
  O --> P[Validate DNS 1.0.1.30 and 1.0.1.31]
  P --> Q[Set traffic confirmation and resume]
  Q --> R[validate-identity-ha --allow-degraded]
  R --> S[complete-degraded; keep old source fenced]
  S --> T[Rebuild former primary from surviving site]
  T --> U[Strict HA validation and optional planned failback]
```

Canonical source: `diagrams/identity-unplanned-failover-runbook.mmd`.

#### 8.11.1 Immediate incident actions

Do not immediately change DNS and do not power the failed primary back on while deciding what to do.

```bash
cd /home/k8admin/k8mm-seg1opdev-multicluster

# Management plane must be available for the supported runbook.
kubectl --context j64seg1opman get nodes
kubectl --context j64seg1opman -n fleet-default get gitrepo

# Determine repository-declared state and whether a transition already exists.
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-transition-diagnostics
```

If `identity-transition-status` shows a non-terminal journal, **stop here and use 8.12**. Do not create a second failover operation.

If `j64seg1opman` is unavailable, restore management first. This repository does not implement or endorse an undocumented management-less direct CNPG promotion.

#### 8.11.2 Inspect the surviving replica before accepting RPO

Example below assumes J64 failed and J52 is the surviving target:

```bash
TARGET=j52seg1opdev
PGNS=oppostgres
PGCLUSTER=oppostgres-opkeycloak-db

kubectl --context "$TARGET" -n "$PGNS" get clusters.postgresql.cnpg.io/"$PGCLUSTER" -o wide

PGPOD="$(kubectl --context "$TARGET" -n "$PGNS" get clusters.postgresql.cnpg.io/"$PGCLUSTER" -o jsonpath='{.status.currentPrimary}')"
echo "TARGET=$TARGET PGPOD=$PGPOD"

kubectl --context "$TARGET" -n "$PGNS" exec "$PGPOD" -- \
  psql -U postgres -d postgres -Atqc \
  "select 'in_recovery='||pg_is_in_recovery(),
          'last_replay_lsn='||coalesce(pg_last_wal_replay_lsn()::text,'NULL'),
          'last_replay_age='||coalesce((clock_timestamp()-pg_last_xact_replay_timestamp())::text,'NULL');"

kubectl --context "$TARGET" -n "$PGNS" exec "$PGPOD" -- \
  psql -U postgres -d postgres -Atqc \
  "select concat_ws('|','wal_receiver',coalesce(status,'missing'),coalesce(sender_host,'missing'),
          coalesce(sender_port::text,'missing'),coalesce(last_msg_receipt_time::text,'missing'))
     from pg_stat_wal_receiver;"
```

Interpretation:

- `in_recovery=t` is expected before promotion.
- `last_replay_lsn` must be a real PostgreSQL LSN. The switchover script itself refuses unplanned promotion if it cannot obtain a trustworthy replay LSN.
- If the WAL receiver is absent because the source is down, that is expected after the failure; capture the last replay evidence and incident timestamp for the RPO record.
- Do **not** run the normal `verify-database-replication` gate as a requirement for unplanned promotion when the source is gone; it is intentionally a planned/healthy-path check.

For J52 failed / J64 surviving, set `TARGET=j64seg1opdev` and run the same commands.

#### 8.11.3 Prepare and test the hard-fence hook

The hook is site/environment-specific and must perform a real isolation action such as verified hypervisor power-off, network isolation, or another approved control that prevents the old PostgreSQL primary from becoming reachable/writable. A script that only prints a message and exits `0` is **not** an acceptable fence.

The repository includes a fail-closed template at:

```text
scripts/management/failover/examples/hard-fence-source.example.sh
```

Copy it to an approved protected path and replace the `exit 1` placeholder with the site's real fence **and verification** commands:

```bash
sudo install -d -m 0750 /opt/kmm/failover
sudo install -m 0750 \
  scripts/management/failover/examples/hard-fence-source.example.sh \
  /opt/kmm/failover/fence-identity-source.sh

sudoedit /opt/kmm/failover/fence-identity-source.sh
bash -n /opt/kmm/failover/fence-identity-source.sh
sudo chmod 0750 /opt/kmm/failover/fence-identity-source.sh
```

The example intentionally fails until implemented. Exercise the real fence only in an approved test/DR window, because a correct implementation is expected to isolate or power off the selected source site. During an actual transition the controller passes these environment variables to the hook:

```text
IDENTITY_SWITCHOVER_PHASE=hard-fence-source
IDENTITY_SWITCHOVER_SOURCE_CONTEXT=<failed-source-site>
IDENTITY_SWITCHOVER_SOURCE_IP=<failed-source-ingress-vip>
IDENTITY_SWITCHOVER_TARGET_CONTEXT=<surviving-target-site>
IDENTITY_SWITCHOVER_TARGET_IP=<surviving-target-ingress-vip>
IDENTITY_SWITCHOVER_CANONICAL_HOST=opkeycloak.dev.jde.cybercom.ic.gov
```

Your hook should exit `0` **only after the old source is both fenced and independently verified fenced**. It should exit non-zero if fencing or verification cannot be proven.

#### 8.11.4 Start unplanned promotion — J64 failed, promote J52

Only after the RPO review and hard fence are ready:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/opt/kmm/failover/fence-identity-source.sh
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM

./scripts/deploy-platform.sh switch-identity j52
```

The workflow will:

1. record the surviving target's replay LSN/WAL-receiver snapshot;
2. pause Fleet;
3. attempt best-effort source Keycloak shutdown if the source API is still reachable;
4. execute the mandatory hard-fence hook;
5. promote J52 without requiring a source demotion token;
6. mark J64 runtime labels inactive, Keycloak `0`, and PostgreSQL hibernation `on`;
7. mark J52 active with Keycloak `3` and reconcile Fleet;
8. validate J52 direct canonical-SNI OIDC health;
9. stop at `dns-cutover-pending` / `waiting-external`.

#### 8.11.5 Start unplanned promotion — J52 failed, promote J64

Use the exact same control sequence with the target reversed:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/opt/kmm/failover/fence-identity-source.sh
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM

./scripts/deploy-platform.sh switch-identity j64
```

The fence hook will receive `IDENTITY_SWITCHOVER_SOURCE_CONTEXT=j52seg1opdev` and must fence J52.

#### 8.11.6 Perform the DNS cutover after target OIDC is healthy

For J64 failed / J52 promoted:

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
```

For J52 failed / J64 promoted:

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
```

Validate both Segment1 DNS servers. J52 example:

```bash
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov CNAME +short
dig @1.0.1.30 opkeycloak.dev.jde.cybercom.ic.gov A +short
dig @1.0.1.31 opkeycloak.dev.jde.cybercom.ic.gov A +short

./scripts/deploy-platform.sh identity-dns-status j52
```

Do not resume until `segment1DnsConsensus=match` and direct target OIDC is healthy.

#### 8.11.7 Resume the unplanned journal after DNS change

J52 example:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev

./scripts/deploy-platform.sh resume-identity-transition
```

J64 example:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j64seg1opdev

./scripts/deploy-platform.sh resume-identity-transition
```

After the command returns:

```bash
unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_SWITCHOVER_MODE
unset IDENTITY_ALLOW_UNPLANNED_FAILOVER
unset IDENTITY_UNPLANNED_RPO_ACK
unset IDENTITY_HARD_FENCE_SOURCE_HOOK
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

A successful unplanned operation intentionally ends:

```text
status=complete-degraded
stage=complete-degraded
```

That is a successful service restoration, **not** a restored HA posture.

#### 8.11.8 Validate service in degraded mode

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
```

Keep the failed/former primary hard-fenced. Do not remove the fence merely because the active site is healthy.

### 8.12 Interrupted transition recovery: exactly what to do by stage

Always begin with:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics
```

Use the journal's **recorded target**. Do not infer a new target from what you wish the state to be.

| Journal condition | Correct action |
| --- | --- |
| No journal / terminal journal | A new planned or unplanned operation may be considered after normal preflight. |
| Planned, before `source-demoted` | Resume the same operation, or use `rollback-identity-transition` if the change must be abandoned. |
| Planned, at/after `source-demoted` | **Resume only.** Do not manually reverse CNPG fields, Fleet labels, or DNS. |
| Unplanned, before `source-hard-fenced` | Re-establish the hard-fence hook environment and resume. The source must still be fenced before promotion. |
| Unplanned, at/after `source-hard-fenced` | Keep the physical/network fence in place and resume the same operation. |
| `dns-cutover-pending` / `waiting-external` | Make/verify the recorded DNS CNAME change, set both confirmations, and resume. |

**Planned resume example:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
```

**Planned rollback, only before `source-demoted`:**

```bash
./scripts/deploy-platform.sh rollback-identity-transition
```

**Unplanned resume before `source-hard-fenced`:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/opt/kmm/failover/fence-identity-source.sh

./scripts/deploy-platform.sh resume-identity-transition
```

The journal already records the mode/RPO decision, but the hook path itself is not stored in the journal. Re-exporting the complete unplanned environment on early-stage resume avoids losing the hard-fence dependency.

**DNS-gate resume example:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
```

### 8.13 DNS gate behavior and bounded waits

The controller prints the gate, elapsed time, remaining time, and the blocking state. Example:

```text
[INFO] WAIT gate=dns-cname-tls-oidc elapsed=30s remaining=150s segment1DNS=mismatch expectedCNAME=j52seg1opdev-ingress expectedIP=1.0.0.225 directTargetOIDC=healthy controllerCanonicalOIDC=unhealthy details=resolver=1.0.1.30 ...; resolver=1.0.1.31 ...;
```

Useful commands:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics
./scripts/deploy-platform.sh identity-dns-status <active|j64|j52>
```

Default waits:

| Gate | Default | Override |
| --- | ---: | --- |
| DNS-admin Segment1 resolver validation after acknowledgement | 180 s | `IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS` |
| Controller-DNS / target traffic timeout | 600 s | `IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS` |
| Expected DNS convergence warning | 90 s | `IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS` |
| Published DNS TTL | 30 s | `IDENTITY_DNS_TTL_SECONDS` |
| Target Keycloak/exposure | 900 s | `IDENTITY_TARGET_EXPOSURE_TIMEOUT_SECONDS` |
| Fleet post-role reconciliation | 900 s | `IDENTITY_FLEET_RECONCILE_TIMEOUT_SECONDS` |
| CNPG WAL/demotion/promotion | 900 s | `IDENTITY_DATABASE_TRANSITION_TIMEOUT_SECONDS` |
| Kubernetes API request | 10 s/request | `IDENTITY_KUBECTL_REQUEST_TIMEOUT` |
| DNS/NSS lookup | 5 s | `IDENTITY_DNS_LOOKUP_TIMEOUT_SECONDS` |
| Poll interval | 5 s | `IDENTITY_FAILOVER_POLL_INTERVAL_SECONDS` |
| Progress report interval | 30 s | `IDENTITY_FAILOVER_DIAGNOSTIC_INTERVAL_SECONDS` |

If DNS Admin acknowledgement has been given but the two Segment1 resolvers do not converge within the 180-second validation window, the database/Keycloak role transfer is **not** rolled back. The controller records `waiting-external`, releases the Lease, and exits so DNS can be corrected and the same journal resumed.

### 8.14 Rebuild the former primary after unplanned promotion

After an unplanned promotion, the old primary may be on a divergent PostgreSQL timeline. **Do not simply reconnect it and do not immediately planned-failback to it.** Keep it fenced until it is deliberately rebuilt as a replica of the surviving active site.

```mermaid
flowchart LR
  A[Unplanned failover complete-degraded] --> B[Keep former primary fenced]
  B --> C[Validate surviving active site]
  C --> D[Confirm backup / recovery evidence]
  D --> E[rebuild-identity-standby former-primary]
  E --> F[pg_basebackup from active site]
  F --> G[Re-enroll distributed CNPG topology]
  G --> H[verify-database-replication]
  H --> I[validate-identity-ha strict]
  I --> J[Remove temporary disaster fence only under approved change]
  J --> K[Optional planned switchback]
```

Canonical source: `diagrams/identity-unplanned-recovery.mmd`.

**Step 1 — prove the surviving site is serving production identity.**

```bash
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
```

**Step 2 — confirm the former primary is still fenced and select it explicitly.**

Example after J64 failed and J52 was promoted:

```bash
FORMER_PRIMARY=j64seg1opdev
```

Example after J52 failed and J64 was promoted:

```bash
FORMER_PRIMARY=j52seg1opdev
```

**Step 3 — acknowledge destructive standby recreation.** The rebuild deletes the old standby CNPG Cluster/PVC objects. Longhorn/PV retention behavior is described elsewhere in this guide; confirm the active site is healthy and that required recovery evidence/backups are preserved before proceeding.

```bash
export IDENTITY_REBUILD_CONFIRM="$FORMER_PRIMARY"
export IDENTITY_REBUILD_DELETE_STORAGE=true

./scripts/deploy-platform.sh rebuild-identity-standby "$FORMER_PRIMARY"

unset IDENTITY_REBUILD_CONFIRM
unset IDENTITY_REBUILD_DELETE_STORAGE
```

The rebuild workflow validates replication network/TLS reachability first, pauses Fleet, recreates the standby with `pg_basebackup`, re-enrolls the distributed topology, and runs strict replication/HA validation.

**Step 4 — independently verify restored HA.**

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-transition-diagnostics
```

Only after strict HA checks pass should the temporary disaster fence be removed under an approved recovery change and a planned switchback be considered.

### 8.15 Operational rules that prevent split brain or accidental outage

- Never start an opposite-direction switch while a non-terminal journal exists.
- Never delete the transition Lease or journal to bypass a failed stage.
- Never swap static `kmm.dev/identity=primary|secondary` labels.
- Never manually patch CNPG `replica.primary`, `replica.self`, promotion tokens, or demotion tokens during an active journal.
- Explicitly set `IDENTITY_SWITCHOVER_MODE=planned` or `unplanned` in controlled procedures; do not rely on `auto` as the operator decision mechanism.
- DNS Admins change only the canonical CNAME; the failover controller never modifies authoritative DNS.
- Validate the canonical identity record against `IDENTITY_DNS_SERVERS=1.0.1.30 1.0.1.31`; do not use the deployment controller's local resolver as the production DNS authority.
- Keep `IDENTITY_DNS_REQUIRE_ALL_SERVERS=true` unless an approved DNS design explicitly accepts resolver disagreement.
- Do not request the CNAME change until the workflow reports `dns-cutover-pending` and direct target OIDC is healthy.
- After DNS change, resume the **same journal** with `IDENTITY_TRAFFIC_CUTOVER_CONFIRM` for the recorded target.
- A raw ingress IP is not a Keycloak health test; use the canonical FQDN/SNI or the script's direct `curl --resolve` health logic.
- `no healthy upstream` on the warm site is expected when Keycloak instances are `0`.
- Unplanned promotion requires hard fencing before promotion. If the old writable site can return and accept writes, do not promote the peer.
- Keep the former primary fenced throughout `complete-degraded` operation and until it has been rebuilt from the surviving primary.
- Never treat `complete-degraded` as restored HA; it means service is restored on one site and the peer must still be rebuilt.

## 9. Elastic observability operations

The default model uses one Elastic Agent DaemonSet and one kube-state-metrics Deployment per cluster, with one Fleet enrollment policy/token per cluster. A compatibility `ExternalName` Service named `kube-state-metrics` is placed in `elastic-agent-system` so the Elastic Kubernetes integration's short-name scrape target resolves to `kube-state-metrics.elastic-monitoring.svc.cluster.local`. kube-state-metrics explicitly collects `endpointslices` instead of the deprecated core/v1 `endpoints` resource on Kubernetes v1.33+.

Validate:

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If enrollment fails, confirm Fleet Server URL, CA/SAN correctness, token-to-policy mapping, network reachability, and the `elastic-agent` Secret seeded on the affected cluster.

## 10. GitLab Runner operations

The Runner is Fleet-owned in `gitlab-runner-system` on `j64seg1opman`.

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get pods
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

Rotate the runner authentication token or GitLab CA by updating the protected input file and rerunning `./scripts/deploy-platform.sh seed-secrets`. Do not commit the `glrt-*` token. GitLab controls the runner tag, protected status, locking, and project/group scope; the cluster bundle controls runtime version, executor policy, and the exact approved Harbor job-image allowlist.

Every pipeline now starts with `runner:canary`. That job intentionally proves the Kubernetes executor path rather than only manager registration: job Pod admission, helper pull, approved Ansible image pull, repository clone, restricted security context/RBAC, and artifact upload must all work before `validate:gitops-package` runs. Validation selects a Python interpreter by importing the required PyYAML APIs in isolated mode, wraps that exact runtime as the job-local `python3`, and then executes repository Python checks with safe-path isolation; a shadow `yaml` module in the checkout must not be accepted.

## 11. Certificate operations

cert-manager uses the Segment1 ClusterIssuer seeded through the protected CA material. Check certificate status:

```bash
kubectl --context j64seg1opman get certificates -A
kubectl --context j64seg1opman get clusterissuer
```

Repeat for the affected cluster. Do not disable TLS verification to work around CA-chain failures; fix trust or certificate identity.

Cross-site PostgreSQL replication certificates are also an operational lifecycle item. `verify-database-replication` compares the generated source certificate/CA fingerprints with the copied peer Secrets and rejects certificates inside the configured minimum-validity window. Rotate the source certificate through the approved certificate process, rerun the identity Secret synchronization/enablement path, and prove fingerprint agreement plus bidirectional replication before a maintenance window. Do not wait for switchover day to discover an expired replication certificate.

## 12. Ingress and HTTPProxy operations

List Contour proxies:

```bash
kubectl --context j64seg1opdev get httpproxy -A
```

Inspect a proxy:

```bash
kubectl --context j64seg1opdev -n <namespace> describe httpproxy <name>
```

An `invalid` HTTPProxy usually indicates a missing backend Service/port, missing TLS Secret, invalid route definition, or ingress-class/dependency problem. Resolve the underlying reference rather than deleting the proxy.

## 13. CIS/PodSecurity lifecycle

Rancher/Fleet and several platform components require scoped privileged PSA namespaces. Keep exceptions limited to system namespaces and prepare Rancher/Fleet namespaces before cluster import. Application namespaces should remain restricted unless a reviewed workload requirement says otherwise.

## 14. Upgrade lifecycle

For every component upgrade:

1. confirm RKE2/Rancher/Fleet compatibility;
2. obtain/promote images through the approved air-gap workflow;
3. stage the exact Helm chart archive;
4. update the package allowlist, OCI inventory, and checksums;
5. review chart defaults for newly introduced transitive images;
6. update values and compatibility controls;
7. run `validate-package`;
8. publish immutable OCI charts;
9. deploy through Git/Fleet;
10. validate all service-specific gates.

The shared Helm wrapper requires Helm 4 and uses `--rollback-on-failure`; the deprecated `--atomic` CLI alias is not part of the supported wrapper path.

## 15. Backup and recovery boundaries

- GitLab: back up repository data and branch history according to GitLab operations policy.
- KubeHarbor: preserve registry projects/artifacts and CA configuration.
- Rancher/Fleet: preserve Rancher state according to the management-cluster recovery plan.
- RKE2: maintain the approved etcd snapshot/recovery process outside this repository.
- Longhorn: snapshots/replicas are in-cluster; define off-cluster backup separately where required.
- Identity: cross-site replication and Longhorn are **not** substitutes for off-cluster backup/PITR. This repository does not invent an object-store target or credentials; production authorization requires an approved off-cluster CloudNativePG backup destination, retention policy, restore test, and documented PITR RPO/RTO. Until that is supplied, this remains an explicit recovery-control gap rather than a silently fabricated configuration.
- protected configuration: securely back up credential files, CA material, and Istio CA directories outside Git.

## 16. Change-management evidence

For significant changes retain:

- Git commit and branch deployed;
- `validate-package` output;
- Fleet GitRepo commit and bundle state;
- relevant Rancher/Fleet/Longhorn/identity validation output;
- diagnostic bundle for failed changes;
- security/exception review when privileged namespace or certificate behavior changes.
