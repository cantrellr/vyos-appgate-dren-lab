#!/usr/bin/env bash
set -Eeuo pipefail

# FAIL-CLOSED EXAMPLE ONLY.
# Copy this file to an approved protected path and replace the placeholder
# section with site-specific fencing AND independent verification.
#
# The switchover controller supplies:
#   IDENTITY_SWITCHOVER_PHASE
#   IDENTITY_SWITCHOVER_SOURCE_CONTEXT
#   IDENTITY_SWITCHOVER_SOURCE_IP
#   IDENTITY_SWITCHOVER_TARGET_CONTEXT
#   IDENTITY_SWITCHOVER_TARGET_IP
#   IDENTITY_SWITCHOVER_CANONICAL_HOST
#
# Exit 0 only after the old source cannot return writable.  Examples of an
# acceptable control include verified hypervisor power-off, verified network
# isolation, or another approved infrastructure fence.  Merely being unable to
# ping the source is not sufficient proof of database fencing.

: "${IDENTITY_SWITCHOVER_PHASE:?missing IDENTITY_SWITCHOVER_PHASE}"
: "${IDENTITY_SWITCHOVER_SOURCE_CONTEXT:?missing source context}"
: "${IDENTITY_SWITCHOVER_TARGET_CONTEXT:?missing target context}"

if [[ "${IDENTITY_SWITCHOVER_PHASE}" != "hard-fence-source" ]]; then
  echo "ERROR: unexpected phase: ${IDENTITY_SWITCHOVER_PHASE}" >&2
  exit 2
fi

echo "ERROR: hard fence is not implemented for ${IDENTITY_SWITCHOVER_SOURCE_CONTEXT}." >&2
echo "Implement the approved isolation action and a positive verification check before allowing this hook to exit 0." >&2
exit 1
