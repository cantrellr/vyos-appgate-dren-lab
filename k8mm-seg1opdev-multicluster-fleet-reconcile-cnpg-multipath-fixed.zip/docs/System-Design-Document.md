# SEG1 OPDEV multicluster system design

## Executive summary

The platform is a four-cluster air-gapped RKE2 environment. Rancher provides centralized lifecycle management; Fleet pulls declarative bundles from Git and OCI charts from KubeHarbor. All clusters share an Istio trust domain, use one restricted Segment1 ingress plane, use ONTAP through Trident, and send Kubernetes telemetry to an external Elastic Stack through Fleet-managed Elastic Agents.

## Logical architecture

```mermaid
flowchart TB
  Git[Git repository] --> Fleet[Rancher Fleet]
  Harbor[KubeHarbor OCI and images] --> Fleet
  subgraph M[j64seg1opman]
    Rancher[Rancher Manager]
    MF[Common platform + Istio + Kiali + Elastic Agent]
  end
  subgraph A[j64seg1opdev]
    AP[Common platform + Istio + Kiali + Elastic Agent]
    KC1[Active Keycloak]
    PG1[Writable CloudNativePG]
  end
  subgraph B[j52seg1opdev]
    BP[Common platform + Istio + Kiali + Elastic Agent]
    KC2[Keycloak at zero until promotion]
    PG2[Streaming CloudNativePG replica]
  end
  subgraph C[r01seg1opdev]
    CP[Common platform + Istio + Kiali + Elastic Agent]
  end
  Rancher --> Fleet
  Fleet --> MF
  Fleet --> AP
  Fleet --> BP
  Fleet --> CP
  PG1 -. asynchronous WAL .-> PG2
  AP <--> BP
  AP <--> CP
  MF <--> AP
  MF <--> BP
  MF <--> CP
  MF --> ELK[External Fleet Server / Elastic Stack]
  AP --> ELK
  BP --> ELK
  CP --> ELK
```

## Platform layers

| Layer | Components | Design intent |
| --- | --- | --- |
| control | Rancher Manager, Fleet | lifecycle plus one GitOps ownership plane |
| artifacts | Git, KubeHarbor OCI/images | disconnected, immutable delivery |
| DNS/PKI | CoreDNS forwarding, cert-manager, external CA files | internal name resolution and TLS issuance |
| ingress | MetalLB, Contour/Envoy `segment1` | one restricted ingress plane per cluster |
| storage | Trident NFS/iSCSI, Trident Protect | ONTAP-backed persistent storage and protection |
| identity | Keycloak operator, Keycloak, CloudNativePG, PgBouncer | active/warm-secondary identity service |
| mesh | Istio base/CNI/istiod/east-west, Kiali | shared trust, cross-cluster service discovery, visualization |
| monitoring | Elastic Agent 9.4.2, kube-state-metrics 2.16.0 | node and cluster telemetry to external ELK |
| host readiness | Chrony, open-iscsi, multipath-tools | consistent node time and storage prerequisites |

## Deployment data flow

The operator publishes verified chart archives to `oci://kubeharbor.dev.kube/k8mm-charts`, mirrors required images, and commits bundle changes to Git. Rancher/Fleet reads Git using a workspace Secret and pulls charts using a separate OCI Secret/CA. Fleet templates cluster-specific VIPs, networks, storage endpoints, and identity state from cluster labels.

Sensitive values never enter the Git repository. The bootstrap reads mode-restricted files and creates the Kubernetes Secrets expected by Fleet workloads.

## Monitoring design

Each cluster has one Elastic Agent DaemonSet. The per-node preset runs on control-plane and worker nodes, uses host networking and host persistence, and enables Kubernetes leader-election support. A separate kube-state-metrics Deployment is installed in `elastic-monitoring`; an ExternalName Service in `elastic-agent-system` preserves the short host expected by the Kubernetes integration.

One Fleet policy/token per cluster is the production baseline. This gives four tokens and four independently revocable policy assignments.

## Identity design

j64 is initially writable and active. j52 runs a physical streaming replica and a zero-instance Keycloak resource. Promotion is controlled by `scripts/management/failover/failover-to-j52.sh`, which pauses downstream Fleet, fences traffic, verifies planned WAL catch-up when possible, promotes j52, changes durable Fleet labels, activates Keycloak, and unpauses reconciliation.

## Security boundaries

- Segment1 is default-deny and backends opt in through a namespace label.
- Namespace PSA levels are explicit; privileged exceptions are limited to components requiring host/network/storage access.
- Istio automatic injection is disabled in platform namespaces.
- SSH host-key verification is required by host preflight.
- Kubernetes Secrets and private keys are generated from protected runtime inputs, not committed YAML.
- Chart packages are allowlisted and checksum-verified.

## Failure domains

A single cluster loss should not stop the remaining clusters. Loss of j64 application requires controlled identity promotion. Loss of management does not terminate running workloads but stops reconciliation. Loss of KubeHarbor/Git blocks new reconciliation. Loss of Fleet Server affects monitoring enrollment/output but not workload execution. Loss of external Prometheus/Grafana degrades Kiali telemetry.
