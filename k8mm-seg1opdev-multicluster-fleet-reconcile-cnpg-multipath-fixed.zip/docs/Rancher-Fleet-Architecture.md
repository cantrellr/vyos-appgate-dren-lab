# Rancher Manager and Fleet architecture

## Decision

Rancher Manager owns cluster lifecycle and Fleet owns steady-state platform/application delivery. A second GitOps engine is not deployed because overlapping reconcilers create ambiguous ownership and rollback behavior.

## Bootstrap boundary

The management cluster must exist before Rancher can manage anything. `scripts/management/fleet/00-bootstrap-management.sh` therefore installs the minimum chain imperatively on `j64seg1opman`:

1. KubeHarbor pull Secret;
2. external Rancher v2.14.2 image-list, Harbor inventory, and per-node pull validation;
3. CoreDNS forwarding patch;
4. cert-manager CA Secret;
5. cert-manager;
6. MetalLB and Segment1 address pool;
7. Segment1 Contour release `ingress-segment1`;
8. Rancher release `rancher`;
9. Rancher Webhook and Fleet system-component validation.

Once Rancher/Fleet is available, the same common platform is represented by Fleet bundles. Matching Helm release names allow Fleet to adopt/reconcile the bootstrap releases instead of creating parallel installations.

## Fleet workspaces

`fleet-local` targets the Rancher local cluster. `fleet-default` targets downstream clusters. Both use the same Git repository, Git credentials, OCI credentials, CA trust, and ordered bundle paths, but the downstream GitRepo additionally includes identity bundles.

## Cluster-label contract

| Label | Purpose |
| --- | --- |
| `kmm.dev/context` | exact kubeconfig/environment identity |
| `kmm.dev/site` | physical/logical site |
| `kmm.dev/role` | management or application |
| `kmm.dev/platform=seg1opdev` | downstream platform target |
| `kmm.dev/identity` | primary, secondary, secondary-pending, or none |
| `kmm.dev/identity-site` | operator placement guard |
| `kmm.dev/segment1-pool` | MetalLB range |
| `kmm.dev/segment1-lb-ip` | Contour VIP |
| `kmm.dev/eastwest-lb-ip` | Istio gateway VIP |
| `kmm.dev/istio-network` | mesh network name |
| `kmm.dev/trident-*` | ONTAP backend inputs |
| `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-*` | durable identity role state |

Static topology labels do not change during identity failover. Dynamic role labels do, which prevents Fleet from reverting the promoted state.

## What Fleet intentionally does not own

- Rancher bootstrap and cluster provisioning;
- host package/service preparation;
- private runtime Secret generation;
- CoreDNS bootstrap patch;
- Chrony host-time agent;
- Istio remote Secrets;
- CNPG replication certificate transfer;
- identity promotion/fencing hooks.

These are dependency, credential, or cross-cluster control operations rather than ordinary desired-state objects.

## Availability

Fleet itself is hosted with Rancher on `j64seg1opman`. A management outage does not immediately stop running workloads, but it prevents reconciliation, new deployments, and centralized lifecycle actions. Back up Rancher and Fleet state and preserve Git/KubeHarbor availability as control-plane dependencies.
