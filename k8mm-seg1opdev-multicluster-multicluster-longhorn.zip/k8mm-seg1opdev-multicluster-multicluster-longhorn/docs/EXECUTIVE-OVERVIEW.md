# Executive Overview

> **Baseline:** v2.1 — August 20, 2026  
> **Audience:** program leadership, upper-level management, customer leadership, security stakeholders, and technical decision-makers.

## Mission and business purpose

The Segment1 OPDEV K8s Mystical Mesh platform provides a centrally governed, disconnected Kubernetes environment across four RKE2 clusters. Its purpose is to give application teams a repeatable platform for containerized workloads while keeping software supply, identity, storage, ingress, monitoring, and lifecycle management under a controlled operating model suitable for a restricted network.

The design reduces manual cluster-by-cluster administration by using Rancher Manager for cluster lifecycle and Rancher Fleet for GitOps delivery. The desired state is held in GitLab, approved images and Helm charts are served from KubeHarbor, and platform changes are reconciled consistently across the clusters.

## Executive summary

The platform consists of one management cluster and three application clusters. It provides:

- centralized cluster lifecycle and visibility through Rancher;
- Git-based desired-state delivery through Fleet;
- an Istio multicluster service mesh with controlled east-west gateways;
- a dedicated Segment1 Contour/Envoy ingress plane with per-cluster VIPs;
- Longhorn distributed block storage on validated XFS worker disks;
- two-site Keycloak identity backed by CloudNativePG with asynchronous cross-site replication;
- Fleet-managed Elastic Agents and kube-state-metrics;
- private PKI integration through cert-manager;
- air-gap artifact control through KubeHarbor and checksum-validated packages;
- host-time enforcement using Chrony with synchronization as a deployment gate; and
- CIS/PodSecurity controls with narrowly scoped exceptions for infrastructure components that require privilege.

## System topology and external dependencies

```mermaid
flowchart TB
  ADMIN[Platform administrators and support teams]
  GITLAB[GitLab\nGit source of truth]
  HARBOR[KubeHarbor\nOCI charts and container images]
  DNS[Private DNS\ndev.kube and enterprise zones]
  NTP[Approved NTP sources]
  CA[Enterprise / Segment1 CA]
  ELASTIC[External Elastic Fleet Server]
  OBS[External Prometheus / Grafana]

  subgraph MGMT[j64seg1opman - Management Cluster]
    RANCHER[Rancher Manager]
    FLEET[Rancher Fleet]
    MESH_M[Istio / Kiali]
    STORAGE_M[Longhorn]
    AGENT_M[Elastic Agent]
  end

  subgraph J64[j64seg1opdev - Primary Application Cluster]
    MESH_J64[Istio / Kiali]
    STORAGE_J64[Longhorn]
    PG_PRIMARY[CloudNativePG Primary]
    KC_PRIMARY[Keycloak Active]
    AGENT_J64[Elastic Agent]
  end

  subgraph J52[j52seg1opdev - Secondary Identity Cluster]
    MESH_J52[Istio / Kiali]
    STORAGE_J52[Longhorn]
    PG_REPLICA[CloudNativePG Replica]
    KC_STANDBY[Keycloak Standby]
    AGENT_J52[Elastic Agent]
  end

  subgraph R01[r01seg1opdev - Application Cluster]
    MESH_R01[Istio / Kiali]
    STORAGE_R01[Longhorn]
    AGENT_R01[Elastic Agent]
  end

  ADMIN --> RANCHER
  GITLAB --> FLEET
  HARBOR --> FLEET
  HARBOR --> MGMT
  HARBOR --> J64
  HARBOR --> J52
  HARBOR --> R01
  RANCHER --> FLEET
  FLEET --> MESH_M
  FLEET --> MESH_J64
  FLEET --> MESH_J52
  FLEET --> MESH_R01
  FLEET --> STORAGE_J64
  FLEET --> STORAGE_J52
  FLEET --> STORAGE_R01
  FLEET --> PG_PRIMARY
  FLEET --> PG_REPLICA
  FLEET --> KC_PRIMARY
  PG_PRIMARY -. asynchronous WAL replication .-> PG_REPLICA
  MESH_M <--> MESH_J64
  MESH_M <--> MESH_J52
  MESH_M <--> MESH_R01
  AGENT_M --> ELASTIC
  AGENT_J64 --> ELASTIC
  AGENT_J52 --> ELASTIC
  AGENT_R01 --> ELASTIC
  MESH_M --> OBS
  MESH_J64 --> OBS
  MESH_J52 --> OBS
  MESH_R01 --> OBS
  DNS --> MGMT
  DNS --> J64
  DNS --> J52
  DNS --> R01
  NTP --> MGMT
  NTP --> J64
  NTP --> J52
  NTP --> R01
  CA --> MGMT
  CA --> J64
  CA --> J52
  CA --> R01

  classDef external stroke-dasharray: 5 5
  class GITLAB,HARBOR,DNS,NTP,CA,ELASTIC,OBS external
```

The dashed dependencies in the diagram are external to the Kubernetes clusters and remain critical to service delivery. A healthy Kubernetes control plane cannot compensate for an unavailable GitLab, KubeHarbor, DNS, NTP, CA, Elastic, or required network path.

### Cluster roles

| Cluster | Role | Service responsibility |
| --- | --- | --- |
| `j64seg1opman` | management | Rancher, Fleet, management ingress substrate, common platform services |
| `j64seg1opdev` | application / primary identity site | application workloads, active Keycloak, primary CloudNativePG |
| `j52seg1opdev` | application / secondary identity site | application workloads, warm PostgreSQL replica, standby Keycloak definition |
| `r01seg1opdev` | application | application workloads and common platform services |

## Governance and ownership

The environment deliberately separates responsibility:

- **Infrastructure teams** own the VM/OS baseline, routing, DNS, NTP, host trust, and storage mounts.
- **Rancher operations** own RKE2 cluster lifecycle and centralized management.
- **Platform engineering** owns Fleet bundles, platform configuration, validation, and release workflows.
- **Registry/release engineering** owns image promotion and KubeHarbor content integrity.
- **Identity operations** owns controlled Keycloak/PostgreSQL failover and fencing.
- **Security operations** reviews CIS/PSA exceptions, certificates, privileged workloads, and audit evidence.
- **Help desk and support** use the documented triage path and escalate by failure domain rather than making direct production changes.

This separation is intentional: the Git repository is the source of truth for steady-state Kubernetes resources, while credentials and cross-cluster control actions remain outside Git.

## Availability model

Running workloads continue if Rancher/Fleet is temporarily unavailable, but the organization loses centralized reconciliation, deployment, and lifecycle operations until management is restored. GitLab and KubeHarbor are therefore control-plane dependencies even though they are external to Kubernetes.

The identity service has a primary/warm-secondary architecture. `j64seg1opdev` is normally writable and serves Keycloak traffic. `j52seg1opdev` maintains an asynchronous PostgreSQL replica and can be promoted through a controlled workflow. Planned failover can minimize data loss by catching up WAL before promotion. Unplanned failover has a non-zero recovery-point risk because replication is asynchronous.

Longhorn protects against individual worker-disk/node failures within a cluster according to its replica policy, but Longhorn is **not** a substitute for an off-cluster backup strategy. Cross-cluster or disaster recovery requirements must be addressed separately.

## Security posture

The platform applies a restricted-by-default model with explicitly documented exceptions for infrastructure workloads that require host or network privilege. Examples include Longhorn, Istio CNI, MetalLB, Rancher/Fleet system agents, Chrony, and Elastic Agent.

Key security controls include:

- no plaintext runtime credentials committed to Git;
- TLS trust anchored to the approved Segment1 CA;
- private OCI registry authentication and CA validation;
- immutable chart checksums and package inventories;
- explicit namespace labels and mesh-injection rules;
- Longhorn administrative UIs limited to Segment1 source addresses by Contour `ipAllowPolicy`;
- identity exposure only on the currently active Keycloak site; and
- deployment gates that fail when time, storage, registry, or Fleet prerequisites are not valid.

## Operational health indicators

Management and customer reporting can use the following high-level indicators:

| Indicator | Healthy state |
| --- | --- |
| Rancher | UI/API reachable and downstream clusters Connected/Active |
| Fleet | GitRepos Ready and all intended BundleDeployments Active |
| Registry | KubeHarbor reachable, trusted, authenticated, required artifacts present |
| Time | Chrony reports selected source, positive stratum, `Leap status: Normal` on every node |
| Storage | Longhorn manager/CSI healthy; nodes/disks schedulable; required PVCs Bound |
| Mesh | Istiod and east-west gateways Ready; Kiali reachable where configured |
| Identity | primary Keycloak Ready; primary database healthy; secondary replication healthy |
| Monitoring | Elastic Agents enrolled in the intended per-cluster policies |

## Key risks and management decisions

1. **External service concentration.** GitLab, KubeHarbor, private DNS, NTP, and external monitoring must be treated as platform dependencies with their own availability and backup plans.
2. **Management-cluster dependency.** A management outage does not immediately stop workloads, but it blocks reconciliation and centralized lifecycle management.
3. **Asynchronous identity replication.** Unplanned failover can lose acknowledged transactions. RPO expectations should be formally accepted.
4. **Privileged infrastructure components.** Required CIS/PSA exceptions should remain scoped, documented, and periodically reviewed.
5. **Administrative UI access.** Longhorn and Kiali are administrative tools and should remain restricted to trusted management networks and appropriate authentication controls.
6. **Air-gap release discipline.** Every component upgrade requires coordinated Git, chart, image, checksum, trust, and compatibility validation. Public Internet access is not a fallback path.
7. **Time service correctness.** A reachable NTP endpoint is insufficient; it must itself be synchronized. The platform now verifies NTP quality rather than simple UDP reachability.

## Go/no-go acceptance criteria

A release is operationally acceptable when static package validation passes, required images/charts exist in KubeHarbor, all four clusters are reachable, Rancher/Fleet are healthy, Chrony and Longhorn host preflight pass, intended Fleet bundles are Active, identity HA validation passes, and monitoring agents are enrolled correctly.

The authoritative technical acceptance procedures are in [Deployment and Configuration](DEPLOYMENT-AND-CONFIGURATION.md), [Operations and Lifecycle](OPERATIONS-AND-LIFECYCLE.md), and [Troubleshooting and Support](TROUBLESHOOTING-AND-SUPPORT.md).
