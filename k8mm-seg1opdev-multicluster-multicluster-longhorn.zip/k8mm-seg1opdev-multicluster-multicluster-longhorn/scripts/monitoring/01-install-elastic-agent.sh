#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/cis.sh
source "${SCRIPT_DIR}/../_lib/cis.sh"

CONTEXTS=()
BREAK_GLASS="${KMM_BREAK_GLASS:-false}"

usage() {
  cat <<USAGE
Usage: KMM_BREAK_GLASS=true $0 (--all | --context <context> ...)

Direct Helm fallback for Elastic Agent 9.4.2 and kube-state-metrics 6.1.0.
Normal deployment is owned by Fleet bundles 70-kube-state-metrics and
71-elastic-agent. Runtime Secrets must already be seeded.
USAGE
}

while (($#)); do
  case "$1" in
    --all) CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}"); shift ;;
    --context)
      [[ $# -ge 2 ]] || die "--context requires a value."
      CONTEXTS+=("$2"); shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; die "Unknown argument: $1" ;;
  esac
done

[[ "${BREAK_GLASS}" == true ]] || die "Fleet owns Elastic monitoring. Set KMM_BREAK_GLASS=true only for controlled direct-Helm recovery."
((${#CONTEXTS[@]})) || { usage >&2; die "Choose --all or at least one --context."; }

ELASTIC_CHART="${HELM_PACKAGES_DIR}/elastic-agent-9.4.2.tgz"
KSM_CHART="${HELM_PACKAGES_DIR}/kube-state-metrics-6.1.0.tgz"
ELASTIC_VALUES="${YAML_DIR}/monitoring/elastic-agent-per-node-9.4.2-values.yaml"
KSM_VALUES="${YAML_DIR}/monitoring/kube-state-metrics-6.1.0-values.yaml"
KSM_ALIAS="${YAML_DIR}/monitoring/kube-state-metrics-agent-alias.yaml"

require_kubernetes_tools
require_cmd jq
for file in "${ELASTIC_CHART}" "${KSM_CHART}" "${ELASTIC_VALUES}" "${KSM_VALUES}" "${KSM_ALIAS}"; do
  ensure_file "${file}"
done

for context in "${CONTEXTS[@]}"; do
  validate_supported_context "${context}"
  validate_context_access "${context}"
  use_context "${context}"

  ensure_cis_namespace elastic-agent-system true privileged
  ensure_cis_namespace elastic-monitoring true restricted
  kubectl label namespace elastic-agent-system \
    k8mm.dev/monitoring-agent=true \
    k8mm.dev/elastic-agent-topology=single \
    --overwrite >/dev/null

  for namespace in elastic-agent-system elastic-monitoring; do
    ensure_registry_secret "${namespace}"
  done
  kubectl -n elastic-agent-system get secret elastic-agent-fleet-enrollment >/dev/null \
    || die "${context}: missing elastic-agent-system/elastic-agent-fleet-enrollment. Run the Fleet secret-seeding phase."
  kubectl -n elastic-agent-system get secret devlocal-ca-bundle-secret >/dev/null \
    || die "${context}: missing elastic-agent-system/devlocal-ca-bundle-secret. Run the Fleet secret-seeding phase."

  log "${context}: break-glass installation of kube-state-metrics..."
  helm_upgrade_install kube-state-metrics "${KSM_CHART}" elastic-monitoring "${KSM_VALUES}"
  apply_file_in_namespace elastic-agent-system "${KSM_ALIAS}"

  log "${context}: break-glass installation of Elastic Agent..."
  helm_upgrade_install elastic-agent-node "${ELASTIC_CHART}" elastic-agent-system "${ELASTIC_VALUES}"
  kubectl -n elastic-agent-system rollout status daemonset/agent-pernode-elastic-agent-node --timeout="${KUBECTL_TIMEOUT}"
done

warn "Direct Helm recovery completed. Resume Fleet reconciliation and verify that Fleet adopts the same release names."
