#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
init_site_cluster "$@"
require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
failures=0
check_count() {
  local label="$1" expected="$2" actual="$3"
  if [[ "${actual}" != "${expected}" ]]; then
    warn "${label}: expected ${expected}, found ${actual}"
    failures=$((failures + 1))
  else
    log "${label}: ${actual}"
  fi
}
pg_ready="$(kubectl -n oppostgres get pods -l cnpg.io/cluster=oppostgres-opkeycloak-db --field-selector=status.phase=Running -o name | wc -l | xargs)"
pooler_ready="$(kubectl -n oppostgres get deployment oppostgres-opkeycloak-db-pooler-rw -o jsonpath='{.status.availableReplicas}')"
keycloak_ready="$(kubectl -n opkeycloak get statefulset opkeycloak -o jsonpath='{.status.readyReplicas}')"
check_count "CNPG running pods" 3 "${pg_ready}"
check_count "PgBouncer available replicas" 3 "${pooler_ready:-0}"
check_count "Keycloak ready replicas" 3 "${keycloak_ready:-0}"
kubectl -n oppostgres get cluster oppostgres-opkeycloak-db >/dev/null
kubectl -n oppostgres get service oppostgres-opkeycloak-db-pooler-rw >/dev/null
kubectl -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert >/dev/null
[[ "${failures}" -eq 0 ]] || die "Identity HA validation failed with ${failures} issue(s)."
log "Identity HA validation passed."
