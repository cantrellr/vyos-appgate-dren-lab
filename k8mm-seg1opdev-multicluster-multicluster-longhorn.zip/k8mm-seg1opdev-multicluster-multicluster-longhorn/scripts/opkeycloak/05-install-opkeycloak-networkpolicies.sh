#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
init_site_cluster "${2:-j64}" "${3:-seg1opdev}"
ACTION="${1:-apply}"
POLICY_DIR="${YAML_DIR}/opkeycloak/networkpolicies"
[[ "${ACTION}" == "apply" || "${ACTION}" == "delete" ]] || die "Usage: $0 [apply|delete] [site] [cluster]"
require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
validate_yaml_dir "${POLICY_DIR}"
runtime_policy="$(mktemp)"
trap 'rm -f "${runtime_policy:-}"' EXIT
kube_api_ip="$(kubectl get service kubernetes -n default -o jsonpath='{.spec.clusterIP}')"
[[ -n "${kube_api_ip}" ]] || die "Unable to detect kubernetes.default ClusterIP."
cat >"${runtime_policy}" <<YAML
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: oppostgres-allow-kubernetes-api-egress
  namespace: oppostgres
spec:
  podSelector:
    matchLabels:
      cnpg.io/cluster: oppostgres-opkeycloak-db
  policyTypes: [Egress]
  egress:
    - to:
        - ipBlock: {cidr: ${kube_api_ip}/32}
      ports:
        - {protocol: TCP, port: 443}
YAML
if [[ "${ACTION}" == "apply" ]]; then
  kubectl apply -f "${POLICY_DIR}"
  kubectl apply -f "${runtime_policy}"
else
  kubectl delete -f "${POLICY_DIR}" --ignore-not-found
  kubectl delete networkpolicy oppostgres-allow-kubernetes-api-egress -n oppostgres --ignore-not-found
fi
log "Identity NetworkPolicy action '${ACTION}' completed."
