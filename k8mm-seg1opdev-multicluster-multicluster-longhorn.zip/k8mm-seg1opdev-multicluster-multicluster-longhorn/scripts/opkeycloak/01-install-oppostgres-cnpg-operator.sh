#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"
init_site_cluster "$@"
NAMESPACE="oppostgres"
RELEASE="oppostgres-operator"
CHART_PATH="${CNPG_CHART:-${HELM_PACKAGES_DIR}/cloudnative-pg-0.29.0.tgz}"
VALUES="${YAML_DIR}/oppostgres/values/cnpg-operator-values.yaml"
require_kubernetes_tools
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"
helm_upgrade_install "${RELEASE}" "${CHART_PATH}" "${NAMESPACE}" "${VALUES}"
wait_for_deployment_rollout "${NAMESPACE}" "${RELEASE}" "${KUBECTL_TIMEOUT}"
log "${RELEASE} installed in ${K8_CONTEXT}/${NAMESPACE}."
