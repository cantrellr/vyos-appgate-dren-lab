#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"
init_site_cluster "$@"
NAMESPACE="opkeycloak"
RESOURCE_DIR="${YAML_DIR}/opkeycloak/resources"
CRDS_FILE="${RESOURCE_DIR}/opkeycloak-seg1opdev-crds-v1.yaml"
OPERATOR_SOURCE="${RESOURCE_DIR}/opkeycloak-seg1opdev-operator-source-v1.yaml"
RENDERER="${ROOT_DIR}/scripts/security/render-keycloak-operator-cis.py"
require_kubectl
require_cmd python3
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"
ensure_file "${CRDS_FILE}"
ensure_file "${OPERATOR_SOURCE}"
ensure_file "${RENDERER}"
apply_file "${CRDS_FILE}"
rendered_operator="$(mktemp)"
trap 'rm -f "${rendered_operator:-}"' EXIT
python3 "${RENDERER}" "${OPERATOR_SOURCE}" >"${rendered_operator}"
validate_yaml_file "${rendered_operator}"
apply_file_in_namespace "${NAMESPACE}" "${rendered_operator}"
wait_for_deployment_rollout "${NAMESPACE}" opkeycloak-operator "${KUBECTL_TIMEOUT}"
log "Keycloak Operator installed and hardened for Restricted Pod Security."
