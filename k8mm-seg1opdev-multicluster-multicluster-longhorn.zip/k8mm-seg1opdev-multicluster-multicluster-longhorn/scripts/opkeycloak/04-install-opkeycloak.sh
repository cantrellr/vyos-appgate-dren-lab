#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"
init_site_cluster "$@"
NAMESPACE="${KEYCLOAK_NAMESPACE:-opkeycloak}"
POSTGRES_NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"
RESOURCE_DIR="${YAML_DIR}/opkeycloak/resources"
RESOURCES="${RESOURCE_DIR}/opkeycloak-seg1opdev-resources-v1.yaml"
KEYCLOAK_CR="${RESOURCE_DIR}/opkeycloak-seg1opdev-cr-v1.yaml"
require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"
"${SCRIPT_DIR}/00-prepare-opkeycloak-runtime-secrets.sh" "${SITE}" "${CLUSTER}"
kubectl -n "${POSTGRES_NAMESPACE}" get service "${POOLER_NAME}" >/dev/null 2>&1 || die "PgBouncer service ${POSTGRES_NAMESPACE}/${POOLER_NAME} is missing."
if [[ -n "${OPKEYCLOAK_KEYTAB_FILE:-}" ]]; then
  ensure_file "${OPKEYCLOAK_KEYTAB_FILE}"
  kubectl -n "${NAMESPACE}" create secret generic opkeycloak-keytab --from-file=opkeycloak.keytab="${OPKEYCLOAK_KEYTAB_FILE}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null
fi
if [[ -n "${OPKEYCLOAK_PROVIDER_FILE:-}" ]]; then
  ensure_file "${OPKEYCLOAK_PROVIDER_FILE}"
  kubectl -n "${NAMESPACE}" create secret generic opkeycloak-provider --from-file=provider.jar="${OPKEYCLOAK_PROVIDER_FILE}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null
fi
apply_file_in_namespace "${NAMESPACE}" "${RESOURCES}"
apply_file_in_namespace "${NAMESPACE}" "${KEYCLOAK_CR}"
log "Waiting for all three Keycloak pods..."
kubectl -n "${NAMESPACE}" rollout status statefulset/opkeycloak --timeout="${KUBECTL_TIMEOUT}"
kubectl -n "${NAMESPACE}" wait --for=condition=Ready pod -l app.kubernetes.io/instance=opkeycloak --timeout="${KUBECTL_TIMEOUT}"
log "Keycloak HA installed behind Segment1 Contour and connected through PgBouncer."
