#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"

for cmd in find grep tar sha256sum python3; do require_cmd "${cmd}"; done
failures=0

while IFS= read -r -d '' file; do
  bash -n "${file}" || { warn "Shell syntax failed: ${file#${ROOT_DIR}/}"; failures=$((failures + 1)); }
done < <(find "${INSTALL_DIR}" -type f -name '*.sh' -print0)

while IFS= read -r -d '' file; do
  [[ "${file}" == "${SCRIPT_DIR}/validate-deployment-package.sh" ]] && continue
  if grep -Iq . "${file}" && grep -Eq 'BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY|BEGIN PKCS12' "${file}"; then
    warn "Private key material detected: ${file#${ROOT_DIR}/}"
    failures=$((failures + 1))
  fi
done < <(find "${ROOT_DIR}" -type f ! -path '*/.git/*' -print0)

if ! python3 - "${ROOT_DIR}" <<'PY'
import re, sys
from pathlib import Path
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML is required')
root=Path(sys.argv[1]); errors=[]
credential_keys={'bootstrapPassword','password','clientSecret','client-secret','token'}
empty={'','""',"''",'null','Null','NULL','~','{}'}
for path in sorted(root.rglob('*')):
    if path.suffix not in {'.yaml','.yml'} or '.git' in path.parts:
        continue
    # Helm templates contain Go-template syntax and are intentionally not valid
    # standalone YAML until rendered by Helm. Validate chart metadata/values here
    # and validate template structure in validate-fleet-layout.sh.
    if 'templates' in path.parts and 'chart' in path.parts:
        continue
    text=path.read_text(encoding='utf-8')
    try:
        docs=list(yaml.safe_load_all(text))
    except Exception as exc:
        errors.append(f'invalid YAML {path.relative_to(root)}: {exc}'); continue
    for doc in docs:
        if isinstance(doc,dict) and doc.get('kind')=='Secret':
            errors.append(f'committed Kubernetes Secret manifest: {path.relative_to(root)}')
    for line_no,line in enumerate(text.splitlines(),1):
        m=re.match(r'^\s*([A-Za-z][A-Za-z0-9_-]*)\s*:\s*(.*?)\s*$',line)
        if not m or m.group(1) not in credential_keys: continue
        value=m.group(2).split(' #',1)[0].strip()
        if value not in empty and not value.startswith(('secret:', '${', '<')):
            errors.append(f'credential-like literal in {path.relative_to(root)}:{line_no}')
if errors:
    print('\n'.join('[WARN] '+x for x in errors),file=sys.stderr); raise SystemExit(1)
PY
then failures=$((failures + 1)); fi

if ! (cd "${ROOT_DIR}/helm" && sha256sum --check SHA256SUMS >/dev/null); then
  warn "Helm package checksum validation failed."
  failures=$((failures + 1))
fi

#host_bundle="${ROOT_DIR}/host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz"
#host_bundle_checksum="${ROOT_DIR}/host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz.sha256"
#if ! (cd "${ROOT_DIR}/host-packages" && sha256sum --check "${host_bundle_checksum##*/}" >/dev/null); then
#  warn "Longhorn host package archive checksum validation failed."
#  failures=$((failures + 1))
#elif ! tar -tzf "${host_bundle}" >/dev/null; then
#  warn "Longhorn host package archive is not a valid tar.gz."
#  failures=$((failures + 1))
#else
#  host_deb_count="$(tar -tzf "${host_bundle}" | grep -Ec '/packages/[^/]+[.]deb$' || true)"
#  [[ "${host_deb_count}" -eq 16 ]] || {
#    warn "Longhorn host package archive contains ${host_deb_count} .deb files; expected 16."
#    failures=$((failures + 1))
#  }
#fi

mapfile -t required_packages < <(grep -Ev '^[[:space:]]*(#|$)' "${ROOT_DIR}/helm/required-packages.txt")
mapfile -t checksum_packages < <(awk '{print $2}' "${ROOT_DIR}/helm/SHA256SUMS" | sed 's#^packages/##' | sort)
mapfile -t sorted_required_packages < <(printf '%s\n' "${required_packages[@]}" | sort)
if [[ "$(printf '%s\n' "${checksum_packages[@]}")" != "$(printf '%s\n' "${sorted_required_packages[@]}")" ]]; then
  warn "SHA256SUMS does not exactly cover required-packages.txt."
  failures=$((failures + 1))
fi
for package in "${required_packages[@]}"; do
  if [[ ! -f "${HELM_PACKAGES_DIR}/${package}" ]]; then
    warn "Missing Helm package: ${package}"; failures=$((failures + 1))
  elif ! tar -tzf "${HELM_PACKAGES_DIR}/${package}" >/dev/null; then
    warn "Invalid Helm archive: ${package}"; failures=$((failures + 1))
  fi
done
extra_packages="$(find "${HELM_PACKAGES_DIR}" -maxdepth 1 -type f -name '*.tgz' -printf '%f\n' | grep -vxFf <(printf '%s\n' "${required_packages[@]}") || true)"
if [[ -n "${extra_packages}" ]]; then
  warn "Unreferenced Helm packages remain:"; printf '%s\n' "${extra_packages}" >&2; failures=$((failures + 1))
fi

if ! python3 - "${ROOT_DIR}" <<'PYCHARTS'
from pathlib import Path
import sys
import tarfile
import yaml

root = Path(sys.argv[1])
package_names = [line.strip() for line in (root/'helm'/'required-packages.txt').read_text().splitlines()
                 if line.strip() and not line.lstrip().startswith('#')]
fleet_package_names = [line.strip() for line in (root/'helm'/'fleet-oci-packages.txt').read_text().splitlines()
                       if line.strip() and not line.lstrip().startswith('#')]
oci_items = {line.strip() for line in (root/'helm'/'required-oci-artifacts.txt').read_text().splitlines()
             if line.strip() and not line.lstrip().startswith('#')}
expected_oci = set()
chart_names = set()
errors = []
for filename in package_names:
    archive = root/'helm'/'packages'/filename
    try:
        with tarfile.open(archive, 'r:gz') as package:
            chart_members = [m for m in package.getmembers()
                             if m.name.count('/') == 1 and m.name.endswith('/Chart.yaml')]
            if len(chart_members) != 1:
                errors.append(f'{filename}: expected one top-level Chart.yaml')
                continue
            chart = yaml.safe_load(package.extractfile(chart_members[0])) or {}
    except Exception as exc:
        errors.append(f'{filename}: unable to read chart metadata: {exc}')
        continue
    name = str(chart.get('name') or '')
    version = str(chart.get('version') or '')
    if not name or not version:
        errors.append(f'{filename}: chart name/version is missing')
        continue
    expected_filename = f'{name}-{version}.tgz'
    if filename != expected_filename:
        errors.append(f'{filename}: metadata expects filename {expected_filename}')
    if name in chart_names:
        errors.append(f'{filename}: duplicate chart name {name}')
    chart_names.add(name)
    if filename in fleet_package_names:
        expected_oci.add(f'oci://kubeharbor.dev.kube/k8mm-charts/{name}:{version}')

unknown_fleet_packages = sorted(set(fleet_package_names) - set(package_names))
if unknown_fleet_packages:
    errors.append(f'Fleet OCI package list contains unknown packages: {unknown_fleet_packages}')
if 'rancher-2.15.0.tgz' in fleet_package_names:
    errors.append('Rancher bootstrap chart must not be in fleet-oci-packages.txt')
if oci_items != expected_oci:
    errors.append(f'OCI inventory mismatch: missing={sorted(expected_oci-oci_items)} extra={sorted(oci_items-expected_oci)}')

fleet_oci = set()
for fleet_file in sorted((root/'fleet'/'bundles').glob('*/fleet.yaml')):
    data = yaml.safe_load(fleet_file.read_text(encoding='utf-8')) or {}
    helm = data.get('helm') or {}
    repo = helm.get('repo')
    chart = helm.get('chart')
    version = helm.get('version')
    if repo:
        errors.append(
            f'{fleet_file.relative_to(root)}: helm.repo is not valid for the pinned Fleet v0.15.2 OCI loader; '
            'use helm.chart'
        )
    if chart and str(chart).startswith('oci://'):
        fleet_oci.add(f'{chart}:{version}')
if fleet_oci != expected_oci:
    errors.append(f'Fleet chart ownership mismatch: missing={sorted(expected_oci-fleet_oci)} extra={sorted(fleet_oci-expected_oci)}')

rancher_installer = (root/'scripts'/'management'/'rancher'/'01-install-rancher.sh').read_text(encoding='utf-8')
if 'rancher-2.15.0.tgz' not in rancher_installer:
    errors.append('Rancher package is not referenced by the management bootstrap installer')

rancher_resources = root/'yaml'/'j64'/'seg1opman-cluster'/'resources'/'rancher-j64manager-resources-v1.yaml'
try:
    resource_docs = list(yaml.safe_load_all(rancher_resources.read_text(encoding='utf-8')))
except Exception as exc:
    errors.append(f'Unable to inspect Rancher resources: {exc}')
else:
    proxies = [item for item in resource_docs
               if isinstance(item, dict) and item.get('kind') == 'HTTPProxy'
               and (item.get('metadata') or {}).get('name') == 'rancher-httpproxy']
    if len(proxies) != 1:
        errors.append('Expected exactly one cattle-system/rancher-httpproxy resource')
    else:
        routes = ((proxies[0].get('spec') or {}).get('routes') or [])
        websocket_route = any(
            route.get('enableWebsockets') is True
            and (route.get('timeoutPolicy') or {}).get('response') == 'infinity'
            and (route.get('timeoutPolicy') or {}).get('idle') == 'infinity'
            and any(condition.get('prefix') == '/' for condition in (route.get('conditions') or []))
            and any(service.get('name') == 'rancher' and service.get('port') == 80
                    for service in (route.get('services') or []))
            for route in routes if isinstance(route, dict)
        )
        if not websocket_route:
            errors.append('Rancher HTTPProxy must enable WebSockets with infinite response/idle timeouts on the / route to rancher:80')

rancher_values = root/'yaml'/'j64'/'seg1opman-cluster'/'values'/'rancher-j64manager-values-v1.yaml'
try:
    values = yaml.safe_load(rancher_values.read_text(encoding='utf-8')) or {}
except Exception as exc:
    errors.append(f'Unable to inspect Rancher values: {exc}')
else:
    fleet_values = values.get('fleet') or ''
    if not isinstance(fleet_values, str) or 'KUBE_FEATURE_WatchListClient' not in fleet_values or 'value: "false"' not in fleet_values:
        errors.append('Rancher values must pass KUBE_FEATURE_WatchListClient=false to the bundled Fleet chart')

if errors:
    print('\n'.join('[WARN] '+error for error in errors), file=sys.stderr)
    raise SystemExit(1)
print(f'Chart metadata, OCI inventory, and ownership checks passed for {len(package_names)} packages.')
PYCHARTS
then failures=$((failures + 1)); fi

if ! grep -q 'validate-rancher-registry.sh" preflight' "${ROOT_DIR}/scripts/management/fleet/00-bootstrap-management.sh"; then
  warn "Management bootstrap does not enforce external Rancher registry validation."
  failures=$((failures + 1))
fi
if ! grep -q '02-validate-rancher-system.sh' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh"; then
  warn "Rancher installer does not validate webhook/Fleet readiness."
  failures=$((failures + 1))
fi
if ! grep -q '00-prepare-rancher-psa.sh' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh"; then
  warn "Rancher installer does not prepare privileged Rancher/Fleet PSA namespaces."
  failures=$((failures + 1))
fi
if ! grep -q '00-prepare-rancher-psa.sh.*--check --all' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate Rancher/Fleet PSA namespaces on all clusters."
  failures=$((failures + 1))
fi
if ! grep -q '04-configure-fleet-watchlist.sh.*--all --check' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate the Kubernetes 1.35 WatchListClient workaround on all clusters."
  failures=$((failures + 1))
fi
if ! grep -q '05-validate-imported-clusters.sh.*--wait' "${ROOT_DIR}/scripts/management/fleet/00-preflight-fleet.sh"; then
  warn "Fleet preflight does not validate Rancher imported-cluster connectivity."
  failures=$((failures + 1))
fi
for token in cattle-system cattle-fleet-system 'pod-security.kubernetes.io/enforce=privileged'; do
  if ! grep -q "${token}" "${ROOT_DIR}/scripts/management/rancher/00-prepare-rancher-psa.sh"; then
    warn "Rancher PSA preparation script is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if ! grep -q 'repair-rancher-psa' "${ROOT_DIR}/scripts/deploy-platform.sh"; then
  warn "deploy-platform.sh does not expose the Rancher/Fleet PSA repair phase."
  failures=$((failures + 1))
fi
for phase in configure-fleet-watchlist validate-rancher-imports repair-rancher-agents; do
  if ! grep -q "${phase}" "${ROOT_DIR}/scripts/deploy-platform.sh"; then
    warn "deploy-platform.sh does not expose required Rancher/Fleet phase: ${phase}"
    failures=$((failures + 1))
  fi
done
for token in KUBE_FEATURE_WatchListClient spec.agentEnvVars fleet-controller fleet-agent; do
  if ! grep -q "${token}" "${ROOT_DIR}/scripts/management/rancher/04-configure-fleet-watchlist.sh"; then
    warn "Fleet WatchList compatibility script is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if ! grep -q 'RANCHER_REGISTRY_ENFORCE=true' "${ROOT_DIR}/config/fleet-bootstrap.example.env"; then
  warn "Example runtime config does not enforce Rancher registry validation."
  failures=$((failures + 1))
fi

if grep -RIn --exclude='*.md' --exclude='*.tgz' --exclude='validate-deployment-package.sh' -- '--atomic' "${ROOT_DIR}/scripts" >/dev/null; then
  warn "Deployment scripts still use Helm's deprecated --atomic flag."
  failures=$((failures + 1))
fi
if ! grep -q -- '--rollback-on-failure' "${ROOT_DIR}/scripts/_lib/common.sh"; then
  warn "helm_upgrade_install does not use --rollback-on-failure."
  failures=$((failures + 1))
fi
if ! grep -q 'HELM_MIN_VERSION="${HELM_MIN_VERSION:-4.0.0}"' "${ROOT_DIR}/scripts/_lib/common.sh"; then
  warn "The shared Helm wrapper does not enforce Helm 4.0.0 or newer."
  failures=$((failures + 1))
fi
for token in DEV_KUBE_DNS_SERVERS JDE_DNS_SERVERS JCP_DNS_SERVERS FLEET_OCI_PROBE_IMAGE; do
  if ! grep -q "^${token}=" "${ROOT_DIR}/config/fleet-bootstrap.example.env"; then
    warn "Example runtime config is missing private DNS/OCI setting: ${token}"
    failures=$((failures + 1))
  fi
done
for token in __DEV_KUBE_DNS_SERVERS__ 'policy sequential' 'failover SERVFAIL REFUSED'; do
  if ! grep -q "${token}" "${ROOT_DIR}/yaml/resources/coredns-configmap-rke2-patch-v1.yaml"; then
    warn "CoreDNS template is missing required private-zone resilience token: ${token}"
    failures=$((failures + 1))
  fi
done
for token in 'load_kmm_runtime_config' 'kmm-coredns-registry-probe' 'CoreDNS cannot resolve'; do
  if ! grep -q "${token}" "${ROOT_DIR}/scripts/core/01-patch-coredns.sh"; then
    warn "CoreDNS patch workflow is missing runtime rendering/probe token: ${token}"
    failures=$((failures + 1))
  fi
done
for caller in scripts/management/fleet/00-preflight-fleet.sh scripts/management/fleet/03-bootstrap-gitrepos.sh; do
  if ! grep -q '02-validate-fleet-oci.sh' "${ROOT_DIR}/${caller}"; then
    warn "${caller} does not enforce in-cluster Fleet OCI validation."
    failures=$((failures + 1))
  fi
done
if ! grep -q 'gitjob-event-writer' "${ROOT_DIR}/yaml/resources/fleet-gitjob-events-rbac-v1.yaml" ||    ! grep -q 'fleet-gitjob-events-rbac-v1.yaml' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh"; then
  warn "Supplemental GitJob event RBAC is missing or not applied during Rancher installation."
  failures=$((failures + 1))
fi
if ! grep -q 'auth can-i create events' "${ROOT_DIR}/scripts/management/rancher/02-validate-rancher-system.sh"; then
  warn "Rancher validation does not verify GitJob event permissions."
  failures=$((failures + 1))
fi
if [[ "$(grep -c '00-prepare-rancher-psa.sh' "${ROOT_DIR}/scripts/management/rancher/01-install-rancher.sh")" -lt 2 ]]; then
  warn "Rancher installation does not reconcile PSA labels after Rancher creates runtime namespaces."
  failures=$((failures + 1))
fi

if ! grep -q 'FLEET_RECONCILE_TIMEOUT_SECONDS' "${ROOT_DIR}/scripts/management/fleet/04-validate-fleet.sh"; then
  warn "Fleet validation does not wait for GitRepo scanning and Bundle generation."
  failures=$((failures + 1))
fi
if ! grep -q 'forceSyncGeneration' "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh"; then
  warn "Fleet GitRepo bootstrap does not trigger an immediate synchronization."
  failures=$((failures + 1))
fi
if ! grep -q '02-validate-cert-manager-bootstrap.sh" j64 seg1opman' "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh"; then
  warn "Fleet GitRepo bootstrap does not validate the management cert-manager bootstrap contract."
  failures=$((failures + 1))
fi
if [[ "$(grep -c 'fleet/bundles/10-cert-manager' "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh")" -ne 1 ]] || \
   [[ "$(grep -c 'fleet/bundles/11-cert-manager-config' "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh")" -ne 1 ]]; then
  warn "The real cert-manager bundles must be downstream-only; fleet-local uses bootstrap contract markers."
  failures=$((failures + 1))
fi
for marker in \
  fleet/local-bundles/10-bootstrap-cert-manager-ready \
  fleet/local-bundles/11-bootstrap-cert-manager-config-ready
do
  if [[ "$(grep -c "${marker}" "${ROOT_DIR}/scripts/management/fleet/03-bootstrap-gitrepos.sh")" -ne 1 ]]; then
    warn "fleet-local bootstrap contract path is missing or duplicated: ${marker}"
    failures=$((failures + 1))
  fi
done
for identity_script in \
  scripts/management/fleet/05-enable-identity-secondary.sh \
  scripts/management/fleet/06-validate-identity-ha.sh \
  scripts/management/failover/failover-to-j52.sh \
  scripts/opkeycloak/02-install-oppostgres-cnpg-keycloak-db.sh
do
  if ! grep -q 'clusters.postgresql.cnpg.io' "${ROOT_DIR}/${identity_script}"; then
    warn "Identity script uses ambiguous CNPG Cluster resource shorthand: ${identity_script}"
    failures=$((failures + 1))
  fi
done
longhorn_preflight="${ROOT_DIR}/scripts/management/preflight/longhorn-storage-preflight.sh"
for token in '/mnt/k8sdata' 'open-iscsi' 'nfs-common' 'multipathd' 'node.longhorn.io/create-default-disk=true'; do
  if ! grep -q "${token}" "${longhorn_preflight}"; then
    warn "Longhorn storage preflight is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if grep -Eq 'mkfs|wipefs|parted|fdisk' "${longhorn_preflight}"; then
  warn "Longhorn storage preflight must remain non-destructive."
  failures=$((failures + 1))
fi
if grep -Eq '^[[:space:]]*(sudo[[:space:]]+-n[[:space:]]+)?apt(-get)?[[:space:]]' "${longhorn_preflight}"; then
  warn "Longhorn deployed-node preflight must not invoke apt or apt-get."
  failures=$((failures + 1))
fi
if ! grep -Fq 'dpkg-query -W -f="\${db:Status-Abbrev}"' "${longhorn_preflight}"; then
  warn "Longhorn preflight must escape the dpkg-query format token so remote Bash does not expand db under set -u."
  failures=$((failures + 1))
fi
for istio_fleet in \
  "${ROOT_DIR}/fleet/bundles/60-istio-base/fleet.yaml" \
  "${ROOT_DIR}/fleet/bundles/62-istiod/fleet.yaml"
do
  for pointer in '/webhooks/0/clientConfig/caBundle' '/webhooks/0/failurePolicy'; do
    if ! grep -Fq -- "${pointer}" "${istio_fleet}"; then
      warn "Istio Fleet bundle does not ignore controller-owned validating webhook field ${pointer}: ${istio_fleet#${ROOT_DIR}/}"
      failures=$((failures + 1))
    fi
  done
done
if ! grep -q 'validate_storage_bundle_generation' "${ROOT_DIR}/scripts/management/fleet/04-validate-fleet.sh"; then
  warn "Fleet runtime validation does not reject stale pre-Longhorn Bundle content."
  failures=$((failures + 1))
fi
#for token in 'dpkg --unpack packages/*.deb' 'dpkg --configure --pending' 'sha256sum --check SHA256SUMS'; do
#  if ! grep -Fq "${token}" "${ROOT_DIR}/scripts/management/preflight/install-longhorn-host-deps.sh"; then
#    warn "Offline Longhorn installer is missing required token: ${token}"
#    failures=$((failures + 1))
#  fi
#done

for forbidden in build helm/charts apps/istio scripts/management/argocd helm/packages/argo-cd-9.5.20.tgz rancher-airgap scripts/management/preflight/rancher-airgap.sh; do
  [[ ! -e "${ROOT_DIR}/${forbidden}" ]] || { warn "Forbidden legacy/Argo artifact exists: ${forbidden}"; failures=$((failures + 1)); }
done

required=(
  config/fleet-bootstrap.example.env
  helm/required-oci-artifacts.txt
  helm/fleet-oci-packages.txt
  scripts/_lib/runtime-config.sh
  scripts/core/02-validate-cert-manager-bootstrap.sh
  scripts/management/fleet/00-bootstrap-management.sh
  scripts/management/fleet/00-preflight-fleet.sh
  scripts/management/fleet/01-seed-runtime-secrets.sh
  scripts/management/fleet/02-label-fleet-clusters.sh
  scripts/management/fleet/02-validate-fleet-oci.sh
  scripts/management/fleet/03-bootstrap-gitrepos.sh
  scripts/management/fleet/04-validate-fleet.sh
  scripts/management/preflight/publish-fleet-charts.sh
  scripts/management/preflight/validate-rancher-registry.sh
  scripts/management/rancher/00-prepare-rancher-psa.sh
  scripts/management/rancher/02-validate-rancher-system.sh
  scripts/management/rancher/03-repair-rancher-system.sh
  scripts/management/rancher/04-configure-fleet-watchlist.sh
  scripts/management/rancher/05-validate-imported-clusters.sh
  yaml/resources/coredns-configmap-rke2-patch-v1.yaml
  yaml/resources/fleet-gitjob-events-rbac-v1.yaml
  scripts/validate-fleet-layout.sh
  fleet/bundles/61-istio-cni/fleet.yaml
  fleet/local-bundles/10-bootstrap-cert-manager-ready/fleet.yaml
  fleet/local-bundles/10-bootstrap-cert-manager-ready/contract.yaml
  fleet/local-bundles/11-bootstrap-cert-manager-config-ready/fleet.yaml
  fleet/local-bundles/11-bootstrap-cert-manager-config-ready/contract.yaml
  fleet/bundles/53-keycloak/fleet.yaml
  fleet/bundles/70-kube-state-metrics/fleet.yaml
  fleet/bundles/71-elastic-agent/fleet.yaml
  scripts/management/preflight/cluster-time.sh
  yaml/resources/segment1-chrony-daemonset.yaml
  yaml/resources/segment1-chrony-restore-timesyncd-daemonset.yaml
  scripts/management/preflight/longhorn-storage-preflight.sh
  scripts/management/failover/failover-to-j52.sh
  scripts/monitoring/02-validate-elastic-agent.sh
)
for path in "${required[@]}"; do
  [[ -f "${ROOT_DIR}/${path}" ]] || { warn "Missing Fleet deployment input: ${path}"; failures=$((failures + 1)); }
 # scripts/management/preflight/install-longhorn-host-deps.sh
 # scripts/management/preflight/build-longhorn-host-deps-bundle.sh
 # host-packages/README.md
 # host-packages/BUNDLE-README.md
 # host-packages/longhorn-host-deps-ubuntu-24.04-amd64.manifest
 # host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz
 # host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz.sha256
done

chrony_script="${ROOT_DIR}/scripts/management/preflight/cluster-time.sh"
chrony_manifest="${ROOT_DIR}/yaml/resources/segment1-chrony-daemonset.yaml"
chrony_restore_manifest="${ROOT_DIR}/yaml/resources/segment1-chrony-restore-timesyncd-daemonset.yaml"
for token in 'CONTEXTS=()' '--verify-only' 'chronyc waitsync' 'chronyc -n ntpdata' 'Leap status' 'restore_timesyncd_context'; do
  if ! grep -Fq -- "${token}" "${chrony_script}"; then
    warn "Chrony installer is missing required synchronization/targeting token: ${token}"
    failures=$((failures + 1))
  fi
done
for token in 'name: chrony-status' '/var/lib/k8mm/chrony' 'STATUS_INTERVAL_SECONDS' 'chronyc -h 127.0.0.1 -n tracking'; do
  if ! grep -Fq -- "${token}" "${chrony_manifest}"; then
    warn "Chrony DaemonSet is missing required state/telemetry token: ${token}"
    failures=$((failures + 1))
  fi
done
for token in 'name: chrony-restore-timesyncd' 'timedatectl set-ntp true' '/var/lib/k8mm/chrony' '/tmp/restore-complete'; do
  if ! grep -Fq -- "${token}" "${chrony_restore_manifest}"; then
    warn "Chrony restore DaemonSet is missing required token: ${token}"
    failures=$((failures + 1))
  fi
done
if grep -Fq 'CONTEXTS=(j64seg1opman j64seg1opdev j52seg1opdev r01seg1opdev)' "${chrony_script}"; then
  warn "Chrony --context regression: contexts must not be pre-populated before argument parsing."
  failures=$((failures + 1))
fi

"${SCRIPT_DIR}/validate-fleet-layout.sh" || failures=$((failures + 1))
[[ "${failures}" -eq 0 ]] || die "Deployment package validation failed with ${failures} issue(s)."
log "Deployment package validation passed."
