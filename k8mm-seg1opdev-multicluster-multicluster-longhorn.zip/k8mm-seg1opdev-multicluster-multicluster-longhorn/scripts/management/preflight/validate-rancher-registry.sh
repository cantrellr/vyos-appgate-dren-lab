#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../../_lib/common.sh"
# shellcheck source=../../_lib/runtime-config.sh
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

ACTION="${1:-preflight}"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

RANCHER_VERSION="${RANCHER_VERSION:-2.15.0}"
RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
RANCHER_IMAGE_LIST_FILE="${RANCHER_IMAGE_LIST_FILE:-${RANCHER_IMAGE_LIST:-}}"
RANCHER_REGISTRY_VALIDATE_MODE="${RANCHER_REGISTRY_VALIDATE_MODE:-all}"
RANCHER_NODE_PULL_TIMEOUT="${RANCHER_NODE_PULL_TIMEOUT:-300s}"

usage() {
  cat <<USAGE
Usage: $0 [preflight|validate-list|validate-registry|validate-node-pulls]

This script performs validation only. Image acquisition and promotion are owned by
cantrellr/k8s-airgap-images.

Runtime settings:
  RANCHER_IMAGE_LIST_FILE          Path to the Rancher image list exported/staged from k8s-airgap-images
  RANCHER_REGISTRY_VALIDATE_MODE   all or core; default: all
  RANCHER_CONTEXT                  default: j64seg1opman
  RANCHER_NODE_PULL_TIMEOUT        default: 300s
  REGISTRY_HOST                    default: kubeharbor.dev.kube
  REGISTRY_USERNAME_FILE           protected KubeHarbor username file
  REGISTRY_PASSWORD_FILE           protected KubeHarbor password/token file
  RANCHER_CA_FILE or CA_CERT_FILE  KubeHarbor issuing CA PEM
USAGE
}

load_image_list() {
  [[ -n "${RANCHER_IMAGE_LIST_FILE}" ]] \
    || die "Set RANCHER_IMAGE_LIST_FILE to the Rancher image list maintained by k8s-airgap-images."
  ensure_file "${RANCHER_IMAGE_LIST_FILE}"
}

validate_list() {
  load_image_list
  local image_count family
  image_count="$(grep -Ev '^[[:space:]]*(#|$)' "${RANCHER_IMAGE_LIST_FILE}" | wc -l | tr -d ' ')"
  (( image_count >= 25 )) \
    || die "${RANCHER_IMAGE_LIST_FILE} contains only ${image_count} entries; it is not a complete Rancher inventory."

  grep -Eq "(^|/)rancher/rancher:v?${RANCHER_VERSION}$" "${RANCHER_IMAGE_LIST_FILE}" \
    || die "${RANCHER_IMAGE_LIST_FILE} does not include rancher/rancher:v${RANCHER_VERSION}."

  # Fleet v0.10 and later embeds the former gitjob image functionality in
  # rancher/fleet. Rancher still creates a Deployment named gitjob, but it no
  # longer requires a separate rancher/gitjob image family.
  for family in \
    rancher/shell \
    rancher/fleet \
    rancher/fleet-agent \
    rancher/rancher-agent \
    rancher/rancher-webhook; do
    grep -Eq "(^|/)${family}([:@]|$)" "${RANCHER_IMAGE_LIST_FILE}" \
      || die "${RANCHER_IMAGE_LIST_FILE} is missing required image family ${family}."
  done

  log "Validated external Rancher v${RANCHER_VERSION} image list with ${image_count} references."
}

load_registry_credentials() {
  [[ -f "${CONFIG_FILE}" ]] || die "Runtime config is required for registry access: ${CONFIG_FILE}"
  : "${REGISTRY_USERNAME_FILE:?Set REGISTRY_USERNAME_FILE in ${CONFIG_FILE}}"
  : "${REGISTRY_PASSWORD_FILE:?Set REGISTRY_PASSWORD_FILE in ${CONFIG_FILE}}"
  REGISTRY_USERNAME="$(read_required_secret_file REGISTRY_USERNAME_FILE)"
  REGISTRY_PASSWORD="$(read_required_secret_file REGISTRY_PASSWORD_FILE)"
  export REGISTRY_USERNAME REGISTRY_PASSWORD
  REGISTRY_CA_FILE="${RANCHER_CA_FILE:-${CA_CERT_FILE:-${FLEET_HELM_CA_FILE:-}}}"
  [[ -n "${REGISTRY_CA_FILE}" ]] || die "Set RANCHER_CA_FILE, CA_CERT_FILE, or FLEET_HELM_CA_FILE."
  ensure_file "${REGISTRY_CA_FILE}"
}

normalize_relative_reference() {
  local ref="$1" first
  ref="${ref#oci://}"
  ref="${ref#docker://}"
  ref="${ref#https://}"
  ref="${ref#http://}"
  first="${ref%%/*}"
  if [[ "${ref}" == */* && ( "${first}" == *.* || "${first}" == *:* || "${first}" == localhost ) ]]; then
    ref="${ref#*/}"
  fi
  printf '%s' "${ref}"
}

manifest_url_for_reference() {
  local ref repo manifest last
  ref="$(normalize_relative_reference "$1")"
  if [[ "${ref}" == *@* ]]; then
    repo="${ref%@*}"
    manifest="${ref#*@}"
  else
    last="${ref##*/}"
    if [[ "${last}" == *:* ]]; then
      repo="${ref%:*}"
      manifest="${last#*:}"
    else
      repo="${ref}"
      manifest="latest"
    fi
  fi
  printf 'https://%s/v2/%s/manifests/%s' "${REGISTRY_HOST}" "${repo}" "${manifest}"
}

selected_images() {
  case "${RANCHER_REGISTRY_VALIDATE_MODE}" in
    all)
      grep -Ev '^[[:space:]]*(#|$)' "${RANCHER_IMAGE_LIST_FILE}"
      ;;
    core)
      grep -Ev '^[[:space:]]*(#|$)' "${RANCHER_IMAGE_LIST_FILE}" | \
        grep -E '(^|/)(rancher/(rancher|shell|fleet|fleet-agent|rancher-agent|rancher-webhook))([:@]|$)'
      ;;
    *)
      die "RANCHER_REGISTRY_VALIDATE_MODE must be all or core."
      ;;
  esac
}

validate_registry() {
  validate_list
  require_cmd curl
  load_registry_credentials

  local netrc missing_file image url checked=0 missing=0
  netrc="$(mktemp)"
  missing_file="$(mktemp)"
  chmod 0600 "${netrc}" "${missing_file}"
  cleanup_registry_validation() {
    rm -f "${netrc:-}" "${missing_file:-}"
  }
  trap cleanup_registry_validation EXIT
  printf 'machine %s login %s password %s\n' \
    "${REGISTRY_HOST%%:*}" "${REGISTRY_USERNAME}" "${REGISTRY_PASSWORD}" >"${netrc}"

  log "Validating Rancher v${RANCHER_VERSION} ${RANCHER_REGISTRY_VALIDATE_MODE} inventory in ${REGISTRY_HOST}..."
  while IFS= read -r image; do
    [[ -n "${image}" ]] || continue
    checked=$((checked + 1))
    url="$(manifest_url_for_reference "${image}")"
    if ! curl --fail --silent --show-error --location \
      --netrc-file "${netrc}" --cacert "${REGISTRY_CA_FILE}" \
      -H 'Accept: application/vnd.oci.image.index.v1+json' \
      -H 'Accept: application/vnd.oci.image.manifest.v1+json' \
      -H 'Accept: application/vnd.docker.distribution.manifest.list.v2+json' \
      -H 'Accept: application/vnd.docker.distribution.manifest.v2+json' \
      --output /dev/null "${url}"; then
      printf '%s\n' "${image}" >>"${missing_file}"
      missing=$((missing + 1))
    fi
    if (( checked % 50 == 0 )); then
      log "Validated ${checked} registry references..."
    fi
  done < <(selected_images)

  (( checked > 0 )) || die "No images were selected from ${RANCHER_IMAGE_LIST_FILE}."
  if (( missing > 0 )); then
    warn "${missing} of ${checked} Rancher images are missing or inaccessible in ${REGISTRY_HOST}:"
    sed -n '1,80p' "${missing_file}" >&2
    (( missing <= 80 )) || warn "Only the first 80 missing references were printed."
    die "KubeHarbor does not contain the required Rancher inventory. Run the k8s-airgap-images promotion workflow first."
  fi

  cleanup_registry_validation
  trap - EXIT
  log "Validated ${checked} Rancher image manifests in ${REGISTRY_HOST}."
}

select_node_test_image() {
  local image
  image="$(grep -Ev '^[[:space:]]*(#|$)' "${RANCHER_IMAGE_LIST_FILE}" | \
    grep -E '(^|/)rancher/shell([:@]|$)' | tail -1 || true)"
  [[ -n "${image}" ]] || die "Unable to find rancher/shell in ${RANCHER_IMAGE_LIST_FILE}."
  printf '%s/%s' "${REGISTRY_HOST}" "$(normalize_relative_reference "${image}")"
}

validate_node_pulls() {
  validate_list
  require_cmd kubectl
  validate_context_access "${RANCHER_CONTEXT}"
  local namespace="rancher-registry-preflight-$(date +%s)" image desired ready
  image="$(select_node_test_image)"
  cleanup_node_test() {
    kubectl --context "${RANCHER_CONTEXT}" delete namespace "${namespace}" \
      --ignore-not-found --wait=false >/dev/null 2>&1 || true
  }
  trap cleanup_node_test EXIT

  kubectl --context "${RANCHER_CONTEXT}" create namespace "${namespace}" >/dev/null
  kubectl --context "${RANCHER_CONTEXT}" label namespace "${namespace}" --overwrite \
    pod-security.kubernetes.io/enforce=privileged \
    pod-security.kubernetes.io/audit=privileged \
    pod-security.kubernetes.io/warn=privileged >/dev/null

  cat <<YAML | kubectl --context "${RANCHER_CONTEXT}" apply -f - >/dev/null
apiVersion: apps/v1
kind: DaemonSet
metadata:
  name: rancher-registry-node-test
  namespace: ${namespace}
spec:
  selector:
    matchLabels:
      app: rancher-registry-node-test
  template:
    metadata:
      labels:
        app: rancher-registry-node-test
    spec:
      tolerations:
        - operator: Exists
      containers:
        - name: test
          image: ${image}
          imagePullPolicy: Always
          command: ["sh", "-c", "trap : TERM INT; sleep 600 & wait"]
      terminationGracePeriodSeconds: 1
YAML

  log "Forcing every ${RANCHER_CONTEXT} node to pull ${image} without a Kubernetes imagePullSecret..."
  if ! kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" rollout status \
    daemonset/rancher-registry-node-test --timeout="${RANCHER_NODE_PULL_TIMEOUT}"; then
    kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get pods -o wide >&2 || true
    kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get events --sort-by=.lastTimestamp >&2 || true
    die "One or more RKE2 nodes cannot pull Rancher system images from ${REGISTRY_HOST}. Fix /etc/rancher/rke2/registries.yaml trust/authentication on every node."
  fi

  desired="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get daemonset rancher-registry-node-test \
    -o jsonpath='{.status.desiredNumberScheduled}')"
  ready="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get daemonset rancher-registry-node-test \
    -o jsonpath='{.status.numberReady}')"
  [[ "${desired}" =~ ^[1-9][0-9]*$ && "${ready}" == "${desired}" ]] \
    || die "Registry pull test did not run successfully on every management node (desired=${desired:-0}, ready=${ready:-0})."

  cleanup_node_test
  trap - EXIT
  log "Every management-cluster node can authenticate to and trust ${REGISTRY_HOST}."
}

case "${ACTION}" in
  validate-list) validate_list ;;
  validate-registry) validate_registry ;;
  validate-node-pulls) validate_node_pulls ;;
  preflight) validate_registry; validate_node_pulls ;;
  help|-h|--help) usage ;;
  *) usage >&2; die "Unknown action: ${ACTION}" ;;
esac
