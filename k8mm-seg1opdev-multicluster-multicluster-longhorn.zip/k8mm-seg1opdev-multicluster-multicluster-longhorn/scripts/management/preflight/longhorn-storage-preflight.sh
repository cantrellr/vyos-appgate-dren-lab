#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"

SSH_USER="${SSH_USER:-k8admin}"
SSH_IDENTITY_FILE="${SSH_IDENTITY_FILE:-}"
SSH_STRICT_HOST_KEY_CHECKING="${SSH_STRICT_HOST_KEY_CHECKING:-yes}"
LONGHORN_DATA_PATH="${LONGHORN_DATA_PATH:-/mnt/k8sdata}"
LONGHORN_DATA_FILESYSTEM="${LONGHORN_DATA_FILESYSTEM:-xfs}"
LONGHORN_MIN_DISK_GIB="${LONGHORN_MIN_DISK_GIB:-240}"
CONTINUE_ON_ERROR="${CONTINUE_ON_ERROR:-false}"
CONTEXTS=()

usage() {
  cat <<USAGE
Usage: $0 (--all | --context <kubectl-context> ...) [options]

Validates preinstalled Longhorn worker-node prerequisites and labels successful
nodes for the default Longhorn disk. This validation-only routine never runs
apt, contacts a package repository, formats, mounts, unmounts, or erases a disk.

Options:
  --all                       Target all supported contexts
  --context <context>         Target one context; may be repeated
  --ssh-user <user>           SSH account (default: ${SSH_USER})
  --identity-file <path>      SSH private key path
  --continue-on-error         Process remaining nodes after a failure
  -h, --help                  Show this help

Environment:
  LONGHORN_DATA_PATH          Default: /mnt/k8sdata
  LONGHORN_DATA_FILESYSTEM    Default: xfs
  LONGHORN_MIN_DISK_GIB       Default: 240
  SSH_STRICT_HOST_KEY_CHECKING=yes|accept-new
USAGE
}

while (($#)); do
  case "$1" in
    --all) CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}"); shift ;;
    --context) [[ $# -ge 2 ]] || die "--context requires a value."; CONTEXTS+=("$2"); shift 2 ;;
    --ssh-user) [[ $# -ge 2 ]] || die "--ssh-user requires a value."; SSH_USER="$2"; shift 2 ;;
    --identity-file) [[ $# -ge 2 ]] || die "--identity-file requires a value."; SSH_IDENTITY_FILE="$2"; shift 2 ;;
    --continue-on-error) CONTINUE_ON_ERROR=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; die "Unknown argument: $1" ;;
  esac
done

((${#CONTEXTS[@]})) || { usage >&2; die "Choose --all or at least one --context."; }
[[ "${SSH_STRICT_HOST_KEY_CHECKING}" =~ ^(yes|accept-new)$ ]] || die "Unsupported SSH host-key policy."
[[ "${CONTINUE_ON_ERROR}" =~ ^(true|false)$ ]] || die "CONTINUE_ON_ERROR must be true or false."
[[ "${LONGHORN_DATA_PATH}" == /* ]] || die "LONGHORN_DATA_PATH must be absolute."
[[ "${LONGHORN_MIN_DISK_GIB}" =~ ^[0-9]+$ ]] || die "LONGHORN_MIN_DISK_GIB must be an integer."

require_cmd kubectl
require_cmd jq
require_cmd ssh
[[ -z "${SSH_IDENTITY_FILE}" || -f "${SSH_IDENTITY_FILE}" ]] || die "SSH identity file not found: ${SSH_IDENTITY_FILE}"

ssh_args=(-o BatchMode=yes -o ConnectTimeout=15 -o "StrictHostKeyChecking=${SSH_STRICT_HOST_KEY_CHECKING}")
[[ -n "${SSH_IDENTITY_FILE}" ]] && ssh_args+=(-i "${SSH_IDENTITY_FILE}")

remote_script='set -Eeuo pipefail
data_path="$1"
expected_fs="$2"
minimum_gib="$3"

sudo -n true
for package in open-iscsi nfs-common cryptsetup dmsetup xfsprogs; do
  status="$(dpkg-query -W -f="\${db:Status-Abbrev}" "${package}" 2>/dev/null || true)"
  [[ "${status}" == ii* ]] || { echo "required package is not installed: ${package}" >&2; exit 10; }
done
for command in iscsiadm mount.nfs cryptsetup dmsetup findmnt xfs_info; do
  command -v "${command}" >/dev/null || { echo "required command is missing: ${command}" >&2; exit 11; }
done

sudo -n modprobe iscsi_tcp
printf "%s\n" iscsi_tcp | sudo -n tee /etc/modules-load.d/longhorn.conf >/dev/null
sudo -n systemctl enable --now iscsid.service

# Multipath can claim Longhorn block devices. Preserve its package/configuration,
# but stop the service and socket so Longhorn owns its devices unambiguously.
sudo -n systemctl disable --now multipathd.service multipathd.socket >/dev/null 2>&1 || true
if sudo -n systemctl is-active --quiet multipathd.service || sudo -n systemctl is-active --quiet multipathd.socket; then
  echo "multipathd remains active" >&2
  exit 20
fi

sudo -n mountpoint -q "${data_path}" || { echo "not a mountpoint: ${data_path}" >&2; exit 21; }
actual_fs="$(findmnt -n -o FSTYPE --target "${data_path}")"
[[ "${actual_fs}" == "${expected_fs}" ]] || { echo "filesystem is ${actual_fs}, expected ${expected_fs}" >&2; exit 22; }
mount_options="$(findmnt -n -o OPTIONS --target "${data_path}")"
[[ ",${mount_options}," == *,rw,* ]] || { echo "mount is not read-write" >&2; exit 23; }
size_bytes="$(findmnt -b -n -o SIZE --target "${data_path}")"
minimum_bytes=$((minimum_gib * 1024 * 1024 * 1024))
((size_bytes >= minimum_bytes)) || { echo "disk is smaller than ${minimum_gib} GiB" >&2; exit 24; }
propagation="$(findmnt -n -o PROPAGATION /)"
[[ "${propagation}" == shared || "${propagation}" == rshared ]] || { echo "root mount propagation is ${propagation}, expected shared" >&2; exit 25; }

sudo -n install -d -o root -g root -m 0750 "${data_path}"
probe="${data_path}/.longhorn-preflight.$$"
sudo -n touch "${probe}"
sudo -n rm -f "${probe}"
sudo -n iscsiadm --version
sudo -n systemctl is-active --quiet iscsid.service
printf "Longhorn prerequisite validation passed for %s (%s, %s bytes).\n" "${data_path}" "${actual_fs}" "${size_bytes}"'

failures=0
validated=0
declare -A visited=()
for context in "${CONTEXTS[@]}"; do
  validate_supported_context "${context}"
  validate_context_access "${context}"
  mapfile -t workers < <(
    kubectl --context "${context}" get nodes -o json |
      jq -r '.items[]
        | select((.metadata.labels["node-role.kubernetes.io/control-plane"] // "") == "")
        | select((.metadata.labels["node-role.kubernetes.io/master"] // "") == "")
        | select((.metadata.labels["node-role.kubernetes.io/etcd"] // "") == "")
        | [.metadata.name, ([.status.addresses[] | select(.type == "InternalIP") | .address][0] // "")]
        | @tsv'
  )
  ((${#workers[@]})) || { warn "${context}: no worker nodes found."; failures=$((failures + 1)); continue; }

  for worker in "${workers[@]}"; do
    IFS=$'	' read -r node ip <<<"${worker}"
    [[ -n "${ip}" ]] || { warn "${context}/${node}: no InternalIP."; failures=$((failures + 1)); continue; }
    key="${context}/${node}"
    [[ -z "${visited[${key}]:-}" ]] || continue
    visited["${key}"]=1
    log "Validating preinstalled Longhorn prerequisites on ${context}/${node} (${ip})..."
    if ssh "${ssh_args[@]}" "${SSH_USER}@${ip}" bash -s --       "${LONGHORN_DATA_PATH}" "${LONGHORN_DATA_FILESYSTEM}" "${LONGHORN_MIN_DISK_GIB}" <<<"${remote_script}"; then
      kubectl --context "${context}" label node "${node}" node.longhorn.io/create-default-disk=true --overwrite >/dev/null
      validated=$((validated + 1))
    else
      warn "Longhorn storage validation failed for ${context}/${node}."
      failures=$((failures + 1))
      [[ "${CONTINUE_ON_ERROR}" == true ]] || die "Stopped after the first Longhorn prerequisite failure."
    fi
  done
done

((failures == 0)) || die "Longhorn storage preflight completed with ${failures} failed worker node(s)."
log "Longhorn storage preflight passed for ${validated} worker node(s)."
