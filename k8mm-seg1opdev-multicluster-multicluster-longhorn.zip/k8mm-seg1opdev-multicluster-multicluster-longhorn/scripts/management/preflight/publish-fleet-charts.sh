#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../../_lib/common.sh"
# shellcheck source=../../_lib/runtime-config.sh
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

HELM_REGISTRY_HOST="${HELM_REGISTRY_HOST:-${REGISTRY_HOST:-kubeharbor.dev.kube}}"
OCI_BASE="${FLEET_OCI_BASE:-oci://${HELM_REGISTRY_HOST}/k8mm-charts}"
PACKAGE_LIST="${ROOT_DIR}/helm/fleet-oci-packages.txt"
HELM_REGISTRY_USERNAME_FILE="${HELM_REGISTRY_USERNAME_FILE:-${FLEET_HELM_USERNAME_FILE:-}}"
HELM_REGISTRY_PASSWORD_FILE="${HELM_REGISTRY_PASSWORD_FILE:-${FLEET_HELM_PASSWORD_FILE:-}}"
HELM_REGISTRY_CA_FILE="${HELM_REGISTRY_CA_FILE:-${FLEET_HELM_CA_FILE:-}}"

require_cmd helm
require_cmd tar
require_cmd sha256sum
ensure_file "${PACKAGE_LIST}"
[[ -n "${HELM_REGISTRY_USERNAME_FILE}" ]] || die "Set HELM_REGISTRY_USERNAME_FILE or FLEET_HELM_USERNAME_FILE."
[[ -n "${HELM_REGISTRY_PASSWORD_FILE}" ]] || die "Set HELM_REGISTRY_PASSWORD_FILE or FLEET_HELM_PASSWORD_FILE."
[[ -n "${HELM_REGISTRY_CA_FILE}" ]] || die "Set HELM_REGISTRY_CA_FILE or FLEET_HELM_CA_FILE."
ensure_file "${HELM_REGISTRY_USERNAME_FILE}"
ensure_file "${HELM_REGISTRY_PASSWORD_FILE}"
ensure_file "${HELM_REGISTRY_CA_FILE}"

(cd "${ROOT_DIR}/helm" && sha256sum --check SHA256SUMS >/dev/null) \
  || die "Helm package checksum validation failed."

registry_username="$(cat "${HELM_REGISTRY_USERNAME_FILE}")"
[[ -n "${registry_username}" ]] || die "Helm registry username file is empty."
[[ -s "${HELM_REGISTRY_PASSWORD_FILE}" ]] || die "Helm registry password file is empty."

log "Authenticating Helm to ${HELM_REGISTRY_HOST}..."
helm registry login "${HELM_REGISTRY_HOST}" \
  --username "${registry_username}" \
  --password-stdin \
  --ca-file "${HELM_REGISTRY_CA_FILE}" <"${HELM_REGISTRY_PASSWORD_FILE}"

mapfile -t packages < <(grep -Ev '^[[:space:]]*(#|$)' "${PACKAGE_LIST}")
((${#packages[@]})) || die "No Fleet-owned packages are listed in ${PACKAGE_LIST}."

for package in "${packages[@]}"; do
  archive="${HELM_PACKAGES_DIR}/${package}"
  ensure_file "${archive}"
  tar -tzf "${archive}" >/dev/null || die "Invalid Helm archive: ${archive}"
  log "Publishing ${package} to ${OCI_BASE}..."
  helm push "${archive}" "${OCI_BASE}"
done

unset registry_username
log "Published ${#packages[@]} Fleet-owned Helm chart(s) to ${OCI_BASE}."
