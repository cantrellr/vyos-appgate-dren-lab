#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
load_kmm_runtime_config "${CONFIG_FILE}"
require_cmd kubectl
require_cmd jq

CLUSTER_NAME=oppostgres-opkeycloak-db
CNPG_CLUSTER_RESOURCE=clusters.postgresql.cnpg.io
NAMESPACE=oppostgres

identity_fleet_cluster_json() {
  local display_name="$1"
  fleet_cluster_json fleet-default "${display_name}" "${RANCHER_CONTEXT:-j64seg1opman}"
}

site_sql() {
  local context="$1" sql="$2" pod
  pod="$(kubectl --context "${context}" -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME},role=primary" -o jsonpath='{.items[0].metadata.name}')"
  kubectl --context "${context}" -n "${NAMESPACE}" exec "${pod}" -- psql -U postgres -d postgres -Atqc "${sql}"
}

validate_keycloak() {
  local context="$1" expected="$2" actual
  actual="$(kubectl --context "${context}" -n opkeycloak get keycloak opkeycloak -o jsonpath='{.spec.instances}')"
  [[ "${actual}" == "${expected}" ]] || die "${context}: Keycloak instances=${actual}, Fleet label=${expected}."
}

validate_keycloak_exposure() {
  local context="$1" expected_instances="$2" proxy_status proxy_description cert_ready service_port

  if (( expected_instances > 0 )); then
    service_port="$(kubectl --context "${context}" -n opkeycloak get service opkeycloak-service \
      -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
    [[ "${service_port}" == "8080" ]] || \
      die "${context}: active Keycloak site is missing opkeycloak-service TCP/8080; Contour HTTPProxy cannot become valid."

    cert_ready="$(kubectl --context "${context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
      -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
    [[ "${cert_ready}" == "True" ]] || \
      die "${context}: active Keycloak TLS Certificate is not Ready; HTTPProxy will remain invalid until the TLS Secret exists."

    proxy_status="$(kubectl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
      -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
    proxy_description="$(kubectl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
      -o jsonpath='{.status.description}' 2>/dev/null || true)"
    [[ "${proxy_status,,}" == "valid" ]] || \
      die "${context}: active Keycloak HTTPProxy status=${proxy_status:-missing}: ${proxy_description:-no Contour status description}."
    log "${context}: Keycloak HTTPProxy is valid and backed by opkeycloak-service:8080 with a Ready TLS certificate."
  else
    if kubectl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy >/dev/null 2>&1; then
      proxy_status="$(kubectl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
        -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
      proxy_description="$(kubectl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
        -o jsonpath='{.status.description}' 2>/dev/null || true)"
      die "${context}: standby Keycloak instances=0 but opkeycloak-httpproxy still exists (status=${proxy_status:-unknown}: ${proxy_description:-no description}). Fleet should remove standby exposure."
    fi
    log "${context}: standby Keycloak instances=0 and no HTTPProxy is published, as designed."
  fi
}

validate_replication_service_ip() {
  local context="$1" expected="$2" actual
  actual="$(kubectl --context "${context}" -n "${NAMESPACE}" get service oppostgres-replication-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  [[ -n "${actual}" ]] || die "${context}: PostgreSQL replication LoadBalancer has no IP."
  [[ "${actual}" == "${expected}" ]] || die "${context}: PostgreSQL replication LoadBalancer IP=${actual}, Fleet label=${expected}."
  [[ "${actual}" == 1.0.0.* || "${actual}" == 1.0.1.* ]] || die "${context}: PostgreSQL replication IP ${actual} is outside Segment1 1.0.0.0/23."
}

j64_json="$(identity_fleet_cluster_json "${FLEET_J64_APP_DISPLAY_NAME}")"
j52_json="$(identity_fleet_cluster_json "${FLEET_J52_APP_DISPLAY_NAME}")"
[[ "${j64_json}" != "null" && "${j52_json}" != "null" ]] || die "Unable to resolve both identity Fleet clusters."

active_count="$(jq -n --argjson a "${j64_json}" --argjson b "${j52_json}" '[ $a, $b ] | map(select(.metadata.labels["kmm.dev/identity-active"] == "true")) | length')"
[[ "${active_count}" == "1" ]] || die "Expected exactly one active identity site; found ${active_count}."

j64_expected="$(jq -r '.metadata.labels["kmm.dev/keycloak-instances"]' <<<"${j64_json}")"
j52_expected="$(jq -r '.metadata.labels["kmm.dev/keycloak-instances"]' <<<"${j52_json}")"
j64_hibernation="$(jq -r '.metadata.labels["kmm.dev/postgres-hibernation"]' <<<"${j64_json}")"
j52_replica_expected="$(jq -r '.metadata.labels["kmm.dev/postgres-replica-enabled"]' <<<"${j52_json}")"
j64_replication_ip="$(jq -r '.metadata.labels["kmm.dev/postgres-replication-lb-ip"]' <<<"${j64_json}")"
j52_replication_ip="$(jq -r '.metadata.labels["kmm.dev/postgres-replication-lb-ip"]' <<<"${j52_json}")"

if kubectl --context j64seg1opdev -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" >/dev/null 2>&1; then
  validate_keycloak j64seg1opdev "${j64_expected}"
  validate_keycloak_exposure j64seg1opdev "${j64_expected}"
  validate_replication_service_ip j64seg1opdev "${j64_replication_ip}"
  if [[ "${j64_hibernation}" == "on" ]]; then
    pod_count="$(kubectl --context j64seg1opdev -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${pod_count}" == "0" ]] || die "j64 is labeled hibernated but ${pod_count} PostgreSQL pod(s) remain."
  else
    [[ "$(site_sql j64seg1opdev 'select pg_is_in_recovery()')" == "f" ]] || die "j64 primary is unexpectedly in recovery."
  fi
else
  [[ "$(jq -r '.metadata.labels["kmm.dev/identity-active"]' <<<"${j64_json}")" == "false" ]] || die "j64 is unreachable but still labeled active."
  [[ "${j64_expected}" == "0" && "${j64_hibernation}" == "on" ]] || die "j64 is unreachable without persistent fence labels."
  log "j64 is unreachable; validated its Fleet fencing labels only."
fi

kubectl --context j52seg1opdev -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" >/dev/null
validate_keycloak j52seg1opdev "${j52_expected}"
validate_keycloak_exposure j52seg1opdev "${j52_expected}"
validate_replication_service_ip j52seg1opdev "${j52_replication_ip}"
secondary_enabled="$(kubectl --context j52seg1opdev -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" -o jsonpath='{.spec.replica.enabled}' 2>/dev/null || true)"
[[ "${secondary_enabled}" == "${j52_replica_expected}" ]] || die "j52: replica.enabled=${secondary_enabled}, Fleet label=${j52_replica_expected}."
in_recovery="$(site_sql j52seg1opdev 'select pg_is_in_recovery()')"

if [[ "${secondary_enabled}" == "true" ]]; then
  [[ "${in_recovery}" == "t" ]] || die "j52 is configured as a replica but PostgreSQL is writable."
else
  [[ "${in_recovery}" == "f" ]] || die "j52 is configured as promoted but PostgreSQL remains in recovery."
fi

log "Identity HA validation passed: exactly one active Keycloak site, Segment1 replication VIPs, and a consistent PostgreSQL role state."
