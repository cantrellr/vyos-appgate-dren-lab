#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"

CHECK_ONLY=false
RESTART_WORKLOADS=false
ALL_CONTEXTS=false
POSITIONAL=()

usage() {
  cat <<USAGE
Usage:
  $0 <site> <cluster> [--check] [--restart]
  $0 --all [--check] [--restart]

Pre-create and label Rancher/Fleet system namespaces with the privileged Pod
Security Admission profile required by Rancher-managed agents and controllers.

  --all      Apply to all supported kubeconfig contexts.
  --check    Validate labels without changing namespaces.
  --restart  Restart existing Rancher/Fleet Deployments after applying labels.
USAGE
}

while (($#)); do
  case "$1" in
    --all) ALL_CONTEXTS=true ;;
    --check) CHECK_ONLY=true ;;
    --restart) RESTART_WORKLOADS=true ;;
    -h|--help) usage; exit 0 ;;
    --*) die "Unknown option: $1" ;;
    *) POSITIONAL+=("$1") ;;
  esac
  shift
done

if [[ "${CHECK_ONLY}" == true && "${RESTART_WORKLOADS}" == true ]]; then
  die "--check and --restart cannot be used together."
fi

CONTEXTS=()
if [[ "${ALL_CONTEXTS}" == true ]]; then
  ((${#POSITIONAL[@]} == 0)) || die "Do not combine --all with site/cluster arguments."
  CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
else
  ((${#POSITIONAL[@]} == 2)) || { usage >&2; exit 1; }
  context="${POSITIONAL[0]}${POSITIONAL[1]}"
  validate_supported_context "${context}"
  CONTEXTS=("${context}")
fi

required_namespaces_for_context() {
  local context="$1"
  printf '%s\n' cattle-system cattle-fleet-system
  if [[ "${context}" == "j64seg1opman" ]]; then
    printf '%s\n' cattle-fleet-local-system cattle-fleet-clusters-system cattle-turtles-system
  fi
}

optional_namespaces_for_context() {
  local context="$1"
  [[ "${context}" == "j64seg1opman" ]] || return 0
  printf '%s\n' cattle-provisioning-capi-system rancher-operator-system
}

namespace_is_privileged() {
  local context="$1" namespace="$2" label="" actual=""
  for label in enforce audit warn; do
    actual="$(kubectl --context "${context}" get namespace "${namespace}" \
      -o go-template="{{ with index .metadata.labels \"pod-security.kubernetes.io/${label}\" }}{{ . }}{{ end }}")"
    [[ "${actual}" == "privileged" ]] || {
      warn "${context}: ${namespace} expected pod-security.kubernetes.io/${label}=privileged, found ${actual:-<unset>}"
      return 1
    }
  done
  for label in enforce-version audit-version warn-version; do
    actual="$(kubectl --context "${context}" get namespace "${namespace}" \
      -o go-template="{{ with index .metadata.labels \"pod-security.kubernetes.io/${label}\" }}{{ . }}{{ end }}")"
    [[ "${actual}" == "latest" ]] || {
      warn "${context}: ${namespace} expected pod-security.kubernetes.io/${label}=latest, found ${actual:-<unset>}"
      return 1
    }
  done
}

apply_namespace_profile() {
  local context="$1" namespace="$2"

  if ! kubectl --context "${context}" get namespace "${namespace}" >/dev/null 2>&1; then
    kubectl --context "${context}" create namespace "${namespace}" >/dev/null
  fi

  kubectl --context "${context}" label --overwrite namespace "${namespace}" \
    "kubernetes.io/metadata.name=${namespace}" \
    "pod-security.kubernetes.io/enforce=privileged" \
    "pod-security.kubernetes.io/enforce-version=latest" \
    "pod-security.kubernetes.io/audit=privileged" \
    "pod-security.kubernetes.io/audit-version=latest" \
    "pod-security.kubernetes.io/warn=privileged" \
    "pod-security.kubernetes.io/warn-version=latest" \
    "k8mm.dev/cis-managed=true" \
    "k8mm.dev/cis-psa-exception=true" \
    "k8mm.dev/pod-security-profile=privileged" \
    "k8mm.dev/workload-owner=rancher" >/dev/null

  kubectl --context "${context}" label --overwrite namespace "${namespace}" \
    istio.io/rev- istio-injection- \
    segment1.kmm.dev/restricted- kmm.dev/network-zone- >/dev/null 2>&1 || true
}

restart_deployment_if_present() {
  local context="$1" namespace="$2" deployment="$3"
  if ! kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" >/dev/null 2>&1; then
    return 0
  fi

  log "${context}: restarting ${namespace}/${deployment}..."
  kubectl --context "${context}" -n "${namespace}" rollout restart deployment/"${deployment}" >/dev/null
  if ! kubectl --context "${context}" -n "${namespace}" rollout status deployment/"${deployment}" \
      --timeout="${KUBECTL_TIMEOUT}" >/dev/null; then
    warn "${context}: ${namespace}/${deployment} did not become ready within ${KUBECTL_TIMEOUT}."
    return 1
  fi
}

failures=0
for context in "${CONTEXTS[@]}"; do
  validate_context_access "${context}"

  mapfile -t required_namespaces < <(required_namespaces_for_context "${context}")
  mapfile -t optional_namespaces < <(optional_namespaces_for_context "${context}")

  for namespace in "${required_namespaces[@]}"; do
    if [[ "${CHECK_ONLY}" == true ]]; then
      if ! kubectl --context "${context}" get namespace "${namespace}" >/dev/null 2>&1; then
        warn "${context}: required Rancher namespace is missing: ${namespace}"
        failures=$((failures + 1))
        continue
      fi
      if namespace_is_privileged "${context}" "${namespace}"; then
        printf '[PASS] %s/%s uses privileged PSA labels\n' "${context}" "${namespace}"
      else
        failures=$((failures + 1))
      fi
    else
      log "${context}: applying privileged PSA profile to ${namespace}..."
      apply_namespace_profile "${context}" "${namespace}"
    fi
  done

  for namespace in "${optional_namespaces[@]}"; do
    if ! kubectl --context "${context}" get namespace "${namespace}" >/dev/null 2>&1; then
      continue
    fi
    if [[ "${CHECK_ONLY}" == true ]]; then
      if namespace_is_privileged "${context}" "${namespace}"; then
        printf '[PASS] %s/%s uses privileged PSA labels\n' "${context}" "${namespace}"
      else
        failures=$((failures + 1))
      fi
    else
      log "${context}: applying privileged PSA profile to existing ${namespace}..."
      apply_namespace_profile "${context}" "${namespace}"
    fi
  done

  if [[ "${RESTART_WORKLOADS}" == true ]]; then
    restart_deployment_if_present "${context}" cattle-system cattle-cluster-agent || failures=$((failures + 1))
    restart_deployment_if_present "${context}" cattle-fleet-system fleet-agent || failures=$((failures + 1))

    if [[ "${context}" == "j64seg1opman" ]]; then
      restart_deployment_if_present "${context}" cattle-system rancher || failures=$((failures + 1))
      restart_deployment_if_present "${context}" cattle-system rancher-webhook || failures=$((failures + 1))
      restart_deployment_if_present "${context}" cattle-fleet-system fleet-controller || failures=$((failures + 1))
      restart_deployment_if_present "${context}" cattle-fleet-system gitjob || failures=$((failures + 1))
      restart_deployment_if_present "${context}" cattle-fleet-local-system fleet-agent || failures=$((failures + 1))
    fi
  fi
done

[[ "${failures}" -eq 0 ]] || die "Rancher/Fleet PSA preparation failed with ${failures} issue(s)."
if [[ "${CHECK_ONLY}" == true ]]; then
  log "Rancher/Fleet PSA namespace validation passed."
else
  log "Rancher/Fleet system namespaces now use the required privileged PSA profile."
fi
