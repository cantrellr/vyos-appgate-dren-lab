#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
FLEET_WATCHLIST_ENV_NAME="${FLEET_WATCHLIST_ENV_NAME:-KUBE_FEATURE_WatchListClient}"
FLEET_WATCHLIST_ENV_VALUE="${FLEET_WATCHLIST_ENV_VALUE:-false}"
FLEET_WATCHLIST_TIMEOUT_SECONDS="${FLEET_WATCHLIST_TIMEOUT_SECONDS:-900}"
FLEET_WATCHLIST_WRITE_RETRIES="${FLEET_WATCHLIST_WRITE_RETRIES:-20}"

MODE="management"
CHECK_ONLY=false
WAIT_FOR_RESOURCES=false
SKIP_MISSING=false

usage() {
  cat <<USAGE
Usage:
  $0 --management-only [--check] [--wait]
  $0 --all [--check] [--wait]
  $0 --existing [--check]

Configure the Fleet Kubernetes 1.35 WatchListClient compatibility workaround.
The authoritative downstream setting is written to each Fleet Cluster resource
at spec.agentEnvVars. Generated fleet-agent Deployments are then observed until
Fleet recreates/reconciles them with the expected environment setting.

  --management-only  Configure fleet-controller and the fleet-local agent.
  --all              Require and configure all four Fleet Cluster resources.
  --existing         Configure every currently present target and skip missing imports.
  --check            Validate without changing resources.
  --wait             Wait for expected Fleet resources and Deployments to appear.
USAGE
}

while (($#)); do
  case "$1" in
    --management-only) MODE="management" ;;
    --all) MODE="all" ;;
    --existing) MODE="all"; SKIP_MISSING=true ;;
    --check) CHECK_ONLY=true ;;
    --wait) WAIT_FOR_RESOURCES=true ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

require_cmd kubectl
require_cmd jq
validate_context_access "${RANCHER_CONTEXT}"

FLEET_LOCAL_CLUSTER_DISPLAY_NAME="${FLEET_LOCAL_CLUSTER_DISPLAY_NAME:-j64seg1opman}"
FLEET_J64_APP_DISPLAY_NAME="${FLEET_J64_APP_DISPLAY_NAME:-j64seg1opdev}"
FLEET_J52_APP_DISPLAY_NAME="${FLEET_J52_APP_DISPLAY_NAME:-j52seg1opdev}"
FLEET_R01_APP_DISPLAY_NAME="${FLEET_R01_APP_DISPLAY_NAME:-r01seg1opdev}"

deployment_exists() {
  local context="$1" namespace="$2" deployment="$3"
  kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" >/dev/null 2>&1
}

wait_for_deployment() {
  local context="$1" namespace="$2" deployment="$3"
  local deadline=$((SECONDS + FLEET_WATCHLIST_TIMEOUT_SECONDS))
  until deployment_exists "${context}" "${namespace}" "${deployment}"; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
}

deployment_has_workaround() {
  local context="$1" namespace="$2" deployment="$3"
  kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" -o json 2>/dev/null | jq -e \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      (.spec.template.spec.containers | length) > 0 and
      all(.spec.template.spec.containers[];
        any((.env // [])[]?; .name == $name and .value == $value)
      )
    ' >/dev/null
}

deployment_is_reconciled() {
  local context="$1" namespace="$2" deployment="$3"
  kubectl --context "${context}" -n "${namespace}" get deployment "${deployment}" -o json 2>/dev/null | jq -e \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      (.spec.template.spec.containers | length) > 0 and
      all(.spec.template.spec.containers[];
        any((.env // [])[]?; .name == $name and .value == $value)
      ) and
      ((.status.observedGeneration // 0) >= (.metadata.generation // 0)) and
      (
        ((.spec.replicas // 1) == 0) or
        (
          ((.status.updatedReplicas // 0) >= (.spec.replicas // 1)) and
          ((.status.availableReplicas // 0) >= (.spec.replicas // 1))
        )
      )
    ' >/dev/null
}

wait_for_deployment_reconciliation() {
  local context="$1" namespace="$2" deployment="$3"
  local deadline=$((SECONDS + FLEET_WATCHLIST_TIMEOUT_SECONDS))

  until deployment_is_reconciled "${context}" "${namespace}" "${deployment}"; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
}

retry_set_env() {
  local context="$1" namespace="$2" deployment="$3"
  local attempt output rc

  for ((attempt = 1; attempt <= FLEET_WATCHLIST_WRITE_RETRIES; attempt++)); do
    if output="$(kubectl --context "${context}" -n "${namespace}" set env \
      deployment/"${deployment}" --containers='*' \
      "${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}" 2>&1)"; then
      return 0
    fi
    rc=$?

    if grep -Eqi 'object has been deleted|not found|the object has been modified|conflict|unable to connect|connection reset|unexpected EOF' <<<"${output}"; then
      warn "${context}: ${namespace}/${deployment} changed during update; retrying (${attempt}/${FLEET_WATCHLIST_WRITE_RETRIES})."
      sleep 3
      continue
    fi

    printf '%s\n' "${output}" >&2
    return "${rc}"
  done

  warn "${context}: exhausted retries updating ${namespace}/${deployment}."
  return 1
}

configure_deployment() {
  local context="$1" namespace="$2" deployment="$3"

  if ! deployment_exists "${context}" "${namespace}" "${deployment}"; then
    if [[ "${WAIT_FOR_RESOURCES}" == true ]]; then
      wait_for_deployment "${context}" "${namespace}" "${deployment}" || {
        warn "${context}: timed out waiting for ${namespace}/${deployment}."
        return 1
      }
    elif [[ "${SKIP_MISSING}" == true ]]; then
      warn "${context}: skipping missing ${namespace}/${deployment}."
      return 0
    else
      warn "${context}: required Deployment is missing: ${namespace}/${deployment}"
      return 1
    fi
  fi

  if [[ "${CHECK_ONLY}" == true ]]; then
    if deployment_has_workaround "${context}" "${namespace}" "${deployment}"; then
      printf '[PASS] %s/%s/%s sets %s=%s on every container\n' \
        "${context}" "${namespace}" "${deployment}" \
        "${FLEET_WATCHLIST_ENV_NAME}" "${FLEET_WATCHLIST_ENV_VALUE}"
      return 0
    fi
    warn "${context}: ${namespace}/${deployment} does not set ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE} on every container."
    return 1
  fi

  log "${context}: configuring ${namespace}/${deployment} with ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}..."
  retry_set_env "${context}" "${namespace}" "${deployment}" || return 1

  if ! wait_for_deployment_reconciliation "${context}" "${namespace}" "${deployment}"; then
    warn "${context}: timed out waiting for ${namespace}/${deployment} to reconcile with ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}."
    return 1
  fi
}

resolve_fleet_cluster() {
  local namespace="$1" display_name="$2"
  local deadline=$((SECONDS + FLEET_WATCHLIST_TIMEOUT_SECONDS))
  local resource=""

  while true; do
    if resource="$(fleet_cluster_resource "${namespace}" "${display_name}" "${RANCHER_CONTEXT}" 2>/dev/null)"; then
      printf '%s\n' "${resource}"
      return 0
    fi
    [[ "${WAIT_FOR_RESOURCES}" == true ]] || return 1
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
}

fleet_cluster_has_workaround() {
  local namespace="$1" resource="$2"
  kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" \
    get cluster.fleet.cattle.io "${resource}" -o json | jq -e \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      any((.spec.agentEnvVars // [])[]?; .name == $name and .value == $value)
    ' >/dev/null
}

configure_fleet_cluster() {
  local namespace="$1" display_name="$2" downstream_context="$3" agent_namespace="$4"
  local resource="" cluster_json="" env_json="" patch_json=""

  if ! resource="$(resolve_fleet_cluster "${namespace}" "${display_name}")"; then
    if [[ "${SKIP_MISSING}" == true ]]; then
      warn "Skipping Fleet Cluster ${namespace}/${display_name}; it has not been created/imported yet."
      return 0
    fi
    fleet_cluster_inventory "${RANCHER_CONTEXT}"
    warn "Required Fleet Cluster is missing: ${namespace}/${display_name}"
    return 1
  fi

  if [[ "${CHECK_ONLY}" == true ]]; then
    if fleet_cluster_has_workaround "${namespace}" "${resource}"; then
      printf '[PASS] %s/%s propagates %s=%s to its Fleet agent\n' \
        "${namespace}" "${resource}" \
        "${FLEET_WATCHLIST_ENV_NAME}" "${FLEET_WATCHLIST_ENV_VALUE}"
    else
      warn "${namespace}/${resource} does not propagate ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE} through spec.agentEnvVars."
      return 1
    fi

    validate_context_access "${downstream_context}"
    configure_deployment "${downstream_context}" "${agent_namespace}" fleet-agent
    return $?
  fi

  cluster_json="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" \
    get cluster.fleet.cattle.io "${resource}" -o json)"
  env_json="$(jq -c \
    --arg name "${FLEET_WATCHLIST_ENV_NAME}" \
    --arg value "${FLEET_WATCHLIST_ENV_VALUE}" '
      ((.spec.agentEnvVars // []) | map(select(.name != $name))) +
      [{"name": $name, "value": $value}]
    ' <<<"${cluster_json}")"
  patch_json="$(jq -cn --argjson env "${env_json}" '{spec:{agentEnvVars:$env}}')"

  log "Configuring Fleet Cluster ${namespace}/${resource} to propagate ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}..."
  kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" patch \
    cluster.fleet.cattle.io "${resource}" --type=merge -p "${patch_json}" >/dev/null

  # Do not directly mutate a generated fleet-agent Deployment here. Updating
  # spec.agentEnvVars causes Fleet to replace/recreate that Deployment, and a
  # simultaneous 'kubectl set env' races the controller and can fail with
  # "object has been deleted". The Cluster CR is the source of truth; wait for
  # Fleet's reconciliation to produce a ready Deployment with the expected env.
  validate_context_access "${downstream_context}"

  if ! deployment_exists "${downstream_context}" "${agent_namespace}" fleet-agent; then
    if [[ "${WAIT_FOR_RESOURCES}" == true ]]; then
      wait_for_deployment "${downstream_context}" "${agent_namespace}" fleet-agent || {
        warn "${downstream_context}: timed out waiting for ${agent_namespace}/fleet-agent after updating ${namespace}/${resource}."
        return 1
      }
    elif [[ "${SKIP_MISSING}" == true ]]; then
      warn "${downstream_context}: Fleet Cluster was updated, but ${agent_namespace}/fleet-agent is not present yet; skipping runtime wait."
      return 0
    else
      warn "${downstream_context}: required Deployment is missing: ${agent_namespace}/fleet-agent"
      return 1
    fi
  fi

  log "${downstream_context}: waiting for Fleet to reconcile ${agent_namespace}/fleet-agent..."
  if ! wait_for_deployment_reconciliation "${downstream_context}" "${agent_namespace}" fleet-agent; then
    warn "${downstream_context}: timed out waiting for ${agent_namespace}/fleet-agent to reconcile with ${FLEET_WATCHLIST_ENV_NAME}=${FLEET_WATCHLIST_ENV_VALUE}."
    return 1
  fi

  printf '[PASS] %s/%s/fleet-agent reconciled with %s=%s\n' \
    "${downstream_context}" "${agent_namespace}" \
    "${FLEET_WATCHLIST_ENV_NAME}" "${FLEET_WATCHLIST_ENV_VALUE}"
}

failures=0

configure_deployment "${RANCHER_CONTEXT}" cattle-fleet-system fleet-controller || failures=$((failures + 1))
configure_fleet_cluster fleet-local "${FLEET_LOCAL_CLUSTER_DISPLAY_NAME}" j64seg1opman cattle-fleet-local-system || failures=$((failures + 1))

if [[ "${MODE}" == "all" ]]; then
  configure_fleet_cluster fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" j64seg1opdev cattle-fleet-system || failures=$((failures + 1))
  configure_fleet_cluster fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" j52seg1opdev cattle-fleet-system || failures=$((failures + 1))
  configure_fleet_cluster fleet-default "${FLEET_R01_APP_DISPLAY_NAME}" r01seg1opdev cattle-fleet-system || failures=$((failures + 1))
fi

(( failures == 0 )) || die "Fleet WatchListClient compatibility configuration failed with ${failures} issue(s)."
if [[ "${CHECK_ONLY}" == true ]]; then
  log "Fleet WatchListClient compatibility validation passed."
else
  log "Fleet controllers and agents are configured to use standard List+Watch behavior."
fi
