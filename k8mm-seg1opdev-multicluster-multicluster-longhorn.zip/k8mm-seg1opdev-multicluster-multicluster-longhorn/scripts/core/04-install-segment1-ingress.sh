#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"

NAMESPACE="segment1"
RELEASE="${CONTOUR_SEGMENT1_RELEASE:-ingress-segment1}"
CHART="contour-21.1.4.tgz"
OPTIONS="$(site_cluster_options_dir "${SITE}" "${CLUSTER}")"
case "${K8_CONTEXT}" in
  j64seg1opman) VALUES="ingress-j64manager-seg1-values-v5.yaml" ;;
  j64seg1opdev) VALUES="ingress-j64domain-seg1-values-v5.yaml" ;;
  j52seg1opdev) VALUES="ingress-j52domain-seg1-values-v5.yaml" ;;
  r01seg1opdev) VALUES="ingress-r01domain-seg1-values-v5.yaml" ;;
esac

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

ensure_dir "${OPTIONS}"
ensure_file "${OPTIONS}/values/${VALUES}"
ensure_chart_package "${HELM_PACKAGES_DIR}/${CHART}"

log "Creating restricted CIS/PSA namespace ${NAMESPACE}..."
ensure_cis_namespace "${NAMESPACE}" true restricted
label_restricted_namespace "${NAMESPACE}"
ensure_registry_secret "${NAMESPACE}"

log "Installing ${RELEASE} from ${REGISTRY_HOST} image sources..."
helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${OPTIONS}/values/${VALUES}"

log "Waiting for ${RELEASE} to be ready..."
wait_for_deployment_available "${NAMESPACE}" "${NAMESPACE}-contour"

log "Applying restricted Segment1 NetworkPolicy package..."
apply_segment1_network_policies "${NAMESPACE}"

log "${RELEASE} installed with restricted Pod Security Admission and restricted-domain NetworkPolicy posture."
