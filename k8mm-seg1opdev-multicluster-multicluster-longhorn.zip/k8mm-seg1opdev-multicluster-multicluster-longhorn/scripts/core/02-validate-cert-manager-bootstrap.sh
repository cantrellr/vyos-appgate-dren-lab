#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"

NAMESPACE="cert-manager"
RELEASE="onprem-cert-manager"
ISSUER="segment1-ca-clusterissuer"
CA_SECRET="segment1-ca-bundle-secret"
REQUIRED_CRDS=(
  clusterissuers.cert-manager.io
  issuers.cert-manager.io
  certificates.cert-manager.io
  certificaterequests.cert-manager.io
  orders.acme.cert-manager.io
  challenges.acme.cert-manager.io
)

require_kubernetes_tools
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

dump_cert_manager_diagnostics() {
  local rc="$1"
  warn "cert-manager bootstrap contract validation failed on ${K8_CONTEXT}; collecting diagnostics."
  helm -n "${NAMESPACE}" status "${RELEASE}" 2>/dev/null || true
  kubectl -n "${NAMESPACE}" get deployment,pod,service,endpointslice -o wide 2>/dev/null || true
  kubectl get crd "${REQUIRED_CRDS[@]}" 2>/dev/null || true
  kubectl get clusterissuer "${ISSUER}" -o yaml 2>/dev/null || true
  kubectl -n "${NAMESPACE}" get events --sort-by='.lastTimestamp' 2>/dev/null | tail -60 || true
  return "${rc}"
}
trap 'rc=$?; dump_cert_manager_diagnostics "${rc}"; exit "${rc}"' ERR

log "Validating bootstrap-owned cert-manager contract on ${K8_CONTEXT}..."
helm -n "${NAMESPACE}" status "${RELEASE}" >/dev/null

for deployment in \
  "${RELEASE}-controller" \
  "${RELEASE}-cainjector" \
  "${RELEASE}-webhook"
do
  wait_for_deployment_available "${NAMESPACE}" "${deployment}" "${KUBECTL_TIMEOUT}"
done

for crd in "${REQUIRED_CRDS[@]}"; do
  kubectl wait \
    --for=condition=Established \
    --timeout="${KUBECTL_TIMEOUT}" \
    "crd/${crd}" >/dev/null
done

kubectl -n "${NAMESPACE}" get secret "${CA_SECRET}" >/dev/null
kubectl get clusterissuer "${ISSUER}" >/dev/null
kubectl wait \
  --for=condition=Ready \
  --timeout="${KUBECTL_TIMEOUT}" \
  "clusterissuer/${ISSUER}" >/dev/null

trap - ERR
log "Bootstrap-owned cert-manager release, CRDs, CA Secret, webhook, and ClusterIssuer are ready on ${K8_CONTEXT}."
