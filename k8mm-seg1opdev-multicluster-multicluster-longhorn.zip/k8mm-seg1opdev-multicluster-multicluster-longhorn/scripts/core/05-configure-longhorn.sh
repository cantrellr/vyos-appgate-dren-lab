#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"
NAMESPACE="longhorn-system"

require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
kubectl get namespace "${NAMESPACE}" >/dev/null 2>&1   || die "Namespace ${NAMESPACE} does not exist. Run 04-install-longhorn.sh first."
require_crd settings.longhorn.io

apply_file "${YAML_DIR}/resources/longhorn-storageclasses-v1.yaml"
apply_file "${YAML_DIR}/resources/longhorn-snapshot-policy-v1.yaml"
log "Longhorn storage classes and recurring snapshot policy configured."
