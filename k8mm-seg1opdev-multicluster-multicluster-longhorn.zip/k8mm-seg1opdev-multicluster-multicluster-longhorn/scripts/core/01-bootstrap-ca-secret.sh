#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"
init_site_cluster "$@"

: "${CA_CERT_FILE:?Set CA_CERT_FILE to the PEM CA certificate}"
: "${CA_KEY_FILE:?Set CA_KEY_FILE to the matching PEM private key}"
ensure_file "${CA_CERT_FILE}"
ensure_file "${CA_KEY_FILE}"
require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace cert-manager true restricted

kubectl -n cert-manager create secret tls segment1-ca-bundle-secret \
  --cert="${CA_CERT_FILE}" \
  --key="${CA_KEY_FILE}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

log "Runtime Segment1 CA signing secret created for ${K8_CONTEXT}. No private key was written to the repository."
