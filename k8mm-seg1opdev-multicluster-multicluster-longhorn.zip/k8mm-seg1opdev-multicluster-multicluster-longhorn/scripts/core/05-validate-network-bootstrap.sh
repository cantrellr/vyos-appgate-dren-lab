#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"

METALLB_NAMESPACE="metallb-system"
METALLB_RELEASE="metallb"
METALLB_CONTROLLER="metallb-controller"
METALLB_POOL="segment1"
METALLB_L2="platform"
CONTOUR_NAMESPACE="segment1"
CONTOUR_RELEASE="${CONTOUR_SEGMENT1_RELEASE:-ingress-segment1}"
CONTOUR_DEPLOYMENT="segment1-contour"
CONTOUR_SERVICE="segment1-envoy"
REQUIRED_METALLB_CRDS=(
  ipaddresspools.metallb.io
  l2advertisements.metallb.io
)

case "${K8_CONTEXT}" in
  j64seg1opman)
    EXPECTED_POOL="1.0.0.201-1.0.0.210"
    EXPECTED_LB_IP="1.0.0.205"
    ;;
  j64seg1opdev)
    EXPECTED_POOL="1.0.0.211-1.0.0.220"
    EXPECTED_LB_IP="1.0.0.215"
    ;;
  j52seg1opdev)
    EXPECTED_POOL="1.0.0.221-1.0.0.230"
    EXPECTED_LB_IP="1.0.0.225"
    ;;
  r01seg1opdev)
    EXPECTED_POOL="1.0.0.231-1.0.0.240"
    EXPECTED_LB_IP="1.0.0.235"
    ;;
  *)
    die "No Segment1 bootstrap network contract is defined for ${K8_CONTEXT}."
    ;;
esac

require_kubernetes_tools
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

network_bootstrap_diagnostics() {
  local rc="$1"
  warn "Bootstrap network contract validation failed on ${K8_CONTEXT}; collecting diagnostics."
  helm -n "${METALLB_NAMESPACE}" status "${METALLB_RELEASE}" 2>/dev/null || true
  kubectl -n "${METALLB_NAMESPACE}" get deployment,daemonset,pod,service -o wide 2>/dev/null || true
  kubectl get crd "${REQUIRED_METALLB_CRDS[@]}" 2>/dev/null || true
  kubectl -n "${METALLB_NAMESPACE}" get ipaddresspool "${METALLB_POOL}" -o yaml 2>/dev/null || true
  kubectl -n "${METALLB_NAMESPACE}" get l2advertisement "${METALLB_L2}" -o yaml 2>/dev/null || true
  helm -n "${CONTOUR_NAMESPACE}" status "${CONTOUR_RELEASE}" 2>/dev/null || true
  kubectl -n "${CONTOUR_NAMESPACE}" get deployment,daemonset,pod,service -o wide 2>/dev/null || true
  kubectl -n "${METALLB_NAMESPACE}" get events --sort-by='.lastTimestamp' 2>/dev/null | tail -50 || true
  kubectl -n "${CONTOUR_NAMESPACE}" get events --sort-by='.lastTimestamp' 2>/dev/null | tail -50 || true
  return "${rc}"
}
trap 'rc=$?; network_bootstrap_diagnostics "${rc}"; exit "${rc}"' ERR

log "Validating bootstrap-owned MetalLB and Segment1 Contour contracts on ${K8_CONTEXT}..."
helm -n "${METALLB_NAMESPACE}" status "${METALLB_RELEASE}" >/dev/null
wait_for_deployment_available "${METALLB_NAMESPACE}" "${METALLB_CONTROLLER}" "${KUBECTL_TIMEOUT}"
for crd in "${REQUIRED_METALLB_CRDS[@]}"; do
  kubectl wait --for=condition=Established --timeout="${KUBECTL_TIMEOUT}" "crd/${crd}" >/dev/null
done

actual_pool="$(kubectl -n "${METALLB_NAMESPACE}" get ipaddresspool "${METALLB_POOL}" -o jsonpath='{.spec.addresses[*]}')"
[[ " ${actual_pool} " == *" ${EXPECTED_POOL} "* ]] || \
  die "MetalLB pool ${METALLB_POOL} on ${K8_CONTEXT} does not contain expected range ${EXPECTED_POOL}; found: ${actual_pool:-<empty>}"
actual_l2_pools="$(kubectl -n "${METALLB_NAMESPACE}" get l2advertisement "${METALLB_L2}" -o jsonpath='{.spec.ipAddressPools[*]}')"
[[ " ${actual_l2_pools} " == *" ${METALLB_POOL} "* ]] || \
  die "MetalLB L2Advertisement ${METALLB_L2} does not reference pool ${METALLB_POOL}."

helm -n "${CONTOUR_NAMESPACE}" status "${CONTOUR_RELEASE}" >/dev/null
wait_for_deployment_available "${CONTOUR_NAMESPACE}" "${CONTOUR_DEPLOYMENT}" "${KUBECTL_TIMEOUT}"
actual_service_type="$(kubectl -n "${CONTOUR_NAMESPACE}" get service "${CONTOUR_SERVICE}" -o jsonpath='{.spec.type}')"
[[ "${actual_service_type}" == "LoadBalancer" ]] || \
  die "${CONTOUR_NAMESPACE}/${CONTOUR_SERVICE} must be type LoadBalancer; found ${actual_service_type:-<empty>}"
actual_lb_ip="$(kubectl -n "${CONTOUR_NAMESPACE}" get service "${CONTOUR_SERVICE}" -o jsonpath='{.spec.loadBalancerIP}')"
[[ "${actual_lb_ip}" == "${EXPECTED_LB_IP}" ]] || \
  die "${CONTOUR_NAMESPACE}/${CONTOUR_SERVICE} must request ${EXPECTED_LB_IP}; found ${actual_lb_ip:-<empty>}"

trap - ERR
log "Bootstrap-owned MetalLB release/config and Segment1 Contour release are ready on ${K8_CONTEXT}."
