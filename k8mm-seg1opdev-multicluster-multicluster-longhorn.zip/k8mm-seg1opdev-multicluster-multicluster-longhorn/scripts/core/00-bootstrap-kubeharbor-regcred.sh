#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

usage() {
  cat <<USAGE
Usage: $0 <site> <cluster> [options]

Creates or updates the secure registry pull secret used by this repo.

Arguments:
  <site>      Site prefix, example: j64
  <cluster>   Cluster suffix, example: seg1opdev

Options:
  --sync-default-namespaces   Copy the secret into known platform namespaces if they already exist
  --sync-existing-namespaces  Copy the secret into every existing namespace except kube-public/kube-node-lease
  --namespace <name>          Also copy the secret into a specific namespace; may be used multiple times
  -h, --help                  Show this help

Environment overrides:
  REGISTRY_HOST               Default: kubeharbor.dev.kube
  REGISTRY_SECRET             Default: regcred-kubeharbor
  REGISTRY_USERNAME           Username for the registry
  REGISTRY_PASSWORD           Password/token for the registry

Examples:
  $0 j64 seg1opdev
  $0 j64 seg1opdev --sync-default-namespaces
  REGISTRY_USERNAME=robot\$kmm REGISTRY_PASSWORD='...' $0 j64 seg1opdev --sync-existing-namespaces
USAGE
}

if [[ $# -lt 2 ]]; then
  usage >&2
  exit 2
fi

SITE="$1"
CLUSTER="$2"
shift 2
K8_CONTEXT="${SITE}${CLUSTER}"
validate_supported_context "${K8_CONTEXT}"
SYNC_DEFAULT_NAMESPACES=false
SYNC_EXISTING_NAMESPACES=false
declare -a EXTRA_NAMESPACES=()

declare -a DEFAULT_NAMESPACES=(
  cert-manager
  metallb-system
  segment1
  longhorn-system
  istio-system
  cattle-system
  cattle-fleet-system
  cattle-fleet-local-system
  cattle-fleet-clusters-system
  cattle-provisioning-capi-system
  cattle-turtles-system
  fleet-local
  fleet-default
)

while [[ $# -gt 0 ]]; do
  case "$1" in
    --sync-default-namespaces)
      SYNC_DEFAULT_NAMESPACES=true
      shift
      ;;
    --sync-existing-namespaces)
      SYNC_EXISTING_NAMESPACES=true
      shift
      ;;
    --namespace)
      [[ $# -ge 2 ]] || die "--namespace requires a value"
      EXTRA_NAMESPACES+=("$2")
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      die "Unknown option: $1"
      ;;
  esac
done

require_cmd kubectl
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_namespace "${REGISTRY_SOURCE_NAMESPACE}"

if [[ -z "${REGISTRY_USERNAME:-}" ]]; then
  read -r -p "KubeHarbor username for ${REGISTRY_HOST}: " REGISTRY_USERNAME
fi
if [[ -z "${REGISTRY_PASSWORD:-}" ]]; then
  read -r -s -p "KubeHarbor password/token for ${REGISTRY_USERNAME}@${REGISTRY_HOST}: " REGISTRY_PASSWORD
  echo
fi
[[ -n "${REGISTRY_USERNAME}" ]] || die "REGISTRY_USERNAME cannot be empty."
[[ -n "${REGISTRY_PASSWORD}" ]] || die "REGISTRY_PASSWORD cannot be empty."

log "Creating/updating ${REGISTRY_SOURCE_NAMESPACE}/${REGISTRY_SECRET} for registry ${REGISTRY_HOST}..."
kubectl create secret docker-registry "${REGISTRY_SECRET}" \
  --docker-server="${REGISTRY_HOST}" \
  --docker-username="${REGISTRY_USERNAME}" \
  --docker-password="${REGISTRY_PASSWORD}" \
  --namespace "${REGISTRY_SOURCE_NAMESPACE}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

sync_if_exists() {
  local namespace="$1"
  if kubectl get namespace "${namespace}" >/dev/null 2>&1; then
    ensure_registry_secret "${namespace}"
  else
    warn "Namespace ${namespace} does not exist yet; skipping registry secret sync."
  fi
}

if [[ "${SYNC_DEFAULT_NAMESPACES}" == "true" ]]; then
  for namespace in "${DEFAULT_NAMESPACES[@]}"; do
    sync_if_exists "${namespace}"
  done
fi
if [[ "${SYNC_EXISTING_NAMESPACES}" == "true" ]]; then
  mapfile -t EXISTING_NAMESPACES < <(
    kubectl get namespaces -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' |
      grep -Ev '^(kube-public|kube-node-lease)$'
  )
  for namespace in "${EXISTING_NAMESPACES[@]}"; do
    sync_if_exists "${namespace}"
  done
fi
for namespace in "${EXTRA_NAMESPACES[@]}"; do
  sync_if_exists "${namespace}"
done
log "KubeHarbor registry pull secret bootstrap completed for ${K8_CONTEXT}."
