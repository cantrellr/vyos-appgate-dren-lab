#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"
OPTIONS="$(site_cluster_options_dir "${SITE}" "${CLUSTER}")"
CHECK_SCRIPT="check-istio-multicluster-config-v2.sh"

require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_file "${OPTIONS}/resources/${CHECK_SCRIPT}"

log "Running Istio multicluster verification script..."
bash "${OPTIONS}/resources/${CHECK_SCRIPT}"

log "Istio configured."
