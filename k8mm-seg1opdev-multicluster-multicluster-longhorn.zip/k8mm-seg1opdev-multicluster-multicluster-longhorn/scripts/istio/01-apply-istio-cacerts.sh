#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
init_site_cluster "$@"
require_kubectl; validate_context_access "$K8_CONTEXT"; use_context "$K8_CONTEXT"
CERT_DIR="${ISTIO_CACERTS_DIR}/${K8_CONTEXT}"
for f in ca-cert.pem ca-key.pem root-cert.pem cert-chain.pem; do ensure_file "${CERT_DIR}/${f}"; done
ensure_namespace istio-system true
kubectl -n istio-system create secret generic cacerts \
  --from-file=ca-cert.pem="${CERT_DIR}/ca-cert.pem" \
  --from-file=ca-key.pem="${CERT_DIR}/ca-key.pem" \
  --from-file=root-cert.pem="${CERT_DIR}/root-cert.pem" \
  --from-file=cert-chain.pem="${CERT_DIR}/cert-chain.pem" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null
log "Applied runtime Istio cacerts for $K8_CONTEXT from $CERT_DIR"
