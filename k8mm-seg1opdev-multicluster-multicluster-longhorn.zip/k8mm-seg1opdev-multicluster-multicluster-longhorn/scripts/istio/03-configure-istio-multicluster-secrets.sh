#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"
NAMESPACE="istio-system"
CLUSTERS=(j64seg1opman j64seg1opdev j52seg1opdev r01seg1opdev)

require_kubectl
require_cmd istioctl
validate_context_access "${K8_CONTEXT}"
[[ "${K8_CONTEXT}" == "j64seg1opman" ]] || die "Run multicluster secret orchestration from j64seg1opman."

log "Creating and labeling ${NAMESPACE} on each cluster..."
for cluster in "${CLUSTERS[@]}"; do
  validate_context_access "${cluster}"
  use_context "${cluster}"
  ensure_namespace "${NAMESPACE}" true
  kubectl label --overwrite namespace "${NAMESPACE}" topology.istio.io/network="${cluster}-net1" >/dev/null
 done

log "Creating Istio remote secrets between clusters..."
for source_cluster in "${CLUSTERS[@]}"; do
  for target_cluster in "${CLUSTERS[@]}"; do
    [[ "${source_cluster}" == "${target_cluster}" ]] && continue
    istioctl create-remote-secret --context "${source_cluster}" --name="${source_cluster}" \
      | kubectl apply -f - --context "${target_cluster}"
  done
done

log "Istio remote secret inventory:"
for cluster in "${CLUSTERS[@]}"; do
  kubectl get secret --namespace "${NAMESPACE}" --context "${cluster}"
done

log "Istio secrets configured."
