#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"

if [[ "${1:-}" == "--all" ]]; then
  shift
  for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do
    "${BASH_SOURCE[0]}" "${context:0:3}" "${context:3}" "$@"
  done
  exit 0
fi

usage() {
  cat >&2 <<USAGE
Usage: $0 <site> <cluster> [--audit|--enforce] [--strict-missing]
       $0 --all [--audit|--enforce] [--strict-missing]
Example: $0 j64 seg1opman --enforce

Audits or enforces the repo namespace sidecar injection contract for the selected cluster.
Default mode is --audit. Missing namespaces are skipped unless --strict-missing is set.
USAGE
}

if [[ "$#" -lt 2 ]]; then
  usage
  exit 2
fi

SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"
shift 2

MODE="audit"
STRICT_MISSING="false"
ISTIO_REV="${ISTIO_REV:-stable}"
ISTIOD_DEPLOYMENT="${ISTIOD_DEPLOYMENT:-istiod-${ISTIO_REV}}"
INJECTOR_WEBHOOK="${INJECTOR_WEBHOOK:-istio-sidecar-injector-${ISTIO_REV}}"
FAILURES=0
WARNINGS=0

# Central namespace sidecar contract.
#
# Mesh-enabled namespaces should receive revisioned sidecars using istio.io/rev.
# echotest is temporary and may not exist until validation runs.
MESH_ENABLED_NAMESPACES=()

# Platform/control namespaces should stay outside the sidecar mesh unless the
# architecture is intentionally redesigned for mesh membership.
MESH_DISABLED_NAMESPACES=(
  cattle-system
  cert-manager
  elastic-agent-system
  elastic-monitoring
  istio-system
  kube-system
  metallb-system
  opkeycloak
  oppostgres
  segment1
  longhorn-system
  longhorn-system
)

for arg in "$@"; do
  case "${arg}" in
    --audit)
      MODE="audit"
      ;;
    --enforce)
      MODE="enforce"
      ;;
    --strict-missing)
      STRICT_MISSING="true"
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage
      die "Unknown argument: ${arg}"
      ;;
  esac
done

require_cmd kubectl
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

record_failure() {
  warn "$*"
  FAILURES=$((FAILURES + 1))
}

record_warning() {
  warn "$*"
  WARNINGS=$((WARNINGS + 1))
}

namespace_exists() {
  local namespace="$1"
  kubectl get namespace "${namespace}" >/dev/null 2>&1
}

namespace_json() {
  local namespace="$1"
  kubectl get namespace "${namespace}" -o json
}

label_value() {
  local namespace="$1"
  local label_key="$2"
  namespace_json "${namespace}" | jq -r --arg key "${label_key}" '.metadata.labels[$key] // ""'
}

handle_missing_namespace() {
  local namespace="$1"
  local desired="$2"

  if [[ "${STRICT_MISSING}" == "true" ]]; then
    record_failure "Namespace ${namespace} is missing; expected contract state: ${desired}."
  else
    log "Namespace ${namespace} is not present; skipping ${desired} contract check."
  fi
}

validate_istio_revision_available_if_needed() {
  local mesh_namespace_present="false"
  local namespace=""

  for namespace in "${MESH_ENABLED_NAMESPACES[@]}"; do
    if namespace_exists "${namespace}"; then
      mesh_namespace_present="true"
      break
    fi
  done

  [[ "${mesh_namespace_present}" == "true" ]] || return 0

  log "Validating Istio revision ${ISTIO_REV} is available for mesh-enabled namespaces..."
  kubectl -n istio-system get deployment "${ISTIOD_DEPLOYMENT}" >/dev/null 2>&1 \
    || record_failure "Missing istio-system/${ISTIOD_DEPLOYMENT}; mesh-enabled namespaces cannot receive working sidecars."
  kubectl get mutatingwebhookconfiguration "${INJECTOR_WEBHOOK}" >/dev/null 2>&1 \
    || record_failure "Missing MutatingWebhookConfiguration ${INJECTOR_WEBHOOK}; istio.io/rev=${ISTIO_REV} namespaces will not receive sidecars."
}

enforce_mesh_enabled_namespace() {
  local namespace="$1"

  log "Enforcing mesh-enabled labels on namespace ${namespace}..."
  kubectl label --overwrite namespace "${namespace}" \
    istio.io/rev="${ISTIO_REV}" \
    kmm.dev/istio-injection="enabled" >/dev/null
  kubectl label namespace "${namespace}" istio-injection- --overwrite >/dev/null 2>&1 || true
}

enforce_mesh_disabled_namespace() {
  local namespace="$1"

  log "Enforcing mesh-disabled labels on namespace ${namespace}..."
  kubectl label namespace "${namespace}" istio.io/rev- --overwrite >/dev/null 2>&1 || true
  kubectl label namespace "${namespace}" istio-injection- --overwrite >/dev/null 2>&1 || true
  kubectl label --overwrite namespace "${namespace}" kmm.dev/istio-injection="disabled" >/dev/null
}

audit_mesh_enabled_namespace() {
  local namespace="$1"
  local rev=""
  local legacy=""
  local contract=""

  if ! namespace_exists "${namespace}"; then
    handle_missing_namespace "${namespace}" "mesh-enabled"
    return 0
  fi

  if [[ "${MODE}" == "enforce" ]]; then
    enforce_mesh_enabled_namespace "${namespace}"
  fi

  rev="$(label_value "${namespace}" "istio.io/rev")"
  legacy="$(label_value "${namespace}" "istio-injection")"
  contract="$(label_value "${namespace}" "kmm.dev/istio-injection")"

  [[ "${rev}" == "${ISTIO_REV}" ]] \
    || record_failure "Namespace ${namespace} should be mesh-enabled with istio.io/rev=${ISTIO_REV}, current value is ${rev:-<unset>}."
  [[ -z "${legacy}" ]] \
    || record_failure "Namespace ${namespace} should not use legacy istio-injection=${legacy}; revisioned injection requires istio.io/rev=${ISTIO_REV}."
  [[ "${contract}" == "enabled" ]] \
    || record_failure "Namespace ${namespace} should have kmm.dev/istio-injection=enabled, current value is ${contract:-<unset>}."
}

audit_mesh_disabled_namespace() {
  local namespace="$1"
  local rev=""
  local legacy=""
  local contract=""

  if ! namespace_exists "${namespace}"; then
    handle_missing_namespace "${namespace}" "mesh-disabled"
    return 0
  fi

  if [[ "${MODE}" == "enforce" ]]; then
    enforce_mesh_disabled_namespace "${namespace}"
  fi

  rev="$(label_value "${namespace}" "istio.io/rev")"
  legacy="$(label_value "${namespace}" "istio-injection")"
  contract="$(label_value "${namespace}" "kmm.dev/istio-injection")"

  [[ -z "${rev}" ]] \
    || record_failure "Namespace ${namespace} should be mesh-disabled but has istio.io/rev=${rev}."
  [[ -z "${legacy}" ]] \
    || record_failure "Namespace ${namespace} should be mesh-disabled but has legacy istio-injection=${legacy}."
  [[ "${contract}" == "disabled" ]] \
    || record_failure "Namespace ${namespace} should have kmm.dev/istio-injection=disabled, current value is ${contract:-<unset>}."
}

log "Running Istio namespace injection contract in ${MODE} mode for context ${K8_CONTEXT}..."

validate_istio_revision_available_if_needed

for namespace in "${MESH_ENABLED_NAMESPACES[@]}"; do
  audit_mesh_enabled_namespace "${namespace}"
done

for namespace in "${MESH_DISABLED_NAMESPACES[@]}"; do
  audit_mesh_disabled_namespace "${namespace}"
done

if [[ "${FAILURES}" -gt 0 ]]; then
  die "Istio namespace injection contract failed with ${FAILURES} issue(s) and ${WARNINGS} warning(s)."
fi

log "Istio namespace injection contract passed for ${K8_CONTEXT} with ${WARNINGS} warning(s)."
