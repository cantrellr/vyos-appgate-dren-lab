#!/usr/bin/env bash
# shellcheck shell=bash

load_kmm_runtime_config() {
  local config_file="${1:?runtime config path is required}"
  [[ -f "${config_file}" ]] || die "Runtime config not found: ${config_file}"

  local mode
  mode="$(stat -c '%a' "${config_file}")"
  (( (8#${mode} & 8#077) == 0 )) || die "Runtime config must not be group/world accessible: ${config_file} (mode ${mode})"

  set -a
  # shellcheck disable=SC1090
  source "${config_file}"
  set +a
}

read_required_secret_file() {
  local variable_name="${1:?variable name is required}"
  local path="${!variable_name:-}"
  [[ -n "${path}" ]] || die "Set ${variable_name} in the runtime config."
  [[ -f "${path}" ]] || die "Secret file referenced by ${variable_name} does not exist: ${path}"
  [[ -s "${path}" ]] || die "Secret file referenced by ${variable_name} is empty: ${path}"
  cat "${path}"
}

require_runtime_file() {
  local variable_name="${1:?variable name is required}"
  local path="${!variable_name:-}"
  [[ -n "${path}" ]] || die "Set ${variable_name} in the runtime config."
  ensure_file "${path}"
}
