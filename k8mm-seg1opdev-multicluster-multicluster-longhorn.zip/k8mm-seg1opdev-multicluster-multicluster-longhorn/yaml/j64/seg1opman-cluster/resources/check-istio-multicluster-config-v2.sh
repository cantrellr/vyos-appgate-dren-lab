#!/usr/bin/env bash
# shellcheck shell=bash
set -Eeuo pipefail

# Validate Istio multicluster service discovery and east-west failover by:
#   1. preparing an Istio-injected test namespace on each cluster,
#   2. deploying one echo server per cluster behind the same Service name,
#   3. deploying a curl client in the primary workload cluster,
#   4. proving traffic still succeeds when the local echo backend is scaled to 0,
#   5. inspecting the sidecar for remote 15443 east-west endpoints/clusters.
#
# This script intentionally remains in the site resource tree because the default
# context matrix is specific to the SEG1 OPDEV four-cluster topology.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../../../.." && pwd)"
DEFAULT_COMMON_SH="${REPO_ROOT}/scripts/_lib/common.sh"
COMMON_SH="${KMM_COMMON_SH:-${DEFAULT_COMMON_SH}}"

if [[ ! -f "${COMMON_SH}" ]]; then
  echo "ERROR: Unable to locate common.sh at: ${COMMON_SH}" >&2
  echo "Expected default location: repo-root/scripts/_lib/common.sh" >&2
  echo "Set KMM_COMMON_SH to override the common library path." >&2
  exit 1
fi

# common.sh sets and exports KMM_COMMON_SH_LOADED. If a parent shell sourced
# common.sh and then launched this script, the environment variable can be
# inherited without the shell functions. Clear the guard in that case so the
# library actually defines require_cmd/log/die in this process.
if [[ -n "${KMM_COMMON_SH_LOADED:-}" ]] && ! declare -F require_cmd >/dev/null 2>&1; then
  unset KMM_COMMON_SH_LOADED
fi

# shellcheck source=../../../../scripts/_lib/common.sh
source "${COMMON_SH}"

if ! declare -F require_cmd >/dev/null 2>&1; then
  echo "ERROR: common.sh was sourced from ${COMMON_SH}, but require_cmd is still not defined." >&2
  echo "Check for an inherited KMM_COMMON_SH_LOADED value or unexpected shell execution mode." >&2
  exit 1
fi

require_cmd kubectl
require_cmd jq
require_cmd istioctl

export MDB_GKE_PROJECT="${MDB_GKE_PROJECT:-preprod}"
export K8S_MANAGEMENT_CLUSTER="${K8S_MANAGEMENT_CLUSTER:-j64seg1opman}"
export K8S_CLUSTER_0="${K8S_CLUSTER_0:-j64seg1opdev}"
export K8S_CLUSTER_1="${K8S_CLUSTER_1:-j52seg1opdev}"
export K8S_CLUSTER_2="${K8S_CLUSTER_2:-r01seg1opdev}"
export K8S_TEST_NAMESPACE="${K8S_TEST_NAMESPACE:-echotest}"

ISTIO_REV="${ISTIO_REV:-stable}"
WAIT_TIMEOUT="${KMM_ISTIO_CHECK_TIMEOUT:-180s}"
ECHO_IMAGE="${KMM_ECHOSERVER_IMAGE:-${REGISTRY_HOST}/corelab/echoserver:1.10}"
CURL_IMAGE="${KMM_CURL_IMAGE:-${REGISTRY_HOST}/curlimages/curl:8.8.0}"
CLIENT_CONTEXT="${KMM_ISTIO_CHECK_CLIENT_CONTEXT:-${K8S_CLUSTER_0}}"
CLIENT_STATEFULSET="${KMM_ISTIO_CHECK_CLIENT_STATEFULSET:-echoserver1}"
CLIENT_DEPLOYMENT="${KMM_ISTIO_CHECK_CLIENT_DEPLOYMENT:-sleep}"
PROXY_CONFIG_RETRIES="${KMM_ISTIO_PROXY_CONFIG_RETRIES:-3}"
PROXY_CONFIG_RETRY_SLEEP="${KMM_ISTIO_PROXY_CONFIG_RETRY_SLEEP:-5}"
CHECK_RUN_ID="${KMM_ISTIO_CHECK_RUN_ID:-$(date +%s)}"

contexts=("${K8S_MANAGEMENT_CLUSTER}" "${K8S_CLUSTER_0}" "${K8S_CLUSTER_1}" "${K8S_CLUSTER_2}")

istiod_deployment_name() {
  [[ -n "${ISTIO_REV}" ]] && printf 'istiod-%s' "${ISTIO_REV}" || printf 'istiod'
}

injector_webhook_name() {
  [[ -n "${ISTIO_REV}" ]] && printf 'istio-sidecar-injector-%s' "${ISTIO_REV}" || printf 'istio-sidecar-injector'
}

validate_istio_ready_for_revision() {
  local ctx="$1"
  local istiod="$(istiod_deployment_name)"
  local webhook="$(injector_webhook_name)"

  kubectl --context "${ctx}" -n istio-system get deploy "${istiod}" >/dev/null 2>&1 \
    || die "Context ${ctx} is missing istio-system/${istiod}. Re-run scripts/istio/02-install-istio-system.sh."
  kubectl --context "${ctx}" -n istio-system rollout status deploy/"${istiod}" --timeout="${WAIT_TIMEOUT}" >/dev/null
  kubectl --context "${ctx}" get mutatingwebhookconfiguration "${webhook}" >/dev/null 2>&1 \
    || die "Context ${ctx} is missing ${webhook}. Pods in namespaces labeled istio.io/rev=${ISTIO_REV:-default} will not receive istio-proxy."
}

validate_contexts() {
  local ctx=""

  log "Validating Kubernetes context access for Istio multicluster check..."
  for ctx in "${contexts[@]}"; do
    validate_context_access "${ctx}"
    kubectl --context "${ctx}" get namespace istio-system >/dev/null 2>&1 \
      || die "Context ${ctx} does not have an istio-system namespace. Install Istio before running this check."
    validate_istio_ready_for_revision "${ctx}"
  done
}

reset_test_workloads() {
  local ctx="$1"
  local idx=""

  log "Removing stale ${K8S_TEST_NAMESPACE} workloads on context ${ctx} so replacement pods use the current namespace labels..."
  kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" delete deployment "${CLIENT_DEPLOYMENT}" \
    --ignore-not-found --wait=true --timeout="${WAIT_TIMEOUT}" >/dev/null 2>&1 || true

  for idx in 0 1 2 3; do
    kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" delete statefulset "echoserver${idx}" \
      --ignore-not-found --wait=true --timeout="${WAIT_TIMEOUT}" >/dev/null 2>&1 || true
  done

  kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" delete service echoserver \
    --ignore-not-found >/dev/null 2>&1 || true
}

prepare_test_namespace() {
  local ctx="$1"
  local namespace_json=""
  local current_rev=""
  local legacy_label=""

  log "Preparing namespace ${K8S_TEST_NAMESPACE} on context ${ctx}..."
  use_context "${ctx}"
  ensure_namespace "${K8S_TEST_NAMESPACE}" false
  ensure_registry_secret "${K8S_TEST_NAMESPACE}"

  if [[ -n "${ISTIO_REV}" ]]; then
    kubectl label namespace "${K8S_TEST_NAMESPACE}" istio.io/rev="${ISTIO_REV}" --overwrite >/dev/null
    kubectl label namespace "${K8S_TEST_NAMESPACE}" istio-injection- --overwrite >/dev/null 2>&1 || true
  else
    kubectl label namespace "${K8S_TEST_NAMESPACE}" istio.io/rev- --overwrite >/dev/null 2>&1 || true
    kubectl label namespace "${K8S_TEST_NAMESPACE}" istio-injection=enabled --overwrite >/dev/null
  fi

  namespace_json="$(kubectl --context "${ctx}" get namespace "${K8S_TEST_NAMESPACE}" -o json)"
  current_rev="$(jq -r '.metadata.labels["istio.io/rev"] // ""' <<<"${namespace_json}")"
  legacy_label="$(jq -r '.metadata.labels["istio-injection"] // ""' <<<"${namespace_json}")"

  if [[ -n "${ISTIO_REV}" && "${current_rev}" != "${ISTIO_REV}" ]]; then
    die "Namespace ${ctx}/${K8S_TEST_NAMESPACE} is not labeled istio.io/rev=${ISTIO_REV}. Current value: ${current_rev:-<unset>}"
  fi

  if [[ -n "${ISTIO_REV}" && -n "${legacy_label}" ]]; then
    die "Namespace ${ctx}/${K8S_TEST_NAMESPACE} still has legacy istio-injection=${legacy_label}; this conflicts with revisioned labels."
  fi

  reset_test_workloads "${ctx}"
}

deploy_echo_server() {
  local ctx="$1"
  local idx="$2"
  local name="echoserver${idx}"

  log "Deploying ${name} on context ${ctx}..."
  kubectl apply --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" -f - <<YAML
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: ${name}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ${name}
  serviceName: echoserver
  template:
    metadata:
      labels:
        app: ${name}
      annotations:
        kmm.dev/istio-check-run: "${CHECK_RUN_ID}"
    spec:
      imagePullSecrets:
        - name: ${REGISTRY_SECRET}
      containers:
        - name: ${name}
          image: ${ECHO_IMAGE}
          imagePullPolicy: Always
          ports:
            - containerPort: 8080
              name: http
YAML
}

create_echo_service() {
  local ctx="$1"
  local idx="$2"
  local app="echoserver${idx}"

  log "Creating stable Service echoserver on context ${ctx} for app ${app}..."
  kubectl apply --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" -f - <<YAML
apiVersion: v1
kind: Service
metadata:
  name: echoserver
spec:
  ports:
    - name: http
      port: 8080
      targetPort: 8080
      protocol: TCP
  selector:
    app: ${app}
YAML
}

show_sidecar_diagnostics() {
  local ctx="$1"
  local pod="$2"
  local containers=""

  warn "Namespace labels for ${ctx}/${K8S_TEST_NAMESPACE}:"
  kubectl --context "${ctx}" get namespace "${K8S_TEST_NAMESPACE}" --show-labels >&2 || true

  containers="$(kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" get pod "${pod}" \
    -o jsonpath='{.spec.containers[*].name}' 2>/dev/null || true)"
  warn "Pod containers in ${ctx}/${K8S_TEST_NAMESPACE}/${pod}: ${containers:-<pod not found>}"

  warn "Recent namespace events for ${ctx}/${K8S_TEST_NAMESPACE}:"
  kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" get events --sort-by=.lastTimestamp 2>/dev/null | tail -n 20 >&2 || true
}

wait_for_pod_sidecar() {
  local ctx="$1"
  local pod="$2"
  local sidecar_ready=""

  log "Waiting for ${ctx}/${K8S_TEST_NAMESPACE}/${pod} and istio-proxy..."
  kubectl wait --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" \
    --for=condition=ready pod "${pod}" \
    --timeout="${WAIT_TIMEOUT}"

  sidecar_ready="$(kubectl --context "${ctx}" -n "${K8S_TEST_NAMESPACE}" \
    get pod "${pod}" \
    -o json | jq -r '.status.containerStatuses[]? | select(.name == "istio-proxy") | .ready')"

  if [[ "${sidecar_ready}" != "true" ]]; then
    show_sidecar_diagnostics "${ctx}" "${pod}"
    die "Pod ${ctx}/${K8S_TEST_NAMESPACE}/${pod} is ready, but istio-proxy is not ready or was not injected. Confirm namespace labels and revision webhook."
  fi
}

wait_for_echo_server() {
  local ctx="$1"
  local idx="$2"
  local name="echoserver${idx}"

  log "Waiting for ${name} pod on context ${ctx}..."
  wait_for_pod_sidecar "${ctx}" "${name}-0"
}

deploy_sleep_client() {
  log "Deploying curl client ${CLIENT_DEPLOYMENT} on context ${CLIENT_CONTEXT}..."
  kubectl apply --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" -f - <<YAML
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${CLIENT_DEPLOYMENT}
spec:
  replicas: 1
  selector:
    matchLabels:
      app: ${CLIENT_DEPLOYMENT}
  template:
    metadata:
      labels:
        app: ${CLIENT_DEPLOYMENT}
      annotations:
        kmm.dev/istio-check-run: "${CHECK_RUN_ID}"
    spec:
      imagePullSecrets:
        - name: ${REGISTRY_SECRET}
      containers:
        - name: curl
          image: ${CURL_IMAGE}
          command:
            - sleep
            - 3650d
YAML

  wait_for_deployment_available "${K8S_TEST_NAMESPACE}" "${CLIENT_DEPLOYMENT}" "${WAIT_TIMEOUT}"
}

get_sleep_pod() {
  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" \
    get pod -l "app=${CLIENT_DEPLOYMENT}" \
    -o jsonpath='{.items[0].metadata.name}'
}

run_echo_calls() {
  local sleep_pod="$1"
  local max_time="$2"

  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" exec "${sleep_pod}" -c curl -- \
    sh -lc "for i in \$(seq 1 5); do echo -n \"\$i \"; curl -sS --max-time ${max_time} http://echoserver:8080/ | head -n1; echo; done"
}

wait_for_sleep_sidecar() {
  local sleep_pod="$1"

  wait_for_pod_sidecar "${CLIENT_CONTEXT}" "${sleep_pod}"
}

istioctl_proxy_config_with_retries() {
  local config_type="$1"
  local sleep_pod="$2"
  local output=""
  local attempt=1

  while (( attempt <= PROXY_CONFIG_RETRIES )); do
    if output="$(istioctl --context "${CLIENT_CONTEXT}" proxy-config "${config_type}" "${sleep_pod}" -n "${K8S_TEST_NAMESPACE}" 2>&1)"; then
      printf '%s\n' "${output}"
      return 0
    fi

    warn "istioctl proxy-config ${config_type} failed for ${sleep_pod} on attempt ${attempt}/${PROXY_CONFIG_RETRIES}."
    warn "Last error: ${output}"
    (( attempt++ ))

    if (( attempt <= PROXY_CONFIG_RETRIES )); then
      sleep "${PROXY_CONFIG_RETRY_SLEEP}"
    fi
  done

  return 1
}

proxy_admin_request() {
  local sleep_pod="$1"
  local admin_path="$2"

  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" exec "${sleep_pod}" -c istio-proxy -- \
    pilot-agent request GET "${admin_path}"
}

show_proxy_introspection() {
  local sleep_pod="$1"
  local endpoints_output=""
  local clusters_output=""
  local admin_output=""

  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" get pod "${sleep_pod}" >/dev/null
  wait_for_sleep_sidecar "${sleep_pod}"

  echo
  echo "--- proxy-config endpoints (look for remote endpoints / network metadata) ---"
  if endpoints_output="$(istioctl_proxy_config_with_retries endpoints "${sleep_pod}")"; then
    grep -E 'echoserver|15443|j64|j52|r01' <<<"${endpoints_output}" || true
  else
    warn "istioctl proxy-config endpoints could not read Envoy admin data. Falling back to pilot-agent inside istio-proxy."
    if admin_output="$(proxy_admin_request "${sleep_pod}" 'clusters?format=json' 2>&1)"; then
      grep -E 'echoserver|15443|j64|j52|r01' <<<"${admin_output}" || true
    else
      warn "pilot-agent fallback for Envoy clusters endpoint also failed."
      warn "Last fallback error: ${admin_output}"
    fi
  fi

  echo
  echo "--- proxy-config clusters (look for outbound|15443|| entries) ---"
  if clusters_output="$(istioctl_proxy_config_with_retries clusters "${sleep_pod}")"; then
    grep 15443 <<<"${clusters_output}" || true
  else
    warn "istioctl proxy-config clusters could not read Envoy admin data. Falling back to pilot-agent config_dump inside istio-proxy."
    if admin_output="$(proxy_admin_request "${sleep_pod}" 'config_dump?mask=dynamic_active_clusters,dynamic_warming_clusters,static_clusters' 2>&1)"; then
      jq -r '.. | objects | select(has("name")) | .name? // empty' <<<"${admin_output}" | grep 15443 || true
    else
      warn "pilot-agent fallback for Envoy config_dump also failed."
      warn "Last fallback error: ${admin_output}"
    fi
  fi
}

main() {
  local idx=""
  local ctx=""
  local sleep_pod=""

  validate_contexts

  log "== 0) Prepare namespaces for sidecar injection =="
  for ctx in "${contexts[@]}"; do
    prepare_test_namespace "${ctx}"
  done

  log "== 1) Deploy echo servers, one per cluster =="
  for idx in 0 1 2 3; do
    deploy_echo_server "${contexts[$idx]}" "${idx}"
  done

  for idx in 0 1 2 3; do
    wait_for_echo_server "${contexts[$idx]}" "${idx}"
  done

  log "== 2) Create stable Service name echoserver in each cluster =="
  for idx in 0 1 2 3; do
    create_echo_service "${contexts[$idx]}" "${idx}"
  done

  log "== 3) Deploy curl client in ${CLIENT_CONTEXT} to generate traffic =="
  use_context "${CLIENT_CONTEXT}"
  deploy_sleep_client
  sleep_pod="$(get_sleep_pod)"
  [[ -n "${sleep_pod}" ]] || die "Unable to find ${CLIENT_DEPLOYMENT} pod in ${CLIENT_CONTEXT}/${K8S_TEST_NAMESPACE}."
  wait_for_sleep_sidecar "${sleep_pod}"

  log "== 4) Baseline calls while all clusters have an echoserver =="
  run_echo_calls "${sleep_pod}" 5

  log "== 5) Prove cross-cluster: scale local backend to 0 and call again =="
  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" scale statefulset "${CLIENT_STATEFULSET}" --replicas=0
  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" rollout status statefulset/"${CLIENT_STATEFULSET}" --timeout="${WAIT_TIMEOUT}" || true
  sleep 5
  run_echo_calls "${sleep_pod}" 5

  log "== 6) Introspection: confirm remote endpoints and 15443 clusters exist in the sidecar =="
  show_proxy_introspection "${sleep_pod}"

  log "== 7) Restore local backend and show load distribution again =="
  kubectl --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" scale statefulset "${CLIENT_STATEFULSET}" --replicas=1
  kubectl wait --context "${CLIENT_CONTEXT}" -n "${K8S_TEST_NAMESPACE}" \
    --for=condition=ready pod \
    -l "statefulset.kubernetes.io/pod-name=${CLIENT_STATEFULSET}-0" \
    --timeout="${WAIT_TIMEOUT}"
  wait_for_pod_sidecar "${CLIENT_CONTEXT}" "${CLIENT_STATEFULSET}-0"
  run_echo_calls "${sleep_pod}" 3

  echo
  echo "✅ Mesh looks healthy if: baseline worked, cross-cluster calls worked with local=0, and 15443 clusters/endpoints are present."
}

main "$@"
