#!/usr/bin/env bash
set -euo pipefail

# Run this on an internet-connected workstation to stage the Rancher chart and official air-gap assets.
# Then copy the resulting bundle directory into the disconnected environment.

RANCHER_VERSION="${RANCHER_VERSION:-v2.14.2}"
RANCHER_CHART_VERSION="${RANCHER_CHART_VERSION:-2.14.2}"
RANCHER_CHART_REPO_NAME="${RANCHER_CHART_REPO_NAME:-rancher-stable}"
RANCHER_CHART_REPO_URL="${RANCHER_CHART_REPO_URL:-https://releases.rancher.com/server-charts/stable}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "${SCRIPT_DIR}/charts" "${SCRIPT_DIR}/official-airgap-assets"

helm repo add "${RANCHER_CHART_REPO_NAME}" "${RANCHER_CHART_REPO_URL}" >/dev/null 2>&1 || true
helm repo update "${RANCHER_CHART_REPO_NAME}"
helm pull "${RANCHER_CHART_REPO_NAME}/rancher" \
  --version "${RANCHER_CHART_VERSION}" \
  --destination "${SCRIPT_DIR}/charts"

for asset in rancher-images.txt rancher-images-digests-linux.txt rancher-save-images.sh rancher-load-images.sh rancher-components.txt; do
  curl -fL -o "${SCRIPT_DIR}/official-airgap-assets/${asset}" \
    "https://github.com/rancher/rancher/releases/download/${RANCHER_VERSION}/${asset}"
done

chmod +x "${SCRIPT_DIR}/official-airgap-assets/rancher-save-images.sh" \
         "${SCRIPT_DIR}/official-airgap-assets/rancher-load-images.sh"

echo "Fetched Rancher chart and official air-gap assets for ${RANCHER_VERSION}."
echo "For full air-gap mirroring, use:"
echo "  cd official-airgap-assets"
echo "  ./rancher-save-images.sh --image-list ./rancher-images.txt"
echo "  ./rancher-load-images.sh --image-list ./rancher-images.txt --registry altregistry.dev.kube:8443/library"
