#!/usr/bin/env bash
set -euo pipefail

IMAGE_LIST="${1:-./images-to-pull.txt}"
REGISTRY="${REGISTRY:-altregistry.dev.kube:8443/library}"
RUNTIME="${RUNTIME:-}"

log() { printf '[INFO] %s\n' "$*"; }
fail() { printf '[ERROR] %s\n' "$*" >&2; exit 1; }

if [[ -z "${RUNTIME}" ]]; then
  if command -v nerdctl >/dev/null 2>&1; then
    RUNTIME="nerdctl"
  elif command -v docker >/dev/null 2>&1; then
    RUNTIME="docker"
  else
    fail "Neither nerdctl nor docker was found. Set RUNTIME=docker or RUNTIME=nerdctl after installing one."
  fi
fi

[[ -f "${IMAGE_LIST}" ]] || fail "Image list not found: ${IMAGE_LIST}"

while IFS= read -r image; do
  image="${image%%#*}"
  image="$(echo "${image}" | xargs || true)"
  [[ -z "${image}" ]] && continue

  target="${REGISTRY}/${image}"
  log "Pulling ${image}"
  ${RUNTIME} pull "${image}"
  log "Tagging ${image} -> ${target}"
  ${RUNTIME} tag "${image}" "${target}"
  log "Pushing ${target}"
  ${RUNTIME} push "${target}"
done < "${IMAGE_LIST}"

log "Image mirror complete."
