#!/usr/bin/env bash
set -euo pipefail

# Rancher UI / Rancher Manager Helm deployment bundle
# Defaults follow the lab/internal registry pattern. Override with env vars as needed.

APP_NAME="${APP_NAME:-rancher}"
NAMESPACE="${NAMESPACE:-cattle-system}"
HOSTNAME="${HOSTNAME:-labrancher.dev.kube}"
INGRESS_CLASS="${INGRESS_CLASS:-devlocal}"
CLUSTER_ISSUER="${CLUSTER_ISSUER:-cotpa-ca-clusterissuer}"
TLS_SECRET="${TLS_SECRET:-rancher-ui-tls}"
REGISTRY="${REGISTRY:-altregistry.dev.kube:8443/library}"
RANCHER_CHART_REPO_NAME="${RANCHER_CHART_REPO_NAME:-rancher-stable}"
RANCHER_CHART_REPO_URL="${RANCHER_CHART_REPO_URL:-https://releases.rancher.com/server-charts/stable}"
RANCHER_CHART_VERSION="${RANCHER_CHART_VERSION:-2.14.2}"
RANCHER_IMAGE_TAG="${RANCHER_IMAGE_TAG:-v2.14.2}"
RANCHER_REPLICAS="${RANCHER_REPLICAS:-3}"
PRIVATE_CA="${PRIVATE_CA:-true}"
CERT_MANAGER_VERSION="${CERT_MANAGER_VERSION:-1.15.0}"
KUBECONFIG_CONTEXT="${KUBECONFIG_CONTEXT:-}"
CHART_TGZ="${CHART_TGZ:-./charts/rancher-${RANCHER_CHART_VERSION}.tgz}"
CA_CERT_FILE="${CA_CERT_FILE:-}"
BOOTSTRAP_PASSWORD="${BOOTSTRAP_PASSWORD:-}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RENDER_DIR="${SCRIPT_DIR}/rendered"
mkdir -p "${RENDER_DIR}"

log() { printf '\n[INFO] %s\n' "$*"; }
warn() { printf '\n[WARN] %s\n' "$*" >&2; }
fail() { printf '\n[ERROR] %s\n' "$*" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "Missing required command: $1"; }

need kubectl
need helm

if [[ -n "${KUBECONFIG_CONTEXT}" ]]; then
  kubectl config use-context "${KUBECONFIG_CONTEXT}"
fi

if [[ -z "${BOOTSTRAP_PASSWORD}" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    BOOTSTRAP_PASSWORD="$(openssl rand -base64 24 | tr -dc 'A-Za-z0-9@%+=_' | head -c 24)"
  else
    BOOTSTRAP_PASSWORD="ChangeMe-Rancher-Admin-Password-Now"
  fi
fi

render_template() {
  local input="$1"
  local output="$2"
  sed \
    -e "s#__APP_NAME__#${APP_NAME}#g" \
    -e "s#__NAMESPACE__#${NAMESPACE}#g" \
    -e "s#__HOSTNAME__#${HOSTNAME}#g" \
    -e "s#__INGRESS_CLASS__#${INGRESS_CLASS}#g" \
    -e "s#__CLUSTER_ISSUER__#${CLUSTER_ISSUER}#g" \
    -e "s#__TLS_SECRET__#${TLS_SECRET}#g" \
    -e "s#__REGISTRY__#${REGISTRY}#g" \
    -e "s#__RANCHER_IMAGE_TAG__#${RANCHER_IMAGE_TAG}#g" \
    -e "s#__RANCHER_REPLICAS__#${RANCHER_REPLICAS}#g" \
    -e "s#__PRIVATE_CA__#${PRIVATE_CA}#g" \
    -e "s#__CERT_MANAGER_VERSION__#${CERT_MANAGER_VERSION}#g" \
    -e "s#__BOOTSTRAP_PASSWORD__#${BOOTSTRAP_PASSWORD}#g" \
    "${input}" > "${output}"
}

VALUES_RENDERED="${RENDER_DIR}/values.rendered.yaml"
RESOURCES_RENDERED="${RENDER_DIR}/resources.rendered.yaml"
render_template "${SCRIPT_DIR}/values.yaml" "${VALUES_RENDERED}"
render_template "${SCRIPT_DIR}/resources.yaml" "${RESOURCES_RENDERED}"

log "Target context: $(kubectl config current-context)"
log "Deploying ${APP_NAME} ${RANCHER_IMAGE_TAG} to namespace ${NAMESPACE}"
log "Hostname: https://${HOSTNAME}"
log "Internal registry: ${REGISTRY}"

log "Applying prerequisite namespace, PriorityClass, and TLS Certificate resources"
kubectl apply -f "${RESOURCES_RENDERED}"

if kubectl api-resources | grep -q '^certificates[[:space:]].*cert-manager.io'; then
  log "Waiting for cert-manager Certificate/${APP_NAME}-ui-cert to become Ready"
  if ! kubectl -n "${NAMESPACE}" wait --for=condition=Ready "certificate/${APP_NAME}-ui-cert" --timeout=180s; then
    warn "Certificate is not Ready yet. Review: kubectl -n ${NAMESPACE} describe certificate ${APP_NAME}-ui-cert"
  fi
else
  warn "cert-manager CRDs were not detected. The Certificate in resources.yaml will not be reconciled until cert-manager is installed."
fi

if [[ "${PRIVATE_CA}" == "true" ]]; then
  log "Ensuring Rancher private CA secret tls-ca exists"
  if kubectl -n "${NAMESPACE}" get secret tls-ca >/dev/null 2>&1; then
    log "tls-ca already exists; leaving it untouched"
  elif [[ -n "${CA_CERT_FILE}" && -f "${CA_CERT_FILE}" ]]; then
    kubectl -n "${NAMESPACE}" create secret generic tls-ca --from-file=cacerts.pem="${CA_CERT_FILE}"
  else
    TMP_CA="${RENDER_DIR}/cacerts.pem"
    if kubectl -n "${NAMESPACE}" get secret "${TLS_SECRET}" -o jsonpath='{.data.ca\.crt}' 2>/dev/null | base64 -d > "${TMP_CA}" && [[ -s "${TMP_CA}" ]]; then
      kubectl -n "${NAMESPACE}" create secret generic tls-ca --from-file=cacerts.pem="${TMP_CA}"
    else
      fail "PRIVATE_CA=true but tls-ca could not be created. Provide CA_CERT_FILE=/path/to/ca.pem or make sure secret/${TLS_SECRET} contains ca.crt."
    fi
  fi
fi

HELM_VERSION_ARGS=(--version "${RANCHER_CHART_VERSION}")
if [[ -f "${CHART_TGZ}" ]]; then
  CHART_REF="${CHART_TGZ}"
  HELM_VERSION_ARGS=()
  log "Using local chart package: ${CHART_REF}"
else
  CHART_REF="${RANCHER_CHART_REPO_NAME}/rancher"
  log "Local chart package not found at ${CHART_TGZ}; using Helm repo ${RANCHER_CHART_REPO_URL}"
  helm repo add "${RANCHER_CHART_REPO_NAME}" "${RANCHER_CHART_REPO_URL}" >/dev/null 2>&1 || true
  helm repo update "${RANCHER_CHART_REPO_NAME}"
fi

log "Installing/upgrading Rancher Helm release"
helm upgrade --install "${APP_NAME}" "${CHART_REF}" \
  --namespace "${NAMESPACE}" \
  "${HELM_VERSION_ARGS[@]}" \
  --values "${VALUES_RENDERED}" \
  --wait \
  --timeout 10m

log "Waiting for Rancher deployment rollout"
kubectl -n "${NAMESPACE}" rollout status deploy/"${APP_NAME}" --timeout=10m

log "Current Rancher objects"
kubectl -n "${NAMESPACE}" get pods,svc,ingress,certificate,secret | grep -E "(${APP_NAME}|${TLS_SECRET}|tls-ca|NAME)" || true

cat <<EOM

[INFO] Rancher should be reachable at:
  https://${HOSTNAME}

[INFO] Bootstrap password used by this install:
  ${BOOTSTRAP_PASSWORD}

[INFO] If Rancher generated/rotated the bootstrap secret, retrieve it with:
  kubectl get secret --namespace ${NAMESPACE} bootstrap-secret -o go-template='{{.data.bootstrapPassword|base64decode}}{{"\\n"}}'

[INFO] Setup URL helper:
  echo "https://${HOSTNAME}/dashboard/?setup=\$(kubectl get secret --namespace ${NAMESPACE} bootstrap-secret -o go-template='{{.data.bootstrapPassword|base64decode}}')"
EOM
