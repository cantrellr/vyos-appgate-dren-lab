# Rancher UI Deployment Bundle

This bundle deploys Rancher Manager / Rancher UI with the Rancher Helm chart using the lab-style pattern: `install.sh`, `values.yaml`, `resources.yaml`, and an explicit image mirror list.

## Defaults

| Setting | Default |
|---|---|
| Namespace | `cattle-system` |
| Hostname | `labrancher.dev.kube` |
| Ingress class | `devlocal` |
| ClusterIssuer | `cotpa-ca-clusterissuer` |
| TLS secret | `rancher-ui-tls` |
| Internal registry root | `altregistry.dev.kube:8443/library` |
| Rancher chart version | `2.14.2` |
| Rancher image tag | `v2.14.2` |
| Replicas | `3` |

## Files

- `install.sh` — applies prerequisites, creates/uses TLS CA secret, deploys Rancher with Helm, waits for rollout, and prints the bootstrap URL.
- `values.yaml` — Rancher Helm values template.
- `resources.yaml` — namespace, PriorityClass, and cert-manager `Certificate` template.
- `images-to-pull.txt` — minimum bootstrap image list and official Rancher air-gap asset pointer.
- `mirror-images.sh` — convenience script to pull, retag, and push images to the internal registry.
- `00-fetch-online-artifacts.sh` — run this on an internet-connected workstation to stage the official chart and Rancher release air-gap assets.

## Install

```bash
chmod +x install.sh mirror-images.sh 00-fetch-online-artifacts.sh

# Optional: mirror the minimum bootstrap images first
REGISTRY=altregistry.dev.kube:8443/library ./mirror-images.sh ./images-to-pull.txt

# Deploy Rancher
HOSTNAME=labrancher.dev.kube \
INGRESS_CLASS=devlocal \
CLUSTER_ISSUER=cotpa-ca-clusterissuer \
REGISTRY=altregistry.dev.kube:8443/library \
./install.sh
```

## Air-gapped chart handling

For a fully disconnected environment, run this from a connected workstation first:

```bash
./00-fetch-online-artifacts.sh
```

Then copy the complete folder into the air-gapped side. `install.sh` automatically uses `./charts/rancher-2.14.2.tgz` when it exists; otherwise it falls back to the online Helm repo.

## Private CA handling

`values.yaml` defaults to `privateCA: true`, so Rancher expects a `tls-ca` secret in `cattle-system` with key `cacerts.pem`. `install.sh` will create it from `secret/rancher-ui-tls` key `ca.crt` when cert-manager provides it. If your issuer does not include `ca.crt`, provide the CA explicitly:

```bash
CA_CERT_FILE=/path/to/ca.pem ./install.sh
```

## Operational note

The short image list is enough for the Rancher server chart bootstrap path in a cluster where cert-manager already exists. For production air-gap operations, mirror the official `rancher-images.txt` asset for the exact Rancher release. That file includes the wider set used by Rancher for agents, Fleet, webhooks, provisioning, and optional tools.
