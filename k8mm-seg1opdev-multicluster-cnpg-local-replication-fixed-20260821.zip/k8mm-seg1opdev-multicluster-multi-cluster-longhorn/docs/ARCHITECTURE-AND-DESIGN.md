# Architecture and Design

> **Baseline:** v2.1 — August 20, 2026  
> **Audience:** architects, systems engineers, security engineers, platform engineers, and senior support staff.

## 1. Architectural principles

The platform is a four-cluster, air-gapped RKE2 environment with these design rules:

1. Rancher Manager owns cluster lifecycle; Rancher Fleet owns steady-state Kubernetes desired state.
2. GitLab is the source of truth for Fleet configuration; KubeHarbor is the source for approved OCI charts and container images.
3. No second GitOps controller is active. Overlapping reconcilers are intentionally avoided.
4. Runtime secrets, private keys, Istio CA directories, and enrollment tokens are not stored in Git.
5. Platform namespaces do not receive automatic Istio sidecars. Mesh participation is explicit.
6. Segment1 is the only MetalLB LoadBalancer address domain for the platform; storage data networks remain outside MetalLB.
7. Host-level prerequisites such as time and Longhorn disks are validated outside Fleet because they are node concerns, not ordinary Kubernetes desired state.

## 2. Overall system topology

```mermaid
flowchart TB
  ADMIN[Platform administrators and support teams]
  GITLAB[GitLab\nGit source of truth]
  HARBOR[KubeHarbor\nOCI charts and container images]
  DNS[Private DNS\ndev.kube and enterprise zones]
  NTP[Approved NTP sources]
  CA[Enterprise / Segment1 CA]
  ELASTIC[External Elastic Fleet Server]
  OBS[External Prometheus / Grafana]

  subgraph MGMT[j64seg1opman - Management Cluster]
    RANCHER[Rancher Manager]
    FLEET[Rancher Fleet]
    MESH_M[Istio / Kiali]
    STORAGE_M[Longhorn]
    AGENT_M[Elastic Agent]
  end

  subgraph J64[j64seg1opdev - Primary Application Cluster]
    MESH_J64[Istio / Kiali]
    STORAGE_J64[Longhorn]
    PG_PRIMARY[CloudNativePG Primary]
    KC_PRIMARY[Keycloak Active]
    AGENT_J64[Elastic Agent]
  end

  subgraph J52[j52seg1opdev - Secondary Identity Cluster]
    MESH_J52[Istio / Kiali]
    STORAGE_J52[Longhorn]
    PG_REPLICA[CloudNativePG Replica]
    KC_STANDBY[Keycloak Standby]
    AGENT_J52[Elastic Agent]
  end

  subgraph R01[r01seg1opdev - Application Cluster]
    MESH_R01[Istio / Kiali]
    STORAGE_R01[Longhorn]
    AGENT_R01[Elastic Agent]
  end

  ADMIN --> RANCHER
  GITLAB --> FLEET
  HARBOR --> FLEET
  HARBOR --> MGMT
  HARBOR --> J64
  HARBOR --> J52
  HARBOR --> R01
  RANCHER --> FLEET
  FLEET --> MESH_M
  FLEET --> MESH_J64
  FLEET --> MESH_J52
  FLEET --> MESH_R01
  FLEET --> STORAGE_J64
  FLEET --> STORAGE_J52
  FLEET --> STORAGE_R01
  FLEET --> PG_PRIMARY
  FLEET --> PG_REPLICA
  FLEET --> KC_PRIMARY
  PG_PRIMARY -. asynchronous WAL replication .-> PG_REPLICA
  MESH_M <--> MESH_J64
  MESH_M <--> MESH_J52
  MESH_M <--> MESH_R01
  AGENT_M --> ELASTIC
  AGENT_J64 --> ELASTIC
  AGENT_J52 --> ELASTIC
  AGENT_R01 --> ELASTIC
  MESH_M --> OBS
  MESH_J64 --> OBS
  MESH_J52 --> OBS
  MESH_R01 --> OBS
  DNS --> MGMT
  DNS --> J64
  DNS --> J52
  DNS --> R01
  NTP --> MGMT
  NTP --> J64
  NTP --> J52
  NTP --> R01
  CA --> MGMT
  CA --> J64
  CA --> J52
  CA --> R01

  classDef external stroke-dasharray: 5 5
  class GITLAB,HARBOR,DNS,NTP,CA,ELASTIC,OBS external
```

### External dependencies

| Dependency | Function | Failure impact |
| --- | --- | --- |
| GitLab (`gitlab001.dev.local`) | Fleet Git source of truth | no new reconciliation or Git-driven recovery |
| KubeHarbor (`kubeharbor.dev.kube`) | images and OCI charts | new pods/charts may fail to pull; upgrades blocked |
| private DNS | resolution for Harbor, Rancher, UIs, identity, replication, monitoring | widespread connection and certificate failures |
| approved NTP | node clock discipline | TLS, logs, distributed systems, and deployment gates affected |
| Segment1 CA | cert-manager issuer and service TLS | certificate issuance/renewal and TLS validation affected |
| Elastic Fleet/ELK | agent enrollment and telemetry | monitoring/log visibility degraded |
| Prometheus/Grafana | Kiali external metrics/dashboard integration | Kiali metrics/graph integrations degraded |
| Segment1 network | ingress VIPs, east-west mesh, identity replication | service and multicluster communication failures |

## 3. Cluster topology and addressing

| Context | Role | Identity role | MetalLB pool | Ingress VIP | PostgreSQL replication VIP | Istio east-west VIP |
| --- | --- | --- | --- | --- | --- | --- |
| `j64seg1opman` | management | none | `1.0.0.201-1.0.0.210` | `1.0.0.205` | — | `1.0.0.210` |
| `j64seg1opdev` | application | primary | `1.0.0.211-1.0.0.220` | `1.0.0.215` | `1.0.0.216` | `1.0.0.220` |
| `j52seg1opdev` | application | warm secondary | `1.0.0.221-1.0.0.230` | `1.0.0.225` | `1.0.0.226` | `1.0.0.230` |
| `r01seg1opdev` | application | none | `1.0.0.231-1.0.0.240` | `1.0.0.235` | — | `1.0.0.240` |

All platform LoadBalancer addresses are within Segment1 (`1.0.0.0/23`).

## 4. GitOps architecture and ownership

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

### Bootstrap boundary

`j64seg1opman` must exist before Rancher/Fleet can manage anything. The management bootstrap therefore installs the minimum dependency chain imperatively: KubeHarbor pull credentials, private DNS forwarding, cert-manager/CA, MetalLB and Segment1 pool, Contour/Envoy, Rancher, and Rancher/Fleet compatibility controls.

After Rancher is available, Fleet delivers common services. On the management cluster, bootstrap remains the lifecycle owner of cert-manager, MetalLB/configuration, and Segment1 Contour because Rancher itself depends on that substrate. Fleet publishes readiness-contract bundles for those local prerequisites instead of attempting to reinstall or adopt them.

Downstream clusters receive the actual Fleet-owned cert-manager, MetalLB, Contour, Longhorn, identity, Istio, Kiali, and monitoring bundles.

### Cluster label contract

Key Fleet labels include:

| Label | Purpose |
| --- | --- |
| `kmm.dev/context` | exact supported cluster identity |
| `kmm.dev/site` | site/location selector |
| `kmm.dev/role` | management or application |
| `kmm.dev/platform=seg1opdev` | platform target guard |
| `kmm.dev/identity` | primary, secondary, secondary-pending, or none |
| `kmm.dev/identity-site` | identity operator placement |
| `kmm.dev/segment1-pool` | per-cluster MetalLB address range |
| `kmm.dev/segment1-lb-ip` | Contour VIP |
| `kmm.dev/eastwest-lb-ip` | Istio east-west VIP |
| `kmm.dev/istio-network` | Istio network identity |
| `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-*` | durable runtime identity role state |
| `node.longhorn.io/create-default-disk=true` | worker passed Longhorn preflight |

Dynamic identity labels change during controlled failover; static topology labels do not.

## 5. Fleet bundle sequence

The active bundle chain is organized by numbered directories and dependency labels rather than relying only on lexical ordering:

- `10/11` cert-manager and CA configuration;
- `20/21` MetalLB and Segment1 address pools;
- `31/32` Contour ingress and Segment1 policies;
- `40/41/42` Longhorn, storage configuration, and Longhorn UI exposure;
- `50/51/52/53/54` CloudNativePG and Keycloak identity stack;
- `60-66` Istio base/CNI/istiod/east-west and Kiali;
- `70/71` kube-state-metrics and Elastic Agent.

The exact package/version allowlist is in `helm/required-oci-artifacts.txt`, and validation enforces that staged charts, checksums, Fleet definitions, and OCI references remain aligned.

## 6. Air-gap artifact architecture

Fleet chart references use the pattern:

```text
oci://kubeharbor.dev.kube/k8mm-charts/<chart>:<version>
```

The deployment host and cluster nodes trust the KubeHarbor issuing CA. Workloads use namespace-local `regcred-kubeharbor`; Fleet workspaces use OCI credentials and CA material seeded into the Fleet namespaces.

Rancher image acquisition/promotion is intentionally owned by the separate air-gap image workflow. This repository validates the externally staged Rancher image list and node-level pull capability; it does not download public images.

## 7. Ingress and administrative endpoints

Every cluster uses the `segment1` Contour ingress class and its assigned Segment1 Envoy VIP. Backend authorization is namespace-based: namespaces intentionally reachable from Segment1 Envoy carry `segment1.ingress/allow-backend=true`, and the Envoy egress policy limits traffic to approved backend ports. Service-to-pod translation is accounted for explicitly; for example, the Longhorn frontend Service port 80 reaches the UI pods on TCP/8000.

Identity NetworkPolicies also preserve controller and database bootstrap reachability. CloudNativePG operator traffic to each database instance-manager status endpoint on TCP/8000 is explicitly allowed. Before the primary PostgreSQL Cluster bundle starts, the prerequisite resources bundle also permits local CNPG cluster members—including replica join jobs and PgBouncer—to reach cluster members on TCP/5432; this prevents an ingress-policy isolation deadlock during creation of replicas 2 and 3. Cross-site replication remains separately restricted to the approved Segment1 CIDR. Default-deny selectors are scoped to application/database workloads rather than namespace-wide selectors that would also isolate the Keycloak or CloudNativePG operators. PgBouncer selectors use CNPG-owned labels (`cnpg.io/poolerName` / `cnpg.io/podRole`) rather than standard application labels that CNPG normalizes on generated pods.

Administrative naming is standardized:

| Context | Longhorn | Kiali |
| --- | --- | --- |
| `j64seg1opman` | `longhorn-man.dev.kube` | `kiali-man.dev.kube` |
| `j64seg1opdev` | `longhorn-j64.dev.kube` | `kiali-j64.dev.kube` |
| `j52seg1opdev` | `longhorn-j52.dev.kube` | `kiali-j52.dev.kube` |
| `r01seg1opdev` | `longhorn-r01.dev.kube` | `kiali-r01.dev.kube` |

Longhorn remains a ClusterIP service internally. Fleet creates a cert-manager `Certificate` and Contour `HTTPProxy` per cluster. The Longhorn proxy has an `ipAllowPolicy` permitting only `1.0.0.0/23` and routes to `longhorn-frontend:80`.

Kiali routes use the same naming convention and are served at the hostname root (`/`). External Prometheus is `https://j64seg1opman-prometheus.dev.kube`; external Grafana is `https://grafana.dev.kube`.

Rancher is exposed as `https://rancher.dev.kube` with a long-lived WebSocket-capable HTTPProxy because cluster agents use `wss://rancher.dev.kube/v3/connect/register`.

## 8. Service mesh design

Fleet installs Istio base, CNI, istiod, one east-west gateway per cluster, and Kiali. The environment shares the Istio trust material supplied outside Git. East-west VIPs are `.210`, `.220`, `.230`, and `.240` for management, j64, j52, and r01 respectively.

Automatic sidecar injection is disabled for platform/control namespaces including cert-manager, Segment1 ingress, MetalLB, Longhorn, Istio, identity, and monitoring. Application namespaces join the mesh only through an explicit reviewed label. This avoids accidentally intercepting controller, CSI, database, ingress, or host-agent traffic.

Istio remote Secrets are created after gateways are Ready by the controlled multicluster-secret workflow; they are not committed to Git.

## 9. Longhorn storage design

Longhorn uses validated worker storage at `/mnt/k8sdata`, expected to be a read/write XFS mount with at least `240 GiB` by default. The golden image contains the required Ubuntu 24.04 amd64 host dependencies. The runtime preflight is non-destructive: it verifies packages, iSCSI, filesystem, capacity, mount propagation, and a temporary write probe; it does not format or repartition disks.

The production storage class used by stateful workloads is `longhorn-xfs-retain`. CloudNativePG data and WAL volumes use Longhorn. `multipathd` is disabled where active because multipath can claim Longhorn devices.

Longhorn provides in-cluster volume replication and snapshots. Disaster recovery or off-cluster backup remains a separate operational requirement.

## 10. Identity high availability

```mermaid
flowchart LR
  USERS[Users and relying applications]
  DNS[Canonical identity DNS name]
  PRIMARYVIP[Primary ingress VIP]
  SECONDARYVIP[Secondary ingress VIP]

  subgraph J64[j64seg1opdev - Primary Site]
    KCP[Keycloak active]
    PGP[CloudNativePG primary]
    LHP[Longhorn volumes]
  end

  subgraph J52[j52seg1opdev - Secondary Site]
    KCS[Keycloak standby]
    PGR[CloudNativePG replica]
    LHR[Longhorn volumes]
  end

  USERS --> DNS
  DNS --> PRIMARYVIP
  PRIMARYVIP --> KCP
  KCP --> PGP
  PGP --> LHP
  PGP -. asynchronous WAL replication .-> PGR
  PGR --> LHR

  FAIL[Failover workflow]
  FAIL --> FENCE[Fence primary]
  FENCE --> PROMOTE[Promote secondary database]
  PROMOTE --> ACTIVATE[Activate secondary Keycloak]
  ACTIVATE --> DNSCUT[Move canonical DNS / ingress target]
  DNSCUT --> SECONDARYVIP
  SECONDARYVIP --> KCS
  KCS --> PGR
```

The canonical identity hostname is `opkeycloak.dev.jde.cybercom.ic.gov`.

- `j64seg1opdev`: active Keycloak site; Keycloak replicas and writable CloudNativePG primary.
- `j52seg1opdev`: warm secondary; streaming PostgreSQL replica; Keycloak custom resource exists with zero instances until promotion.
- only one site is writable and only one Keycloak site serves traffic at a time.

The active Keycloak chart renders its `Certificate` and `HTTPProxy` only when `keycloakInstances > 0`. This prevents the warm standby from advertising an invalid HTTPProxy to a backend service that does not yet exist.

Cross-site PostgreSQL replication is asynchronous. Planned failover can catch up to a final WAL position; unplanned failover may lose the most recent acknowledged writes.

## 11. Monitoring architecture

Each cluster runs a Fleet-managed Elastic Agent DaemonSet and kube-state-metrics Deployment. The default design uses **four Elastic Fleet enrollment tokens**, one policy/token per cluster. This isolates policy, revocation, and data-stream identity by cluster.

Kiali is configured to use external Prometheus/Grafana rather than deploying another monitoring stack in this repository.

## 12. Time architecture

Chrony is a privileged `kube-system/chrony-client` DaemonSet because it adjusts the host clock. It is deliberately outside Fleet. Deployment succeeds only when every node has a selected source, positive stratum, and `Leap status: Normal`.

The implementation distinguishes network reachability from server correctness. An NTP server can answer UDP/123 but still be unusable if it advertises `LI=3`/unsynchronized or stratum 0.

## 13. RKE2 CIS and PodSecurity design

RKE2 CIS mode uses restricted defaults, but infrastructure components cannot all operate under the restricted profile. The repository therefore creates scoped privileged PSA exceptions for Rancher/Fleet system namespaces and the infrastructure namespaces that require host/network access. Application namespaces remain restricted unless explicitly approved.

Service-account token mounting is disabled where charts permit it, and namespace/mesh controls are validated before onboarding.

## 14. Rancher/Fleet compatibility controls

The baseline is pinned to Rancher `2.15.0`, bundled Fleet `0.15.2`, RKE2 `v1.35.6+rke2r1`, and Helm `4.0.0` or newer.

Required compatibility controls include:

- long-lived Rancher WebSocket route through Contour;
- scoped privileged PSA labels for Rancher/Fleet system namespaces;
- `KUBE_FEATURE_WatchListClient=false` on Fleet controllers/agents to avoid Kubernetes 1.35 watch-stream instability;
- private OCI registry DNS, CA trust, authentication, and GitJob RBAC;
- Fleet 0.15.2 OCI chart-source compatibility using `chart: oci://kubeharbor.dev.kube/k8mm-charts/<chart>`; validation **rejects bundle-anchor workarounds** used by older layouts.

## 15. Failure domains

A failure should be classified before remediation:

- **management/control:** Rancher, Fleet, GitJob, management ingress;
- **supply chain:** GitLab, KubeHarbor, OCI/chart/image inventory;
- **network/name/trust:** DNS, routing, NTP, CA, TLS;
- **cluster runtime:** RKE2, CNI, node pressure, PSA;
- **mesh/ingress:** Istio, east-west gateway, Contour/Envoy, HTTPProxy;
- **storage:** Longhorn node/disk/CSI/volume;
- **identity/data:** CloudNativePG, Keycloak, replication, failover state;
- **monitoring:** Elastic Agent/Fleet, kube-state-metrics, external Prometheus/Grafana.

The troubleshooting document maps these failure domains to help-desk and engineering escalation procedures.
