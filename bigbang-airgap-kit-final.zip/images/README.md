# Images directory

This directory holds machine‑readable definitions of all container
images required by Big Bang.  The file `bigbang-images.yaml` lists
each image by its repository and tag.  You can generate this file
automatically using `scripts/01-generate-image-list.sh` or convert
an upstream `images.txt` list using the command shown in the
Image Management chapter.

When mirroring images into your private registry, the scripts in
`../scripts/` read this file and perform the necessary operations.
Update the list whenever you change the Big Bang version or enable
additional packages.