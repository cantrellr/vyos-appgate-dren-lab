# 08 — Appendix

## Useful links

* **Big Bang documentation** – <https://docs-bigbang.dso.mil/>.
* **Quick Start guide** – instructions for a minimal installation,
  including the list of core components【933028610960299†L920-L936】.
* **Airgap guide** – describes packaging images (`images.tar.gz`) and
  setting up a private registry【851617246581943†L1036-L1040】.
* **Flux documentation** – <https://fluxcd.io/docs/>.
* **RKE2 documentation** – <https://docs.rke2.io/>.
* **Helm documentation** – <https://helm.sh/docs/>.

## Glossary

* **Flux** – A GitOps engine for Kubernetes.  It keeps the state of
  your cluster in sync with configuration stored in Git.
* **Helm** – A package manager for Kubernetes that manages charts.
* **OCI registry** – A registry implementing the [OCI](https://opencontainers.org/)
  distribution specification.  Both container images and Helm charts
  can be stored in OCI registries.
* **Istio** – A service mesh providing traffic management, security
  and observability features for microservices.
* **Kyverno** – A Kubernetes policy engine for admission control and
  dynamic configuration.
* **NeuVector** – A container runtime security platform.
* **Loki** – A log aggregation system by Grafana Labs, integrated
  with Big Bang via Alloy.
* **Tempo** – A trace collector by Grafana Labs.
* **Metrics Server** – A lightweight metrics provider for Kubernetes.

## Acronyms

| Acronym | Meaning |
|---------|---------|
| **RKE2** | Rancher Kubernetes Engine 2 |
| **BB**   | Big Bang |
| **CR**   | Custom Resource |
| **OCI**  | Open Container Initiative |