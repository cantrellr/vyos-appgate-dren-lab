# 00 — Overview

## Purpose

This repository bundles everything you need to deploy and operate the
Big Bang platform on an RKE2 cluster in disconnected or
internet‑restricted environments.  Big Bang is a Helm umbrella chart
that deploys a curated set of cloud‑native tools that together form a
secure, compliant platform.  The default installation includes Istio
CRDs and control plane, Istio ingress gateways, Kiali, Kyverno,
Loki, the metrics‑server, Tempo, Grafana and NeuVector【933028610960299†L920-L936】.
These components provide secure service mesh networking, policy
enforcement, observability (logging, metrics and tracing) and
runtime security in one cohesive package.

For organizations that operate in environments without direct access to
external registries (air‑gap) or under strict supply‑chain controls,
Big Bang’s standard installation procedure via Helm charts and remote
images is insufficient.  This kit provides a framework for
collecting the required container images, mirroring them into an
internal registry, generating configuration manifests, and deploying
everything using GitOps practices.

## Architecture summary

At a high level, the system consists of:

* **Developer workstation** – where you prepare images, generate
  manifests and initiate deployment.  You must install several
  command‑line tools including `kubectl`, `helm`, `flux`, `jq` and
  `yq`【933028610960299†L944-L967】.
* **Private container registry** – hosts all images required by
  Big Bang.  The `images` directory contains machine‑readable
  manifests describing the images and tags.  Scripts in `scripts/`
  automate pulling, retagging and pushing these images.
* **RKE2 cluster** – the target Kubernetes cluster.  You can build
  your own cluster on a VM or bare metal, or use cloud VMs, as long as
  it meets the hardware requirements (8 CPUs, 32 GiB RAM suggested)
  referenced in the Big Bang Quick Start【933028610960299†L996-L999】.
* **Flux GitOps controller** – installed into the cluster to
  continuously reconcile the desired state stored in Git with the
  actual state of the cluster.  Flux watches the manifests and values
  files in this repository and orchestrates Helm releases.

The documentation in this `docs/` directory is organised chronologically
to guide you from preparation to deployment and operations.