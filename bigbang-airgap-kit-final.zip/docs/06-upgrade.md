# 06 — Upgrading Big Bang

Upgrading Big Bang involves several coordinated steps: refreshing
container images, updating your values file, and triggering Flux to
apply the new chart version.  The following procedure assumes you
have already deployed a previous version using this kit.

## 1. Plan the upgrade

1. Read the release notes for the target Big Bang version to
   understand breaking changes and new features.
2. Identify any additional packages you plan to enable during the
   upgrade and prepare configuration overrides accordingly.
3. Schedule a maintenance window.  Upgrades may involve rolling
   restarts of control plane components (Istio, NeuVector, Loki, etc.).

## 2. Update images

Run `scripts/01-generate-image-list.sh` with the new chart version.
This regenerates `images/bigbang-images.yaml` for the target release.
Then run `scripts/02-pull-retag-push.sh` to mirror the updated images
into your private registry.  Verify the presence of the new images
with `scripts/03-verify-images.sh`.

## 3. Adjust values

Review the differences between your existing values file and the
sample in `config/values-example.yaml` for the new version.  Pay
attention to:

* Deprecated keys – remove any keys no longer supported.
* New defaults – update your overrides to align with upstream changes.
* Package versions – adjust tags if you override image repositories.

Commit your updated `values.yaml` to Git.

## 4. Bump chart version

Update the version specified in the HelmRelease resource (in
`scripts/05-deploy-bigbang.sh` or your Flux manifests).  For
example, change `version: 3.8.0` to `version: 3.9.0`.  Commit the
change.  Flux will detect the new version and perform a rolling
upgrade.

Monitor the upgrade using `kubectl get helmreleases -n bigbang` and
`kubectl get pods -n bigbang`.  Refer to the troubleshooting
documentation if pods fail to come up.

## 5. Post‑upgrade tasks

* Verify that all core services are functioning as expected.
* Update documentation and runbooks to reflect new features.
* If new packages were enabled, configure access and credentials.

Upgrades should be tested in a non‑production environment before
applying to production clusters.