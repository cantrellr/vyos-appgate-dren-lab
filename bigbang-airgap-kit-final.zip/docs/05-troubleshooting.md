# 05 — Troubleshooting

This chapter collects common issues encountered during an air‑gapped
deployment of Big Bang and suggests possible resolutions.  Always
consult the logs of the affected pods (`kubectl logs`) and Flux
resources (`flux logs`) for more details.

## Long installation times

The initial deployment can take tens of minutes because all
container images must be downloaded.  The Quick Start warns that slow
network connectivity to the upstream registry leads to long waits【933028610960299†L1032-L1036】.
To mitigate:

* Run `scripts/02-pull-retag-push.sh` from a location with fast
  connectivity.
* Use `skopeo copy` or a corporate cache to mirror images faster.
* Ensure your private registry is reachable with sufficient bandwidth
  from both your workstation and the cluster.

## “ImagePullBackOff” or “ErrImagePull” errors

If pods fail to pull images after deployment:

1. Verify that the image exists in your private registry by running
   `docker pull <altregistry>/<path>:<tag>`.
2. Ensure that `config/registries.yaml` is correctly configured on
   each node and that containerd has been restarted.
3. Check the secret in the `bigbang` namespace (`regcred`) to ensure
   credentials are valid.  If your registry uses a self‑signed
   certificate, make sure the cluster trusts the certificate.

## Flux errors

### HelmChart fails to download

If Flux cannot fetch the Big Bang chart, ensure that the Helm
repository URL and version are correct.  For air‑gapped installs,
mirror the chart archive into your own Git or registry and update
`scripts/05-deploy-bigbang.sh` accordingly.

### HelmRelease stuck in “Ready” false

Inspect the Helm release status using `kubectl get helmreleases -n
bigbang -o yaml` and `flux logs`.  Common causes include:

* Invalid values in your `config/values-example.yaml` (duplicate keys
  or syntax errors).
* Missing secrets or config maps referenced by the chart.
* Insufficient cluster resources.

## Services are not reachable

If you cannot access Grafana, Kiali or other dashboards:

* Check the status of the Istio ingress gateway and load balancer
  service (`kubectl get svc -n istio-system`).  Ensure an external IP
  or node port is assigned.
* Verify DNS or `/etc/hosts` entries for your chosen hostname.
* Ensure that your firewall allows traffic to the ingress port (443).

## Upgrading Big Bang fails

See `docs/06-upgrade.md` for guidance on upgrading.  Typically,
upgrades fail if you forget to mirror new images or adjust values for
changes between releases.