# 02 — Image Management

Deploying Big Bang in an air‑gapped environment requires explicit
management of container images.  The official Big Bang airgap guide
explains that all images needed to run Big Bang are packaged in
`images.tar.gz`, with a list of image references provided in
`images.txt`【851617246581943†L1036-L1040】.  This kit extends that idea by
automating the generation, mirroring and verification of images.

## Generating the image list

Use the script `scripts/01-generate-image-list.sh` to produce a
machine‑readable list of container images for the version of Big Bang
you intend to deploy.  The script performs the following steps:

1. Pulls the Big Bang Helm chart (specified by version) from the
   configured source (e.g., `oci://registry1.dso.mil/ironbank/bigbang/bigbang`).
2. Renders the chart with `helm template` and extracts all
   `image:` references using `yq`.
3. Normalises and de‑duplicates the list, writing the result to
   `images/bigbang-images.yaml`.

If you already have an upstream `images.txt` from a Big Bang release,
you can convert it into YAML by running:

```sh
awk -F: '{print "  - name: "$1"\n    tag: "$2}' images.txt > images/bigbang-images.yaml
```

## Mirroring images into your private registry

Once you have `images/bigbang-images.yaml`, use
`scripts/02-pull-retag-push.sh` to download each image from
`registry1.dso.mil`, retag it to your private registry and push it.
The script reads the list from the YAML file and uses Docker by
default, but can be adapted to use Podman or Skopeo.  Before running
the script, set the following environment variables:

```sh
export ALT_REGISTRY=altregistry.dev.kube:8443
export ALT_USERNAME=<your-registry-user>
export ALT_PASSWORD=<your-registry-password>
./scripts/02-pull-retag-push.sh
```

The Big Bang documentation notes that a slow connection to the
upstream registry can cause long wait times【933028610960299†L1032-L1036】.
If you encounter timeouts, consider running the script from a network
with better connectivity or mirror images via `skopeo copy` to avoid
full pulls.

### Registry mirrors

RKE2 and other Kubernetes distributions support configuring
`containerd` to mirror upstream registries.  The sample
`config/registries.yaml` file shows how to map `registry1.dso.mil` to
your private registry.  Alternatively, you can import the images
directly into the cluster runtime using `scripts/04-load-images-into-cluster.sh`.

## Verifying the mirror

After pushing images, run `scripts/03-verify-images.sh` to ensure that
each retagged image can be pulled.  The script attempts to pull
images from your private registry and logs any that are missing.

You can also query your registry API to list repositories and tags,
e.g., `curl -k https://myregistry.example.com/v2/_catalog`, as shown in
the airgap guide【851617246581943†L1101-L1113】.

## Loading images into the cluster

If your cluster does not have connectivity to the private registry you
just populated (e.g. due to strict firewall rules), use
`scripts/04-load-images-into-cluster.sh` to import images into the
cluster’s container runtime.  This script saves the retagged images as
tar archives and uses `ctr images import` on each RKE2 node.