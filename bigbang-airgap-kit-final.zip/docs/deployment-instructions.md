# Deployment Instructions

This document provides a consolidated, step‑by‑step procedure for
deploying the Big Bang platform onto an RKE2 security cluster using
the air‑gapped kit in this repository.  It is intended for
operators who prefer a single reference rather than navigating the
individual chapters in the `docs/` directory.  For background and
architectural context, see `docs/system-design.md`.

## 1. Prepare your workstation

Install the required CLI tools on your workstation:

* [`kubectl`](https://kubernetes.io/docs/tasks/tools/) – interacts
  with the cluster.
* [`helm`](https://helm.sh/) – used to render charts locally and by
  Flux.
* [`flux`](https://fluxcd.io/docs/) – the GitOps controller.  The
  Quick Start guide lists these and other tools (e.g. `jq`, `yq`)【933028610960299†L944-L967】.
* [`skopeo`](https://github.com/containers/skopeo) or
  [`crane`](https://github.com/google/go-containerregistry) – for
  copying container images between registries.

Ensure you have access to a private registry and credentials if
authentication is required.

## 2. Generate a list of container images

1. Clone or fork this repository.
2. Edit `scripts/01-generate-image-list.sh` to specify the chart
   version of Big Bang you intend to deploy.  Then run:

   ```sh
   bash scripts/01-generate-image-list.sh
   ```

   The script pulls the Big Bang chart, renders it using `helm` and
   extracts all container image references.  It writes them to
   `images/bigbang-images.yaml` in YAML format.  You can verify
   additional images in the Big Bang release’s `images.txt` file for
   air‑gapped deployment【851617246581943†L1036-L1040】.

## 3. Mirror images to your private registry

1. Set the environment variables used by the mirroring script:

   ```sh
   export ALT_REGISTRY=altregistry.dev.kube:8443
   export ALT_USERNAME=<your‑registry‑username>
   export ALT_PASSWORD=<your‑registry‑password>
   ```

2. Run the mirroring script:

   ```sh
   bash scripts/02-pull-retag-push.sh
   ```

   The script reads `images/bigbang-images.yaml`, logs in to the
   private registry (if credentials are provided), pulls each image
   from the upstream registry, retags it with your registry prefix and
   pushes it.  Results are logged to `image_prep.log`.

3. Verify that the images are present in your registry by querying
   its catalogue.  The Airgap guide provides an example using
   `curl` against the registry’s `/v2/_catalog` endpoint【851617246581943†L1101-L1113】.

4. Optionally run:

   ```sh
   bash scripts/03-verify-images.sh
   ```

   to attempt to pull each mirrored image from the private registry
   and report any missing tags.

## 4. Prepare the RKE2 cluster

1. Install RKE2 on your target nodes according to the official
   documentation.  Ensure that each node has at least 8 CPUs and
   32 GiB of memory【933028610960299†L996-L999】.
2. Copy `config/registries.yaml` into `/etc/rancher/rke2/` on each
   node.  This config instructs containerd to mirror
   `registry1.dso.mil` to your private registry.  Restart RKE2 to
   apply the changes.
3. If the private registry cannot be reached from the cluster,
   transfer the mirrored images tar files to each node and run
   `scripts/04-load-images-into-cluster.sh` to import them into
   containerd.

## 5. Install Flux

Install the Flux components in your cluster:

```sh
flux install \
  --components-extra=image-reflector-controller,image-automation-controller
```

This command creates the `flux-system` namespace and deploys Flux
controllers.  You should run this from your workstation with
`kubectl` context pointing to the cluster.

## 6. Configure namespaces and secrets

1. Create the namespace for Big Bang:

   ```sh
   kubectl apply -f manifests/namespace.yaml
   ```

2. Create a Docker registry secret containing your private registry
   credentials.  Replace variables accordingly:

   ```sh
   kubectl create secret docker-registry regcred \
     --namespace=bigbang \
     --docker-server=${ALT_REGISTRY} \
     --docker-username=${ALT_USERNAME} \
     --docker-password=${ALT_PASSWORD} \
     --docker-email="user@example.com"
   ```

3. Edit `config/values-example.yaml` to set the `domain`,
   `registryCredentials.name`, `registryCredentials.namespace` and
   optionally tweak package values.

## 7. Configure GitOps sources

1. Fork this repository to your own Git server or push it to a
   repository accessible by Flux.
2. Create a `GitRepository` resource pointing to your fork:

   ```sh
   flux create source git bigbang-kit \
     --url=https://git.example.com/youruser/bigbang-airgap-kit.git \
     --branch=main \
     --interval=5m
   ```

3. Create a `HelmRelease` resource to deploy Big Bang.  You can use
   the CLI or let the provided script create it for you:

   ```sh
   flux create helmrelease bigbang \
     --source=bigbang-kit \
     --chart=charts/bigbang \
     --version="3.8.0" \
     --namespace=bigbang \
     --values=config/values-example.yaml \
     --interval=5m
   ```

Alternatively, run:

```sh
bash scripts/05-deploy-bigbang.sh
```

which installs Flux (if necessary), creates the namespace and secret,
and defines the Git source and Helm release.

## 8. Monitor deployment

Deployment may take a significant amount of time because the cluster
must download all container images【933028610960299†L1032-L1036】.  You
can monitor progress using:

```sh
kubectl get hr -n bigbang
kubectl get pods -n bigbang
flux get all -A
```

Wait until all pods are in the `Running` or `Succeeded` state and the
`HelmRelease` reports `Ready`.

## 9. Post‑deployment tasks

1. Configure DNS to map your chosen domain (e.g. `bigbang.example.com`)
   to the external IP of the Istio ingress gateway.  Use
   `kubectl get svc -n istio-system` to find the IP.
2. Access dashboards:
   * **Grafana** – `https://grafana.<your-domain>` (default admin
     password defined in `values-example.yaml`).
   * **Kiali** – `https://kiali.<your-domain>`.
   * **NeuVector** – `https://neuvector.<your-domain>`.
3. Explore additional packages and mission applications.  See
   `docs/04-post-deployment.md` for suggestions.

## 10. Upgrades and maintenance

When new Big Bang releases are published:

1. Update the chart version in `scripts/01-generate-image-list.sh` and
   regenerate `bigbang-images.yaml`.
2. Rerun `scripts/02-pull-retag-push.sh` to mirror new images.
3. Update the `HelmRelease` version and push changes to Git.  Flux
   will automatically upgrade your deployment.
4. Perform routine maintenance such as rotating secrets, applying
   operating system patches, monitoring resource usage and testing
   backups.

For troubleshooting tips, see `docs/05-troubleshooting.md`.