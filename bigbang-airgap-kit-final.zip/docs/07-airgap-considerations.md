# 07 — Air‑Gap Considerations

Deploying Big Bang in a completely disconnected environment requires
careful planning.  The official airgap guide notes that the images
needed to run Big Bang are bundled in `images.tar.gz` and listed in
`images.txt`【851617246581943†L1036-L1040】.  You must load these images
into a private registry and configure your cluster to use that
registry.

## Setting up a private registry

There are many options for hosting a private registry, including
Harbor, Docker Distribution (`registry:2`), GitLab Container Registry
and JFrog Artifactory.  The airgap guide provides an example using
Docker Distribution and self‑signed certificates【851617246581943†L1047-L1094】.
Key steps:

1. Extract `images.tar.gz` and load the `registry:2` image onto your
   registry host.
2. Generate TLS certificates for your registry.  Provide appropriate
   Common Name and Subject Alternative Names (SANs)【851617246581943†L1063-L1076】.
3. Run the registry container with mounted certificates and
   configuration.  See the sample `registry.sh` in the airgap guide.
4. Verify that the registry is reachable by running
   `curl -k https://<registry-host>:5443/v2/_catalog`【851617246581943†L1101-L1113】.

This kit assumes that you have an existing registry available at
`altregistry.dev.kube:8443`.  You may adapt the provided scripts to
bootstrap your own registry.

## Mirroring and registry configuration

When your cluster cannot access the upstream registry
(`registry1.dso.mil`), configure containerd to mirror the upstream
registries to your private registry.  The sample `config/registries.yaml`
shows how to map `registry1.dso.mil` to your internal endpoint.  Copy
the file into `/etc/rancher/rke2/` and restart the `rke2-server`
service.  For other distributions, refer to the relevant documentation.

Alternatively, import the images directly into the cluster’s
runtime using `ctr images import` (see `scripts/04-load-images-into-cluster.sh`).

## Package charts offline

To install Helm charts in an air‑gap you must mirror not only the
container images but also the chart packages.  You can mirror the
Big Bang chart by running `helm pull oci://registry1.dso.mil/ironbank/bigbang/bigbang
--version <version> --untar --untardir charts/` and committing the
extracted chart into this repository or hosting it in your own OCI
registry.  Update `scripts/05-deploy-bigbang.sh` to reference the
local chart directory or your mirrored repository.