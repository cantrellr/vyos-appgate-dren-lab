# 01 — Prerequisites

This chapter describes the requirements for your workstation, the target
Kubernetes cluster and supporting infrastructure.  Many of these
requirements are adapted from the official Big Bang Quick Start
documentation【933028610960299†L944-L967】.

## Workstation

You should use a UNIX‑like system (Linux or macOS) or Windows with
WSL2.  Ensure you have a functional GNU environment with Git and the
following command‑line utilities installed:

| Tool            | Purpose                                   | Installation link |
|-----------------|--------------------------------------------|------------------|
| `bash` (≥ 4.x)   | Required shell for the provided scripts    | N/A (usually preinstalled) |
| [`kubectl`](https://kubernetes.io/docs/tasks/tools/) | Interact with your RKE2 cluster | Official Kubernetes packages |
| [`helm`](https://helm.sh/) (≥ 3.9) | Install and manage charts | Download from helm.sh |
| [`flux`](https://fluxcd.io/) (≥ 2.1) | GitOps engine for Kubernetes | Install via brew, apt or official script |
| [`jq`](https://jqlang.github.io/jq/) | JSON processor used by scripts | Package manager or binary download |
| [`yq`](https://github.com/mikefarah/yq) (≥ 4.45.1) | YAML processor for scripting | Install via brew, pip or binary |
| [`docker`](https://docs.docker.com/) or [`podman`](https://podman.io/) | Used to pull, retag and push images | Package manager or official installer |
| [`skopeo`](https://github.com/containers/skopeo) (optional) | Verify remote images without pulling them | Package manager |

In addition, ensure you have an account on
[Platform One’s Registry1](https://registry1.dso.mil/) to download
upstream images【933028610960299†L967-L969】.  You will need your
username and CLI secret to authenticate.

## Target cluster

* **RKE2 installation** – Install RKE2 on one or more nodes.
  You should allocate at least 8 vCPUs, 32 GiB RAM and 150 GiB of
  storage for a minimal production cluster; more resources are
  recommended for high availability or additional Big Bang packages.
* **Network connectivity** – The cluster must be able to pull images
  from your private registry.  If the cluster is completely
  air‑gapped, plan to import images into the cluster’s container
  runtime (see `scripts/04-load-images-into-cluster.sh`).
* **DNS** – Configure DNS or `/etc/hosts` entries for the
  `hostname` you plan to use (e.g. `bigbang.example.com`) so that
  external clients can reach the Istio ingress gateway.
* **Storage class** – Ensure a default storage class is configured
  for persistent volumes (e.g., `longhorn` on bare‑metal or `gp2` on AWS).

## Private registry

A private registry is required to host the container images used by
Big Bang.  This can be hosted on a VM, on an appliance like Harbor,
or as part of your RKE2 cluster.  The registry should be reachable
from both your workstation (for pushing images) and the RKE2 cluster
(for pulling images).  Credentials should be stored securely and
referenced in `config/values-example.yaml`.