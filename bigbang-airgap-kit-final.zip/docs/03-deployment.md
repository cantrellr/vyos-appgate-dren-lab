# 03 — Deployment

This chapter guides you through deploying Big Bang onto an RKE2
cluster using GitOps principles.  Before proceeding ensure you have
completed the prerequisites and image management steps described in
previous chapters.

## Step 1: Prepare your cluster

1. Install RKE2 on your servers and configure `kubectl` access.
   Follow the instructions on the RKE2 website for your operating
   system.  Ensure that a default storage class is present and that
   nodes have sufficient resources (see the prerequisites chapter).
2. Configure your cluster runtime to mirror your private registry.
   Copy `config/registries.yaml` into `/etc/rancher/rke2/` on each
   node and restart RKE2.  The sample file instructs containerd to
   pull images from `altregistry.dev.kube:8443` when a request is
   made to `registry1.dso.mil`.
3. (Optional) Import images into the cluster.  If your cluster cannot
   reach the private registry, run
   `scripts/04-load-images-into-cluster.sh` from a node with access to
   the image tar files.

## Step 2: Install Flux

Flux is the GitOps engine that will watch this repository and apply
changes automatically.  Install it on your cluster:

```sh
flux install \
  --components-extra=image-reflector-controller,image-automation-controller
```

This creates the `flux-system` namespace and deploys the source,
kustomize and helm controllers.

## Step 3: Create namespaces and secrets

1. Create the namespace for Big Bang:

```sh
kubectl apply -f manifests/namespace.yaml
```

2. Create a Docker registry secret in the `bigbang` namespace
   containing credentials for your private registry:

```sh
kubectl create secret docker-registry regcred \
  --namespace bigbang \
  --docker-server=${ALT_REGISTRY} \
  --docker-username=${ALT_USERNAME} \
  --docker-password=${ALT_PASSWORD} \
  --docker-email="user@example.com"
```

The name `regcred` must match the reference used in your values file
(see `config/values-example.yaml`).  If your registry does not
require authentication you may skip this step and remove the
`registryCredentials` block from your values file.

## Step 4: Configure GitOps sources

Flux pulls configuration from Git.  You can use this repository as a
local source or push it to your own Git server.  Create a
`GitRepository` resource that points to your fork and a corresponding
`Kustomization` or `HelmRelease` to deploy Big Bang.  For example:

```sh
flux create source git bigbang-kit \
  --url=https://git.example.com/youruser/bigbang-airgap-kit.git \
  --branch=main \
  --interval=5m 

flux create helmchart bigbang \
  --source=bigbang-kit \
  --chart=charts/bigbang \
  --version="3.8.0" \
  --interval=5m

flux create helmrelease bigbang \
  --source=bigbang-kit \
  --chart=charts/bigbang \
  --version="3.8.0" \
  --namespace=bigbang \
  --values=config/values-example.yaml \
  --interval=5m
```

Alternatively, you can run the provided script:

```sh
scripts/05-deploy-bigbang.sh
```

which encapsulates the steps above.

## Step 5: Monitor the deployment

Use the following commands to track progress:

```sh
kubectl get hr -n bigbang
kubectl get pods -n bigbang
flux get all -A
```

Initial deployment can take a long time because all container images
must be downloaded【933028610960299†L1032-L1036】.  Be patient and
monitor the status of pods until they are ready.

## Step 6: Access services

Configure DNS for your chosen hostname (e.g. `bigbang.example.com`) to
point to the external IP address of the Istio ingress gateway (check
`kubectl get svc -n istio-system` to find the IP).  Then access
services such as Grafana (`https://grafana.<hostname>`), Kiali
(`https://kiali.<hostname>`), Kyverno policy reporter and others.

Refer to `docs/04-post-deployment.md` for additional post‑install
tasks.