# System Design for Big Bang Air‑Gapped RKE2 Security Cluster

## Purpose and scope

This document describes the architecture and design decisions behind
the Big Bang air‑gapped deployment kit contained in this repository.
Its purpose is to enable repeatable, secure deployment of the
Big Bang platform onto a stand‑alone
[RKE2](https://docs.rke2.io/) cluster that functions as a security
cluster in environments with no or limited internet access.  The
design draws inspiration from the `k8s‑mystical‑mesh` pattern and
incorporates best practices for image management, private registry
mirroring, GitOps workflows and operational hardening.  Throughout
this document you will find citations to the official Big Bang
documentation for reference.

## System context

The deployment environment consists of three main actors:

1. **Developer workstation** – where operators prepare container
   images, generate manifests and initiate deployment.  This host
   must have `kubectl`, `helm`, `flux`, `jq`, `yq` and other CLI
   tools installed【933028610960299†L944-L967】.
2. **Private container registry** – an internal registry (e.g.
   Harbor, Quay or Artifactory) reachable from both the workstation
   and the cluster.  It hosts all container images required by
   Big Bang.  For air‑gapped deployments Big Bang packages its
   required images into `images.tar.gz` and lists them in
   `images.txt`【851617246581943†L1036-L1040】, which we mirror into
   the private registry.
3. **RKE2 security cluster** – the target Kubernetes cluster.  It
   runs a high‑availability control plane and worker nodes with
   hardened configuration.  Containerd is configured to pull from
   the private registry rather than upstream registries.  The
   recommended minimum resources are 8 CPUs and 32 GiB RAM per node
   (see the Big Bang Quick Start hardware guidance【933028610960299†L996-L999】).

Additionally, a **Git server** hosts this repository or your fork.
Flux on the cluster pulls manifests and values from Git and
reconciles them into the cluster.

## High‑level architecture

![High‑Level Deployment Diagram](bigbang-diagram.png)

The diagram above summarises the flow of artefacts and control in the
system:

* Operators on the workstation run scripts (`01‑generate‑image‑list.sh`,
  `02‑pull‑retag‑push.sh`) to discover all container images used by
  the Big Bang Helm chart and mirror them into the private registry.
* The RKE2 cluster’s container runtime is configured to mirror
  `registry1.dso.mil` (Big Bang’s upstream registry) to
  `altregistry.dev.kube:8443` using the `config/registries.yaml` file.
  The Airgap guide explains how to set up a local registry with TLS
  certificates【851617246581943†L1047-L1094】 and verify it via
  `/v2/_catalog`【851617246581943†L1101-L1113】.
* A Flux GitOps controller runs in the cluster.  It watches a
  `GitRepository` source (pointing to this repository or your fork)
  and applies `Kustomization` and `HelmRelease` objects.  Flux
  installs the Big Bang chart and manages upgrades.
* Big Bang is a Helm umbrella chart that deploys several core
  packages: Istio CRDs and control plane, Istio ingress gateways,
  Kiali, Kyverno, Loki, metrics‑server, Tempo, Grafana and
  NeuVector【933028610960299†L920-L936】.  Additional packages can be
  enabled or disabled via the values file.

## Component descriptions

### Big Bang packages

Big Bang groups related open‑source projects into logical packages.
The default installation includes the following, each of which can be
tuned or disabled:

| Package        | Purpose                                                     |
|---------------|-------------------------------------------------------------|
| **Istio**     | Provides a service mesh, secure mTLS networking, ingress
|               | gateways and policy enforcement.                             |
| **Kiali**     | Observability dashboard for Istio service mesh.             |
| **Kyverno**   | Kubernetes policy engine used for supply‑chain and RBAC
|               | policies.                                                   |
| **Loki**      | Log aggregation backend.                                    |
| **Metrics Server** | Kubernetes resource metrics API used by autoscalers.|
| **Tempo**     | Distributed tracing backend.                                |
| **Grafana**   | Visualisation and dashboarding.                             |
| **NeuVector** | Container runtime security and network isolation.           |

These components together provide secure networking, observability,
policy enforcement and runtime defence for mission workloads.  The
list above corresponds to the default values from the Big Bang Quick
Start guide【933028610960299†L920-L936】.  Additional packages (e.g.
Elasticsearch, ArgoCD, GitLab) can be enabled by editing
`config/values-example.yaml`.

### Private registry

Air‑gapped installations require that all images be hosted on an
internal registry accessible from the cluster.  The Big Bang Airgap
guide describes generating TLS certificates, creating a registry and
using tools like `skopeo` or `crane` to copy images from
`registry1.dso.mil` to the private registry【851617246581943†L1047-L1094】.
Our scripts automate this process: `01‑generate‑image‑list.sh`
renders the Helm chart to discover image references; `02‑pull‑retag‑push.sh`
pulls and retags them; `03‑verify‑images.sh` confirms that all
mirrored images are available; `04‑load‑images‑into‑cluster.sh` can be
used to load images directly into containerd if the registry is not
reachable from the cluster.

### RKE2 cluster configuration

The RKE2 nodes should be configured to mirror upstream registries.
Place `config/registries.yaml` under `/etc/rancher/rke2/` on each node
and restart RKE2.  This file instructs containerd to redirect image
pulls from `registry1.dso.mil` to your private registry.  If your
registry uses self‑signed certificates, add them to
`/etc/rancher/rke2/certs.d/` and update `registries.yaml` accordingly.
The Airgap guide provides an example of using `registry:2` and
OpenSSL to generate certificates【851617246581943†L1047-L1094】【851617246581943†L1063-L1076】.

### GitOps workflow

Flux is installed into the `flux-system` namespace using `flux install`.
You configure a `GitRepository` pointing to your fork of this kit and
a `HelmRelease` to install Big Bang.  Flux will periodically pull
changes from Git and reconcile them into the cluster.  This allows
declarative, repeatable deployments and enables easy upgrades.  When
you change `config/values-example.yaml` or update the Big Bang chart
version, Flux will automatically perform the upgrade.

### Deployment script

The provided script `scripts/05-deploy-bigbang.sh` orchestrates the
deployment: it installs Flux if necessary, creates the `bigbang`
namespace and registry secret, and applies the Flux resources.  You
can also perform these steps manually using the CLI commands shown in
`docs/03-deployment.md`.

## Data flows

The deployment process comprises several stages:

1. **Image discovery** – `01‑generate‑image‑list.sh` uses the Helm
   chart and `yq` to enumerate all container images.  This ensures
   that dependencies such as Prometheus exporters, sidecars and
   init containers are included.  You can regenerate the list for
   different chart versions.
2. **Image mirroring** – `02‑pull‑retag‑push.sh` pulls each image
   from the upstream registry, retags it with your private registry
   prefix and pushes it.  The script logs successes and failures.
3. **Verification** – `03‑verify‑images.sh` attempts to pull each
   retagged image from your registry.  Missing images are
   enumerated for resolution.
4. **Cluster preparation** – RKE2 is installed and configured to
   mirror registries.  Optional: `04‑load‑images‑into‑cluster.sh`
   loads the images directly if the registry cannot be reached.
5. **Deployment** – `05‑deploy‑bigbang.sh` installs Flux and applies
   the `HelmRelease` using your `config/values-example.yaml`.
   Initial deployment may take a long time because images are
   downloaded【933028610960299†L1032-L1036】; monitor the pods and
   helm releases until they are ready.
6. **Post‑deployment** – After Big Bang is ready, verify the
   components, configure DNS for your chosen domain and log into
   dashboards like Grafana, Kiali and NeuVector.  Additional
   mission applications can be installed on top of Big Bang.

## Operational considerations

* **Security** – Big Bang is designed to meet DoD Platform One
  Iron Bank requirements and FIPS standards.  However, you must
  perform additional hardening such as STIG remediation, audit log
  collection and RBAC tuning.  Always validate that your cluster
  complies with your organisation’s security policies.
* **Upgrades** – When upgrading Big Bang, regenerate your image
  list, mirror the new images and update the chart version in your
  `HelmRelease` resource.  Perform upgrades in a test environment
  before applying them to production.
* **Networking** – Ensure that your cluster nodes can reach the
  private registry.  Use a load balancer or VIP for the registry if
  deploying across multiple nodes.  Configure DNS to route service
  traffic to the Istio ingress gateway.
* **Storage** – Provide persistent volumes (PV/PVC) for Grafana,
  Prometheus (if enabled) and other stateful components.  Storage
  must meet performance requirements.
* **Monitoring & alerting** – Use Grafana and Tempo to monitor
  service health and performance.  Integrate with external alerting
  systems if required.

## References

The information in this design document is based on the official
Big Bang documentation, including the Quick Start guide and Airgap
guide.  Key references include:

* Default components installed by Big Bang【933028610960299†L920-L936】.
* Workstation prerequisites【933028610960299†L944-L967】.
* Guidance on slow initial deployment due to image downloads【933028610960299†L1032-L1036】.
* Packaging of images in `images.tar.gz` and `images.txt` for
  air‑gapped deployments【851617246581943†L1036-L1040】.
* Steps for setting up a private registry with TLS certificates【851617246581943†L1047-L1094】【851617246581943†L1063-L1076】.
* Verifying the registry’s catalogue【851617246581943†L1101-L1113】.

For further reading, consult the Big Bang documentation at
<https://docs-bigbang.dso.mil/latest/docs/>.