const pptxgen = require('pptxgenjs');
const fs = require('fs');

/*
 * This script generates a PowerPoint presentation summarising the
 * system design and deployment process for the Big Bang air‑gap kit.
 * Run `node slides/create_slides.js` from the repository root to
 * produce `slides/bigbang-airgap-kit.pptx`.  The resulting file can
 * be used for training sessions, briefings or documentation.
 */

async function buildPresentation() {
  const pptx = new pptxgen();
  pptx.defineLayout({ name: '16x9', width: 10, height: 5.625 });
  pptx.layout = '16x9';

  // Helper to load an image from disk and convert to data URI
  function loadImage(filePath) {
    const img = fs.readFileSync(filePath);
    const b64 = img.toString('base64');
    const ext = filePath.split('.').pop();
    return `data:image/${ext};base64,${b64}`;
  }

  // Read the architecture diagram for later use.  Use __dirname to build
  // a path relative to this script so it works when executed from the
  // repository root.  The diagram is stored in the docs/ directory.
  const path = require('path');
  const diagramPath = path.join(__dirname, '..', 'docs', 'bigbang-diagram.png');
  const diagram = loadImage(diagramPath);

  // Colour palette
  const colors = {
    primary: '11355E',      // dark blue
    secondary: '0A6496',    // medium blue
    accent: '007ACC',       // azure
    light: 'F5F5F5',        // very light grey
    darkText: '333333',
    lightText: '666666'
  };

  // Title slide
  let slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Big Bang Air‑Gap Kit', {
    x: 0.5, y: 1.5, w: 9, h: 1.0,
    fontSize: 40, bold: true, color: colors.primary
  });
  slide.addText('RKE2 Security Cluster Deployment', {
    x: 0.5, y: 2.6, w: 9, h: 0.7,
    fontSize: 18, color: colors.secondary
  });
  slide.addText('System Design & Deployment Overview', {
    x: 0.5, y: 3.4, w: 9, h: 0.6,
    fontSize: 14, italic: true, color: colors.lightText
  });
  slide.addText(' ', { x:0, y:0, w:0, h:0 }); // anchor to avoid first shape cropping

  // Agenda slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Agenda', {
    x: 0.5, y: 0.5, w: 9, h: 0.7,
    fontSize: 28, bold: true, color: colors.primary
  });
  const agendaItems = [
    'Overview & Motivation',
    'Architecture & Components',
    'Deployment Workflow',
    'Operations & Best Practices',
    'Summary'
  ];
  agendaItems.forEach((text, idx) => {
    slide.addText([
      { text: `${idx + 1}. `, options: { color: colors.secondary, fontSize: 18, bold: true } },
      { text, options: { color: colors.darkText, fontSize: 18 } }
    ], { x: 0.7, y: 1.4 + idx * 0.5, w: 8, h: 0.5, bullet: false });
  });

  // Overview slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Overview & Motivation', {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 26, bold: true, color: colors.primary
  });
  slide.addText([
    { text: '• ', options: { color: colors.secondary, fontSize: 18 } },
    { text: 'Deploy Big Bang in disconnected or high security environments.', options: { color: colors.darkText, fontSize: 18 } }
  ], { x: 0.7, y: 1.3, w: 9, h: 0.5 });
  slide.addText([
    { text: '• ', options: { color: colors.secondary, fontSize: 18 } },
    { text: 'Mirror and manage container images via an internal registry.', options: { color: colors.darkText, fontSize: 18 } }
  ], { x: 0.7, y: 1.8, w: 9, h: 0.5 });
  slide.addText([
    { text: '• ', options: { color: colors.secondary, fontSize: 18 } },
    { text: 'Leverage GitOps to ensure repeatable, declarative deployments.', options: { color: colors.darkText, fontSize: 18 } }
  ], { x: 0.7, y: 2.3, w: 9, h: 0.5 });

  // Architecture & Components slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Architecture & Components', {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 26, bold: true, color: colors.primary
  });
  // Left column: bullet points for main components
  const components = [
    { title: 'Developer Workstation', desc: 'Generates image list, mirrors images and initiates deployment.' },
    { title: 'Private Registry', desc: 'Hosts mirrored images and serves them to RKE2 cluster.' },
    { title: 'RKE2 Cluster', desc: 'High‑availability Kubernetes cluster hardened for security.' },
    { title: 'Flux GitOps', desc: 'Automates deployment of Big Bang from Git.' },
    { title: 'Big Bang Packages', desc: 'Istio, Kiali, Kyverno, Loki, metrics‑server, Tempo, Grafana, NeuVector.' }
  ];
  let yPos = 1.2;
  components.forEach((comp) => {
    slide.addText([
      { text: comp.title + ': ', options: { color: colors.secondary, fontSize: 14, bold: true } },
      { text: comp.desc, options: { color: colors.darkText, fontSize: 14 } }
    ], { x: 0.5, y: yPos, w: 5.0, h: 0.5, wrap: true });
    yPos += 0.6;
  });
  // Right column: embed diagram
  slide.addImage({ data: diagram, x: 5.7, y: 1.2, w: 4.0, h: 3.0 });

  // Deployment Workflow slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Deployment Workflow', {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 26, bold: true, color: colors.primary
  });
  const steps = [
    'Generate image list with Helm and yq.',
    'Mirror images to your private registry.',
    'Prepare the RKE2 cluster and configure registry mirrors.',
    'Install Flux and create GitOps sources.',
    'Deploy Big Bang via HelmRelease and monitor rollout.'
  ];
  steps.forEach((item, idx) => {
    slide.addText([
      { text: `${idx + 1}. `, options: { color: colors.secondary, fontSize: 16, bold: true } },
      { text: item, options: { color: colors.darkText, fontSize: 16 } }
    ], { x: 0.7, y: 1.4 + idx * 0.5, w: 8.5, h: 0.5, wrap: true });
  });

  // Operations & Best Practices slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Operations & Best Practices', {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 26, bold: true, color: colors.primary
  });
  const practices = [
    'Harden the cluster: apply STIG remediation and enable audit logging.',
    'Regularly update images and chart versions; test upgrades in staging.',
    'Monitor component health via Grafana, Loki and Tempo.',
    'Secure registry access with TLS and authentication.',
    'Automate everything with GitOps to avoid drift.'
  ];
  practices.forEach((item, idx) => {
    slide.addText([
      { text: '• ', options: { color: colors.secondary, fontSize: 16 } },
      { text: item, options: { color: colors.darkText, fontSize: 16 } }
    ], { x: 0.7, y: 1.4 + idx * 0.45, w: 8.8, h: 0.5, wrap: true });
  });

  // Summary slide
  slide = pptx.addSlide();
  slide.background = { fill: colors.light };
  slide.addText('Summary', {
    x: 0.5, y: 0.4, w: 9, h: 0.6,
    fontSize: 26, bold: true, color: colors.primary
  });
  slide.addText([
    { text: 'You now have a complete toolkit for deploying Big Bang on RKE2 in air‑gapped environments.', options: { color: colors.darkText, fontSize: 16 } },
    { text: '\n\n', options: {} },
    { text: 'Use the scripts to mirror images, prepare your cluster, install Flux and deploy the chart.', options: { color: colors.darkText, fontSize: 16 } },
    { text: '\n\n', options: {} },
    { text: 'Follow best practices for security, monitoring and upgrades to maintain a resilient platform.', options: { color: colors.darkText, fontSize: 16 } }
  ], { x: 0.7, y: 1.3, w: 8.8, h: 3.5, wrap: true });

  // Write the file
  // Write the file into the same directory as this script
  const outputPath = path.join(__dirname, 'bigbang-airgap-kit.pptx');
  await pptx.writeFile({ fileName: outputPath });
  console.log(`Presentation created successfully at ${outputPath}`);
}

buildPresentation().catch((err) => console.error(err));