#!/usr/bin/env bash
# 03-verify-images.sh
#
# Verify that all retagged images exist in your private registry.  This
# script reads the images list and attempts to pull each image from
# the alternate registry.  Any missing images are recorded in a
# report.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

IMAGES_FILE="${IMAGES_FILE:-$SCRIPT_DIR/../images/bigbang-images.yaml}"
ALT_REGISTRY="${ALT_REGISTRY:?ALT_REGISTRY must be set to verify images}"

check_command docker
check_command yq

mapfile -t IMAGES < <(parse_images "$IMAGES_FILE")
MISSING=()

for IMAGE in "${IMAGES[@]}"; do
  DST_PATH="${IMAGE#registry1.dso.mil/}"
  DST="$ALT_REGISTRY/$DST_PATH"
  if ! verify_image "$DST"; then
    log_warn "Missing: $DST"
    MISSING+=("$DST")
  else
    log_info "Found: $DST"
  fi
done

if (( ${#MISSING[@]} > 0 )); then
  log_error "The following images are missing in $ALT_REGISTRY:"
  for IMG in "${MISSING[@]}"; do
    echo "  - $IMG"
  done
  exit 1
else
  log_info "All images are present in $ALT_REGISTRY"
fi