#!/usr/bin/env bash
# lib.sh
#
# Library functions for image operations and configuration.  This file
# assumes that util.sh is in the same directory and will source it to
# obtain logging and utility functions.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=util.sh
source "$SCRIPT_DIR/util.sh"

# Read a YAML images file and output a list of full image references
# in the form repository:tag.  Requires `yq` to be installed.
parse_images() {
  local yaml_file="$1"
  check_command yq
  yq -r '.images[] | .name + ":" + .tag' "$yaml_file"
}

# Pull an image using Docker or Podman.  If the pull fails the
# function logs a warning and returns non‑zero.
pull_image() {
  local image="$1"
  if ! docker pull "$image"; then
    log_warn "Failed to pull $image"
    return 1
  fi
}

# Tag an image for the destination registry.  Accepts source and
# destination image references.
retag_image() {
  local src="$1" dst="$2"
  docker tag "$src" "$dst"
}

# Push an image to the destination registry.  Logs progress.
push_image() {
  local dst="$1"
  if ! docker push "$dst"; then
    log_error "Failed to push $dst"
    return 1
  fi
}

# Verify that an image exists in the destination registry by
# attempting to pull it.  Returns 0 on success, 1 on failure.
verify_image() {
  local dst="$1"
  if docker pull "$dst" >/dev/null 2>&1; then
    return 0
  else
    return 1
  fi
}