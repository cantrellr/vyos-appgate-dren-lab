#!/usr/bin/env bash
# 04-load-images-into-cluster.sh
#
# Load retagged images into an RKE2 cluster's container runtime.  This
# script is useful when cluster nodes cannot pull from the private
# registry due to network restrictions.  It pulls each image from the
# private registry, saves it as a tar archive and imports it into
# containerd using `ctr images import`.  You must run this script on
# each RKE2 node with root privileges.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

IMAGES_FILE="${IMAGES_FILE:-$SCRIPT_DIR/../images/bigbang-images.yaml}"
ALT_REGISTRY="${ALT_REGISTRY:?ALT_REGISTRY must be set (e.g. altregistry.dev.kube:8443)}"

check_command docker
check_command ctr
check_command yq

mapfile -t IMAGES < <(parse_images "$IMAGES_FILE")

WORK_DIR="/tmp/bb-images"
mkdir -p "$WORK_DIR"

for IMAGE in "${IMAGES[@]}"; do
  DST_PATH="${IMAGE#registry1.dso.mil/}"
  DST="$ALT_REGISTRY/$DST_PATH"
  TAR_FILE="$WORK_DIR/$(echo "$DST_PATH" | tr '/:' '_').tar"
  log_info "Pulling $DST"
  docker pull "$DST"
  log_info "Saving $DST to $TAR_FILE"
  docker save -o "$TAR_FILE" "$DST"
  log_info "Importing $TAR_FILE into containerd"
  sudo ctr -n k8s.io images import "$TAR_FILE"
done

log_info "Image import completed.  You may remove $WORK_DIR to free space."