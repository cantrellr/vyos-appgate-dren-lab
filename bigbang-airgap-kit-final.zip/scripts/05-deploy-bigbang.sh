#!/usr/bin/env bash
# 05-deploy-bigbang.sh
#
# Install Big Bang onto an RKE2 cluster using Flux and Helm.  This
# script assumes you have mirrored images into your private registry
# and configured cluster access.  It creates the necessary
# namespaces, secrets and HelmRelease resources.  You can run this
# script from your workstation after setting the appropriate
# environment variables.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

NAMESPACE="${BB_NAMESPACE:-bigbang}"
RELEASE_NAME="${BB_RELEASE:-bigbang}"
BB_VERSION="${BB_VERSION:-3.8.0}"
CHART_SOURCE="${CHART_SOURCE:-oci://registry1.dso.mil/ironbank/bigbang/bigbang}"
VALUES_FILE="${VALUES_FILE:-$SCRIPT_DIR/../config/values-example.yaml}"
ALT_REGISTRY="${ALT_REGISTRY:-altregistry.dev.kube:8443}"
ALT_USERNAME="${ALT_USERNAME:-}"
ALT_PASSWORD="${ALT_PASSWORD:-}"

check_command helm
check_command kubectl
check_command flux

# Install Flux if it is not present
if ! kubectl get ns flux-system >/dev/null 2>&1; then
  log_info "Installing Flux controllers…"
  flux install --components-extra=image-reflector-controller,image-automation-controller
fi

# Create namespace
if ! kubectl get ns "$NAMESPACE" >/dev/null 2>&1; then
  log_info "Creating namespace $NAMESPACE"
  kubectl apply -f "$SCRIPT_DIR/../manifests/namespace.yaml"
fi

# Create registry secret if credentials provided
if [[ -n "$ALT_USERNAME" && -n "$ALT_PASSWORD" ]]; then
  if ! kubectl get secret regcred -n "$NAMESPACE" >/dev/null 2>&1; then
    log_info "Creating docker-registry secret regcred in $NAMESPACE"
    kubectl create secret docker-registry regcred \
      --namespace "$NAMESPACE" \
      --docker-server="$ALT_REGISTRY" \
      --docker-username="$ALT_USERNAME" \
      --docker-password="$ALT_PASSWORD" \
      --docker-email="user@example.com"
  fi
fi

# Deploy Big Bang using Helm.  If CHART_SOURCE is an OCI registry the helm
# client must be authenticated; otherwise specify a local chart directory.
log_info "Installing Big Bang chart version $BB_VERSION into namespace $NAMESPACE"
helm upgrade --install "$RELEASE_NAME" "$CHART_SOURCE" \
  --namespace "$NAMESPACE" \
  --create-namespace \
  --version "$BB_VERSION" \
  -f "$VALUES_FILE"

log_info "Big Bang deployment triggered.  Monitor using kubectl get hr -n $NAMESPACE"