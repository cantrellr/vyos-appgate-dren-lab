#!/usr/bin/env bash
# util.sh
#
# Common utility functions used by the scripts in this repository.  These
# functions provide simple logging and command availability checks.

set -o errexit -o pipefail -o nounset

# Print an informational message in green.
log_info() {
  echo -e "\e[32m[INFO] $*\e[0m"
}

# Print a warning message in yellow.
log_warn() {
  echo -e "\e[33m[WARN] $*\e[0m"
}

# Print an error message in red to stderr.
log_error() {
  echo -e "\e[31m[ERROR] $*\e[0m" >&2
}

# Check that a command exists in PATH; exit with an error if not.
check_command() {
  if ! command -v "$1" >/dev/null 2>&1; then
    log_error "Required command '$1' is not installed or not in PATH."
    exit 1
  fi
}

# Create a directory if it does not already exist.
ensure_dir() {
  mkdir -p "$1"
}