#!/usr/bin/env bash
# 01-generate-image-list.sh
#
# Generate a list of container images used by the Big Bang chart.
#
# This script pulls the specified version of the Big Bang Helm chart,
# renders it using `helm template`, extracts all image references
# and writes them to a YAML file under the `images/` directory.  It
# requires `helm`, `yq` and `grep`.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

BB_VERSION="${BB_VERSION:-3.8.0}"
CHART="oci://registry1.dso.mil/ironbank/bigbang/bigbang"
OUTPUT_FILE="${OUTPUT_FILE:-$SCRIPT_DIR/../images/bigbang-images.yaml}"

check_command helm
check_command yq

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT

log_info "Fetching Big Bang chart version ${BB_VERSION}…"
helm pull "$CHART" --version "$BB_VERSION" --untar --untardir "$TMP_DIR"

CHART_DIR="${TMP_DIR}/bigbang"

log_info "Rendering chart to extract image references…"
helm template bigbang "$CHART_DIR" > "$TMP_DIR/rendered.yaml"

log_info "Parsing images…"
IMAGES=$(grep -oE 'image:\s*"?[^" ]+"?' "$TMP_DIR/rendered.yaml" | awk '{print $2}' | sed 's/"//g' | sort -u)

ensure_dir "$(dirname "$OUTPUT_FILE")"
echo "images:" > "$OUTPUT_FILE"
for IMG in $IMAGES; do
  NAME="${IMG%:*}"
  TAG="${IMG##*:}"
  echo "  - name: $NAME" >> "$OUTPUT_FILE"
  echo "    tag: \"$TAG\"" >> "$OUTPUT_FILE"
done

log_info "Wrote $(wc -l < "$OUTPUT_FILE") lines to $OUTPUT_FILE"