#!/usr/bin/env bash
# 02-pull-retag-push.sh
#
# Pull all images defined in images/bigbang-images.yaml, retag them
# for the alternate registry and push them.  Requires Docker or
# Podman, plus `yq` and the helper functions in lib.sh.

set -o errexit -o pipefail -o nounset

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib.sh
source "$SCRIPT_DIR/lib.sh"

IMAGES_FILE="${IMAGES_FILE:-$SCRIPT_DIR/../images/bigbang-images.yaml}"
ALT_REGISTRY="${ALT_REGISTRY:?ALT_REGISTRY must be set (e.g. altregistry.dev.kube:8443)}"
ALT_USERNAME="${ALT_USERNAME:-}"
ALT_PASSWORD="${ALT_PASSWORD:-}"

check_command docker
check_command yq

log_info "Loading image list from $IMAGES_FILE"
mapfile -t IMAGES < <(parse_images "$IMAGES_FILE")

LOG_FILE="$(pwd)/pull_retag_push.log"
log_info "Logging to $LOG_FILE"
echo "Image pull/retag/push started at $(date)" > "$LOG_FILE"

if [[ -n "$ALT_USERNAME" && -n "$ALT_PASSWORD" ]]; then
  log_info "Logging into $ALT_REGISTRY"
  echo "$ALT_PASSWORD" | docker login "$ALT_REGISTRY" --username "$ALT_USERNAME" --password-stdin >> "$LOG_FILE" 2>&1
else
  log_info "Skipping registry login; assuming credentials are present or registry is anonymous"
fi

for IMAGE in "${IMAGES[@]}"; do
  SRC="$IMAGE"
  DST_PATH="${IMAGE#registry1.dso.mil/}"
  DST="$ALT_REGISTRY/$DST_PATH"
  log_info "Processing $SRC → $DST"
  echo "Processing $SRC → $DST" >> "$LOG_FILE"
  if pull_image "$SRC" >> "$LOG_FILE" 2>&1; then
    retag_image "$SRC" "$DST" >> "$LOG_FILE" 2>&1
    if push_image "$DST" >> "$LOG_FILE" 2>&1; then
      log_info "Pushed $DST"
    fi
  fi
done

log_info "Image mirror completed at $(date)"