# Big Bang Air‑Gapped Deployment Kit

This repository provides a comprehensive toolkit for deploying the
[Big Bang](https://docs-bigbang.dso.mil/latest/docs/) platform onto a
stand‑alone [RKE2](https://docs.rke2.io/) cluster in an air‑gapped or
internet‑restricted environment.  It is designed to be easy to fork
and extend, with modular scripts, well‑documented configuration files,
and detailed guidance.  The layout of the repository is inspired by
industry best practices and mirrors the structure shown in the
accompanying diagram.

## Contents

```
.
├── docs/                      # Detailed documentation covering every phase of deployment
│   ├── 00-overview.md
│   ├── 01-prerequisites.md
│   ├── 02-image-management.md
│   ├── 03-deployment.md
│   ├── 04-post-deployment.md
│   ├── 05-troubleshooting.md
│   ├── 06-upgrade.md
│   ├── 07-airgap-considerations.md
│   └── 08-appendix.md
├── images/
│   ├── bigbang-images.yaml    # Machine‑readable list of container images
│   └── README.md             # Explanation of the images list and how to update it
├── scripts/                  # All automation scripts used during the deployment
│   ├── 01-generate-image-list.sh
│   ├── 02-pull-retag-push.sh
│   ├── 03-verify-images.sh
│   ├── 04-load-images-into-cluster.sh
│   ├── 05-deploy-bigbang.sh
│   ├── lib.sh
│   └── util.sh
├── manifests/
│   ├── namespace.yaml
│   └── bigbang-cr.yaml
├── charts/
│   └── README.md             # Guidance on working with Helm charts
├── overlays/
│   ├── default/
│   │   └── kustomization.yaml
│   └── example-custom-values/
│       └── kustomization.yaml
├── config/
│   ├── mirror-config.yaml    # Example skopeo or crane mirror configuration
│   ├── registries.yaml       # RKE2 mirror configuration file
│   └── values-example.yaml   # Example Big Bang values file
├── .gitignore
├── LICENSE
└── README.md (this file)
```

In addition to the repository files, this project includes a detailed
system design document and deployment instructions, as well as
PowerPoint slides to help teach others how to use and extend this
kit.

## Quick Start

1. Read the documentation in `docs/` to understand the overall design,
   prerequisites and workflow.  The Big Bang Quick Start guide lists
   the core components installed by default (Istio, Istio‐Gateways,
   Kiali, Kyverno, Loki, metrics‑server, Tempo, Grafana and
   NeuVector)【933028610960299†L920-L936】 and outlines the tools you
   need on your workstation【933028610960299†L944-L967】.
2. Use `scripts/01-generate-image-list.sh` to produce a list of
   container images for the version of Big Bang you plan to deploy.
3. Run `scripts/02-pull-retag-push.sh` to pull images from the
   upstream registry, retag them for your private registry and push
   them.  Sample configuration for image mirrors is in
   `config/mirror-config.yaml`.
4. Import the images into your RKE2 cluster using
   `scripts/04-load-images-into-cluster.sh` (if your cluster cannot
   pull from the private registry directly).
5. Deploy Big Bang using `scripts/05-deploy-bigbang.sh` after
   customizing `config/values-example.yaml`.

For detailed instructions, refer to the `docs/03-deployment.md` and
`docs/04-post-deployment.md` sections.

## Additional resources

This kit is accompanied by supplementary material to help you and your
team understand the architecture and deployment process:

* **System design document** (`docs/system-design.md`) – An
  in‑depth description of the RKE2 security cluster architecture,
  component interactions and rationale behind design decisions.  It
  covers networking, security boundaries, registry mirroring,
  GitOps workflows and operational considerations.
* **Deployment instructions** – Step‑by‑step guidance is interwoven
  throughout the `docs/` directory (especially `03-deployment.md`),
  but a condensed summary is provided in the system design document.
* **Slide deck** (`slides/bigbang-airgap-kit.pptx`) – A PowerPoint
  presentation that visualises the system architecture, explains the
  deployment workflow and highlights best practices.  Use it for
  training sessions or executive briefings.