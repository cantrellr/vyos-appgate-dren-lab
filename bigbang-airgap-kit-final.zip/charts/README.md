# Charts

Big Bang is distributed as a Helm chart hosted on
`registry1.dso.mil` under the `ironbank/bigbang/bigbang` repository.  This
directory is reserved for chart sources used by this deployment kit.

In most cases you will not need to modify the Big Bang chart directly;
instead you control behaviour via the values file (`config/values-example.yaml`).
However, for air‑gapped deployments you may want to mirror the chart
into your own OCI registry or extract it into this directory.  To do
so:

```sh
helm pull oci://registry1.dso.mil/ironbank/bigbang/bigbang \
  --version 3.8.0 --untar --untardir charts/
```

This will create a `charts/bigbang` directory containing the chart
templates and values.  You can then reference the chart with a
relative path in your Helm commands or Flux manifests.  Be aware
that storing large charts in Git repositories can impact clone
performance; consider using an OCI chart repository when possible.