# Host package artifacts

> Documentation baseline: v2.1 — August 19, 2026.

Host package archives are separate from Helm and container-image inventories.
The Longhorn archive targets Ubuntu 24.04 amd64 golden images.

| Artifact | Purpose |
| --- | --- |
| `longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz` | offline installer plus 16 pinned `.deb` packages |
| `longhorn-host-deps-ubuntu-24.04-amd64.manifest` | package/version/architecture source of truth |
| `longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz.sha256` | transfer-integrity checksum |
| `BUNDLE-README.md` | instructions embedded in the archive |

Build or reproduce the archive only on a connected Ubuntu 24.04 amd64 staging
host:

```bash
scripts/management/preflight/build-longhorn-host-deps-bundle.sh
```

Inside the air gap, copy the archive to the golden image, verify the external
SHA-256, extract it, run `sudo ./install.sh --verify-only`, then run
`sudo ./install.sh`. The installer uses `dpkg` against local files only; it
does not invoke apt or access a repository.

The archive is part of the v2.1 release baseline and must be promoted through
the same malware scanning, removable-media, checksum, and approval controls as
the Helm and container artifacts.
