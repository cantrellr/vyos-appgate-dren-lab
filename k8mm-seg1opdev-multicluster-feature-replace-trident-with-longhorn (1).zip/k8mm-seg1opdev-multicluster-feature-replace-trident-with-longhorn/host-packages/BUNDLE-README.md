# Longhorn host dependency bundle

> Bundle baseline: v2.1 — August 19, 2026.

This bundle contains the pinned Ubuntu 24.04 amd64 packages required by the
Longhorn worker preflight: open-iSCSI, NFSv4 client support, cryptsetup,
device-mapper utilities, XFS utilities, and their non-base dependencies.

It is intended for the golden image. It does not format, partition, mount,
unmount, or erase storage, and it does not use apt or contact any repository.

Install on the connected golden-image VM after copying the bundle inside:

```bash
tar -xzf longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz
cd longhorn-host-deps-ubuntu-24.04-amd64
sudo ./install.sh --verify-only
sudo ./install.sh
```

Seal the golden image only after installation succeeds. New nodes cloned from
that image are then validation-only targets for `prepare-longhorn-nodes`.
