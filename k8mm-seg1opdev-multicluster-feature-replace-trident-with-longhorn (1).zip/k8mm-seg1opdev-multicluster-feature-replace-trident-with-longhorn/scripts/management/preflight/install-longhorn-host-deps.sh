#!/usr/bin/env bash
set -Eeuo pipefail

BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERIFY_ONLY=false

usage() {
  cat <<USAGE
Usage: sudo $0 [--verify-only]

Installs the pinned Longhorn host packages from this local bundle without
running apt, contacting a repository, or formatting/mounting storage.
USAGE
}

while (($#)); do
  case "$1" in
    --verify-only) VERIFY_ONLY=true; shift ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done

[[ "$(id -u)" -eq 0 ]] || { echo "Run as root." >&2; exit 1; }
[[ "$(uname -m)" == x86_64 ]] || { echo "This bundle requires x86_64/amd64." >&2; exit 1; }
source /etc/os-release
[[ "${ID:-}" == ubuntu && "${VERSION_ID:-}" == 24.04 ]] || {
  echo "This bundle is approved only for Ubuntu 24.04." >&2
  exit 1
}

cd "${BUNDLE_DIR}"
sha256sum --check SHA256SUMS

if [[ "${VERIFY_ONLY}" == true ]]; then
  echo "Bundle integrity and platform validation passed."
  exit 0
fi

export DEBIAN_FRONTEND=noninteractive
dpkg --audit
dpkg --unpack packages/*.deb
dpkg --configure --pending

while IFS='|' read -r package version architecture; do
  [[ -n "${package}" && "${package:0:1}" != "#" ]] || continue
  installed_version="$(dpkg-query -W -f='${Version}' "${package}")"
  installed_architecture="$(dpkg-query -W -f='${Architecture}' "${package}")"
  status="$(dpkg-query -W -f='${db:Status-Abbrev}' "${package}")"
  [[ "${status}" == ii* ]] || { echo "${package} is not fully installed." >&2; exit 1; }
  [[ "${installed_version}" == "${version}" ]] || {
    echo "${package}: installed ${installed_version}, expected ${version}." >&2
    exit 1
  }
  [[ "${installed_architecture}" == "${architecture}" ]] || {
    echo "${package}: installed ${installed_architecture}, expected ${architecture}." >&2
    exit 1
  }
done < PACKAGES.manifest

modprobe iscsi_tcp
printf '%s\n' iscsi_tcp >/etc/modules-load.d/longhorn.conf
systemctl enable iscsid.service
systemctl start iscsid.service
systemctl is-active --quiet iscsid.service

for command in iscsiadm mount.nfs cryptsetup dmsetup xfs_info findmnt; do
  command -v "${command}" >/dev/null || { echo "Missing command: ${command}" >&2; exit 1; }
done

install -d -o root -g root -m 0755 /var/lib/k8mm
cp PACKAGES.manifest /var/lib/k8mm/longhorn-host-deps.manifest
echo "Longhorn host dependencies installed and validated without network access."
