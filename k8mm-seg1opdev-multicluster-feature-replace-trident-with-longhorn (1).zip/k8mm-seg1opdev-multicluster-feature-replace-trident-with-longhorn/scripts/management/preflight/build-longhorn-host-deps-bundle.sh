#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"
MANIFEST="${ROOT_DIR}/host-packages/longhorn-host-deps-ubuntu-24.04-amd64.manifest"
INSTALLER="${SCRIPT_DIR}/install-longhorn-host-deps.sh"
BUNDLE_README="${ROOT_DIR}/host-packages/BUNDLE-README.md"
OUTPUT_DIR="${OUTPUT_DIR:-${ROOT_DIR}/host-packages}"
ARCHIVE="${OUTPUT_DIR}/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "${WORK_DIR}"' EXIT

[[ "$(uname -m)" == x86_64 ]] || { echo "Builder must be x86_64." >&2; exit 1; }
source /etc/os-release
[[ "${ID:-}" == ubuntu && "${VERSION_ID:-}" == 24.04 ]] || {
  echo "Builder must run on Ubuntu 24.04." >&2
  exit 1
}
for command in apt-get dpkg-deb sha256sum tar gzip; do
  command -v "${command}" >/dev/null || { echo "Missing command: ${command}" >&2; exit 1; }
done
[[ -f "${MANIFEST}" && -f "${INSTALLER}" && -f "${BUNDLE_README}" ]] || {
  echo "Bundle source files are incomplete." >&2
  exit 1
}

stage="${WORK_DIR}/longhorn-host-deps-ubuntu-24.04-amd64"
mkdir -p "${stage}/packages" "${WORK_DIR}/apt/lists/partial"
cp "${MANIFEST}" "${stage}/PACKAGES.manifest"
cp "${INSTALLER}" "${stage}/install.sh"
cp "${BUNDLE_README}" "${stage}/README.md"
chmod 0755 "${stage}/install.sh"

sources="${WORK_DIR}/sources.list"
cat >"${sources}" <<'SOURCES'
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu noble main universe
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu noble-updates main universe
deb [arch=amd64 signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://security.ubuntu.com/ubuntu noble-security main universe
SOURCES

apt_options=(
  -o "Dir::Etc::sourcelist=${sources}"
  -o Dir::Etc::sourceparts=-
  -o "Dir::State::lists=${WORK_DIR}/apt/lists"
  -o APT::Get::List-Cleanup=0
)
apt-get "${apt_options[@]}" update

while IFS='|' read -r package version architecture; do
  [[ -n "${package}" && "${package:0:1}" != "#" ]] || continue
  (
    cd "${stage}/packages"
    apt-get "${apt_options[@]}" download "${package}:${architecture}=${version}"
  )
done < "${MANIFEST}"

package_count="$(find "${stage}/packages" -maxdepth 1 -type f -name '*.deb' | wc -l)"
manifest_count="$(grep -Ev '^[[:space:]]*(#|$)' "${MANIFEST}" | wc -l)"
[[ "${package_count}" -eq "${manifest_count}" ]] || {
  echo "Downloaded ${package_count} packages; expected ${manifest_count}." >&2
  exit 1
}

while IFS='|' read -r package version architecture; do
  [[ -n "${package}" && "${package:0:1}" != "#" ]] || continue
  match=false
  for deb in "${stage}/packages/"*.deb; do
    if [[ "$(dpkg-deb -f "${deb}" Package)" == "${package}" &&
          "$(dpkg-deb -f "${deb}" Version)" == "${version}" &&
          "$(dpkg-deb -f "${deb}" Architecture)" == "${architecture}" ]]; then
      match=true
      break
    fi
  done
  [[ "${match}" == true ]] || { echo "Downloaded metadata mismatch for ${package}." >&2; exit 1; }
done < "${MANIFEST}"

(
  cd "${stage}"
  sha256sum packages/*.deb > SHA256SUMS
  sha256sum --check SHA256SUMS
)

mkdir -p "${OUTPUT_DIR}"
(
  cd "${WORK_DIR}"
  tar --sort=name --mtime='UTC 2026-08-19 00:00:00' --owner=0 --group=0 --numeric-owner     -czf "${ARCHIVE}" longhorn-host-deps-ubuntu-24.04-amd64
)
sha256sum "${ARCHIVE}" > "${ARCHIVE}.sha256"
echo "Created ${ARCHIVE}"
