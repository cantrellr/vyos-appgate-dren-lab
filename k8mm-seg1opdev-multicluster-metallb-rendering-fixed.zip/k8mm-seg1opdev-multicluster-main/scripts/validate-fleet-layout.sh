#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"
require_cmd python3

python3 - "${ROOT_DIR}" <<'PY2'
from pathlib import Path
import ipaddress
import re
import sys
import tarfile
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML is required for Fleet layout validation')

root = Path(sys.argv[1])
bundle_root = root / 'fleet' / 'bundles'
local_bundle_root = root / 'fleet' / 'local-bundles'
fleet_files = sorted(bundle_root.glob('*/fleet.yaml'))
local_fleet_files = sorted(local_bundle_root.glob('*/fleet.yaml'))
expected = {
    'cert-manager', 'cert-manager-config', 'metallb', 'metallb-config', 'contour-segment1',
    'trident-operator', 'trident-config', 'trident-protect',
    'oppostgres-operator', 'oppostgres', 'oppostgres-replica',
    'opkeycloak-operator', 'opkeycloak', 'opkeycloak-secondary',
    'istio-base', 'istio-cni', 'istiod', 'istio-eastwestgateway',
    'kiali-operator', 'kiali', 'kube-state-metrics', 'elastic-agent',
}
if len(fleet_files) != len(expected):
    raise SystemExit(f'Expected {len(expected)} downstream/common Fleet bundles; found {len(fleet_files)}')

local_expected = {
    'bootstrap-cert-manager-ready',
    'bootstrap-cert-manager-config-ready',
}

# Rancher v2.15.0 bundles Fleet v0.15.2. In that implementation, the
# bundlereader queues a remote chart only when HelmOptions.Chart is non-empty.
# Keep the OCI URL under helm.chart for this pinned runtime even though newer
# Fleet documentation prefers helm.repo for OCI sources.
expected_oci_charts = {
    '10-cert-manager': ('oci://kubeharbor.dev.kube/k8mm-charts/cert-manager', '1.5.14'),
    '20-metallb': ('oci://kubeharbor.dev.kube/k8mm-charts/metallb', '0.15.2'),
    '31-contour-segment1': ('oci://kubeharbor.dev.kube/k8mm-charts/contour', '21.1.4'),
    '40-trident-operator': ('oci://kubeharbor.dev.kube/k8mm-charts/trident-operator', '100.2602.1'),
    '42-trident-protect': ('oci://kubeharbor.dev.kube/k8mm-charts/trident-protect', '100.2602.0'),
    '50-cnpg-operator': ('oci://kubeharbor.dev.kube/k8mm-charts/cloudnative-pg', '0.29.0'),
    '51-postgresql-ha': ('oci://kubeharbor.dev.kube/k8mm-charts/cluster', '0.7.0'),
    '60-istio-base': ('oci://kubeharbor.dev.kube/k8mm-charts/base', '1.30.1'),
    '61-istio-cni': ('oci://kubeharbor.dev.kube/k8mm-charts/cni', '1.30.1'),
    '62-istiod': ('oci://kubeharbor.dev.kube/k8mm-charts/istiod', '1.30.1'),
    '63-eastwest-gateway': ('oci://kubeharbor.dev.kube/k8mm-charts/gateway', '1.30.1'),
    '64-kiali-operator': ('oci://kubeharbor.dev.kube/k8mm-charts/kiali-operator', '2.27.0'),
    '65-kiali-server': ('oci://kubeharbor.dev.kube/k8mm-charts/kiali-server', '2.27.0'),
    '70-kube-state-metrics': ('oci://kubeharbor.dev.kube/k8mm-charts/kube-state-metrics', '6.1.0'),
    '71-elastic-agent': ('oci://kubeharbor.dev.kube/k8mm-charts/elastic-agent', '9.4.2'),
}
if len(local_fleet_files) != len(local_expected):
    raise SystemExit(
        f'Expected {len(local_expected)} management bootstrap-contract bundles; '
        f'found {len(local_fleet_files)}'
    )

bundle_labels = set()
bundle_names = set()
parsed = {}
for path in list((root/'fleet').rglob('*.yaml')) + list((root/'fleet').rglob('*.yml')):
    # Helm templates are Go-template sources and are not valid standalone YAML
    # until Helm renders them. Validate all Fleet/config/value YAML separately.
    if 'templates' in path.parts and 'chart' in path.parts:
        continue
    try:
        list(yaml.safe_load_all(path.read_text(encoding='utf-8')))
    except Exception as exc:
        raise SystemExit(f'Invalid YAML {path.relative_to(root)}: {exc}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    parsed[path.parent.name] = data
    name = data.get('name')
    label = (data.get('labels') or {}).get('kmm.dev/bundle')
    if not name or not label:
        raise SystemExit(f'{path.relative_to(root)}: missing bundle name or kmm.dev/bundle label')
    if 'overrideTargets' in data:
        raise SystemExit(f'{path.relative_to(root)}: overrideTargets is not a Fleet field; use targetCustomizations')
    if '${ get .ClusterLabels' in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{path.relative_to(root)}: cluster-label templates belong in values/manifests, not fleet.yaml fields')
    bundle_names.add(name)
    bundle_labels.add(label)
    helm = data.get('helm') or {}
    repo = helm.get('repo')
    chart = helm.get('chart')
    if repo:
        raise SystemExit(
            f'{path.relative_to(root)}: helm.repo is prohibited for this Fleet v0.15.2 baseline; '
            'use the approved OCI URL in helm.chart so the remote chart is actually loaded'
        )
    if path.parent.name in expected_oci_charts:
        expected_chart, expected_version = expected_oci_charts[path.parent.name]
        if chart != expected_chart:
            raise SystemExit(
                f'{path.relative_to(root)}: expected helm.chart {expected_chart!r}; found {chart!r}'
            )
        if str(helm.get('version')) != expected_version:
            raise SystemExit(
                f'{path.relative_to(root)}: expected chart version {expected_version!r}; '
                f'found {helm.get("version")!r}'
            )
        if not helm.get('releaseName'):
            raise SystemExit(f'{path.relative_to(root)}: external OCI bundle is missing helm.releaseName')
        if helm.get('valuesFiles') != ['values.yaml']:
            raise SystemExit(
                f'{path.relative_to(root)}: external OCI bundle must reference only values.yaml; '
                f'found {helm.get("valuesFiles")!r}'
            )
    elif chart and str(chart).startswith('oci://'):
        raise SystemExit(f'{path.relative_to(root)}: unexpected OCI chart bundle {chart}')

if bundle_names != expected:
    raise SystemExit(f'Fleet bundle name mismatch. Missing={sorted(expected-bundle_names)} extra={sorted(bundle_names-expected)}')

local_names = set()
local_labels = set()
local_parsed = {}
for path in local_fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    local_parsed[path.parent.name] = data
    name = data.get('name')
    label = (data.get('labels') or {}).get('kmm.dev/bundle')
    if not name or not label:
        raise SystemExit(f'{path.relative_to(root)}: missing bundle name or kmm.dev/bundle label')
    local_names.add(name)
    local_labels.add(label)

if local_names != local_expected:
    raise SystemExit(
        f'Management bootstrap-contract bundle mismatch. '
        f'Missing={sorted(local_expected-local_names)} extra={sorted(local_names-local_expected)}'
    )
if local_labels != {'cert-manager', 'cert-manager-config'}:
    raise SystemExit(f'Management bootstrap-contract labels are incorrect: {sorted(local_labels)}')

for path in local_fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    for dep in data.get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if not label or label not in local_labels:
            raise SystemExit(f'{path.relative_to(root)}: unresolved local dependsOn label {label!r}')

local_contracts = {
    '10-bootstrap-cert-manager-ready': {
        'name': 'kmm-bootstrap-contract-cert-manager',
        'label': 'cert-manager',
        'tokens': ('owner: bootstrap-management', 'helmRelease: onprem-cert-manager'),
    },
    '11-bootstrap-cert-manager-config-ready': {
        'name': 'kmm-bootstrap-contract-cert-manager-config',
        'label': 'cert-manager-config',
        'tokens': ('owner: bootstrap-management', 'clusterIssuer: segment1-ca-clusterissuer'),
    },
}
for directory, contract in local_contracts.items():
    manifest = local_bundle_root/directory/'contract.yaml'
    if not manifest.is_file():
        raise SystemExit(f'{manifest.relative_to(root)} is missing')
    manifest_text = manifest.read_text(encoding='utf-8')
    for token in (
        f"name: {contract['name']}",
        'app.kubernetes.io/managed-by: Fleet',
        f"kmm.dev/bootstrap-contract: {contract['label']}",
        *contract['tokens'],
    ):
        if token not in manifest_text:
            raise SystemExit(f'{manifest.relative_to(root)} is missing token: {token}')
    fleet_text = (local_bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    for token in (
        f"kmm.dev/bundle: {contract['label']}",
        f"name: {contract['name']}",
        'namespace: cert-manager',
        'path: /metadata/labels/app.kubernetes.io~1managed-by',
    ):
        if token not in fleet_text:
            raise SystemExit(f'{directory}/fleet.yaml is missing bootstrap-contract token: {token}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    for dep in data.get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if not label or label not in bundle_labels:
            raise SystemExit(f'{path.relative_to(root)}: unresolved dependsOn label {label!r}')

def has_target(directory, key, value):
    custom = parsed[directory].get('targetCustomizations') or []
    return any((((x.get('clusterSelector') or {}).get('matchLabels') or {}).get(key) == value) for x in custom)

def has_deny(directory):
    custom = parsed[directory].get('targetCustomizations') or []
    return any(x.get('clusterSelector') == {} and x.get('doNotDeploy') is True for x in custom)

for directory in ('50-cnpg-operator', '52-keycloak-operator'):
    if not (has_target(directory, 'kmm.dev/identity-site', 'true') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: dual-site operator guard is incomplete')
for directory in ('51-postgresql-ha', '53-keycloak'):
    if not (has_target(directory, 'kmm.dev/identity', 'primary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: primary identity guard is incomplete')
for directory in ('51-postgresql-replica', '54-keycloak-secondary'):
    if not (has_target(directory, 'kmm.dev/identity', 'secondary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: secondary identity guard is incomplete')

primary_values = (bundle_root/'51-postgresql-ha'/'values.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-hibernation', 'dataDurability: required', 'failoverQuorum: true'):
    if token not in primary_values:
        raise SystemExit(f'Primary PostgreSQL values missing HA token: {token}')
secondary_cluster = (bundle_root/'51-postgresql-replica'/'cluster.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-replica-enabled', 'opkeycloak-postgres-j64.dev.kube', 'pg_basebackup:', 'streaming_replica'):
    if token not in secondary_cluster:
        raise SystemExit(f'Secondary PostgreSQL manifest missing token: {token}')
for path in (bundle_root/'53-keycloak'/'keycloak.yaml', bundle_root/'54-keycloak-secondary'/'keycloak.yaml'):
    if 'kmm.dev/keycloak-instances' not in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{path.relative_to(root)} does not derive instances from the Fleet cluster label')

cni_values_path = bundle_root/'61-istio-cni'/'values.yaml'
cni_values = cni_values_path.read_text(encoding='utf-8')
for token in ('/opt/cni/bin', '/etc/cni/net.d'):
    if token not in cni_values:
        raise SystemExit(f'Istio CNI values missing RKE2 path: {token}')
cni_values_data = yaml.safe_load(cni_values) or {}
cni_profile = cni_values_data.get('profile')
if cni_profile:
    cni_package = root/'helm'/'packages'/'cni-1.30.1.tgz'
    if not cni_package.is_file():
        raise SystemExit('helm/packages/cni-1.30.1.tgz is missing; cannot validate Istio CNI profile')
    profile_member = f'cni/files/profile-{cni_profile}.yaml'
    with tarfile.open(cni_package, 'r:gz') as archive:
        if profile_member not in archive.getnames():
            raise SystemExit(
                f'61-istio-cni/values.yaml selects unsupported Istio profile {cni_profile!r}; '
                f'{profile_member} is not present in cni-1.30.1.tgz. Omit profile to use chart defaults.'
            )
istiod_values = (bundle_root/'62-istiod'/'values.yaml').read_text(encoding='utf-8')
if 'pilot:' not in istiod_values or 'enabled: true' not in istiod_values:
    raise SystemExit('Istiod values do not enable pilot.cni')
for address in ('1.0.0.210', '1.0.0.220', '1.0.0.230', '1.0.0.240'):
    if address not in istiod_values:
        raise SystemExit(f'Istiod meshNetworks missing Segment1 east-west address: {address}')

pool_template_path = bundle_root/'21-metallb-config'/'chart'/'templates'/'address-pools.yaml'
if not pool_template_path.is_file():
    raise SystemExit('MetalLB config Helm template is missing')
pool_manifest = pool_template_path.read_text(encoding='utf-8')
if pool_manifest.count('kind: IPAddressPool') != 1 or 'name: segment1' not in pool_manifest:
    raise SystemExit('MetalLB must expose exactly one Segment1 IPAddressPool')
if 'name: regular' in pool_manifest or 'metallb-' + 'regular-pool' in pool_manifest:
    raise SystemExit('A non-Segment1 MetalLB pool remains in the Fleet bundle')

segment_values = (bundle_root/'31-contour-segment1'/'values.yaml').read_text(encoding='utf-8')
for token in ('manageCRDs: true', 'name: segment1', 'default: true', 'kmm.dev/segment1-lb-ip'):
    if token not in segment_values:
        raise SystemExit(f'Segment1 Contour values missing single-ingress token: {token}')
if not (bundle_root/'31-contour-segment1'/'backend-egress.yaml').is_file():
    raise SystemExit('Segment1 backend egress policy is missing')

monitoring_values_path = bundle_root/'71-elastic-agent'/'values.yaml'
monitoring_values = monitoring_values_path.read_text(encoding='utf-8')
monitoring_values_data = yaml.safe_load(monitoring_values) or {}
per_node = (((monitoring_values_data.get('agent') or {}).get('presets') or {}).get('perNode') or {})
providers = per_node.get('providers') or {}
if 'kubernetes' in providers:
    raise SystemExit(
        '71-elastic-agent/values.yaml must not override presets.perNode.providers.kubernetes. '
        'The packaged Elastic Agent chart already provides node: ${NODE_NAME}; copying that token into a '
        'Fleet valuesFile makes Fleet v0.15.2 interpret NODE_NAME as a template function.'
    )
for token in (
    'kubeharbor.dev.kube/elastic-agent/elastic-agent',
    'elastic-agent-fleet-enrollment',
    'devlocal-ca-bundle-secret',
    'preset: perNode',
    'kubernetes_leaderelection:',
    'enabled: true',
    'kube-state-metrics:',
):
    if token not in monitoring_values:
        raise SystemExit(f'Elastic Agent values missing token: {token}')
ksm_values = (bundle_root/'70-kube-state-metrics'/'values.yaml').read_text(encoding='utf-8')
for token in ('kubeharbor.dev.kube', 'kube-state-metrics/kube-state-metrics', 'tag: v2.16.0'):
    if token not in ksm_values:
        raise SystemExit(f'kube-state-metrics values missing token: {token}')
if (bundle_root/'00-namespaces').exists():
    raise SystemExit('fleet/bundles/00-namespaces must not exist; runtime preflight owns namespace lifecycle and PSA labels')

seed_script = (root/'scripts'/'management'/'fleet'/'01-seed-runtime-secrets.sh').read_text(encoding='utf-8')
for token in (
    'cert-manager segment1 metallb-system trident-system trident-protect istio-system elastic-agent-system elastic-monitoring',
    'for namespace in oppostgres opkeycloak',
    'k8mm.dev/monitoring-agent=true',
):
    if token not in seed_script:
        raise SystemExit(f'Runtime namespace provisioning is missing required token: {token}')

anchor_files = sorted(bundle_root.rglob('bundle-anchor.yaml'))
if anchor_files:
    raise SystemExit(
        'Bundle-anchor workarounds are prohibited. Fleet v0.15.2 must package the real OCI charts via '
        'helm.chart. Remove: ' + ', '.join(str(p.relative_to(root)) for p in anchor_files)
    )
for fleet_path in fleet_files:
    fleet_text = fleet_path.read_text(encoding='utf-8')
    for retired_token in ('kmm-fleet-anchor-', 'kmm.dev/fleet-bundle-anchor'):
        if retired_token in fleet_text:
            raise SystemExit(f'{fleet_path.relative_to(root)} contains retired anchor token {retired_token}')

for path in (
    bundle_root/'31-contour-segment1'/'monitoring-networkpolicy.yaml',
    bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-ha'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-replica'/'monitoring-networkpolicy.yaml',
):
    text = path.read_text(encoding='utf-8')
    if 'k8mm.dev/monitoring-agent' not in text:
        raise SystemExit(f'{path.relative_to(root)} lacks the monitoring namespace selector')

# Fleet v0.15.2 preprocesses files referenced by helm.valuesFiles and treats ${ ... }
# as Fleet Go templates. Reject shell/application-style ${NAME} tokens in external
# values files; keep those in packaged chart defaults or explicitly disable preprocessing.
for directory, data in parsed.items():
    helm = data.get('helm') or {}
    for values_name in helm.get('valuesFiles') or []:
        values_path = bundle_root/directory/values_name
        values_text = values_path.read_text(encoding='utf-8')
        for expression in re.findall(r'\$\{([^{}]+)\}', values_text):
            expression = expression.strip()
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', expression):
                raise SystemExit(
                    f'{values_path.relative_to(root)} contains bare ${{{expression}}}, which Fleet v0.15.2 '
                    'will parse as a Fleet template. Keep runtime env placeholders in the packaged chart '
                    'defaults or disable/escape Fleet preprocessing deliberately.'
                )

monitoring_source_pairs = (
    (root/'yaml'/'monitoring'/'elastic-agent-per-node-9.4.2-values.yaml', bundle_root/'71-elastic-agent'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-6.1.0-values.yaml', bundle_root/'70-kube-state-metrics'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-agent-alias.yaml', bundle_root/'71-elastic-agent'/'kube-state-metrics-alias.yaml'),
    (root/'yaml'/'monitoring'/'segment1-elastic-agent-networkpolicy.yaml', bundle_root/'31-contour-segment1'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'opkeycloak-ingress-from-monitoring.yaml', bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-ha'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-replica'/'monitoring-networkpolicy.yaml'),
)
for source, managed in monitoring_source_pairs:
    if source.read_text(encoding='utf-8') != managed.read_text(encoding='utf-8'):
        raise SystemExit(f'Monitoring source drift: {source.relative_to(root)} != {managed.relative_to(root)}')

failover_script = (root/'scripts'/'management'/'failover'/'failover-to-j52.sh').read_text(encoding='utf-8')
for token in ('../../_lib/common.sh', '../../_lib/runtime-config.sh'):
    if token not in failover_script:
        raise SystemExit(f'Identity failover script does not resolve moved library path: {token}')
deploy_script = (root/'scripts'/'deploy-platform.sh').read_text(encoding='utf-8')
if 'management/failover/failover-to-j52.sh' not in deploy_script:
    raise SystemExit('Deployment orchestrator does not reference the moved failover script')

gitrepo_script = (root/'scripts'/'management'/'fleet'/'03-bootstrap-gitrepos.sh').read_text(encoding='utf-8')
if 'fleet/bundles/00-namespaces' in gitrepo_script:
    raise SystemExit('GitRepo bootstrap still references the retired namespace bundle')
for bundle_path in ('fleet/bundles/10-cert-manager', 'fleet/bundles/11-cert-manager-config'):
    if gitrepo_script.count(bundle_path) != 1:
        raise SystemExit(
            f'GitRepo bootstrap must include {bundle_path} only in fleet-default; '
            'bootstrap-management owns cert-manager on fleet-local'
        )
for bundle_path in (
    'fleet/local-bundles/10-bootstrap-cert-manager-ready',
    'fleet/local-bundles/11-bootstrap-cert-manager-config-ready',
):
    if gitrepo_script.count(bundle_path) != 1:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} exactly once in fleet-local')
for bundle_path in ('fleet/bundles/20-metallb', 'fleet/bundles/21-metallb-config'):
    if gitrepo_script.count(bundle_path) != 2:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} in local and downstream scopes')
if '02-validate-cert-manager-bootstrap.sh" j64 seg1opman' not in gitrepo_script:
    raise SystemExit('GitRepo bootstrap must validate the management cert-manager bootstrap contract before creating fleet-local markers')
for token in (
    r"helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'",
    'helmSecretName: kmm-helm-credentials',
):
    if gitrepo_script.count(token) != 2:
        raise SystemExit(f'Both managed GitRepos must contain the OCI authentication control: {token}')

cert_install_script = (root/'scripts'/'core'/'02-install-cert-manager.sh').read_text(encoding='utf-8')
for token in (
    'Waiting for cert-manager CRDs to become established',
    'clusterissuers.cert-manager.io',
    '02-validate-cert-manager-bootstrap.sh',
):
    if token not in cert_install_script:
        raise SystemExit(f'cert-manager bootstrap installer is missing sequencing/validation token: {token}')

cert_contract_validator = root/'scripts'/'core'/'02-validate-cert-manager-bootstrap.sh'
if not cert_contract_validator.is_file():
    raise SystemExit('scripts/core/02-validate-cert-manager-bootstrap.sh is missing')
contract_validator_text = cert_contract_validator.read_text(encoding='utf-8')
for token in (
    'helm -n "${NAMESPACE}" status "${RELEASE}"',
    'clusterissuer/${ISSUER}',
    '--for=condition=Ready',
    'dump_cert_manager_diagnostics',
):
    if token not in contract_validator_text:
        raise SystemExit(f'cert-manager bootstrap validator is missing token: {token}')

cert_chart_dir = bundle_root/'10-cert-manager'
cert_values_data = yaml.safe_load((cert_chart_dir/'values.yaml').read_text(encoding='utf-8')) or {}
if cert_values_data.get('installCRDs') is not True:
    raise SystemExit('10-cert-manager/values.yaml must set installCRDs: true before cert-manager-config is applied')
for candidate in cert_chart_dir.glob('*.yaml'):
    if candidate.name in {'fleet.yaml', 'values.yaml'}:
        continue
    text = candidate.read_text(encoding='utf-8')
    if 'apiVersion: cert-manager.io/' in text:
        raise SystemExit(f'{candidate.relative_to(root)} must not contain cert-manager custom resources; use 11-cert-manager-config')
config_fleet = (bundle_root/'11-cert-manager-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: cert-manager-config',
    'kmm.dev/bundle: cert-manager',
    'releaseName: cert-manager-config',
    'takeOwnership: true',
):
    if token not in config_fleet:
        raise SystemExit(f'11-cert-manager-config/fleet.yaml is missing token: {token}')
issuer_manifest = bundle_root/'11-cert-manager-config'/'segment1-ca-clusterissuer.yaml'
if not issuer_manifest.is_file():
    raise SystemExit('11-cert-manager-config/segment1-ca-clusterissuer.yaml is missing')
issuer_text = issuer_manifest.read_text(encoding='utf-8')
for token in ('kind: ClusterIssuer', 'name: segment1-ca-clusterissuer', 'secretName: segment1-ca-bundle-secret'):
    if token not in issuer_text:
        raise SystemExit(f'cert-manager config manifest is missing token: {token}')

metallb_chart_dir = bundle_root/'20-metallb'
metallb_values_data = yaml.safe_load((metallb_chart_dir/'values.yaml').read_text(encoding='utf-8')) or {}
if ((metallb_values_data.get('crds') or {}).get('enabled')) is not True:
    raise SystemExit('20-metallb/values.yaml must set crds.enabled: true before metallb-config is applied')
if (metallb_chart_dir/'address-pools.yaml').exists():
    raise SystemExit('20-metallb must contain only the external chart definition; move MetalLB custom resources to 21-metallb-config')
metallb_config_fleet = (bundle_root/'21-metallb-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: metallb-config',
    'kmm.dev/bundle: metallb',
    'releaseName: metallb-config',
    'takeOwnership: true',
):
    if token not in metallb_config_fleet:
        raise SystemExit(f'21-metallb-config/fleet.yaml is missing token: {token}')
metallb_config_dir = bundle_root/'21-metallb-config'
metallb_config_data = yaml.safe_load((metallb_config_dir/'fleet.yaml').read_text(encoding='utf-8')) or {}
metallb_helm = metallb_config_data.get('helm') or {}
if metallb_helm.get('chart') != './chart':
    raise SystemExit('21-metallb-config must use its local ./chart adapter so cluster-specific values are rendered by Helm')
if metallb_helm.get('valuesFiles') != ['fleet-values.yaml']:
    raise SystemExit('21-metallb-config must use fleet-values.yaml for per-cluster Fleet preprocessing')
metallb_fleet_values = metallb_config_dir/'fleet-values.yaml'
if not metallb_fleet_values.is_file():
    raise SystemExit('21-metallb-config/fleet-values.yaml is missing')
fleet_values_text = metallb_fleet_values.read_text(encoding='utf-8')
if 'segment1Pool:' not in fleet_values_text or 'kmm.dev/segment1-pool' not in fleet_values_text or '${ get .ClusterLabels' not in fleet_values_text:
    raise SystemExit('21-metallb-config/fleet-values.yaml must resolve segment1Pool from the Fleet cluster label')
chart_yaml = metallb_config_dir/'chart'/'Chart.yaml'
chart_values = metallb_config_dir/'chart'/'values.yaml'
metallb_config_manifest = metallb_config_dir/'chart'/'templates'/'address-pools.yaml'
for required_path in (chart_yaml, chart_values, metallb_config_manifest):
    if not required_path.is_file():
        raise SystemExit(f'MetalLB config local Helm chart is missing {required_path.relative_to(metallb_config_dir)}')
manifest_text = metallb_config_manifest.read_text(encoding='utf-8')
for token in ('kind: IPAddressPool', 'name: segment1', 'kind: L2Advertisement', 'name: platform', '.Values.segment1Pool'):
    if token not in manifest_text:
        raise SystemExit(f'MetalLB config chart template is missing token: {token}')
if '${ get .ClusterLabels' in manifest_text:
    raise SystemExit('MetalLB chart template must not contain Fleet cluster-label expressions; keep them in fleet-values.yaml')
for directory in ('31-contour-segment1', '63-eastwest-gateway'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: metallb-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on metallb-config')
for directory in ('53-keycloak', '54-keycloak-secondary', '62-istiod', '65-kiali-server'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: cert-manager-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on cert-manager-config')
for bundle_path in ('fleet/bundles/70-kube-state-metrics', 'fleet/bundles/71-elastic-agent'):
    if gitrepo_script.count(bundle_path) != 2:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} in local and downstream scopes')

label_script = (root/'scripts'/'management'/'fleet'/'02-label-fleet-clusters.sh').read_text(encoding='utf-8')
required_network_tokens = (
    '1.0.0.201-1.0.0.210', '1.0.0.205', '1.0.0.210',
    '1.0.0.211-1.0.0.220', '1.0.0.215', '1.0.0.216', '1.0.0.220',
    '1.0.0.221-1.0.0.230', '1.0.0.225', '1.0.0.226', '1.0.0.230',
    '1.0.0.231-1.0.0.240', '1.0.0.235', '1.0.0.240',
)
for token in required_network_tokens:
    if token not in label_script:
        raise SystemExit(f'Fleet label script missing Segment1 allocation: {token}')

# MetalLB requires a CIDR or a complete startIP-endIP range. Reject shorthand
# such as 1.0.0.211-220 before it reaches the validating webhook.
short_range = re.search(r'\b(?:\d{1,3}\.){3}\d{1,3}-\d{1,3}(?!\.)\b', label_script)
if short_range:
    raise SystemExit(
        f'Fleet label script contains invalid abbreviated MetalLB range: {short_range.group(0)}; '
        'use full start-end IP notation'
    )
segment_network = ipaddress.ip_network('1.0.0.0/23')
range_literals = set(re.findall(r'\b((?:\d{1,3}\.){3}\d{1,3})-((?:\d{1,3}\.){3}\d{1,3})\b', label_script))
for start_literal, end_literal in range_literals:
    start = ipaddress.ip_address(start_literal)
    end = ipaddress.ip_address(end_literal)
    if start not in segment_network or end not in segment_network:
        raise SystemExit(f'Fleet label script contains a MetalLB range outside Segment1: {start_literal}-{end_literal}')
    if int(start) > int(end):
        raise SystemExit(f'Fleet label script contains a reversed MetalLB range: {start_literal}-{end_literal}')
for literal in set(re.findall(r'\b1\.0\.[01]\.\d{1,3}\b', label_script)):
    if ipaddress.ip_address(literal) not in segment_network:
        raise SystemExit(f'Fleet label script contains an address outside Segment1: {literal}')

forbidden_patterns = (
    re.compile(r'\b10\.0\.4\.'),
    re.compile(r'kmm\.dev/metallb-regular-pool', re.IGNORECASE),
    re.compile(r'\b(devlocal-argocd|contour-devlocal|ingress-devlocal)\b', re.IGNORECASE),
)
for relative in ('config', 'fleet', 'scripts', 'yaml'):
    directory = root / relative
    if not directory.exists():
        continue
    for path in directory.rglob('*'):
        if path == root/'scripts'/'validate-fleet-layout.sh':
            continue
        if not path.is_file() or path.suffix in {'.tgz', '.gz', '.zip'}:
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        for pattern in forbidden_patterns:
            if pattern.search(text):
                raise SystemExit(f'{path.relative_to(root)} contains retired deployment token matching {pattern.pattern}')

for path in (root/'README.md', root/'docs'/'Fleet-Operations.md', root/'docs'/'Rancher-Fleet-Architecture.md'):
    text = path.read_text(encoding='utf-8').lower()
    for retired in ('devlocal-argocd', 'contour-devlocal', 'ingress-devlocal'):
        if retired in text:
            raise SystemExit(f'{path.relative_to(root)} still describes retired component {retired}')

compatibility_doc = (root/'docs'/'Rancher-Fleet-RKE2-1.35-Compatibility.md').read_text(encoding='utf-8')
for token in (
    'Fleet 0.15.2 OCI chart-source compatibility',
    'chart: oci://kubeharbor.dev.kube/k8mm-charts/<chart>',
    'rejects bundle-anchor workarounds',
):
    if token not in compatibility_doc:
        raise SystemExit(f'Fleet compatibility documentation is missing token: {token}')

for context, address in {'j64seg1opman':'1.0.0.210','j64seg1opdev':'1.0.0.220','j52seg1opdev':'1.0.0.230','r01seg1opdev':'1.0.0.240'}.items():
    site = context[:3]
    cluster = context[3:]
    source = root/'yaml'/site/f'{cluster}-cluster'/'values'/'istio-istiod-values-v1.yaml'
    text = source.read_text(encoding='utf-8')
    if address not in text or 'segment1-ca-clusterissuer' not in text:
        raise SystemExit(f'{source.relative_to(root)} is not aligned with Segment1 mesh addressing and CA')

print('Fleet YAML, dependencies, monitoring, two-site identity, RKE2 CNI, and Segment1-only network checks passed.')
PY2

if grep -RIl --exclude='*.md' -i 'argocd' \
  "${ROOT_DIR}/fleet" "${ROOT_DIR}/scripts/deploy-platform.sh" "${ROOT_DIR}/scripts/management/fleet"; then
  die "Argo CD references remain in active Fleet code."
fi

log "Fleet layout validation passed."
