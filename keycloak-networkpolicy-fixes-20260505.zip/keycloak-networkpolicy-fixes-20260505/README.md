# Keycloak NetworkPolicy Fix Package

This package contains corrected Kubernetes NetworkPolicies for the Keycloak broker traffic path between:

- HyperMute Keycloak: `hmkeycloak.jcp.twzbuild` / LB `10.22.1.245`
- OnPrem Keycloak: `opkeycloak.jde.cybercom.ic.gov` / LB `1.0.1.245`

## What was fixed

The original policies had two major issues:

1. The ingress allow policies selected `app.kubernetes.io/component: contour`, but backend traffic to the Keycloak pods comes from **Envoy** pods, not the Contour controller pods.
2. Two ingress policies were placed in the `hypermute` and `onprem` namespaces while the Keycloak pods are deployed in the `keycloak` namespace, so those policies did not select the Keycloak pods.

## Actual traffic path

For HyperMute Keycloak fetching OnPrem discovery:

```text
hmkeycloak pod
  -> 1.0.1.245:443
  -> onprem Envoy LoadBalancer
  -> opkeycloak backend service
  -> opkeycloak pod:8080
```

For OnPrem Keycloak fetching HyperMute discovery:

```text
opkeycloak pod
  -> 10.22.1.245:443
  -> hypermute Envoy LoadBalancer
  -> hmkeycloak backend service
  -> hmkeycloak pod:8080
```

## Files included

```text
build/install/keycloak/21-keycloak-networkpolicies.sh
build/sites/all/resources/keycloak-networkpolicies/hypermute/00-hmkeycloak-deny-all.yaml
build/sites/all/resources/keycloak-networkpolicies/hypermute/01-hmkeycloak-egress.yaml
build/sites/all/resources/keycloak-networkpolicies/hypermute/03-hmkeycloak-ingress-from-hypermute-envoy.yaml
build/sites/all/resources/keycloak-networkpolicies/onprem/00-opkeycloak-deny-all.yaml
build/sites/all/resources/keycloak-networkpolicies/onprem/01-opkeycloak-egress.yaml
build/sites/all/resources/keycloak-networkpolicies/onprem/03-opkeycloak-ingress-from-onprem-envoy.yaml
build/sites/all/resources/keycloak-networkpolicies/cleanup/delete-obsolete-keycloak-networkpolicies.sh
```

## Apply

From the root of your repo after copying these files in:

```bash
chmod +x build/install/keycloak/21-keycloak-networkpolicies.sh
./build/install/keycloak/21-keycloak-networkpolicies.sh apply
```

Then remove obsolete policies from earlier drafts:

```bash
chmod +x build/sites/all/resources/keycloak-networkpolicies/cleanup/delete-obsolete-keycloak-networkpolicies.sh
./build/sites/all/resources/keycloak-networkpolicies/cleanup/delete-obsolete-keycloak-networkpolicies.sh
```

## Validate labels before applying

Confirm the Envoy labels in each ingress namespace:

```bash
kubectl -n onprem get pods --show-labels | grep -i envoy
kubectl -n hypermute get pods --show-labels | grep -i envoy
```

The policies expect Envoy pods to have:

```text
app.kubernetes.io/component=envoy
```

If your chart renders a different Envoy label, update the two ingress policy podSelectors.

## Validate backend port

Confirm Keycloak backend service target ports:

```bash
kubectl -n keycloak get svc -o wide | grep -E 'opkeycloak|hmkeycloak'
kubectl -n keycloak describe svc <opkeycloak-service-name>
kubectl -n keycloak describe svc <hmkeycloak-service-name>
```

The policies allow Envoy to Keycloak pods on TCP/8080. If your Keycloak service targets 8443 instead, change the ingress policy port from 8080 to 8443.

## Test discovery

From a debug pod in the `keycloak` namespace, or directly from the Keycloak pod if it has curl:

```bash
curl -vk --connect-timeout 5 \
  https://opkeycloak.jde.cybercom.ic.gov/realms/jde/.well-known/openid-configuration

curl -vk --connect-timeout 5 \
  https://hmkeycloak.jcp.twzbuild/realms/jcp/.well-known/openid-configuration
```

If curl returns JSON, NetworkPolicy is no longer the blocker. If curl returns a TLS chain error, fix the Keycloak truststore. If it times out, check routing, firewalls, and the applied policy selectors.
