#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"
init_site_cluster "$@"
NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
RELEASE="${CNPG_CLUSTER_RELEASE:-oppostgres}"
CHART_PATH="${CNPG_CLUSTER_CHART:-${HELM_PACKAGES_DIR}/cluster-0.7.0.tgz}"
VALUES="${YAML_DIR}/oppostgres/values/oppostgres-cnpg-keycloak-db-seg1opdev-values-v1.yaml"
PGBOUNCER_PDB="${YAML_DIR}/oppostgres/resources/oppostgres-seg1opdev-pgbouncer-pdb-v1.yaml"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"
require_kubernetes_tools
require_cmd jq
require_cmd openssl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"
"${SCRIPT_DIR}/00-prepare-opkeycloak-runtime-secrets.sh" "${SITE}" "${CLUSTER}"
log "Installing three CNPG PostgreSQL instances and three PgBouncer instances..."
helm_upgrade_install "${RELEASE}" "${CHART_PATH}" "${NAMESPACE}" "${VALUES}"
apply_file_in_namespace "${NAMESPACE}" "${PGBOUNCER_PDB}"
kubectl -n "${NAMESPACE}" wait "cluster/${CLUSTER_NAME}" --for=condition=Ready --timeout=15m
kubectl -n "${NAMESPACE}" wait "deployment/${POOLER_NAME}" --for=condition=Available --timeout=5m
cat <<SUMMARY
OPPostgreSQL HA deployment complete.
Context: ${K8_CONTEXT}
PostgreSQL instances: 3
PgBouncer instances: 3
Application endpoint: ${POOLER_NAME}.${NAMESPACE}.svc.cluster.local:5432
Direct RW endpoint: ${CLUSTER_NAME}-rw.${NAMESPACE}.svc.cluster.local:5432
SUMMARY
