#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
RANCHER_SYSTEM_TIMEOUT_SECONDS="${RANCHER_SYSTEM_TIMEOUT_SECONDS:-900}"

require_cmd kubectl
require_cmd jq
validate_context_access "${RANCHER_CONTEXT}"

print_diagnostics() {
  warn "Rancher system validation failed. Current Rancher/Fleet workload state:"
  kubectl --context "${RANCHER_CONTEXT}" get deployments -A 2>/dev/null | \
    grep -E 'NAMESPACE|rancher|fleet|gitjob|webhook' >&2 || true
  kubectl --context "${RANCHER_CONTEXT}" get pods -A -o wide 2>/dev/null | \
    grep -E 'NAMESPACE|rancher|fleet|gitjob|webhook|helm-operation|ImagePull|Error|CrashLoop' >&2 || true

  warn "Pods with image/configuration failures:"
  kubectl --context "${RANCHER_CONTEXT}" get pods -A -o json 2>/dev/null | jq -r '
    .items[] as $pod |
    (($pod.status.containerStatuses // []) + ($pod.status.initContainerStatuses // []))[]? |
    select(.state.waiting.reason != null or (.state.terminated.exitCode // 0) != 0) |
    [$pod.metadata.namespace, $pod.metadata.name, .name,
     (.state.waiting.reason // ("exit=" + ((.state.terminated.exitCode // 0)|tostring))),
     (.state.waiting.message // .state.terminated.message // "")] | @tsv' >&2 || true

  mapfile -t failed_operations < <(
    kubectl --context "${RANCHER_CONTEXT}" -n cattle-system get pods \
      --field-selector=status.phase=Failed -o name 2>/dev/null | grep '/helm-operation-' | tail -10 || true
  )
  for pod_ref in "${failed_operations[@]}"; do
    warn "Helm output for ${pod_ref}:"
    kubectl --context "${RANCHER_CONTEXT}" -n cattle-system logs "${pod_ref}" -c helm --tail=160 >&2 || true
  done

  warn "Rancher Contour HTTPProxy state:"
  kubectl --context "${RANCHER_CONTEXT}" -n cattle-system get httpproxy rancher-httpproxy \
    -o yaml >&2 2>/dev/null || true

  warn "Recent Rancher system-chart errors:"
  kubectl --context "${RANCHER_CONTEXT}" -n cattle-system logs deployment/rancher \
    --since=90m --prefix 2>/dev/null | \
    grep -Ei 'helm-operation|system chart|fleet|webhook|imagepull|failed|error' | tail -200 >&2 || true
}

wait_for_deployment() {
  local namespace="$1" name="$2" deadline=$((SECONDS + RANCHER_SYSTEM_TIMEOUT_SECONDS))
  until kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get deployment "${name}" >/dev/null 2>&1; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
  local remaining=$((deadline - SECONDS))
  (( remaining > 0 )) || return 1
  kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" rollout status \
    deployment/"${name}" --timeout="${remaining}s" >/dev/null
}

wait_for_crd() {
  local name="$1" deadline=$((SECONDS + RANCHER_SYSTEM_TIMEOUT_SECONDS))
  until kubectl --context "${RANCHER_CONTEXT}" get "crd/${name}" >/dev/null 2>&1; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done
  local remaining=$((deadline - SECONDS))
  (( remaining > 0 )) || return 1
  kubectl --context "${RANCHER_CONTEXT}" wait --for=condition=Established \
    "crd/${name}" --timeout="${remaining}s" >/dev/null
}

wait_for_rancher_httpproxy() {
  local deadline=$((SECONDS + RANCHER_SYSTEM_TIMEOUT_SECONDS))
  local proxy_json=""

  until proxy_json="$(kubectl --context "${RANCHER_CONTEXT}" -n cattle-system \
      get httpproxy rancher-httpproxy -o json 2>/dev/null)"; do
    (( SECONDS < deadline )) || return 1
    sleep 5
  done

  until jq -e '
      (.status.currentStatus // "" | ascii_downcase) == "valid" and
      any(.spec.routes[]?;
        .enableWebsockets == true and
        any(.conditions[]?; .prefix == "/") and
        any(.services[]?; .name == "rancher" and (.port | tonumber) == 80)
      )
    ' <<<"${proxy_json}" >/dev/null; do
    (( SECONDS < deadline )) || return 1
    sleep 5
    proxy_json="$(kubectl --context "${RANCHER_CONTEXT}" -n cattle-system \
      get httpproxy rancher-httpproxy -o json 2>/dev/null || true)"
  done
}

failures=0
for crd in clusters.fleet.cattle.io gitrepos.fleet.cattle.io bundledeployments.fleet.cattle.io; do
  if ! wait_for_crd "${crd}"; then
    warn "Required Fleet CRD is unavailable: ${crd}"
    failures=$((failures + 1))
  fi
done

for target in \
  cattle-system/rancher-webhook \
  cattle-fleet-system/fleet-controller \
  cattle-fleet-system/gitjob \
  cattle-fleet-local-system/fleet-agent; do
  namespace="${target%/*}"
  deployment="${target#*/}"
  log "Waiting for ${namespace}/${deployment}..."
  if ! wait_for_deployment "${namespace}" "${deployment}"; then
    warn "Deployment did not become ready: ${namespace}/${deployment}"
    failures=$((failures + 1))
  fi
done

if ! kubectl --context "${RANCHER_CONTEXT}" -n fleet-local get cluster.fleet.cattle.io local >/dev/null 2>&1; then
  warn "Fleet local cluster object is missing: fleet-local/local"
  failures=$((failures + 1))
fi

log "Validating Rancher Contour HTTPProxy and WebSocket support..."
if ! wait_for_rancher_httpproxy; then
  warn "cattle-system/rancher-httpproxy is missing, invalid, or does not enable WebSockets for the Rancher service."
  failures=$((failures + 1))
fi

if (( failures > 0 )); then
  print_diagnostics
  die "Rancher is running, but ${failures} required Rancher/Fleet component check(s) failed."
fi

log "Rancher HTTPProxy WebSockets, webhook, Fleet controller, GitJob, local Fleet agent, CRDs, and fleet-local/local are ready."
