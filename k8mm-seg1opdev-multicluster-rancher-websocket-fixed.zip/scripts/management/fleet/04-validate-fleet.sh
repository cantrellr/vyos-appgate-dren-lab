#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"
require_cmd jq

for repo in fleet-local/k8mm-seg1opdev-multicluster-local fleet-default/k8mm-seg1opdev-multicluster-downstream; do
  namespace="${repo%%/*}"; name="${repo##*/}"
  kubectl -n "${namespace}" get gitrepo "${name}" >/dev/null
  kubectl -n "${namespace}" get gitrepo "${name}" -o json | jq -e '
    (.status.conditions // []) | all(.status != "False" or (.type != "Ready" and .type != "Accepted"))' >/dev/null \
    || die "Fleet GitRepo ${repo} reports a failing Ready/Accepted condition."
done

managed_bundles_json="$({
  kubectl -n fleet-local get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-local \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
  kubectl -n fleet-default get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-downstream \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
} | sort -u | jq -R -s 'split("\n") | map(select(length > 0))')"

managed_count="$(jq 'length' <<<"${managed_bundles_json}")"
[[ "${managed_count}" -gt 0 ]] || die "No Fleet Bundles were generated for the two managed GitRepos."

bundledeployments_json="$(kubectl get bundledeployments.fleet.cattle.io -A -o json)"
not_ready="$(jq -r --argjson managed "${managed_bundles_json}" '
  [ .items[] as $bd
    | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
       ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
    | select($managed | index($bundle))
    | select(($bd.status.ready // false) != true)
  ] | length' <<<"${bundledeployments_json}")"

if [[ "${not_ready}" != "0" ]]; then
  jq -r --argjson managed "${managed_bundles_json}" '
    .items[] as $bd
    | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
       ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
    | select($managed | index($bundle))
    | select(($bd.status.ready // false) != true)
    | [$bd.metadata.namespace, $bd.metadata.name, ($bd.status.message // "not Ready")] | @tsv' \
    <<<"${bundledeployments_json}" >&2
  die "${not_ready} BundleDeployment(s) owned by this repository are not Ready."
fi

log "Fleet reconciliation validation passed for ${managed_count} repository-owned Bundle(s)."
