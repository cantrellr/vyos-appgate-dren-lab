# Cluster host preflight

## Chrony

`scripts/management/preflight/cluster-time.sh` renders and applies `yaml/resources/segment1-chrony-daemonset.yaml` to selected contexts. The default is all four clusters.

```bash
export NTP_SERVERS='1.0.0.1 1.0.0.2'
scripts/management/preflight/cluster-time.sh --all
```

The DaemonSet uses privileged host PID/network access to disable `systemd-timesyncd` and run the air-gapped Chrony image. Required images:

```text
kubeharbor.dev.kube/library/ultimate-k8s-toolbox:v1.0.1
kubeharbor.dev.kube/library/chrony-air-gapped:v0.1.4
```

The `kube-system/regcred-kubeharbor` Secret must exist. Removing the DaemonSet does not re-enable `systemd-timesyncd`; restoration is a separate host change.

```bash
scripts/management/preflight/cluster-time.sh --all --uninstall
```

## iSCSI and multipath

The storage preflight obtains each node's InternalIP from Kubernetes and connects by SSH. It installs or verifies `open-iscsi` and `multipath-tools`, converges a minimal baseline, enables `iscsid`/`multipathd`, and validates the effective multipath configuration.

```bash
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"
export SSH_STRICT_HOST_KEY_CHECKING=yes
scripts/management/preflight/iscsi-multipath-fix.sh --all
```

Requirements:

- node host keys already in `known_hosts`, or deliberately use `accept-new` for first enrollment;
- key-based, noninteractive SSH;
- passwordless `sudo` for package, file, and service operations;
- Ubuntu/Debian package management;
- maintenance-window approval.

The default baseline is:

```text
defaults {
    user_friendly_names no
    find_multipaths no
}
```

If a different `/etc/multipath.conf` already exists, the script stops rather than overwriting vendor/site policy. After review, approve replacement with `--replace-existing-config` or `REPLACE_EXISTING_CONFIG=true`; the old file is backed up with a UTC timestamp.

## Orchestrator

```bash
scripts/deploy-platform.sh host-preflight
```

`onboard` and `all` also execute host preflight before registering Fleet, ensuring Trident is not deployed before iSCSI/multipath readiness.
