# Rancher registry validation and Helm operation recovery

## Why `helm-operation-*` pods matter

Rancher uses temporary `helm-operation-*` pods in `cattle-system` to install and upgrade Rancher-managed system charts. The pod normally contains a Helm container and a proxy sidecar. A `1/2 Error` result usually means the Helm command failed while the proxy sidecar remained available.

For this deployment, the critical Rancher-managed releases are Rancher Webhook and Fleet. Rancher is not considered ready until all of the following exist and are available:

- `cattle-system/rancher-webhook`;
- `cattle-fleet-system/fleet-controller`;
- `cattle-fleet-system/gitjob` (the workload name remains `gitjob`, but Fleet v0.10+ runs it from the `rancher/fleet` image; no separate `rancher/gitjob` image is required);
- `cattle-fleet-local-system/fleet-agent`;
- Fleet cluster, GitRepo, and BundleDeployment CRDs;
- `fleet-local/local`.

## Artifact ownership

The seg1opdev repository contains the local `rancher-2.14.2.tgz` bootstrap chart and all deployment/repair logic. It does not download, save, load, retag, or push Rancher container images.

Rancher image acquisition and promotion are owned by `cantrellr/k8s-airgap-images`. That repository must provide a Rancher image list containing the complete v2.14.2 inventory and promote the images into `kubeharbor.dev.kube` using strip-registry mapping.

Configure the staged list path:

```bash
RANCHER_IMAGE_LIST_FILE=/home/k8admin/k8s-airgap-images/source-lists/rancher-images.list
RANCHER_REGISTRY_ENFORCE=true
RANCHER_REGISTRY_VALIDATE_MODE=all
```

The validator rejects undersized lists and requires the Rancher, shell, Fleet, Fleet Agent, GitJob, Rancher Agent, and Rancher Webhook image families.

## Registry and node validation

Every `j64seg1opman` node must trust and authenticate to KubeHarbor through `/etc/rancher/rke2/registries.yaml`. A Kubernetes image pull Secret alone is not sufficient for every Rancher-created system workload.

Run:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
```

This command:

1. validates the external image list;
2. checks the selected image manifests in KubeHarbor;
3. creates a temporary DaemonSet with `imagePullPolicy: Always` and no Kubernetes pull Secret;
4. confirms every management node can pull a Rancher image using node-level RKE2 registry configuration;
5. removes the temporary namespace.

## Rancher Helm chart ownership

The Rancher chart is installed directly from:

```text
helm/packages/rancher-2.14.2.tgz
```

It is listed in `helm/required-packages.txt` for package integrity, but excluded from `helm/fleet-oci-packages.txt`. `publish-fleet-charts.sh` therefore does not push the Rancher bootstrap chart. Fleet-owned application charts are still published to `oci://kubeharbor.dev.kube/k8mm-charts`.

Rancher's bundled system charts are delivered by Rancher Manager after installation. Their container images must already exist in KubeHarbor.

## Rancher ingress and downstream-cluster WebSockets

Rancher downstream cluster agents use the remotedialer WebSocket endpoint at:

```text
wss://rancher.dev.kube/v3/connect/register
```

The Contour `HTTPProxy` in
`yaml/j64/seg1opman-cluster/resources/rancher-j64manager-resources-v1.yaml`
must enable WebSockets on the root route to the Rancher service:

```yaml
routes:
  - conditions:
      - prefix: /
    enableWebsockets: true
    services:
      - name: rancher
        port: 80
```

Without this setting, the Rancher UI and `/ping` endpoint can remain reachable while
`cattle-cluster-agent` repeatedly fails registration with:

```text
403 Forbidden
websocket: bad handshake
```

The Rancher installer applies this manifest during bootstrap. The repair workflow
reapplies it for an existing installation, and Rancher system validation fails when
the route is missing, invalid, or not WebSocket-enabled.

## Repair an existing failed installation

After the image inventory is present and node pulls pass, run:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow:

1. reruns external image-list, Harbor, and node-pull validation;
2. refreshes `regcred-kubeharbor` in existing Rancher namespaces;
3. attaches the pull Secret to existing Rancher/Fleet service accounts as a fallback;
4. removes failed temporary Helm operation pods/resources;
5. reapplies the Rancher certificate and WebSocket-enabled Contour `HTTPProxy`;
6. restarts Rancher to force system-chart reconciliation;
7. waits for the Rancher route, Webhook, Fleet, GitJob, the local agent, Fleet CRDs, and `fleet-local/local`.

Do not delete healthy Rancher/Fleet resources manually. The repair command removes only failed temporary Helm operations and lets Rancher reconcile desired state.

## Validation and diagnostics

```bash
./scripts/deploy-platform.sh validate-rancher-system
```

Validation also confirms that `cattle-system/rancher-httpproxy` is valid and enables WebSockets on the root route to `rancher:80`. When validation fails, it prints Rancher/Fleet workload state, the full `HTTPProxy` state, waiting and terminated container reasons, Helm logs from failed `helm-operation-*` pods, and recent Rancher system-chart errors.

The `fleet` phase runs this validation before attempting to label Fleet clusters. This prevents a missing Fleet installation from being misreported as a display-name lookup problem.

## Version alignment

The deployment remains pinned to Rancher `2.14.2` and RKE2 `v1.35.6+rke2r1`. The Rancher chart declares Kubernetes `<1.36.0-0`, so RKE2 1.35.6 satisfies that chart constraint. Helm 3.18 or newer is enforced by the installer.
