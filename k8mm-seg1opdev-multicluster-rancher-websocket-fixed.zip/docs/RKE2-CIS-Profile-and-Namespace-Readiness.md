# RKE2 CIS profile and namespace readiness

RKE2 CIS mode does not make third-party charts automatically compliant. This repository explicitly labels namespaces, disables unwanted service-account token mounting, and documents privileged exceptions.

## Namespace baseline

| Namespace | PSA enforcement | Reason |
| --- | --- | --- |
| `cert-manager` | restricted | certificate controllers/webhooks |
| `segment1` | restricted | Contour/Envoy hardened chart configuration |
| `elastic-monitoring` | restricted | kube-state-metrics |
| `oppostgres` | restricted | PostgreSQL/CNPG data tier |
| `opkeycloak` | restricted | Keycloak/operator |
| `metallb-system` | privileged | speaker networking |
| `trident-system` | privileged | CSI/node/storage access |
| `trident-protect` | privileged | storage protection controllers |
| `istio-system` | privileged | Istio CNI and gateway requirements |
| `elastic-agent-system` | privileged | host logs, metrics, networking, and persistence |

Automatic Istio injection is disabled in all platform namespaces. Application namespaces opt in separately under the injection contract.

## Validation

```bash
scripts/security/01-verify-cis-readiness.sh --all
scripts/istio/05-audit-namespace-injection.sh --all
```

Review chart upgrades for new capabilities, host mounts, service-account permissions, seccomp settings, and root requirements before changing a namespace profile. Do not solve an individual pod failure by broadly labeling an unrelated namespace privileged.

## Documented exceptions

Chrony is deployed in `kube-system` as a privileged host-time agent. The Elastic Agent namespace is privileged by design. These exceptions should be included in the platform security plan and monitored for unexpected workloads.
