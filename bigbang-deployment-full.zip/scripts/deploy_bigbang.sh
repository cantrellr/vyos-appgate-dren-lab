#!/usr/bin/env bash
# deploy_bigbang.sh
#
# This script demonstrates how to deploy Big Bang onto an RKE2
# (Rancher Kubernetes Engine 2) cluster using Flux and Helm.  It
# assumes you have prepared your images with the accompanying
# ``pull_retag_push.sh`` script and that your cluster can access the
# target registry (ALT_REGISTRY) defined in your values file.  The
# script includes extensive comments to aid in understanding the
# workflow; adjust paths and configuration values as necessary for
# your environment.

set -euo pipefail

###############################################################################
# 1. Prerequisites
#
# Ensure the following tools are installed on the machine executing this script:
#   - kubectl (matching your RKE2 version)
#   - helm (version ≥ 3.9)
#   - flux CLI (version ≥ 2.1)
#   - jq and yq for manipulating YAML (optional but recommended)
#   - Access to the RKE2 cluster via KUBECONFIG
#   - Access to the private image registry (ALT_REGISTRY) containing your
#     retagged images.  See ``pull_retag_push.sh`` for instructions on
#     preparing the registry.
###############################################################################

# Configurable variables
BB_NAMESPACE="bigbang"
BB_RELEASE="bigbang"
BB_VERSION="3.8.0"  # Update to desired Big Bang release
ALT_REGISTRY="${ALT_REGISTRY:-altregistry.dev.kube:8443}"
VALUES_FILE="${VALUES_FILE:-$(dirname "$0")/../values.yaml}"

###############################################################################
# 2. Install Flux (if not already installed)
#
# Flux is used as the GitOps engine to manage the Big Bang HelmRelease.
# The following section installs Flux into the ``flux-system`` namespace
# using manifests provided by the Big Bang project.  You may omit this
# step if Flux is already running on your cluster.
#
# Note: The sample script expects that the Big Bang repository (or a
# mirror of it) has been extracted into ``bigbang`` relative to this
# script.  The flux manifests are located in ``scripts/deploy/flux.yaml``
# within that repository.  If you are deploying from a Git mirror, update
# the path accordingly.
###############################################################################

if ! kubectl get ns flux-system &> /dev/null; then
  echo "Installing Flux components…"
  # Install Flux using the CLI.  This command installs the source,
  # kustomize and helm controllers into the flux-system namespace.  See
  # https://fluxcd.io/docs/installation/ for additional options.
  flux install \
    --components-extra=image-reflector-controller,image-automation-controller
else
  echo "Flux appears to be installed; skipping installation."
fi

###############################################################################
# 3. Prepare namespace and secrets
#
# Big Bang uses a dedicated namespace.  Create it if it does not exist.
# Additionally, set up a Kubernetes secret to hold the credentials for
# your private registry.  This secret will be referenced in your
# ``values.yaml`` via ``registryCredentials``.  If your registry is
# unauthenticated, this secret may be omitted.
###############################################################################

if ! kubectl get ns "$BB_NAMESPACE" &> /dev/null; then
  echo "Creating namespace $BB_NAMESPACE"
  kubectl create namespace "$BB_NAMESPACE"
fi

# Create a docker-registry secret for the private registry.  Replace
# ALT_USERNAME and ALT_PASSWORD with your registry credentials.  If
# authentication is not required, you can skip creating this secret and
# remove ``registryCredentials`` from your values file.
#
# Example:
# kubectl create secret docker-registry regcred \
#   --namespace "$BB_NAMESPACE" \
#   --docker-server="$ALT_REGISTRY" \
#   --docker-username="$ALT_USERNAME" \
#   --docker-password="$ALT_PASSWORD" \
#   --docker-email="user@example.com"

###############################################################################
# 4. Customize values.yaml
#
# The ``values.yaml`` file controls which Big Bang packages are enabled
# and configures registry information.  A sample ``values.yaml`` has
# been provided in this repository.  Adjust the following keys:
#
#   registryCredentials.registry   – Set to your private registry
#   registryCredentials.username   – Set to your registry username
#   registryCredentials.password   – Set to your registry password
#   hostname                       – Base domain for services (e.g. bb.example.com)
#   clusterDeploymentType          – Set to "standalone" for RKE2
#   istio.enabled, kyverno.enabled, etc. – Enable/disable Big Bang
#     packages as desired.  By default, all core packages are enabled.
#
# When ready, commit ``values.yaml`` to your Git repository so that Flux
# can reconcile it.
###############################################################################

###############################################################################
# 5. Install Big Bang via HelmRelease
#
# With Flux running and your values configured, create a HelmRelease
# resource that points at the Big Bang helm chart.  The chart is
# included in the Big Bang Git repository.  The following command
# leverages helm directly for a one‑time installation; in production
# environments you would commit a HelmRelease manifest to your GitOps
# repo and let Flux manage it.
###############################################################################

echo "Installing Big Bang release ${BB_RELEASE} using Helm…"

helm upgrade --install "$BB_RELEASE" ./chart \
  --namespace "$BB_NAMESPACE" \
  --create-namespace \
  --version "$BB_VERSION" \
  -f "$VALUES_FILE"

###############################################################################
# 6. Monitor deployment
#
# After running the helm upgrade command, Big Bang’s controllers and
# packages will begin deploying.  Use the following commands to
# monitor progress:
#
#   watch kubectl get hr,gitops,helmreleases -n "$BB_NAMESPACE"
#   watch kubectl get pods -n "$BB_NAMESPACE"
#
# It may take several minutes for all components to become ready.
###############################################################################

echo "Big Bang deployment initiated.  Monitor the namespace ${BB_NAMESPACE} for component status."