#!/usr/bin/env bash
# pull_retag_push.sh
#
# This script prepares container images for use with Big Bang on an
# internet‑restricted cluster.  It reads a list of container image
# references from the file ``images.txt`` in the parent directory, pulls
# each image from its upstream registry, retags it to the target
# registry (``ALT_REGISTRY``) and pushes the retagged image.  Images
# are fetched using ``docker`` but it is trivial to adapt this script
# to use ``skopeo`` or ``ctr`` if preferred.
#
# Usage:
#   export ALT_REGISTRY=altregistry.dev.kube:8443
#   export ALT_USERNAME=<username>
#   export ALT_PASSWORD=<password>
#   ./pull_retag_push.sh
#
# Environment variables:
#   ALT_REGISTRY   – The hostname (and optional port) of the private
#                    registry you control.  This value replaces
#                    ``registry1.dso.mil`` in each image reference.
#   ALT_USERNAME   – Username for the private registry.  Optional if
#                    your registry is unauthenticated or if you have
#                    already logged in.
#   ALT_PASSWORD   – Password for the private registry.  Optional if
#                    your registry is unauthenticated or if you have
#                    already logged in.
#   IMAGES_FILE    – Path to the images list.  Defaults to
#                    ``../images.txt``.
#
# The script logs its progress and writes a report to ``image_prep.log``.
set -euo pipefail

# Default images file
IMAGES_FILE="${IMAGES_FILE:-$(dirname "$0")/../images.txt}"
# Check variables
if [[ -z "${ALT_REGISTRY:-}" ]]; then
  echo "ERROR: ALT_REGISTRY is not set.  Please set the target registry (e.g. altregistry.dev.kube:8443)" >&2
  exit 1
fi

LOG_FILE="$(pwd)/image_prep.log"
echo "Starting image preparation at $(date)" | tee "$LOG_FILE"

# Log in to the target registry if credentials are provided.
if [[ -n "${ALT_USERNAME:-}" && -n "${ALT_PASSWORD:-}" ]]; then
  echo "Logging in to ${ALT_REGISTRY}…" | tee -a "$LOG_FILE"
  echo "$ALT_PASSWORD" | docker login "$ALT_REGISTRY" --username "$ALT_USERNAME" --password-stdin | tee -a "$LOG_FILE"
else
  echo "Skipping docker login – no credentials provided.  Ensure you have access to ${ALT_REGISTRY}." | tee -a "$LOG_FILE"
fi

# Ensure the images file exists
if [[ ! -f "$IMAGES_FILE" ]]; then
  echo "ERROR: images file '$IMAGES_FILE' not found." >&2
  exit 1
fi

# Iterate through each image in the list
while IFS= read -r IMAGE; do
  # Skip empty lines and comments
  [[ -z "$IMAGE" ]] && continue
  [[ "$IMAGE" =~ ^# ]] && continue

  SOURCE_IMAGE="$IMAGE"
  # Derive destination image by replacing the upstream registry prefix
  # with the alternate registry.  The upstream images are hosted on
  # registry1.dso.mil; we strip the first component up to the first
  # slash and prefix it with ALT_REGISTRY.  For example:
  #   registry1.dso.mil/ironbank/opensource/grafana/loki →
  #   altregistry.dev.kube:8443/ironbank/opensource/grafana/loki
  DEST_IMAGE="${IMAGE#registry1.dso.mil/}"
  DEST_IMAGE="${ALT_REGISTRY}/${DEST_IMAGE}"

  echo "Processing $SOURCE_IMAGE → $DEST_IMAGE" | tee -a "$LOG_FILE"

  # Pull the source image from its upstream registry
  if ! docker pull "$SOURCE_IMAGE" &>> "$LOG_FILE"; then
    echo "WARNING: Failed to pull $SOURCE_IMAGE" | tee -a "$LOG_FILE"
    continue
  fi
  # Tag the image for the destination registry
  docker tag "$SOURCE_IMAGE" "$DEST_IMAGE" | tee -a "$LOG_FILE"
  # Push the tagged image to the private registry
  if ! docker push "$DEST_IMAGE" &>> "$LOG_FILE"; then
    echo "ERROR: Failed to push $DEST_IMAGE" | tee -a "$LOG_FILE"
    continue
  fi

  echo "Successfully pushed $DEST_IMAGE" | tee -a "$LOG_FILE"
  # Optionally remove local copies to save disk space
  docker image rm "$SOURCE_IMAGE" "$DEST_IMAGE" &> /dev/null || true
done < "$IMAGES_FILE"

echo "Image preparation complete at $(date)" | tee -a "$LOG_FILE"