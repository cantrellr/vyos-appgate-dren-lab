# Getting Started with Big Bang on RKE2

This guide provides a short, opinionated introduction to deploying
Big Bang onto a stand‑alone RKE2 cluster using the resources in this
repository.  It summarizes the key steps from the Big Bang Quick Start
guide【272137359390158†L920-L936】 and adapts them for an air‑gapped
environment.

## 1. Satisfy the prerequisites

Before you begin, ensure your workstation and cluster meet these
requirements【272137359390158†L944-L967】:

- A running RKE2 cluster with `kubectl` access and a default
  storage class.
- A private container registry reachable from the cluster (e.g.,
  `altregistry.dev.kube:8443`).
- A UNIX workstation with `bash` (version 4+), `kubectl`, `helm`, the
  [Flux CLI](https://fluxcd.io/docs/installation/), `jq` and `yq`.
- An account on the upstream registry (`registry1.dso.mil`) if you
  need to pull images directly.

## 2. Clone or download this repository

Clone this repository or download the zip archive.  From a shell:

```sh
git clone https://example.com/bigbang-deployment.git
cd bigbang-deployment
```

## 3. Pull and retag images

Run the following command to pull all images listed in
`images.txt`, retag them for your private registry, and push them:

```sh
export ALT_REGISTRY=altregistry.dev.kube:8443
export ALT_USERNAME=<registry user>
export ALT_PASSWORD=<registry password>
make images
```

Depending on your connection, this may take several minutes because
there are over 100 images to transfer【272137359390158†L1026-L1037】.

## 4. Customize configuration

Edit `values.yaml` to set your domain name (`hostname`), registry
credentials and any package‑specific overrides.  By default, all core
packages (Istio, Kyverno, Kiali, Loki, Tempo, Grafana, NeuVector,
metrics‑server) are enabled【272137359390158†L920-L936】.  Refer to the
Big Bang values guide for a full list of options.

## 5. Deploy Flux and Big Bang

Install Flux and deploy Big Bang:

```sh
make install
```

This will install Flux into the `flux-system` namespace, create a
namespace for Big Bang, and run a Helm upgrade to install the
Big Bang chart using your `values.yaml`.  Monitor progress with:

```sh
kubectl get pods -n bigbang
kubectl get hr,gitops,helmreleases -n bigbang
```

The initial deployment downloads all images and may take time.  Be
patient—this is normal【272137359390158†L1026-L1037】.

## 6. Access services

Once all pods are running, point your DNS or hosts file at your
cluster’s ingress IP and access services via the hostnames under
`hostname`.  For example, if `hostname` is set to `bigbang.dev`, you
can reach Grafana at `https://grafana.bigbang.dev` and Kiali at
`https://kiali.bigbang.dev`.

## 7. Extend and customize

After the core packages are up and running, you can explore Big Bang
add‑on packages (GitLab, Harbor, Keycloak, etc.) or onboard your own
applications using the Istio ingress gateway.  For package‑specific
instructions consult the
[Big Bang documentation](https://docs-bigbang.dso.mil/latest/docs/).  You
may also wish to configure network policies, integrate SSO and set
up backups using Velero.  Contributions adding additional docs to this
repository are welcome!