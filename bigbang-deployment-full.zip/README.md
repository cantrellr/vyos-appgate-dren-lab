# Big Bang Deployment on RKE2

This repository provides a repeatable process for deploying the
[Big Bang](https://docs-bigbang.dso.mil/latest/docs/) umbrella chart onto a
stand‑alone [RKE2](https://docs.rke2.io/) cluster that acts as a security
cluster.  The goal is to mirror the structure of the
`k8s‑mystical‑mesh` repository by capturing all of the steps necessary to
prepare container images, retag them for an internal registry, and
deploy the Big Bang core packages using GitOps principles.  All scripts
are thoroughly commented and the documentation in this repository
explains **why** each step exists, not just how to run it.

## Overview

Big Bang is a declarative GitOps framework that bundles a curated set
of cloud‑native tools into a single Helm chart.  When installed, it
deploys a service mesh, policy enforcement, observability stack, and
security tooling.  According to the Big Bang Quick Start guide, a
default installation includes Istio CRDs and control plane, Ingress
gateways, Kiali, Kyverno, Loki (via Alloy), the metrics‑server, Grafana,
Tempo and NeuVector【272137359390158†L920-L936】.  These components provide
secure networking, admission control, logging, metrics, tracing, a
dashboard, and container runtime protection out of the box.  Big Bang
can deploy additional add‑on packages such as GitLab, Harbor, Keycloak
or Velero, but this repository focuses on the core packages needed to
bootstrap a security cluster.

## Cluster topology and design

We assume a single RKE2 cluster consisting of one or more Linux nodes.
The cluster will be provisioned with RKE2’s bundled container runtime
(`containerd`).  A private registry (`altregistry.dev.kube:8443`) is
used to host all container images; images are pulled from public
registries, retagged and pushed to the private registry ahead of time.
Flux serves as the GitOps engine to reconcile the state of the cluster
with the contents of this repository.  At a high level the topology
looks like this:

![Big Bang architecture](docs/bigbang-diagram.png)

* **GitOps Engine (Flux)** – watches this Git repository and applies
  Helm releases and Kustomizations to the cluster.
* **Private Registry** – holds all container images required by Big Bang
  after they have been retagged.  This example uses
  `altregistry.dev.kube:8443`.
* **RKE2 Security Cluster** – runs the core Big Bang packages.  Inside
  the cluster:
  * **Istio Service Mesh** – provides secure, mTLS‑enabled traffic
    between services and exposes ingress gateways.
  * **Kyverno Policies** – enforces admission control policies and
    default settings for applications.
  * **Grafana & Loki (Observability)** – stores and visualizes logs
    collected by Alloy and other agents.
  * **Tempo (Tracing)** – collects and exposes distributed traces for
    the observability stack.
  * **Kiali** – visualizes and troubleshoots the Istio service mesh.
  * **NeuVector** – provides runtime security for container workloads
    and network flows.
  * **Metrics Server** – exposes resource utilization metrics to the
    Kubernetes API for autoscaling and monitoring.

## Repository layout

```
bigbang-deployment/
├── images.txt            # list of all container images used by Big Bang
├── values.yaml           # opinionated Big Bang configuration for RKE2
├── scripts/              # helper scripts used during deployment
│   ├── pull_retag_push.sh    # script to download, retag and push images
│   └── deploy_bigbang.sh     # script to install Flux and Big Bang
└── docs/
    └── bigbang-diagram.png  # conceptual architecture diagram
```

### `images.txt`

The file `images.txt` contains one container image reference per line
for a particular Big Bang release.  This list was sourced from the
official Big Bang release artifacts (the Big Bang Airgap guide mentions
that all required images are packaged in `images.tar.gz` and listed
in an accompanying `images.txt` file【953149376188859†L1036-L1123】).
During deployment the images are pulled from their upstream sources
(such as `registry1.dso.mil/ironbank`), retagged to
`altregistry.dev.kube:8443`, and pushed to the private registry.  The
list in this repository is for Big Bang 3.8.0 and may need to be
updated when deploying a newer version.  To update it, fetch the
`images.txt` from the desired release and replace this file.

### `values.yaml`

The `values.yaml` file provides a starting configuration for Big Bang.
It sets the cluster type to `standalone`, defines your private
registry credentials, enables the core packages, and overrides some
default values (such as enabling persistence for Grafana, Loki and
Tempo).  You should review and customize this file according to your
environment.  For example:

- **Hostname** – update the `hostname` field to match the domain you
  intend to use for accessing Big Bang services (e.g.,
  `bigbang.example.com`).
- **Registry credentials** – provide your own username and password for
  the internal registry; these are used by Flux to pull images.
- **Package settings** – enable or disable packages by setting
  `enabled: true/false` and adjust values such as resource limits or
  storage sizes.

For a complete reference of available values, see the
[Big Bang Values Guide](https://docs-bigbang.dso.mil/latest/docs/values/).

### `scripts/pull_retag_push.sh`

This script automates the process of downloading all container images
listed in `images.txt`, retagging them to your private registry, and
pushing them.  The script uses the following workflow:

1. Load environment variables from `.env` (optional) and set defaults
   for the private registry and working directory.
2. Log in to the private registry if `ALT_USERNAME` and `ALT_PASSWORD`
   are provided.
3. Loop through each image in `images.txt`:
   * Pull the image from the upstream registry using `docker pull`.
   * Compute a new tag by replacing the upstream registry prefix with
     your private registry (e.g., `registry1.dso.mil/ironbank/...`
     becomes `altregistry.dev.kube:8443/ironbank/...`).
   * Tag the local image with the new repository and tag.
   * Push the retagged image to the private registry using `docker push`.
4. Write progress messages to both standard output and
   `image_prep.log` for later review.

Run the script from the repository root:

```sh
cd bigbang-deployment
export ALT_REGISTRY=altregistry.dev.kube:8443
export ALT_USERNAME=<your-registry-username>
export ALT_PASSWORD=<your-registry-password>
./scripts/pull_retag_push.sh
```

This step can take some time; there are over 100 images to
download and push for Big Bang 3.8.0.  Ensure you have sufficient
storage space and network bandwidth.

### `scripts/deploy_bigbang.sh`

The `deploy_bigbang.sh` script demonstrates how to bootstrap Flux and
install Big Bang on your RKE2 cluster.  It performs the following high
level tasks:

1. **Prerequisite checks** – verifies that `kubectl`, `helm` and the
   [Flux CLI](https://fluxcd.io/docs/installation/) are available
   and points out other prerequisites from the Big Bang Quick Start
   such as `jq` and `yq`【272137359390158†L944-L967】.
2. **Flux install** – installs the Flux components into the
   `flux-system` namespace.
3. **Secrets** – creates a Kubernetes Secret containing your private
   registry credentials (`regcred`) in the `bigbang` namespace so that
   Flux can pull images from `altregistry.dev.kube:8443`.
4. **GitOps sources** – configures a Flux `GitRepository` pointing to
   this repository and a `HelmRepository` pointing to the Big Bang
   chart (optionally you can mirror the chart internally).  It then
   creates a `HelmRelease` that references `values.yaml` to deploy
   Big Bang.
5. **Monitoring deployment** – suggests watching
   `flux get helmreleases -n bigbang` or `kubectl get pods -n bigbang`
   to monitor progress.  The Quick Start notes that a first
   deployment may take some time because all container images must be
   downloaded【272137359390158†L1026-L1037】.

You can run the script after editing `values.yaml` and pushing your
changes to the branch watched by Flux.  In a production workflow you
would commit changes to a Git server; the script uses `flux` to
configure this repository as the source.

## Prerequisites

Before running any of the scripts in this repository ensure the
following:

- You have an RKE2 cluster provisioned with working `kubectl`
  connectivity and a default storage class.
- Your workstation has the following tools installed: bash (version
  4 or later), `kubectl`, `helm`, the Flux CLI, `jq`, `yq` and the
  Docker or Podman client.  These tools are also listed as
  prerequisites in the Big Bang Quick Start【272137359390158†L944-L967】.
- You have access to a private registry reachable from the cluster.
- [GitOps](https://fluxcd.io/) permissions: Flux will need access
  (either via SSH deploy key or personal access token) to pull this
  repository.  For simplicity the example script uses a local
  filesystem path; adapt it as necessary for your Git server.

## Deployment sequence

The recommended sequence for deploying Big Bang is as follows:

1. **Prepare images** – Run `scripts/pull_retag_push.sh` to pull,
   retag and push all images from `images.txt` into your private
   registry.  Verify that all images are present by listing
   repositories on the registry or running `docker images`.
2. **Customize configuration** – Edit `values.yaml` to reflect your
   domain name, registry credentials and any package‑specific
   overrides (e.g., enabling/disabling packages, adjusting resource
   limits).  Commit these changes to your Git repository.
3. **Install Flux** – Use `scripts/deploy_bigbang.sh` or manually
   install Flux into your cluster.  Create the registry Secret and
   configure the Flux `GitRepository`, `HelmRepository` and
   `HelmRelease` resources.  Flux will install Big Bang using the
   values defined in `values.yaml`.
4. **Verify** – Monitor the rollout using `kubectl get helmreleases
   -n bigbang`, `kubectl get pods -n istio-system`, etc.  Ensure that
   all pods reach the `Running` state.  You can access services via
   the Istio ingress gateway using the hostname configured in
   `values.yaml`.
5. **Add mission applications** – Once the core packages are
   operational you can onboard mission applications or deploy
   additional Big Bang packages.  Refer to the Big Bang documentation
   for package‑specific instructions.

## Troubleshooting and notes

- If pods remain in `Pending` or `ContainerCreating` for a long time,
  it is often due to slow image downloads【272137359390158†L1026-L1037】.  Check
  network connectivity between the cluster and your registry.
- Always pin image tags in `values.yaml` if you override a default
  image repository.  This ensures reproducible builds.
- For advanced customizations (e.g., enabling service mesh passthrough
  gateways, adjusting network policies), consult the Big Bang
  documentation under **Values Guide**, **Network Policies** and
  package‑specific guides.

---

### Acknowledgements

This repository was inspired by the deployment process documented in
the `k8s‑mystical‑mesh` repository.  It combines lessons from the
Big Bang Quick Start documentation and airgap guides【953149376188859†L1036-L1123】【272137359390158†L920-L936】.
Contributions and improvements are welcome.