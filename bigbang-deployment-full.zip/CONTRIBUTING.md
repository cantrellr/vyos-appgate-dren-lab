# Contributing to Big Bang Deployment

We welcome contributions to this repository!  Whether you want to improve documentation, fix a bug, or add a new feature, your help is appreciated.

## Getting started

1. Fork the repository on GitHub.
2. Create a feature branch from `main`.
3. Make your changes, ensuring that the scripts and YAML files remain well commented and maintainable.  Follow the style conventions used in this repository.
4. If you add or modify a script, run [`shellcheck`](https://www.shellcheck.net/) to catch common issues.  If you add Helm values, run `helm template` to ensure your changes are valid.
5. Commit your changes with a clear and concise commit message.
6. Push the branch to your fork and open a pull request.  Describe what you’ve done and reference any relevant issues.

## Code style

* **Shell scripts** – Use `bash -eu -o pipefail` at the top of scripts.  Add helpful comments and usage examples.
* **YAML** – Keep indentation consistent (2 spaces).  Avoid duplicate keys.  Document any non‑default values.
* **Markdown** – Use descriptive headings, short paragraphs and lists to break up content.

## Reporting issues

If you encounter a problem using this repository, please open an issue.  Include a clear description of the problem, steps to reproduce, and any relevant logs or error messages.

## License and CLA

By contributing to this repository you agree that your contributions will be licensed under the MIT license (see `LICENSE`).