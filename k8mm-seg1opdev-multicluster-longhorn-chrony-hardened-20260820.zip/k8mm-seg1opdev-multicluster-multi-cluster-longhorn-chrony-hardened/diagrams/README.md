# Diagrams

> Documentation baseline: v2.1 — August 20, 2026.

- `multicluster-platform.mmd` — current Rancher/Fleet, four-cluster, identity, mesh, and Elastic monitoring topology.

Mermaid source is kept in Git so architectural changes are reviewable. Update the source whenever cluster roles, control-plane ownership, identity roles, or external service dependencies change.
