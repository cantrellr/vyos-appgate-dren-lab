# Application bundle extension point

> Documentation baseline: v2.1 — August 20, 2026.

This directory is intentionally not an active Fleet bundle and therefore contains no `fleet.yaml`.

Create a separate numbered directory for each production application rather than placing unrelated resources into one catch-all bundle. Each new bundle must define:

- a unique `name` and `kmm.dev/bundle` label;
- explicit `dependsOn` selectors;
- cluster targeting plus a catch-all `doNotDeploy` guard when scope is limited;
- KubeHarbor chart/image references;
- runtime Secret ownership outside Git;
- PSA, Istio injection, Segment1 backend, and NetworkPolicy decisions;
- readiness/rollback validation;
- package/checksum/OCI inventory updates and documentation.
