#!/usr/bin/env bash
# shellcheck shell=bash
if [[ -n "${KMM_COMMON_SH_LOADED:-}" ]] && declare -F require_cmd >/dev/null 2>&1; then
  return 0 2>/dev/null || exit 0
fi
# The marker can be inherited by child shells even though shell functions are not.
unset KMM_COMMON_SH_LOADED
export KMM_COMMON_SH_LOADED=1
KMM_COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ROOT_DIR="${KMM_ROOT_DIR:-$(cd "${KMM_COMMON_DIR}/../.." && pwd)}"
export INSTALL_DIR="${ROOT_DIR}/scripts"
export YAML_DIR="${ROOT_DIR}/yaml"
export HELM_PACKAGES_DIR="${ROOT_DIR}/helm/packages"
export RUNTIME_NAME="${KMM_RUNTIME_NAME:-seg1opdev}"
export RUNTIME_DIR="${KMM_RUNTIME_DIR:-${HOME}/.config/k8mm-${RUNTIME_NAME}-multicluster}"
export ISTIO_CACERTS_DIR="${ISTIO_CACERTS_DIR:-${RUNTIME_DIR}/istio-cacerts}"
export REGISTRY_HOST="${REGISTRY_HOST:-kubeharbor.dev.kube}"
export REGISTRY_SECRET="${REGISTRY_SECRET:-regcred-kubeharbor}"
export REGISTRY_SOURCE_NAMESPACE="${REGISTRY_SOURCE_NAMESPACE:-kube-system}"
# Private DNS forwarders used by the rendered RKE2 CoreDNS configuration.
# Values are space- or comma-separated IPv4 addresses and can be overridden in
# the protected runtime configuration file.
export DEV_KUBE_DNS_SERVERS="${DEV_KUBE_DNS_SERVERS:-1.0.1.34 1.0.1.35}"
export JDE_DNS_SERVERS="${JDE_DNS_SERVERS:-1.0.1.34 1.0.1.35}"
export JCP_DNS_SERVERS="${JCP_DNS_SERVERS:-10.22.1.34 10.22.1.35}"
export COREDNS_DNS_PROBE_IMAGE="${COREDNS_DNS_PROBE_IMAGE:-${REGISTRY_HOST}/rancher/shell:v0.7.0}"
export COREDNS_DNS_PROBE_TIMEOUT_SECONDS="${COREDNS_DNS_PROBE_TIMEOUT_SECONDS:-180}"
export FLEET_OCI_PROBE_IMAGE="${FLEET_OCI_PROBE_IMAGE:-${REGISTRY_HOST}/rancher/shell:v0.7.0}"
export FLEET_OCI_PROBE_TIMEOUT_SECONDS="${FLEET_OCI_PROBE_TIMEOUT_SECONDS:-180}"
export HELM_MIN_VERSION="${HELM_MIN_VERSION:-4.0.0}"
export HELM_TIMEOUT="${HELM_TIMEOUT:-15m}"
export KUBECTL_TIMEOUT="${KUBECTL_TIMEOUT:-900s}"
export SEGMENT1_NAMESPACE="${SEGMENT1_NAMESPACE:-segment1}"
export SEGMENT1_INGRESS_ALLOWED_CIDRS="${SEGMENT1_INGRESS_ALLOWED_CIDRS:-1.0.0.0/23}"
readonly KMM_SUPPORTED_CONTEXTS=(j64seg1opman j64seg1opdev j52seg1opdev r01seg1opdev)
log(){ printf '[INFO] %s\n' "$*"; }
warn(){ printf '[WARN] %s\n' "$*" >&2; }
die(){ printf '[ERROR] %s\n' "$*" >&2; exit 1; }
require_cmd(){ command -v "$1" >/dev/null 2>&1 || die "Required command not found in PATH: $1"; }
require_kubectl(){ require_cmd kubectl; }
require_helm(){
  require_cmd helm
  local helm_version
  helm_version="$(helm version --template '{{.Version}}' 2>/dev/null | sed 's/^v//')"
  [[ -n "${helm_version}" ]] || die "Unable to determine the Helm version."
  if [[ "$(printf '%s\n' "${HELM_MIN_VERSION}" "${helm_version}" | sort -V | head -1)" != "${HELM_MIN_VERSION}" ]]; then
    die "This deployment requires Helm ${HELM_MIN_VERSION} or newer because it uses --rollback-on-failure; found ${helm_version}."
  fi
}
require_kubernetes_tools(){ require_kubectl; require_helm; }
require_site_cluster_args(){ [[ "$1" -ge 2 ]] || die "Usage: $2 <site> <cluster>"; }
init_site_cluster(){ require_site_cluster_args "$#" "$0"; export SITE="$1" CLUSTER="$2" K8_CONTEXT="${1}${2}"; validate_supported_context "$K8_CONTEXT"; }
validate_supported_context(){ local c="$1" x; for x in "${KMM_SUPPORTED_CONTEXTS[@]}"; do [[ "$c" == "$x" ]] && return 0; done; die "Unsupported context: $c"; }
site_cluster_options_dir(){ printf '%s/%s/%s-cluster' "$YAML_DIR" "$1" "$2"; }
use_context(){ kubectl config use-context "$1" >/dev/null; }
validate_context_access(){ kubectl --context "$1" cluster-info >/dev/null 2>&1 || die "kubectl context $1 is not reachable"; }
ensure_namespace(){ local ns="$1" disable_istio="${2:-true}"; kubectl get ns "$ns" >/dev/null 2>&1 || kubectl create ns "$ns" >/dev/null; kubectl label --overwrite ns "$ns" kubernetes.io/metadata.name="$ns" >/dev/null; if [[ "$disable_istio" == true ]]; then kubectl label ns "$ns" istio.io/rev- istio-injection- --overwrite >/dev/null 2>&1 || true; fi; }
label_restricted_namespace(){ kubectl label --overwrite ns "$1" segment1.kmm.dev/restricted=true kmm.dev/network-zone=restricted >/dev/null; }
ensure_registry_secret(){ local ns="$1" src="${2:-$REGISTRY_SOURCE_NAMESPACE}" name="${3:-$REGISTRY_SECRET}"; require_cmd jq; kubectl get secret "$name" -n "$src" >/dev/null 2>&1 || die "Missing $src/$name. Run scripts/core/00-bootstrap-kubeharbor-regcred.sh first."; [[ "$ns" == "$src" ]] && return 0; kubectl get secret "$name" -n "$src" -o json | jq --arg ns "$ns" 'del(.metadata.uid,.metadata.resourceVersion,.metadata.creationTimestamp,.metadata.ownerReferences,.metadata.managedFields,.metadata.annotations["kubectl.kubernetes.io/last-applied-configuration"])|.metadata.namespace=$ns' | kubectl apply -f - >/dev/null; }
ensure_file(){ [[ -f "$1" ]] || die "Required file not found: $1"; }
ensure_dir(){ [[ -d "$1" ]] || die "Required directory not found: $1"; }
ensure_chart_package(){ ensure_file "$1"; }
validate_yaml_file(){ local f="$1"; ensure_file "$f"; if command -v yq >/dev/null 2>&1; then yq e '.' "$f" >/dev/null; elif command -v python3 >/dev/null 2>&1; then python3 - "$f" <<'PY2'
import sys
from pathlib import Path
try: import yaml
except Exception: raise SystemExit(0)
list(yaml.safe_load_all(Path(sys.argv[1]).read_text(encoding='utf-8')))
PY2
fi; }
helm_upgrade_install(){ local r="$1" c="$2" n="$3" v="$4"; shift 4; ensure_chart_package "$c"; validate_yaml_file "$v"; helm upgrade --install "$r" "$c" -n "$n" -f "$v" --rollback-on-failure --wait --timeout "$HELM_TIMEOUT" "$@"; }
apply_file(){ validate_yaml_file "$1"; kubectl apply -f "$1"; }
apply_file_in_namespace(){ local n="$1" f="$2"; validate_yaml_file "$f"; kubectl apply -n "$n" -f "$f"; }
wait_for_deployment_available(){ kubectl wait --for=condition=available --timeout="${3:-$KUBECTL_TIMEOUT}" deployment/"$2" -n "$1"; }
wait_for_deployment_rollout(){ kubectl rollout status deployment/"$2" -n "$1" --timeout="${3:-$KUBECTL_TIMEOUT}"; }
wait_for_statefulset_rollout(){ kubectl rollout status statefulset/"$2" -n "$1" --timeout="${3:-$KUBECTL_TIMEOUT}"; }
require_crd(){ kubectl get crd "$1" >/dev/null 2>&1 || die "Required CRD missing: $1"; }

render_segment1_network_policies() {
  local namespace="${1:-${SEGMENT1_NAMESPACE}}"
  local output_file="$2"
  local kube_api_ip=""
  local cidr=""

  kube_api_ip="$(kubectl get service kubernetes -n default -o jsonpath='{.spec.clusterIP}')"
  [[ -n "${kube_api_ip}" ]] || die "Unable to detect kubernetes.default service ClusterIP."

  cat >"${output_file}" <<YAML
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-default-deny
  namespace: ${namespace}
spec:
  podSelector: {}
  policyTypes: [Ingress, Egress]
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-dns-and-kubernetes-api
  namespace: ${namespace}
spec:
  podSelector: {}
  policyTypes: [Egress]
  egress:
    - to:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: kube-system
          podSelector:
            matchExpressions:
              - key: k8s-app
                operator: In
                values: [kube-dns, rke2-coredns-rke2-coredns]
      ports:
        - {protocol: UDP, port: 53}
        - {protocol: TCP, port: 53}
    - to:
        - ipBlock: {cidr: ${kube_api_ip}/32}
      ports:
        - {protocol: TCP, port: 443}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-approved-ingress-to-envoy
  namespace: ${namespace}
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes: [Ingress]
  ingress:
    - from:
YAML
  IFS=',' read -ra _segment1_cidrs <<<"${SEGMENT1_INGRESS_ALLOWED_CIDRS}"
  for cidr in "${_segment1_cidrs[@]}"; do
    cidr="$(printf '%s' "${cidr}" | xargs)"
    [[ -n "${cidr}" ]] && printf '        - ipBlock: {cidr: %s}\n' "${cidr}" >>"${output_file}"
  done
  cat >>"${output_file}" <<'YAML'
      ports:
        - {protocol: TCP, port: 80}
        - {protocol: TCP, port: 443}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-envoy-contour-xds
  namespace: segment1
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes: [Egress]
  egress:
    - to:
        - podSelector:
            matchLabels:
              app.kubernetes.io/component: contour
      ports:
        - {protocol: TCP, port: 8001}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-contour-xds-from-envoy
  namespace: segment1
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: contour
  policyTypes: [Ingress]
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app.kubernetes.io/component: envoy
      ports:
        - {protocol: TCP, port: 8001}
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-envoy-to-approved-backends
  namespace: segment1
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes: [Egress]
  egress:
    - to:
        - namespaceSelector:
            matchLabels:
              segment1.ingress/allow-backend: "true"
      ports:
        - {protocol: TCP, port: 80}
        - {protocol: TCP, port: 443}
        - {protocol: TCP, port: 8080}
        - {protocol: TCP, port: 8443}
        - {protocol: TCP, port: 9000}
YAML
  sed -i "s/namespace: segment1/namespace: ${namespace}/g" "${output_file}"
}

apply_segment1_network_policies() {
  local namespace="${1:-${SEGMENT1_NAMESPACE}}"
  local tmp_file=""
  tmp_file="$(mktemp)"
  trap 'rm -f "${tmp_file}"' RETURN
  render_segment1_network_policies "${namespace}" "${tmp_file}"
  validate_yaml_file "${tmp_file}"
  kubectl apply -f "${tmp_file}"
}
