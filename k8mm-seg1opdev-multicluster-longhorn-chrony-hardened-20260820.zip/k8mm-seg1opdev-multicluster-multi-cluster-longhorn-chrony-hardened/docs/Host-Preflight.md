# Host preflight

> Documentation baseline: v2.1 — August 20, 2026.

Host preflight validates operating-system dependencies that cannot be managed safely by Fleet. The v2.1 workflow separates dependency installation from cluster onboarding: packages are installed once in the Ubuntu 24.04 amd64 golden image, while deployed nodes are validation-only targets.

## Chrony host-time validation

Chrony is deployed as a privileged `kube-system/chrony-client` DaemonSet because it must adjust the host clock. The deployment now treats synchronization as a go/no-go control instead of treating a Running container as success.

```bash
export NTP_SERVERS='1.0.1.34'
./scripts/deploy-platform.sh install-cluster-time
```

For every node, the installer waits for the Chrony pod to start, runs `chronyc waitsync`, and then requires all of the following:

1. `Leap status: Normal`;
2. a positive NTP stratum; and
3. a selected source (`^*`) in `chronyc sources`.

A failure automatically prints `chronyc tracking`, `chronyc sources -v`, `chronyc ntpdata` for every configured NTP server, the Chrony container log, the periodic telemetry log, and pod events. This distinguishes network reachability from an upstream server that is replying while advertising itself as unsynchronized.

Validate the current deployment without changing it:

```bash
./scripts/deploy-platform.sh validate-cluster-time
# or target one cluster
scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

Each pod includes a `chrony-status` telemetry container. Its log emits one compact record every 60 seconds with the node, state, selected source, stratum, leap state, and current system-time correction. This makes `kubectl logs` useful for time-health troubleshooting without enabling verbose measurement logging on stdout.

The installer records the pre-Chrony `systemd-timesyncd` state on each host under `/var/lib/k8mm/chrony` before disabling it. The supported uninstall path removes Chrony and restores that saved state:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

If an older Chrony deployment predates the saved-state mechanism, the restore helper falls back to enabling OS-managed NTP with `timedatectl set-ntp true`. Use `--no-restore-timesyncd` only when another host time service is deliberately managed outside this repository.

`--context` now targets only the explicitly requested context(s); the four supported contexts are selected only when no target is supplied or `--all` is used. `--no-wait` remains available for emergency/debug use, but it intentionally bypasses synchronization validation and therefore is not used by `onboard`, `host-preflight`, or `all`.

## Golden-image package installation

The release artifact is `host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz`. It contains 16 pinned `.deb` packages, an installer, a package manifest, and per-package SHA-256 checksums.

Build or reproduce it on a connected Ubuntu 24.04 amd64 staging host:

```bash
scripts/management/preflight/build-longhorn-host-deps-bundle.sh
sha256sum --check host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz.sha256
```

After transferring the archive inside the air gap, install it on the golden image:

```bash
tar -xzf longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz
cd longhorn-host-deps-ubuntu-24.04-amd64
sudo ./install.sh --verify-only
sudo ./install.sh
```

The installer verifies Ubuntu 24.04/amd64 and all checksums, installs local files with `dpkg`, loads `iscsi_tcp`, enables `iscsid`, validates the required commands, and records the installed manifest under `/var/lib/k8mm`. It does not invoke apt, contact a package repository, or touch the Longhorn data disk.

## Deployed-node validation

```bash
scripts/deploy-platform.sh prepare-longhorn-nodes
# or
scripts/management/preflight/longhorn-storage-preflight.sh --all
```

Use `--context <name>` to target one cluster and `--continue-on-error` to audit every worker in one run.

For each non-control-plane worker, the script:

1. resolves the node InternalIP and connects with strict SSH host-key checking;
2. verifies `open-iscsi`, `nfs-common`, `cryptsetup`, `dmsetup`, and `xfsprogs` are already installed;
3. verifies `iscsiadm`, `mount.nfs`, `cryptsetup`, `dmsetup`, `findmnt`, and `xfs_info`;
4. loads `iscsi_tcp` and ensures `iscsid` is enabled and active;
5. disables active `multipathd` service/socket units because multipath can claim Longhorn devices;
6. verifies `/mnt/k8sdata` is a read-write XFS mount with at least 240 GiB and shared root mount propagation;
7. performs and removes a write probe; and
8. labels the passing node `node.longhorn.io/create-default-disk=true`.

The routine contains no apt call and never formats, partitions, mounts, unmounts, or erases storage. A missing package is a golden-image defect and fails the preflight.

Configuration overrides are `LONGHORN_DATA_PATH`, `LONGHORN_DATA_FILESYSTEM`, and `LONGHORN_MIN_DISK_GIB`.

## Ordering

`onboard` and `all` run Chrony and Longhorn storage validation before Fleet registration. This prevents Longhorn and persistent workloads from reconciling before worker storage is ready.
