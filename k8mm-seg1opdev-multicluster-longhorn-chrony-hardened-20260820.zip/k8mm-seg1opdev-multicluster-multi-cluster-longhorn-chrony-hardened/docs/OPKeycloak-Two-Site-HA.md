# OPKeycloak two-site high availability

> Documentation baseline: v2.1 — August 20, 2026.

## State model

| Site | Initial PostgreSQL role | Initial Keycloak replicas | Ingress |
| --- | --- | --- | --- |
| `j64seg1opdev` | writable primary | 3 | `1.0.0.215` |
| `j52seg1opdev` | streaming replica | 0 | `1.0.0.225` |

The canonical hostname is `opkeycloak.dev.jde.cybercom.ic.gov`. External DNS/load-balancer automation must direct it only to the active site. The Fleet Keycloak charts now render the TLS `Certificate` and Contour `HTTPProxy` only when the site label `kmm.dev/keycloak-instances` is greater than zero. A fenced standby site (`instances=0`) therefore has no root HTTPProxy, avoiding the expected Contour `invalid` state caused by a missing operator-generated `opkeycloak-service`. During failover, changing the Fleet labels to scale the promoted site to three instances automatically creates its Certificate/HTTPProxy and removes exposure from the fenced site.

## Enable secondary

```bash
scripts/deploy-platform.sh enable-identity-secondary
scripts/deploy-platform.sh validate-identity-ha
```

The workflow copies the CNPG-generated client certificate and CA from j64 to j52 through the Kubernetes APIs, creates the target Secret, and changes Fleet labels so the replica bundles reconcile. Private material is not written to Git.

## Planned failover

```bash
export IDENTITY_FAILOVER_CONFIRM=j52seg1opdev
export IDENTITY_FAILOVER_MODE=planned
scripts/deploy-platform.sh failover-identity
```

The script pauses the downstream GitRepo, scales down primary Keycloak, fences the old ingress through the optional hook, blocks new database connections, records a final WAL LSN, waits for j52 replay, changes durable Fleet labels, hibernates the old primary, promotes j52, activates three Keycloak replicas, invokes the traffic activation hook, and unpauses Fleet.

## Unplanned failover

```bash
export IDENTITY_FAILOVER_CONFIRM=j52seg1opdev
export IDENTITY_FAILOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_FAILOVER_HOOK=/protected/bin/identity-failover-hook
scripts/deploy-platform.sh failover-identity
```

The hook is mandatory because the unreachable primary must be fenced outside Kubernetes. Unplanned promotion can lose transactions not yet replayed on j52.

## Failback

Failback is not an automatic reverse promotion. Rebuild the former j64 primary as a replica of j52, prove it has caught up, schedule a planned transition, and then change roles. Never allow two writable PostgreSQL sites or two active canonical Keycloak endpoints.

The active script location is `scripts/management/failover/failover-to-j52.sh`.
