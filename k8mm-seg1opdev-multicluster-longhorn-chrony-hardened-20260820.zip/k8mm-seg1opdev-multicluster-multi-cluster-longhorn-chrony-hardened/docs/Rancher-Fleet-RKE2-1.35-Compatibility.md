# Rancher and Fleet compatibility for RKE2 1.35

> Documentation baseline: v2.1 — August 20, 2026.

This deployment is pinned to Rancher `v2.15.0`, bundled Fleet `v0.15.2`, and RKE2 `v1.35.6+rke2r1`. Five compatibility controls are required for this combination and the RKE2 CIS profile.

## Controls implemented by this repository

### 1. Long-lived Rancher WebSocket route

Imported `cattle-cluster-agent` pods connect to Rancher through:

```text
wss://rancher.dev.kube/v3/connect/register
```

The Contour `HTTPProxy` enables WebSockets and disables route response and idle expiration:

```yaml
enableWebsockets: true
timeoutPolicy:
  response: infinity
  idle: infinity
```

Without WebSocket enablement, agent registration reaches Rancher but fails with `403 Forbidden` and `websocket: bad handshake`. Without long-lived route timeouts, an established agent tunnel can be terminated by the proxy and Rancher can mark the cluster unavailable.

Source manifest:

```text
yaml/j64/seg1opman-cluster/resources/rancher-j64manager-resources-v1.yaml
```

### 2. Scoped CIS Pod Security exceptions

Rancher and Fleet system agents are not guaranteed to satisfy the RKE2 CIS default `restricted` Pod Security profile. Before an import manifest is applied, the repository creates and labels the required namespaces with `privileged:latest` for enforce, audit, and warn.

The exceptions are limited to Rancher/Fleet system namespaces:

- `cattle-system`
- `cattle-fleet-system`
- `cattle-fleet-local-system` on the management cluster
- `cattle-fleet-clusters-system` on the management cluster

Application namespaces remain restricted.

### 3. Fleet WatchListClient workaround

`client-go` v0.35 enables WatchListClient behavior that can cause Fleet `BundleDeployment` watch streams to reset on Kubernetes 1.35. Symptoms include repeated `unable to decode an event from the watch stream`, bookmark expiration, controller cache-sync failures, and bundles stuck in `WaitApplied`.

The repository sets:

```text
KUBE_FEATURE_WatchListClient=false
```

The management `fleet-controller` receives this through the Rancher Helm value passed to the bundled Fleet chart. Local and downstream Fleet agents receive it through each Fleet Cluster resource at:

```text
spec.agentEnvVars
```

The script also patches currently running Deployments so the fix takes effect immediately. The Fleet Cluster resource remains the authoritative mechanism for downstream agent reconciliation.

### 4. Fleet 0.15.2 OCI chart-source compatibility

The Rancher `v2.15.0` bundled Fleet `v0.15.2` resource reader only downloads an external chart when `helm.chart` is non-empty. For this pinned runtime, each air-gapped OCI bundle therefore uses:

```yaml
helm:
  chart: oci://kubeharbor.dev.kube/k8mm-charts/<chart>
  version: "<version>"
```

Do not replace this with an OCI-only `helm.repo` declaration while the platform remains on Fleet `v0.15.2`. In this release, a repo-only bundle can contain only the local YAML files, falsely report the chart bundle as Ready, and upgrade an existing Helm release to an incomplete manifest. `scripts/validate-fleet-layout.sh` enforces the pinned syntax and rejects bundle-anchor workarounds.

The GitRepo `helmRepoURLRegex` still authorizes credential forwarding because Fleet matches the trusted expression against `helm.chart` when `helm.repo` is empty. Re-evaluate this compatibility control after upgrading Fleet; newer releases document `helm.repo` as the preferred OCI field.


### 5. Private OCI registry DNS, trust, and GitJob RBAC

Fleet downloads OCI charts from inside the management cluster. Host-level Harbor access and node image pulls do not prove that the GitJob Pod can resolve `kubeharbor.dev.kube`. The CoreDNS template is therefore rendered from protected runtime settings. For this Segment1 deployment, `DEV_KUBE_DNS_SERVERS` defaults to `1.0.1.34 1.0.1.35`; the obsolete `10.0.1.34/10.231.1.34` forwarders are not used.

The `forward` blocks use sequential upstream selection and fail over on `SERVFAIL` or `REFUSED`. After CoreDNS rolls out, a temporary Pod must resolve the Harbor name. Before either GitRepo is created, another temporary Pod in `cattle-fleet-system` must resolve Harbor, validate the configured CA, and authenticate to `https://kubeharbor.dev.kube/v2/` with the protected Helm credentials.

Rancher `2.15.0` can also leave the GitJob service account unable to create Kubernetes Events. The repository applies a scoped Role/RoleBinding granting only `create`, `patch`, and `update` on core `events` in `cattle-fleet-system`, and validation confirms the permission with `kubectl auth can-i`.

## Rebuild sequence

```bash
./scripts/deploy-platform.sh validate-package
./scripts/management/preflight/publish-fleet-charts.sh
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh bootstrap-management

# Before applying any Rancher import manifest:
./scripts/deploy-platform.sh prepare-rancher-imports

# Import j64seg1opdev, j52seg1opdev, and r01seg1opdev in Rancher.

./scripts/deploy-platform.sh onboard
```

`bootstrap-management` installs Rancher with the Fleet controller workaround and validates the local Fleet agent. `onboard` reapplies the PSA exceptions, propagates the WatchListClient setting to all Fleet Cluster resources, restarts/reconciles existing agents, and waits until all imported clusters are connected.

The Fleet Cluster `spec.agentEnvVars` field is the authoritative source for generated `fleet-agent` Deployments. The compatibility script intentionally does not patch those generated Deployments in parallel with the Fleet controller. It waits through Deployment deletion/recreation until the replacement workload contains the expected environment variable and is available, preventing the transient `error: object has been deleted` race during a fresh Rancher bootstrap.

## Standalone repair and validation

Apply all Rancher/Fleet agent compatibility controls after the downstream clusters have been imported:

```bash
./scripts/deploy-platform.sh repair-rancher-agents
```

Validate imported cluster connectivity:

```bash
./scripts/deploy-platform.sh validate-rancher-imports
```

Validate the Fleet workaround independently:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Run the complete Rancher system validation:

```bash
./scripts/deploy-platform.sh validate-rancher-system
```

## Expected validation results

The Rancher cluster agent log should contain a successful proxy connection and no repeating handshake errors:

```text
Connected to proxy url="wss://rancher.dev.kube/v3/connect/register"
```

Every Fleet controller/agent Deployment should contain:

```text
KUBE_FEATURE_WatchListClient=false
```

Every Fleet Cluster resource should propagate the same variable through `spec.agentEnvVars`. Rancher management cluster conditions should report `Connected=True`, and each downstream `cattle-system/cattle-cluster-agent` Deployment should have at least one available replica.

## Removal criteria

Do not remove the WatchListClient workaround merely because a cluster appears healthy. Remove it only after Rancher/Fleet is upgraded to a release verified against Kubernetes 1.35 without the WatchListClient cache-sync failure, then rerun the full Fleet reconciliation validation.

## Upstream references

- Rancher Fleet issue 5059: `https://github.com/rancher/fleet/issues/5059`
- Rancher Fleet downstream agent environment propagation issue 5091: `https://github.com/rancher/fleet/issues/5091`
- Contour request routing and timeout policy: `https://projectcontour.io/docs/main/config/request-routing/`
