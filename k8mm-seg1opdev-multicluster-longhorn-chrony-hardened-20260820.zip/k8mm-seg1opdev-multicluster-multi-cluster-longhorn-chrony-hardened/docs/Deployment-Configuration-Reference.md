# Deployment configuration reference

> Documentation baseline: v2.1 — August 20, 2026.

## Contexts and addressing

| Context | Site | Fleet role | Segment1 pool | ingress | replication | east-west |
| --- | --- | --- | --- | --- | --- | --- |
| `j64seg1opman` | j64 | local management | `1.0.0.201-1.0.0.210` | `.205` | — | `.210` |
| `j64seg1opdev` | j64 | downstream application/identity primary | `1.0.0.211-1.0.0.220` | `.215` | `.216` | `.220` |
| `j52seg1opdev` | j52 | downstream application/identity secondary | `1.0.0.221-1.0.0.230` | `.225` | `.226` | `.230` |
| `r01seg1opdev` | r01 | downstream application | `1.0.0.231-1.0.0.240` | `.235` | — | `.240` |

## Component versions

| Component | Chart | Application/image |
| --- | --- | --- |
| Rancher | `2.15.0` | Rancher `2.15.0` |
| cert-manager | Bitnami `1.5.14` | `1.18.2` |
| MetalLB | `0.15.2` | `0.15.2` |
| Contour | Bitnami `21.1.4` | Contour `1.32.1` |
| Longhorn | `1.12.1` | `1.12.1` |
| Longhorn host dependencies | offline tar v2.1 | Ubuntu `24.04` amd64, 16 pinned `.deb` packages |
| CloudNativePG operator | `0.29.0` | `1.30.0` |
| CNPG cluster | `0.7.0` | PostgreSQL `17.6`, PgBouncer `1.25.1` |
| Keycloak | direct manifests/operator | operator `26.5.5`, server `26.6.3` |
| Istio | `1.30.1` | `1.30.1` |
| Kiali | `2.27.0` | `2.27.0` |
| Elastic Agent | `9.4.2` | `9.4.2` |
| kube-state-metrics | `6.1.0` | `2.16.0` |

## External endpoints

| Setting | Default/example |
| --- | --- |
| registry | `kubeharbor.dev.kube` |
| OCI project | `k8mm-charts` |
| Fleet Server | `https://1.0.0.30:8220` |
| identity canonical host | `opkeycloak.dev.jde.cybercom.ic.gov` |
| primary replication DNS | `j64seg1opdev-postgres-repl.dev.kube` |
| secondary replication DNS | `j52seg1opdev-postgres-repl.dev.kube` |
| Kiali Prometheus | `https://j64seg1opman-prometheus.dev.kube` |
| Kiali Grafana | `https://grafana.dev.kube` |
| Longhorn data path | `/mnt/k8sdata` |
| Longhorn filesystem | `xfs` |
| Longhorn minimum visible capacity | `240 GiB` |
| Longhorn UI / management | `https://longhorn-man.dev.kube` -> `1.0.0.205` |
| Longhorn UI / j64 downstream | `https://longhorn-j64.dev.kube` -> `1.0.0.215` |
| Longhorn UI / j52 downstream | `https://longhorn-j52.dev.kube` -> `1.0.0.225` |
| Longhorn UI / r01 downstream | `https://longhorn-r01.dev.kube` -> `1.0.0.235` |
| Longhorn UI allowed client CIDR | `1.0.0.0/23` |
| Kiali / management | `https://kiali-man.dev.kube/kiali` -> `1.0.0.205` |
| Kiali / j64 downstream | `https://kiali-j64.dev.kube/kiali` -> `1.0.0.215` |
| Kiali / j52 downstream | `https://kiali-j52.dev.kube/kiali` -> `1.0.0.225` |
| Kiali / r01 downstream | `https://kiali-r01.dev.kube/kiali` -> `1.0.0.235` |
| OPKeycloak HTTPProxy | Published only on the identity site with `kmm.dev/keycloak-instances > 0`; canonical host remains `opkeycloak.dev.jde.cybercom.ic.gov` |
| Longhorn host package archive | `longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz` |
| Longhorn host package SHA-256 | `d76bc98aec3404f33f6e8996d1c86ce4c19dbd95bcddaac4281be1d11d805c5a` |

Validate these values for the target environment; the example file is not a credential vault.

## Required protected inputs

The runtime file references protected files for Git, OCI/registry, Rancher bootstrap, CA certificate/key, Longhorn host-storage settings, Kiali, PostgreSQL, Keycloak, four Elastic Fleet tokens, and the Elastic Fleet CA. It also references one Istio CA directory per context.


## Rancher and Fleet compatibility controls

| Control | Configuration |
| --- | --- |
| Rancher agent WebSockets | Contour `enableWebsockets: true` |
| Persistent agent tunnel | Contour `timeoutPolicy.response: infinity` and `timeoutPolicy.idle: infinity` |
| CIS system namespaces | scoped `privileged:latest` PSA labels for Rancher/Fleet namespaces |
| Fleet Kubernetes 1.35 workaround | `KUBE_FEATURE_WatchListClient=false` on `fleet-controller` and every Fleet agent |
| Private-zone DNS forwarding | `DEV_KUBE_DNS_SERVERS`, `JDE_DNS_SERVERS`, and `JCP_DNS_SERVERS`; defaults use `1.0.1.34/35` for `dev.kube` and JDE |
| Fleet OCI access gate | temporary Pod validates Harbor DNS, CA trust, and Helm credentials before GitRepo creation |
| GitJob event RBAC | namespaced `create`, `patch`, and `update` on core `events` for `cattle-fleet-system/gitjob` |
| Imported-cluster health gate | Rancher `Connected=True` plus an available downstream `cattle-cluster-agent` Deployment |

See [Rancher and Fleet compatibility for RKE2 1.35](Rancher-Fleet-RKE2-1.35-Compatibility.md).

## Fleet bundles

The active package contains separate Longhorn chart and storage-policy bundles alongside the existing platform and application bundles. Namespace creation and CIS/PSA labeling remain preflight responsibilities.

`70-applications` is an extension directory, not an active bundle, because it intentionally has no `fleet.yaml`.

## Namespace labels

Monitoring NetworkPolicies authorize callers by `k8mm.dev/monitoring-agent=true`. Identity targeting uses Fleet cluster labels, not Kubernetes namespace names. Segment1 backends opt in with `segment1.ingress/allow-backend=true`.
