# Helm package contract

> Documentation baseline: v2.1 — August 20, 2026.

`helm/packages` contains immutable chart archives required by bootstrap or Fleet.

- `required-packages.txt` is the complete local package allowlist.
- `fleet-oci-packages.txt` is the subset published to KubeHarbor for Fleet.
- `required-oci-artifacts.txt` is the expected Fleet OCI inventory.
- `SHA256SUMS` is the transfer-integrity baseline.
- `longhorn-images.txt` is the upstream image inventory.
- `longhorn-kubeharbor-images.txt` is the Harbor-qualified mirror inventory.

| Package | Alignment | Owner |
| --- | --- | --- |
| `base-1.30.1.tgz` | Istio base 1.30.1 | Fleet OCI |
| `cert-manager-1.5.14.tgz` | Bitnami chart 1.5.14 / cert-manager 1.18.2 | bootstrap + Fleet OCI |
| `cloudnative-pg-0.29.0.tgz` | CNPG operator 1.30.0 | Fleet OCI |
| `cluster-0.7.0.tgz` | CNPG cluster chart 0.7.0 | Fleet OCI |
| `cni-1.30.1.tgz` | Istio CNI 1.30.1 | Fleet OCI |
| `contour-21.1.4.tgz` | Bitnami chart 21.1.4 / Contour 1.32.1 | bootstrap + Fleet OCI |
| `elastic-agent-9.4.2.tgz` | Elastic Agent 9.4.2 | Fleet OCI |
| `gateway-1.30.1.tgz` | Istio gateway 1.30.1 | Fleet OCI |
| `istiod-1.30.1.tgz` | Istiod 1.30.1 | Fleet OCI |
| `kiali-operator-2.27.0.tgz` | Kiali operator 2.27.0 | Fleet OCI |
| `kiali-server-2.27.0.tgz` | Kiali server 2.27.0 | Fleet OCI |
| `kube-state-metrics-6.1.0.tgz` | kube-state-metrics 2.16.0 | Fleet OCI |
| `metallb-0.15.2.tgz` | MetalLB 0.15.2 | bootstrap + Fleet OCI |
| `rancher-2.15.0.tgz` | Rancher 2.15.0 | local bootstrap only |
| `longhorn-1.12.1.tgz` | Longhorn 1.12.1 | Fleet OCI |

The Rancher chart is intentionally **not** pushed by `publish-fleet-charts.sh`. Rancher is installed from the local archive before Fleet exists. Rancher container-image acquisition and promotion are owned by `cantrellr/k8s-airgap-images`.

Validate:

```bash
cd helm
sha256sum --check SHA256SUMS
```

Publish only Fleet-owned charts:

```bash
scripts/management/preflight/publish-fleet-charts.sh
```

Do not add a package without adding an active owner, checksum, image inventory, acceptance check, and documentation in the same change. Argo CD is not part of this package.
