# Management bootstrap contract bundles

These bundles exist only in the `fleet-local` workspace. They publish the
`cert-manager` and `cert-manager-config` dependency labels after the management
bootstrap contract has been validated.

They do not install, upgrade, adopt, or remove cert-manager. The
`bootstrap-management` workflow remains the sole owner of the
`onprem-cert-manager` Helm release and `segment1-ca-clusterissuer` on
`j64seg1opman`.

The downstream `fleet-default` workspace continues to use the real chart and
configuration bundles under `fleet/bundles/10-cert-manager` and
`fleet/bundles/11-cert-manager-config`.
