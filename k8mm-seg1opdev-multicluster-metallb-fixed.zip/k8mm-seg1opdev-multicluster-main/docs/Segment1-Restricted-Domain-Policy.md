# Segment1 restricted ingress policy

## Purpose

Each cluster exposes one Contour/Envoy ingress plane named `segment1`. There is no second general-purpose ingress plane in this deployment.

## Addressing

| Context | MetalLB pool | Envoy VIP |
| --- | --- | --- |
| `j64seg1opman` | `1.0.0.201-1.0.0.210` | `1.0.0.205` |
| `j64seg1opdev` | `1.0.0.211-1.0.0.220` | `1.0.0.215` |
| `j52seg1opdev` | `1.0.0.221-1.0.0.230` | `1.0.0.225` |
| `r01seg1opdev` | `1.0.0.231-1.0.0.240` | `1.0.0.235` |

The ingress class is `segment1` and is configured as the default class. The release name is `ingress-segment1` on every cluster.

## Network controls

The bundle creates default-deny policies and permits only:

- DNS and Kubernetes API access needed by Contour;
- configured client CIDRs to Envoy ports 80/443;
- Envoy/Contour xDS traffic;
- Envoy egress to namespaces labeled `segment1.ingress/allow-backend=true` on approved service ports;
- Elastic Agent monitoring scrapes from namespaces labeled `k8mm.dev/monitoring-agent=true` to Contour/Envoy metric ports.

The default approved client CIDR is `1.0.0.0/23` and can be changed through `SEGMENT1_INGRESS_ALLOWED_CIDRS` in imperative/break-glass execution. Fleet values and policies remain the steady-state source.

## Backend onboarding

```bash
kubectl --context <context> label namespace <namespace> \
  segment1.ingress/allow-backend=true --overwrite
```

For a permanent platform namespace, add the label to the runtime namespace-provisioning workflow instead of relying on a one-time imperative command. Fleet intentionally does not own namespace objects because those namespaces exist before GitOps reconciliation and carry CIS/PSA policy labels.

## Validation

```bash
for context in j64seg1opman j64seg1opdev j52seg1opdev r01seg1opdev; do
  kubectl --context "$context" -n segment1 get deploy,daemonset,service,networkpolicy
  kubectl --context "$context" get ingressclass segment1
 done
```
