# KubeHarbor registry and disconnected install framework

## Registry contract

All deployment charts and container images must be available from `kubeharbor.dev.kube`. Fleet chart references use:

```text
oci://kubeharbor.dev.kube/k8mm-charts/<chart>:<version>
```

Workloads use the namespace-local pull Secret `regcred-kubeharbor`. Fleet uses `kmm-helm-credentials` in `fleet-local` and `fleet-default` for OCI authentication and CA trust.

## Artifact ownership

| Artifact | Owner |
| --- | --- |
| Rancher and platform container image acquisition/promotion | `cantrellr/k8s-airgap-images` |
| Local Rancher bootstrap chart | this repository: `helm/packages/rancher-2.15.0.tgz` |
| Fleet-owned immutable chart packages | this repository: `helm/packages/` |
| Fleet chart publication to KubeHarbor OCI | `scripts/management/preflight/publish-fleet-charts.sh` |
| Harbor platform lifecycle | KubeHarbor deployment repository |

The seg1opdev repository does not implement Rancher image pull, archive, retag, load, or push operations.

## Publish Fleet charts

```bash
export HELM_REGISTRY_HOST=kubeharbor.dev.kube
export HELM_REGISTRY_USERNAME_FILE=/protected/kubeharbor-username
export HELM_REGISTRY_PASSWORD_FILE=/protected/kubeharbor-token
export HELM_REGISTRY_CA_FILE=/protected/segment1-devlocal-ca.crt
scripts/management/preflight/publish-fleet-charts.sh
```

The script validates checksums and reads `helm/fleet-oci-packages.txt`. The Rancher bootstrap chart is intentionally excluded because Rancher is installed locally before Fleet exists.

## Rancher image inventory

Promote the Rancher v2.15.0 images with `cantrellr/k8s-airgap-images`. Stage its Rancher image list on the deployment host and configure:

```bash
RANCHER_IMAGE_LIST_FILE=/home/k8admin/k8s-airgap-images/source-lists/rancher-images.list
```

Then validate the list, Harbor inventory, and node-level pulls:

```bash
scripts/management/preflight/validate-rancher-registry.sh preflight
```

See [Rancher registry validation and Helm operation recovery](Rancher-Airgap-and-Helm-Operations.md).

## Required image families

Mirror all images referenced by chart defaults/overrides and direct manifests, including cert-manager, MetalLB/FRR, Contour/Envoy, NetApp Trident and Trident Protect, CloudNativePG/PostgreSQL/PgBouncer, Keycloak, Istio, Kiali, Elastic Agent, kube-state-metrics, Rancher and its system dependencies, Chrony, and the Kubernetes toolbox.

Chart presence alone does not guarantee image completeness. Render or inspect every chart with repository values before each disconnected release and update the external image catalog when a chart introduces a new transitive image.

## Integrity

```bash
cd helm
sha256sum --check SHA256SUMS
```

Do not replace an existing OCI chart version with different bytes. Publish a new immutable version and update the repository in one reviewed change.

## Trust

The deployment host, Rancher/Fleet, and every cluster node must trust the KubeHarbor issuing CA. The runtime configuration references CA files rather than disabling TLS verification.
