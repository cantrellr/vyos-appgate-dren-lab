# Elastic Stack monitoring

## Production topology

Each of the four clusters receives:

- Fleet bundle `70-kube-state-metrics` in namespace `elastic-monitoring`;
- Fleet bundle `71-elastic-agent` in namespace `elastic-agent-system`;
- one Elastic Agent 9.4.2 DaemonSet pod per node;
- one kube-state-metrics 2.16.0 Deployment;
- an ExternalName Service named `kube-state-metrics` in the Agent namespace;
- application NetworkPolicies that select `k8mm.dev/monitoring-agent=true`.

The Agent uses the `perNode` preset, host networking, HostPath state persistence, control-plane tolerations, `NODE_IP=status.hostIP`, and Kubernetes leader-election provider support. The chart's embedded kube-state-metrics dependency is disabled because KSM is separately managed and hardened.

## Fleet token requirement

Use **four enrollment tokens**:

| Cluster | Recommended Fleet policy/token |
| --- | --- |
| `j64seg1opman` | management Kubernetes policy |
| `j64seg1opdev` | j64 application Kubernetes policy |
| `j52seg1opdev` | j52 application Kubernetes policy |
| `r01seg1opdev` | r01 application Kubernetes policy |

The policies may share the same integration composition, but each should set a distinct cluster identity and data-stream namespace. Separate tokens provide independent revocation and prevent one cluster from being silently enrolled into another cluster's policy.

## Runtime Secret contract

`config/fleet-bootstrap.example.env` references four protected token files and one Fleet Server CA file. `01-seed-runtime-secrets.sh` creates in every `elastic-agent-system` namespace:

```text
elastic-agent-fleet-enrollment
  FLEET_URL
  FLEET_ENROLLMENT_TOKEN

devlocal-ca-bundle-secret
  ca.crt
```

Do not commit tokens or use `insecure: true` as a permanent TLS workaround.

## Fleet policy expectations

Configure the Kubernetes integration to use:

```text
kube-state-metrics host: http://kube-state-metrics:8080
kubelet host:           https://${env.NODE_IP}:10250
```

Enable node-local logs/metrics and cluster state/events with leader election so cluster-wide streams are not duplicated by every DaemonSet pod. Add PostgreSQL, Keycloak, Contour, or Istio integrations only when the corresponding endpoint and NetworkPolicy are intentionally configured.

## Deployment and validation

Normal deployment occurs through Fleet during `scripts/deploy-platform.sh onboard`.

```bash
scripts/deploy-platform.sh validate-monitoring
```

The validator checks namespaces, labels, Secret keys, KSM availability, alias resolution, DaemonSet readiness, stale split topology, monitoring policy selectors, and recent Agent logs for TLS, DNS, and Fleet connection errors.

## Break-glass installation

`scripts/monitoring/01-install-elastic-agent.sh` is not a parallel deployment method. It refuses to run unless `KMM_BREAK_GLASS=true` and uses the same Helm release names as Fleet. Reconcile or pause Fleet before using it, then return ownership to Git as soon as the incident is resolved.
