#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"
NAMESPACE="trident-system"
RESOURCES_CLASSES="trident-storage-storageclasses-v2.yaml"
RESOURCES_SNAPSHOTS="trident-storage-snapshotclasses-v2.yaml"

require_kubectl
: "${TRIDENT_USERNAME:?Set TRIDENT_USERNAME}"
: "${TRIDENT_PASSWORD:?Set TRIDENT_PASSWORD}"
TRIDENT_MANAGEMENT_LIF="${TRIDENT_MANAGEMENT_LIF:-tridentsvm.dev.kube}"
TRIDENT_DATA_LIF="${TRIDENT_DATA_LIF:-tridentsvm-data.dev.kube}"
TRIDENT_SVM="${TRIDENT_SVM:-tridentSVM}"
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

kubectl get namespace "${NAMESPACE}" >/dev/null 2>&1 \
  || die "Namespace ${NAMESPACE} does not exist. Run 04-install-trident-operator.sh first."
require_crd tridentbackendconfigs.trident.netapp.io

log "Creating/updating runtime Trident backend credentials..."
kubectl -n "${NAMESPACE}" create secret generic tridentsvm-credentials-secret \
  --from-literal=username="${TRIDENT_USERNAME}" \
  --from-literal=password="${TRIDENT_PASSWORD}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

backend_file="$(mktemp)"
trap 'rm -f "${backend_file}"' EXIT
cat >"${backend_file}" <<YAML
apiVersion: trident.netapp.io/v1
kind: TridentBackendConfig
metadata:
  name: trident-nfs-backend
  namespace: ${NAMESPACE}
spec:
  version: 1
  storageDriverName: ontap-nas
  managementLIF: ${TRIDENT_MANAGEMENT_LIF}
  dataLIF: ${TRIDENT_DATA_LIF}
  backendName: trident-nfs-backend
  svm: ${TRIDENT_SVM}
  autoExportPolicy: true
  credentials:
    name: tridentsvm-credentials-secret
---
apiVersion: trident.netapp.io/v1
kind: TridentBackendConfig
metadata:
  name: trident-iscsi-backend
  namespace: ${NAMESPACE}
spec:
  version: 1
  storageDriverName: ontap-san
  managementLIF: ${TRIDENT_MANAGEMENT_LIF}
  backendName: trident-iscsi-backend
  svm: ${TRIDENT_SVM}
  credentials:
    name: tridentsvm-credentials-secret
YAML

log "Applying NetApp Trident backend and storage resources..."
validate_yaml_file "${backend_file}"
kubectl apply -f "${backend_file}"
apply_file "${YAML_DIR}/resources/${RESOURCES_CLASSES}"
apply_file "${YAML_DIR}/resources/${RESOURCES_SNAPSHOTS}"

log "Trident backend, storage classes, and snapshot classes configured."
