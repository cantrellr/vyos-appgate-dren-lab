#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"
NAMESPACE="trident-system"
RELEASE="trident-operator"
CHART="trident-operator-100.2602.1.tgz"
VALUES="trident-values-v2.yaml"
OPTIONS="${YAML_DIR}"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

log "Creating and labeling namespace ${NAMESPACE}..."
ensure_cis_namespace "${NAMESPACE}" false "privileged"
ensure_registry_secret "${NAMESPACE}"

helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${OPTIONS}/values/${VALUES}"

log "Waiting for Trident operator deployment to roll out..."
wait_for_deployment_rollout "${NAMESPACE}" "trident-operator" "${KUBECTL_TIMEOUT}"

log "Trident operator installed."
