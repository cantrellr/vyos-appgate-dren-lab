#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../../_lib/common.sh"

MANIFEST="${YAML_DIR}/resources/segment1-chrony-daemonset.yaml"
NTP_SERVERS="${NTP_SERVERS:-1.0.1.34}"
WAIT_FOR_ROLLOUT=true
ACTION=install
CONTEXTS=(j64seg1opman j64seg1opdev j52seg1opdev r01seg1opdev)

usage() {
  cat <<USAGE
Usage: $0 [--all | --context <kubectl-context> ...] [options]

Deploys the kube-system/chrony-client DaemonSet to the selected RKE2 clusters.
The default target is all four supported contexts.

Options:
  --all                   Target all supported contexts (default)
  --context <context>     Target one context; may be repeated
  --ntp-servers <list>    Space- or comma-separated NTP servers (default: ${NTP_SERVERS})
  --uninstall             Remove the Chrony DaemonSet
  --no-wait               Do not wait for rollout completion
  -h, --help              Show this help

Examples:
  $0 --all --ntp-servers '1.0.0.1 1.0.0.2'
  $0 --context j64seg1opman
  $0 --all --uninstall
USAGE
}

while (($#)); do
  case "$1" in
    --all)
      CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
      shift
      ;;
    --context)
      [[ $# -ge 2 ]] || die "--context requires a value."
      CONTEXTS+=("$2")
      shift 2
      ;;
    --ntp-servers)
      [[ $# -ge 2 ]] || die "--ntp-servers requires a value."
      NTP_SERVERS="$2"
      shift 2
      ;;
    --uninstall)
      ACTION=uninstall
      shift
      ;;
    --no-wait)
      WAIT_FOR_ROLLOUT=false
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      die "Unknown argument: $1"
      ;;
  esac
done

((${#CONTEXTS[@]})) || CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
[[ -n "${NTP_SERVERS//[[:space:],]/}" ]] || die "NTP server list must not be empty."
require_cmd kubectl
require_cmd python3
ensure_file "${MANIFEST}"

render_manifest() {
  local output="$1"
  NTP_SERVERS_VALUE="${NTP_SERVERS}" python3 - "${MANIFEST}" "${output}" <<'PY'
from pathlib import Path
import os
import sys
import yaml

source = Path(sys.argv[1])
target = Path(sys.argv[2])
documents = list(yaml.safe_load_all(source.read_text(encoding="utf-8")))
for document in documents:
    if not isinstance(document, dict) or document.get("kind") != "DaemonSet":
        continue
    containers = document["spec"]["template"]["spec"].get("containers", [])
    for container in containers:
        if container.get("name") != "chrony":
            continue
        for item in container.setdefault("env", []):
            if item.get("name") == "NTP_SERVERS":
                item["value"] = os.environ["NTP_SERVERS_VALUE"]
                break
        else:
            container["env"].append({"name": "NTP_SERVERS", "value": os.environ["NTP_SERVERS_VALUE"]})
target.write_text(yaml.safe_dump_all(documents, sort_keys=False, explicit_start=True), encoding="utf-8")
PY
}

for context in "${CONTEXTS[@]}"; do
  validate_supported_context "${context}"
  validate_context_access "${context}"

  if [[ "${ACTION}" == uninstall ]]; then
    log "Removing Chrony DaemonSet from ${context}..."
    kubectl --context "${context}" -n kube-system delete daemonset chrony-client --ignore-not-found
    continue
  fi

  kubectl --context "${context}" -n kube-system get secret "${REGISTRY_SECRET}" >/dev/null 2>&1 \
    || die "${context}: missing kube-system/${REGISTRY_SECRET}; seed registry credentials first."

  rendered="$(mktemp)"
  trap 'rm -f "${rendered:-}"' EXIT
  render_manifest "${rendered}"

  log "Installing Chrony on ${context} with NTP servers: ${NTP_SERVERS}"
  kubectl --context "${context}" apply -f "${rendered}"
  if [[ "${WAIT_FOR_ROLLOUT}" == true ]]; then
    kubectl --context "${context}" -n kube-system rollout status daemonset/chrony-client --timeout="${KUBECTL_TIMEOUT}"
  fi
  kubectl --context "${context}" -n kube-system get daemonset/chrony-client -o wide
  rm -f "${rendered}"
  trap - EXIT
done

log "Chrony ${ACTION} completed for ${#CONTEXTS[@]} cluster context(s)."
