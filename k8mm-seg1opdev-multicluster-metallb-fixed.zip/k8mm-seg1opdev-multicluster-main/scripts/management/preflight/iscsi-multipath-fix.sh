#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../../_lib/common.sh"

SSH_USER="${SSH_USER:-k8admin}"
SSH_IDENTITY_FILE="${SSH_IDENTITY_FILE:-}"
SSH_STRICT_HOST_KEY_CHECKING="${SSH_STRICT_HOST_KEY_CHECKING:-yes}"
INSTALL_PACKAGES="${INSTALL_PACKAGES:-false}"
CONTINUE_ON_ERROR="${CONTINUE_ON_ERROR:-false}"
USER_FRIENDLY_NAMES="${USER_FRIENDLY_NAMES:-no}"
FIND_MULTIPATHS="${FIND_MULTIPATHS:-no}"
REPLACE_EXISTING_CONFIG="${REPLACE_EXISTING_CONFIG:-false}"
CONTEXTS=()

usage() {
  cat <<USAGE
Usage: $0 (--all | --context <kubectl-context> ...) [options]

Installs/verifies open-iscsi and multipath-tools on every node in the selected
clusters, then converges /etc/multipath.conf without logging credentials.
This changes host storage services; run during a controlled maintenance window.

Options:
  --all                       Target all supported contexts
  --context <context>         Target one context; may be repeated
  --ssh-user <user>           SSH account (default: ${SSH_USER})
  --identity-file <path>      SSH private key path
  --skip-package-install      Require packages to already be installed
  --replace-existing-config   Back up and replace a different /etc/multipath.conf
  --continue-on-error         Process remaining nodes after a failure
  -h, --help                  Show this help

Environment overrides:
  SSH_STRICT_HOST_KEY_CHECKING=yes|accept-new
  USER_FRIENDLY_NAMES=no|yes
  FIND_MULTIPATHS=no|yes|strict|smart
  REPLACE_EXISTING_CONFIG=false|true
USAGE
}

while (($#)); do
  case "$1" in
    --all)
      CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
      shift
      ;;
    --context)
      [[ $# -ge 2 ]] || die "--context requires a value."
      CONTEXTS+=("$2")
      shift 2
      ;;
    --ssh-user)
      [[ $# -ge 2 ]] || die "--ssh-user requires a value."
      SSH_USER="$2"
      shift 2
      ;;
    --identity-file)
      [[ $# -ge 2 ]] || die "--identity-file requires a value."
      SSH_IDENTITY_FILE="$2"
      shift 2
      ;;
    --skip-package-install)
      INSTALL_PACKAGES=false
      shift
      ;;
    --replace-existing-config)
      REPLACE_EXISTING_CONFIG=true
      shift
      ;;
    --continue-on-error)
      CONTINUE_ON_ERROR=true
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      die "Unknown argument: $1"
      ;;
  esac
done

((${#CONTEXTS[@]})) || { usage >&2; die "Choose --all or at least one --context."; }
case "${SSH_STRICT_HOST_KEY_CHECKING}" in yes|accept-new) ;; *) die "SSH_STRICT_HOST_KEY_CHECKING must be yes or accept-new." ;; esac
case "${INSTALL_PACKAGES}" in true|false) ;; *) die "INSTALL_PACKAGES must be true or false." ;; esac
case "${CONTINUE_ON_ERROR}" in true|false) ;; *) die "CONTINUE_ON_ERROR must be true or false." ;; esac
case "${REPLACE_EXISTING_CONFIG}" in true|false) ;; *) die "REPLACE_EXISTING_CONFIG must be true or false." ;; esac
case "${USER_FRIENDLY_NAMES}" in yes|no) ;; *) die "USER_FRIENDLY_NAMES must be yes or no." ;; esac
case "${FIND_MULTIPATHS}" in yes|no|strict|smart) ;; *) die "Unsupported FIND_MULTIPATHS value: ${FIND_MULTIPATHS}." ;; esac

require_cmd kubectl
require_cmd ssh
[[ -z "${SSH_IDENTITY_FILE}" || -f "${SSH_IDENTITY_FILE}" ]] || die "SSH identity file not found: ${SSH_IDENTITY_FILE}"

ssh_args=(
  -o BatchMode=yes
  -o ConnectTimeout=15
  -o "StrictHostKeyChecking=${SSH_STRICT_HOST_KEY_CHECKING}"
)
[[ -n "${SSH_IDENTITY_FILE}" ]] && ssh_args+=( -i "${SSH_IDENTITY_FILE}" )

remote_script='set -Eeuo pipefail
install_packages="$1"
user_friendly_names="$2"
find_multipaths="$3"
replace_existing_config="$4"

sudo -n true
config_existed_before=false
sudo -n test -f /etc/multipath.conf && config_existed_before=true

if [[ "${install_packages}" == true ]]; then
  export DEBIAN_FRONTEND=noninteractive
  sudo -n apt-get update
  sudo -n apt-get install -y open-iscsi multipath-tools
else
  command -v iscsiadm >/dev/null
  command -v multipath >/dev/null
fi

candidate="$(mktemp)"
trap '\''rm -f "${candidate}"'\'' EXIT
cat >"${candidate}" <<CONF
defaults {
    user_friendly_names ${user_friendly_names}
    find_multipaths ${find_multipaths}
}
CONF

retain_existing_config=false
if sudo -n test -f /etc/multipath.conf && ! sudo -n cmp -s "${candidate}" /etc/multipath.conf; then
  effective_config="$(sudo -n multipath -t 2>/dev/null || true)"
  defaults_config="$(printf "%s\n" "${effective_config}" | sed -n "/^[[:space:]]*defaults[[:space:]]*{/,/^[[:space:]]*}/p")"
  effective_user_friendly_names="$(printf "%s\n" "${defaults_config}" | grep -m1 -E "^[[:space:]]*user_friendly_names[[:space:]]+" | sed -E "s/^[[:space:]]*user_friendly_names[[:space:]]+\"?([^\"[:space:]]+)\"?.*/\1/" || true)"
  effective_find_multipaths="$(printf "%s\n" "${defaults_config}" | grep -m1 -E "^[[:space:]]*find_multipaths[[:space:]]+" | sed -E "s/^[[:space:]]*find_multipaths[[:space:]]+\"?([^\"[:space:]]+)\"?.*/\1/" || true)"

  if [[ "${effective_user_friendly_names}" == "${user_friendly_names}" && "${effective_find_multipaths}" == "${find_multipaths}" ]]; then
    retain_existing_config=true
    echo "Existing /etc/multipath.conf retained; effective defaults already match the KMM baseline."
  elif [[ "${config_existed_before}" == true && "${replace_existing_config}" != true ]]; then
    echo "Existing /etc/multipath.conf has effective defaults user_friendly_names=${effective_user_friendly_names:-unknown}, find_multipaths=${effective_find_multipaths:-unknown}; expected ${user_friendly_names}/${find_multipaths}. Refusing to replace it without --replace-existing-config." >&2
    exit 20
  else
    timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
    sudo -n cp -a /etc/multipath.conf "/etc/multipath.conf.${timestamp}.bak"
  fi
fi
if [[ "${retain_existing_config}" != true ]] && { ! sudo -n test -f /etc/multipath.conf || ! sudo -n cmp -s "${candidate}" /etc/multipath.conf; }; then
  sudo -n install -o root -g root -m 0644 "${candidate}" /etc/multipath.conf
fi

sudo -n systemctl enable --now iscsid.service
sudo -n systemctl enable --now multipathd.service
sudo -n systemctl restart multipathd.service
sudo -n systemctl is-active --quiet iscsid.service
sudo -n systemctl is-active --quiet multipathd.service
sudo -n iscsiadm --version
sudo -n multipath -t >/dev/null
printf "multipath.conf converged; iscsid and multipathd are active.\\n"'

failures=0
declare -A visited=()
for context in "${CONTEXTS[@]}"; do
  validate_supported_context "${context}"
  validate_context_access "${context}"
  mapfile -t node_ips < <(kubectl --context "${context}" get nodes -o jsonpath='{range .items[*]}{range .status.addresses[?(@.type=="InternalIP")]}{.address}{"\n"}{end}{end}' | sed '/^$/d' | sort -u)
  ((${#node_ips[@]})) || { warn "${context}: no node InternalIP addresses found."; failures=$((failures + 1)); continue; }

  for ip in "${node_ips[@]}"; do
    [[ -z "${visited[${ip}]:-}" ]] || { log "Skipping duplicate node ${ip}."; continue; }
    visited["${ip}"]=1
    log "Configuring iSCSI/multipath on ${context} node ${ip}..."
    if ! ssh "${ssh_args[@]}" "${SSH_USER}@${ip}" bash -s -- \
      "${INSTALL_PACKAGES}" "${USER_FRIENDLY_NAMES}" "${FIND_MULTIPATHS}" "${REPLACE_EXISTING_CONFIG}" <<<"${remote_script}"; then
      warn "Failed to configure ${context} node ${ip}."
      failures=$((failures + 1))
      [[ "${CONTINUE_ON_ERROR}" == true ]] || die "iSCSI/multipath convergence stopped after the first failure."
    fi
  done
done

((failures == 0)) || die "iSCSI/multipath convergence completed with ${failures} failed node(s)."
log "iSCSI and multipath configuration completed on ${#visited[@]} unique node(s)."
