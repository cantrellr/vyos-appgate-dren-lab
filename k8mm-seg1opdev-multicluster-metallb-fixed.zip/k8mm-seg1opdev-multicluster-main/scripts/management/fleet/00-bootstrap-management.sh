#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
load_kmm_runtime_config "${CONFIG_FILE}"

MANAGEMENT_SITE=j64
MANAGEMENT_CLUSTER=seg1opman
MANAGEMENT_CONTEXT="${MANAGEMENT_SITE}${MANAGEMENT_CLUSTER}"
validate_context_access "${MANAGEMENT_CONTEXT}"

export REGISTRY_USERNAME REGISTRY_PASSWORD
REGISTRY_USERNAME="$(read_required_secret_file REGISTRY_USERNAME_FILE)"
REGISTRY_PASSWORD="$(read_required_secret_file REGISTRY_PASSWORD_FILE)"
export CA_CERT_FILE CA_KEY_FILE RANCHER_CA_FILE
require_runtime_file CA_CERT_FILE
require_runtime_file CA_KEY_FILE
require_runtime_file RANCHER_CA_FILE

log "Bootstrapping the minimum Segment1 management platform required before Rancher/Fleet exists..."
"${INSTALL_DIR}/core/00-bootstrap-kubeharbor-regcred.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"
if [[ "${RANCHER_REGISTRY_ENFORCE:-true}" == "true" ]]; then
  "${INSTALL_DIR}/management/preflight/validate-rancher-registry.sh" preflight
else
  warn "RANCHER_REGISTRY_ENFORCE=false: skipping external Rancher image inventory and node pull validation."
fi
"${INSTALL_DIR}/core/01-patch-coredns.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"
"${INSTALL_DIR}/core/01-bootstrap-ca-secret.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"
"${INSTALL_DIR}/core/02-install-cert-manager.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"
"${INSTALL_DIR}/core/03-install-metallb.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"
CONTOUR_SEGMENT1_RELEASE=ingress-segment1 \
  "${INSTALL_DIR}/core/04-install-segment1-ingress.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"

export RANCHER_BOOTSTRAP_PASSWORD
RANCHER_BOOTSTRAP_PASSWORD="$(read_required_secret_file RANCHER_BOOTSTRAP_PASSWORD_FILE)"
"${INSTALL_DIR}/management/rancher/01-install-rancher.sh" "${MANAGEMENT_SITE}" "${MANAGEMENT_CLUSTER}"

unset REGISTRY_USERNAME REGISTRY_PASSWORD RANCHER_BOOTSTRAP_PASSWORD
log "Management bootstrap complete. Provision or import downstream clusters in Rancher before Fleet onboarding."
