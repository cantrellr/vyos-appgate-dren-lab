#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"
require_cmd jq

label_cluster() {
  local namespace="$1" display="$2" context="$3" site="$4" role="$5" identity="$6"
  local segment_pool="$7" segment_ip="$8" eastwest_ip="$9"
  local identity_site="${10}" identity_active="${11}" keycloak_instances="${12}"
  local postgres_hibernation="${13}" postgres_replica_enabled="${14}" postgres_replication_ip="${15}"
  local resource
  resource="$(fleet_cluster_resource "${namespace}" "${display}" "${RANCHER_CONTEXT:-j64seg1opman}")"

  local -a labels=(
    kmm.dev/platform=seg1opdev
    kmm.dev/context="${context}"
    kmm.dev/site="${site}"
    kmm.dev/role="${role}"
    kmm.dev/identity="${identity}"
    kmm.dev/identity-site="${identity_site}"
    kmm.dev/segment1-pool="${segment_pool}"
    kmm.dev/segment1-lb-ip="${segment_ip}"
    kmm.dev/eastwest-lb-ip="${eastwest_ip}"
    kmm.dev/istio-network="${context}-net1"
    kmm.dev/trident-management-lif="${TRIDENT_MANAGEMENT_LIF}"
    kmm.dev/trident-data-lif="${TRIDENT_DATA_LIF}"
    kmm.dev/trident-svm="${TRIDENT_SVM}"
  )

  if [[ "${identity_site}" == "true" ]]; then
    labels+=(
      kmm.dev/identity-active="${identity_active}"
      kmm.dev/keycloak-instances="${keycloak_instances}"
      kmm.dev/postgres-hibernation="${postgres_hibernation}"
      kmm.dev/postgres-replica-enabled="${postgres_replica_enabled}"
      kmm.dev/postgres-replication-lb-ip="${postgres_replication_ip}"
    )
  fi

  kubectl -n "${namespace}" label cluster.fleet.cattle.io "${resource}" --overwrite "${labels[@]}" >/dev/null
  log "Labeled ${namespace}/${resource} as ${context}."
}

# All non-storage VIPs are allocated from each cluster's existing Segment1 pool.
label_cluster fleet-local "${FLEET_LOCAL_CLUSTER_DISPLAY_NAME}" \
  j64seg1opman j64 management none \
  1.0.0.201-1.0.0.210 1.0.0.205 1.0.0.210 \
  false false 0 off false ""

label_cluster fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" \
  j64seg1opdev j64 application primary \
  1.0.0.211-1.0.0.220 1.0.0.215 1.0.0.220 \
  true true 3 off false 1.0.0.216

label_cluster fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" \
  j52seg1opdev j52 application secondary-pending \
  1.0.0.221-1.0.0.230 1.0.0.225 1.0.0.230 \
  true false 0 off true 1.0.0.226

label_cluster fleet-default "${FLEET_R01_APP_DISPLAY_NAME}" \
  r01seg1opdev r01 application none \
  1.0.0.231-1.0.0.240 1.0.0.235 1.0.0.240 \
  false false 0 off false ""
