#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"
NAMESPACE="istio-system"
OPTIONS="$(site_cluster_options_dir "${SITE}" "${CLUSTER}")"

ISTIO_REV="${ISTIO_REV:-stable}"
ISTIOD_DEPLOYMENT="${ISTIOD_DEPLOYMENT:-istiod-${ISTIO_REV}}"
INJECTOR_WEBHOOK="${INJECTOR_WEBHOOK:-istio-sidecar-injector-${ISTIO_REV}}"

ISTIO_BASE_PACKAGE="base-1.30.1.tgz"
ISTIO_BASE_VALUES="istio-base-values-v1.yaml"
ISTIO_ISTIOD_PACKAGE="istiod-1.30.1.tgz"
ISTIO_ISTIOD_VALUES="istio-istiod-values-v1.yaml"
ISTIO_GATEWAY_PACKAGE="gateway-1.30.1.tgz"
ISTIO_GATEWAY_VALUES="istio-eastwest-gateway-values-v1.yaml"
ISTIO_GATEWAY_RESOURCES="istio-gateway-resources-v2.yaml"
KIALI_OPERATOR_PACKAGE="kiali-operator-2.27.0.tgz"
KIALI_OPERATOR_VALUES="istio-kiali-operator-values-v1.yaml"
KIALI_SERVER_PACKAGE="kiali-server-2.27.0.tgz"
KIALI_SERVER_VALUES="istio-kiali-server-values-v1.yaml"
KIALI_SERVER_RESOURCES="istio-kiali-server-resources-v1.yaml"

validate_revisioned_injection_ready() {
  log "Validating Istio revisioned sidecar injection for revision ${ISTIO_REV}..."

  kubectl -n "${NAMESPACE}" get deployment "${ISTIOD_DEPLOYMENT}" >/dev/null 2>&1 \
    || die "Missing ${NAMESPACE}/${ISTIOD_DEPLOYMENT}. Check ${OPTIONS}/values/${ISTIO_ISTIOD_VALUES}."

  wait_for_deployment_available "${NAMESPACE}" "${ISTIOD_DEPLOYMENT}" "${KUBECTL_TIMEOUT}"

  kubectl get mutatingwebhookconfiguration "${INJECTOR_WEBHOOK}" >/dev/null 2>&1 \
    || die "Missing MutatingWebhookConfiguration ${INJECTOR_WEBHOOK}. Namespaces labeled istio.io/rev=${ISTIO_REV} will not receive sidecars."

  kubectl get namespace "${NAMESPACE}" -o json \
    | jq -e '.metadata.labels["istio.io/rev"] == null and .metadata.labels["istio-injection"] == null' >/dev/null \
    || die "${NAMESPACE} must not be sidecar-injected. Remove istio.io/rev or istio-injection labels from the Istio control namespace."
}

require_kubernetes_tools
require_cmd jq
: "${KIALI_GRAFANA_TOKEN:?Set KIALI_GRAFANA_TOKEN for the external Grafana integration}"
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

ensure_cis_namespace "${NAMESPACE}" true privileged
kubectl label --overwrite namespace "${NAMESPACE}" topology.istio.io/network="${SITE}${CLUSTER}-net1" >/dev/null
ensure_registry_secret "${NAMESPACE}"

log "Creating/updating the runtime Kiali Grafana bearer-token secret..."
kubectl -n "${NAMESPACE}" create secret generic kiali-grafana-credentials \
  --from-literal=token="${KIALI_GRAFANA_TOKEN}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

kubectl -n "${NAMESPACE}" get secret cacerts >/dev/null 2>&1 || die "Missing istio-system/cacerts. Run scripts/istio/01-apply-istio-cacerts.sh first."

helm_upgrade_install "istio-base" "${HELM_PACKAGES_DIR}/${ISTIO_BASE_PACKAGE}" "${NAMESPACE}" "${OPTIONS}/values/${ISTIO_BASE_VALUES}"
helm_upgrade_install "istiod" "${HELM_PACKAGES_DIR}/${ISTIO_ISTIOD_PACKAGE}" "${NAMESPACE}" "${OPTIONS}/values/${ISTIO_ISTIOD_VALUES}"
validate_revisioned_injection_ready

helm_upgrade_install "istio-eastwestgateway" "${HELM_PACKAGES_DIR}/${ISTIO_GATEWAY_PACKAGE}" "${NAMESPACE}" "${OPTIONS}/values/${ISTIO_GATEWAY_VALUES}"
apply_file_in_namespace "${NAMESPACE}" "${OPTIONS}/resources/${ISTIO_GATEWAY_RESOURCES}"
wait_for_deployment_available "${NAMESPACE}" "istio-eastwestgateway-${SITE}${CLUSTER}" "${KUBECTL_TIMEOUT}"

helm_upgrade_install "kiali-operator" "${HELM_PACKAGES_DIR}/${KIALI_OPERATOR_PACKAGE}" "${NAMESPACE}" "${OPTIONS}/values/${KIALI_OPERATOR_VALUES}"
wait_for_deployment_available "${NAMESPACE}" "kiali-operator" "${KUBECTL_TIMEOUT}"

helm_upgrade_install "kiali" "${HELM_PACKAGES_DIR}/${KIALI_SERVER_PACKAGE}" "${NAMESPACE}" "${OPTIONS}/values/${KIALI_SERVER_VALUES}"
wait_for_deployment_available "${NAMESPACE}" "kiali" "${KUBECTL_TIMEOUT}"
apply_file "${OPTIONS}/resources/${KIALI_SERVER_RESOURCES}"

log "Istio service mesh installed and revisioned sidecar injection is available for istio.io/rev=${ISTIO_REV}."
