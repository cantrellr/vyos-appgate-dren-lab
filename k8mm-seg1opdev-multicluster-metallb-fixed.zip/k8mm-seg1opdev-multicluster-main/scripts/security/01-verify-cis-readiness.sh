#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

if [[ "${1:-}" == "--all" ]]; then
  shift
  for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do
    "${BASH_SOURCE[0]}" "${context:0:3}" "${context:3}" "$@"
  done
  exit 0
fi
init_site_cluster "$@"
require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

declare -A EXPECTED_PSA=(
  [cert-manager]=restricted
  [metallb-system]=privileged
  [segment1]=restricted
  [trident-system]=privileged
  [trident-protect]=privileged
  [istio-system]=privileged
  [oppostgres]=restricted
  [opkeycloak]=restricted
  [elastic-agent-system]=privileged
  [elastic-monitoring]=restricted
  [cattle-system]=privileged
  [cattle-fleet-system]=privileged
)
if [[ "${K8_CONTEXT}" == "j64seg1opman" ]]; then
  EXPECTED_PSA[cattle-fleet-local-system]=privileged
  EXPECTED_PSA[cattle-fleet-clusters-system]=privileged
fi

failures=0
for namespace in "${!EXPECTED_PSA[@]}"; do
  expected="${EXPECTED_PSA[$namespace]}"
  if ! kubectl get namespace "${namespace}" >/dev/null 2>&1; then
    printf '[FAIL] namespace missing: %s\n' "${namespace}" >&2
    failures=$((failures + 1))
    continue
  fi
  for mode in enforce audit warn; do
    actual="$(kubectl get namespace "${namespace}" -o go-template="{{ with index .metadata.labels \"pod-security.kubernetes.io/${mode}\" }}{{ . }}{{ end }}")"
    if [[ "${actual}" == "${expected}" ]]; then
      printf '[PASS] %s %s=%s\n' "${namespace}" "${mode}" "${expected}"
    else
      printf '[FAIL] %s expected %s=%s, found %s\n' "${namespace}" "${mode}" "${expected}" "${actual:-<unset>}" >&2
      failures=$((failures + 1))
    fi
  done
  case "${namespace}" in
    cattle-system|cattle-fleet-system|cattle-fleet-local-system|cattle-fleet-clusters-system)
      printf '[PASS] %s default ServiceAccount remains owned by Rancher/Fleet\n' "${namespace}"
      ;;
    *)
      token_mount="$(kubectl -n "${namespace}" get serviceaccount default -o jsonpath='{.automountServiceAccountToken}' 2>/dev/null || true)"
      if [[ "${token_mount}" == "false" ]]; then
        printf '[PASS] %s default ServiceAccount token automount disabled\n' "${namespace}"
      else
        printf '[FAIL] %s default ServiceAccount token automount is %s\n' "${namespace}" "${token_mount:-<unset>}" >&2
        failures=$((failures + 1))
      fi
      ;;
  esac
done
[[ "${failures}" -eq 0 ]] || die "CIS/PSA validation failed with ${failures} issue(s)."
log "CIS/PSA namespace validation passed for ${K8_CONTEXT}."
