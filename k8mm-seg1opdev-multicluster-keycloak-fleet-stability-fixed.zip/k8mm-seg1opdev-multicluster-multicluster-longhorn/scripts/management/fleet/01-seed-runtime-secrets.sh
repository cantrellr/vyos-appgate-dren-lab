#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
source "${SCRIPT_DIR}/../../_lib/cis.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"

registry_username="$(read_required_secret_file REGISTRY_USERNAME_FILE)"
registry_password="$(read_required_secret_file REGISTRY_PASSWORD_FILE)"
kiali_token="$(read_required_secret_file KIALI_GRAFANA_TOKEN_FILE)"
postgres_username="$(read_required_secret_file POSTGRES_APP_USERNAME_FILE)"
postgres_password="$(read_required_secret_file POSTGRES_APP_PASSWORD_FILE)"
keycloak_username="$(read_required_secret_file KEYCLOAK_BOOTSTRAP_USERNAME_FILE)"
keycloak_password="$(read_required_secret_file KEYCLOAK_BOOTSTRAP_PASSWORD_FILE)"

[[ -n "${ELASTIC_FLEET_URL:-}" ]] || die "Set ELASTIC_FLEET_URL in the runtime config."
require_runtime_file ELASTIC_FLEET_CA_FILE
require_runtime_file KEYCLOAK_KEYTAB_FILE_001
require_runtime_file KEYCLOAK_PROVIDER_FILE_001
require_cmd sha256sum
require_cmd base64

secret_key_sha256() {
  local namespace="$1" secret_name="$2" data_key="$3" encoded
  encoded="$(kubectl -n "${namespace}" get secret "${secret_name}" -o json 2>/dev/null | jq -r --arg key "${data_key}" '.data[$key] // empty' 2>/dev/null || true)"
  [[ -n "${encoded}" ]] || return 0
  printf '%s' "${encoded}" | base64 --decode | sha256sum | awk '{print $1}'
}

file_sha256() {
  sha256sum "$1" | awk '{print $1}'
}

restart_keycloak_pods_ordered() {
  local context="$1" namespace="opkeycloak" statefulset="opkeycloak"
  local replicas ordinal pod old_uid new_uid attempt

  replicas="$(kubectl -n "${namespace}" get statefulset "${statefulset}" -o jsonpath='{.spec.replicas}')"
  [[ "${replicas}" =~ ^[0-9]+$ ]] || die "Unable to determine ${namespace}/${statefulset} replica count on ${context}."
  (( replicas > 0 )) || return 0

  # Do not patch rollout annotations on the StatefulSet: that object is owned by
  # the Keycloak Operator. Recycle one server Pod at a time instead, highest
  # ordinal first, and wait for each replacement to become Ready. This refreshes
  # the provider subPath mount without creating Operator/Fleet field contention.
  log "Keycloak runtime artifact changed on ${context}; recycling ${replicas} Keycloak pod(s) one at a time."
  for (( ordinal=replicas-1; ordinal>=0; ordinal-- )); do
    pod="${statefulset}-${ordinal}"
    old_uid=""
    if ! kubectl -n "${namespace}" get pod "${pod}" >/dev/null 2>&1; then
      warn "Expected ${namespace}/${pod} is absent on ${context}; waiting for the StatefulSet controller to create it."
    else
      old_uid="$(kubectl -n "${namespace}" get pod "${pod}" -o jsonpath='{.metadata.uid}')"
      kubectl -n "${namespace}" delete pod "${pod}" --wait=true --timeout="${KUBECTL_TIMEOUT}" >/dev/null
    fi
    new_uid=""
    for (( attempt=1; attempt<=60; attempt++ )); do
      if kubectl -n "${namespace}" get pod "${pod}" >/dev/null 2>&1; then
        new_uid="$(kubectl -n "${namespace}" get pod "${pod}" -o jsonpath='{.metadata.uid}')"
        if [[ -n "${new_uid}" && ( -z "${old_uid}" || "${new_uid}" != "${old_uid}" ) ]]; then
          break
        fi
      fi
      sleep 1
    done
    [[ -n "${new_uid}" && ( -z "${old_uid}" || "${new_uid}" != "${old_uid}" ) ]] || \
      die "Replacement pod ${namespace}/${pod} was not recreated on ${context}."
    kubectl -n "${namespace}" wait --for=condition=Ready "pod/${pod}" --timeout="${KUBECTL_TIMEOUT}"
  done
}

seed_cluster() {
  local context="$1"
  validate_context_access "${context}"
  use_context "${context}"

  for namespace in kube-system cert-manager segment1 metallb-system longhorn-system istio-system elastic-agent-system elastic-monitoring; do
    if [[ "${namespace}" != "kube-system" ]]; then
      psa_level=restricted
      [[ "${namespace}" =~ ^(metallb-system|longhorn-system|istio-system|elastic-agent-system)$ ]] && psa_level=privileged
      ensure_cis_namespace "${namespace}" true "${psa_level}"
      if [[ "${namespace}" =~ ^(longhorn-system|istio-system)$ ]]; then
        kubectl label namespace "${namespace}" \
          segment1.ingress/allow-backend=true --overwrite >/dev/null
      fi
    fi
    kubectl -n "${namespace}" create secret docker-registry regcred-kubeharbor \
      --docker-server="${REGISTRY_HOST:-kubeharbor.dev.kube}" \
      --docker-username="${registry_username}" \
      --docker-password="${registry_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  done

  kubectl -n cert-manager create secret tls segment1-ca-bundle-secret \
    --cert="${CA_CERT_FILE}" \
    --key="${CA_KEY_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  local cacerts_dir="${ISTIO_CACERTS_DIR}/${context}"
  for file in ca-cert.pem ca-key.pem root-cert.pem cert-chain.pem; do
    ensure_file "${cacerts_dir}/${file}"
  done
  kubectl -n istio-system create secret generic cacerts \
    --from-file=ca-cert.pem="${cacerts_dir}/ca-cert.pem" \
    --from-file=ca-key.pem="${cacerts_dir}/ca-key.pem" \
    --from-file=root-cert.pem="${cacerts_dir}/root-cert.pem" \
    --from-file=cert-chain.pem="${cacerts_dir}/cert-chain.pem" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  kubectl -n istio-system create secret generic kiali-grafana-credentials \
    --from-literal=token="${kiali_token}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  kubectl label namespace elastic-agent-system \
    k8mm.dev/monitoring-agent=true \
    k8mm.dev/elastic-agent-topology=single \
    --overwrite >/dev/null

  local token_variable="ELASTIC_FLEET_TOKEN_${context^^}_FILE"
  local elastic_fleet_token=""
  local current_fleet_url_b64=""
  local current_fleet_token_b64=""
  local desired_fleet_url_b64=""
  local desired_fleet_token_b64=""
  local enrollment_secret_changed=false
  elastic_fleet_token="$(read_required_secret_file "${token_variable}")"

  # Secret-backed environment variables are fixed when a Pod is created. Detect
  # an enrollment URL/token rotation without printing either value, then restart
  # the existing per-node Agent DaemonSet after the Secret is updated.
  current_fleet_url_b64="$(kubectl -n elastic-agent-system get secret elastic-agent-fleet-enrollment \
    -o jsonpath='{.data.FLEET_URL}' 2>/dev/null || true)"
  current_fleet_token_b64="$(kubectl -n elastic-agent-system get secret elastic-agent-fleet-enrollment \
    -o jsonpath='{.data.FLEET_ENROLLMENT_TOKEN}' 2>/dev/null || true)"
  desired_fleet_url_b64="$(printf '%s' "${ELASTIC_FLEET_URL}" | base64 | tr -d '\n')"
  desired_fleet_token_b64="$(printf '%s' "${elastic_fleet_token}" | base64 | tr -d '\n')"
  if [[ "${current_fleet_url_b64}" != "${desired_fleet_url_b64}" || \
        "${current_fleet_token_b64}" != "${desired_fleet_token_b64}" ]]; then
    enrollment_secret_changed=true
  fi

  kubectl -n elastic-agent-system create secret generic devlocal-ca-bundle-secret \
    --from-file=ca.crt="${ELASTIC_FLEET_CA_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n elastic-agent-system create secret generic elastic-agent-fleet-enrollment \
    --from-literal=FLEET_URL="${ELASTIC_FLEET_URL}" \
    --from-literal=FLEET_ENROLLMENT_TOKEN="${elastic_fleet_token}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  if [[ "${enrollment_secret_changed}" == "true" ]] && \
     kubectl -n elastic-agent-system get daemonset agent-pernode-elastic-agent-node >/dev/null 2>&1; then
    log "Elastic Fleet enrollment Secret changed on ${context}; restarting the existing Agent DaemonSet."
    kubectl -n elastic-agent-system rollout restart daemonset/agent-pernode-elastic-agent-node >/dev/null
  fi

  unset elastic_fleet_token current_fleet_url_b64 current_fleet_token_b64
  unset desired_fleet_url_b64 desired_fleet_token_b64 enrollment_secret_changed
}

seed_identity_cluster() {
  local context="$1"
  use_context "${context}"
  for namespace in oppostgres opkeycloak; do
    ensure_cis_namespace "${namespace}" true restricted
    if [[ "${namespace}" == "opkeycloak" ]]; then
      kubectl label namespace "${namespace}" \
        segment1.ingress/allow-backend=true --overwrite >/dev/null
    fi
    kubectl -n "${namespace}" create secret docker-registry regcred-kubeharbor \
      --docker-server="${REGISTRY_HOST:-kubeharbor.dev.kube}" \
      --docker-username="${registry_username}" \
      --docker-password="${registry_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
    kubectl -n "${namespace}" create secret generic opkeycloak-postgresql-credentials \
      --from-literal=username="${postgres_username}" \
      --from-literal=password="${postgres_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  done
  kubectl -n opkeycloak create secret generic opkeycloak-bootstrap-admin \
    --from-literal=username="${keycloak_username}" \
    --from-literal=password="${keycloak_password}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  # Keytab/provider artifacts are deliberately runtime inputs, not Git content.
  # Compare hashes before applying so existing Keycloak server Pods are only
  # recycled when the binary payload actually changed. provider.jar is mounted
  # with subPath, which requires a new Pod to observe Secret rotation.
  local current_keytab_sha desired_keytab_sha current_provider_sha desired_provider_sha
  local keycloak_runtime_artifacts_changed=false
  current_keytab_sha="$(secret_key_sha256 opkeycloak opkeycloak-keytab opkeycloak.keytab)"
  desired_keytab_sha="$(file_sha256 "${KEYCLOAK_KEYTAB_FILE_001}")"
  current_provider_sha="$(secret_key_sha256 opkeycloak opkeycloak-provider provider.jar)"
  desired_provider_sha="$(file_sha256 "${KEYCLOAK_PROVIDER_FILE_001}")"

  if [[ "${current_keytab_sha}" != "${desired_keytab_sha}" || \
        "${current_provider_sha}" != "${desired_provider_sha}" ]]; then
    keycloak_runtime_artifacts_changed=true
  fi

  kubectl -n opkeycloak create secret generic opkeycloak-keytab \
    --from-file=opkeycloak.keytab="${KEYCLOAK_KEYTAB_FILE_001}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n opkeycloak label secret opkeycloak-keytab --overwrite \
    app.kubernetes.io/part-of=opkeycloak \
    app.kubernetes.io/component=kerberos-keytab \
    k8mm.dev/secret-management=runtime >/dev/null

  kubectl -n opkeycloak create secret generic opkeycloak-provider \
    --from-file=provider.jar="${KEYCLOAK_PROVIDER_FILE_001}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n opkeycloak label secret opkeycloak-provider --overwrite \
    app.kubernetes.io/part-of=opkeycloak \
    app.kubernetes.io/component=custom-provider \
    k8mm.dev/secret-management=runtime >/dev/null

  if [[ "${keycloak_runtime_artifacts_changed}" == "true" ]] && \
     kubectl -n opkeycloak get statefulset opkeycloak >/dev/null 2>&1; then
    restart_keycloak_pods_ordered "${context}"
  fi
}

for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do
  seed_cluster "${context}"
done
for context in j64seg1opdev j52seg1opdev; do
  seed_identity_cluster "${context}"
done

unset registry_username registry_password
unset kiali_token postgres_username postgres_password keycloak_username keycloak_password
unset ELASTIC_FLEET_URL
log "Runtime Secrets seeded across all four clusters and both identity sites. No credential values were printed or written to Git."
