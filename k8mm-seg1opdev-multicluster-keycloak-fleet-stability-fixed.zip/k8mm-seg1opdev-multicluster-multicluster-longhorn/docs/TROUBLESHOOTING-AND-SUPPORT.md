# Troubleshooting and Support

> **Baseline:** v2.1 — August 20, 2026  
> **Audience:** help desk, support technicians, platform support, systems engineers, and senior escalation engineers.

## 1. Support model

The support objective is to identify the **failure domain** before changing the environment. Most visible failures fall into one of four categories:

1. client/access problem;
2. Kubernetes workload/platform problem;
3. GitOps/source-of-truth problem; or
4. external dependency problem such as GitLab, KubeHarbor, DNS, NTP, CA, Elastic, or network routing.

```mermaid
flowchart TD
  ALERT[User report or monitoring alert]
  T1[Help Desk - Tier 1\nIdentify cluster, URL, symptom, time, scope]
  BASIC[Check Rancher reachability, DNS, certificate, and known status]
  RESTORE{Known client or access issue?}
  T2[Platform Support - Tier 2\nCheck Fleet, pods, events, HTTPProxy, Longhorn, Chrony]
  DIAG[Run collect-gitops-logs.sh and targeted validation]
  OWNER{Failure domain identified?}
  T3[Systems Engineering - Tier 3\nGitOps source, Rancher/Fleet, mesh, identity, storage]
  EXT[External dependency owner\nGitLab, KubeHarbor, DNS, NTP, CA, Elastic, network]
  CHANGE[Correct source of truth or external dependency]
  VERIFY[Run validation and confirm all bundles / services healthy]
  CLOSE[Document resolution and close incident]

  ALERT --> T1
  T1 --> BASIC
  BASIC --> RESTORE
  RESTORE -->|yes| CLOSE
  RESTORE -->|no| T2
  T2 --> DIAG
  DIAG --> OWNER
  OWNER -->|platform| T3
  OWNER -->|external| EXT
  T3 --> CHANGE
  EXT --> CHANGE
  CHANGE --> VERIFY
  VERIFY -->|pass| CLOSE
  VERIFY -->|fail| T3
```

## 2. Incident information required from the help desk

Tier 1 should capture the following before escalation:

- user/customer and callback/contact path;
- date/time and timezone of the failure;
- affected service/URL;
- affected cluster if known;
- exact error message or screenshot;
- whether the issue affects one user, one site, one cluster, or everyone;
- whether it ever worked and the last known-good time;
- recent maintenance/change window if known;
- browser/client source network and source IP when relevant to restricted UIs;
- ticket severity and business impact.

Do **not** ask Tier 1 to delete pods, change Fleet bundles, modify Helm releases, or edit cluster labels.

## 3. Tier 1 — Help Desk checklist

### Rancher or administrative UI unavailable

1. Verify the hostname resolves to the expected Segment1 VIP.
2. Verify the client is on an allowed network.
3. Check whether the browser reports DNS, TCP timeout, HTTP error, or certificate error.
4. Try another known-good administrative URL to determine whether the problem is service-specific or the entire ingress path.
5. Escalate with the exact URL, source network, time, and browser error.

Administrative URLs:

| Service | Management | j64 | j52 | r01 |
| --- | --- | --- | --- | --- |
| Longhorn | `longhorn-man.dev.kube` | `longhorn-j64.dev.kube` | `longhorn-j52.dev.kube` | `longhorn-r01.dev.kube` |
| Kiali | `kiali-man.dev.kube` | `kiali-j64.dev.kube` | `kiali-j52.dev.kube` | `kiali-r01.dev.kube` |

Rancher is `rancher.dev.kube`; identity is `opkeycloak.dev.jde.cybercom.ic.gov`.

### Important Longhorn UI behavior

The Longhorn HTTPProxy allows only `1.0.0.0/23` by design. A user outside the trusted Segment1 source range may be denied even when Longhorn is healthy. Treat that as an access-policy issue, not a storage outage.

## 4. Tier 2 — Platform Support first checks

Set the relevant kubeconfig context and start read-only:

```bash
kubectl --context j64seg1opman get nodes
kubectl --context j64seg1opman get pods -A
kubectl --context j64seg1opman get events -A --sort-by=.lastTimestamp | tail -100
```

Then run the platform validators appropriate to the symptom:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

Collect a diagnostic archive before disruptive changes:

```bash
./scripts/collect-gitops-logs.sh
```

Attach the generated archive to the incident/escalation.

## 5. Determine whether Fleet is reconciling the expected branch

A common and highly deceptive failure is editing one branch while Fleet is configured to reconcile another. Always check:

```bash
git branch --show-current
grep '^FLEET_REPO_BRANCH=' "$KMM_FLEET_CONFIG"
```

Then inspect the live GitRepo branch and commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
kubectl --context j64seg1opman -n fleet-local   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

If the live commit is not the intended Git commit, correct the Git/runtime configuration first. Deleting Bundles will only recreate the same undesired state.

## 6. Fleet Bundle states

### `ErrApplied` with `dependent bundle(s) are not ready`

The displayed bundle is usually **not** the root cause. Follow the named dependency upstream until the first bundle with a direct Helm/schema/resource error is found.

Example chain:

```text
kiali-resources -> kiali -> kiali-operator -> istiod
```

Investigate the first non-ready dependency rather than each downstream red bundle separately.

### `Modified`

`Modified` means the live resource differs from Fleet's normalized desired state. Determine whether this is expected controller mutation or real drift.

Known intentional normalization examples include Istio validating-webhook `caBundle` injection and narrowly scoped operator ownership-label mutation. Do not broadly ignore an entire resource when a field-specific comparison rule is sufficient.

### Missing bundle matching `kmm.dev/bundle=<name>`

Check the Git branch/commit first. Then check that the required bundle path is included in the correct GitRepo and carries the expected label. Retired dependencies such as old Trident bundle names should not exist in the Longhorn design.

## 7. Rancher/Fleet agent problems

### Cluster agent will not connect

Check:

- `rancher.dev.kube` DNS and TLS;
- Contour `rancher-httpproxy` validity;
- WebSocket path `wss://rancher.dev.kube/v3/connect/register`;
- `cattle-system` agent pod logs/events;
- firewall/proxy timeout behavior.

Use:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-rancher-imports
```

### PodSecurity rejection

Typical event:

```text
pods "fleet-agent-..." is forbidden: violates PodSecurity "restricted:latest"
```

Repair the scoped Rancher/Fleet system namespaces:

```bash
./scripts/deploy-platform.sh repair-rancher-psa
```

### Fleet watch-stream/cache problems on Kubernetes 1.35

Symptoms can include repeated watch decode/stream errors and BundleDeployments remaining in `WaitApplied`. Reapply/verify:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

The expected control is `KUBE_FEATURE_WatchListClient=false` on controllers/agents.

## 8. KubeHarbor and image/chart pull failures

Symptoms:

- `ImagePullBackOff` / `ErrImagePull`;
- Fleet OCI chart authentication/TLS failures;
- GitJob cannot resolve or authenticate to Harbor;
- Rancher Helm operation pods fail during disconnected bootstrap.

Checks:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh configure-management-dns
./scripts/deploy-platform.sh validate-fleet-oci
```

Confirm:

- DNS resolves `kubeharbor.dev.kube` from nodes **and pods**;
- CA chain is trusted;
- credentials are valid;
- required chart/image exists at the exact expected path/tag;
- node RKE2 `registries.yaml` trust/authentication is correct.

Do not bypass TLS validation to make the error disappear.

## 9. Chrony / time troubleshooting

### Pod Running but time is not synchronized

A Running Chrony container is not proof of synchronized host time.

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target a cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

Inspect one pod:

```bash
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc sources -v
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc tracking
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc ntpdata <ntp-server>
```

Healthy state requires a `^*` selected source, positive stratum, and `Leap status: Normal`.

### UDP/123 works but Chrony will not select the server

Check the **server's NTP status**, not just connectivity. A reply with leap indicator `unknown/unsynchronized` (`LI=3`) or stratum 0 is invalid as a synchronization source. Escalate to the NTP/AD time-service owner.

The `chrony-status` sidecar provides compact periodic state:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=100
```

## 10. Longhorn troubleshooting

### Longhorn bundle is Active but PVC will not bind

Check:

```bash
kubectl --context <ctx> -n longhorn-system get pods -o wide
kubectl --context <ctx> get nodes -L node.longhorn.io/create-default-disk
kubectl --context <ctx> get storageclass
kubectl --context <ctx> get pvc -A
kubectl --context <ctx> get events -A --sort-by=.lastTimestamp | tail -100
```

Run host validation:

```bash
./scripts/management/preflight/longhorn-storage-preflight.sh --context <ctx>
```

Common root causes include missing iSCSI packages/service, `/mnt/k8sdata` not XFS, insufficient capacity, incorrect mount propagation, multipath claiming devices, or the worker lacking the approved Longhorn disk label.

### Longhorn UI unavailable

Check DNS, source IP policy, `longhorn-ui` Certificate, `longhorn-ui` HTTPProxy, `longhorn-frontend` Service, Envoy, and both sides of the NetworkPolicy path:

```bash
kubectl --context <ctx> -n longhorn-system get certificate,httpproxy,svc,pods
kubectl --context <ctx> -n longhorn-system describe httpproxy longhorn-ui
kubectl --context <ctx> -n longhorn-system get networkpolicy longhorn-ui-allow-segment1-envoy -o yaml
kubectl --context <ctx> -n segment1 get networkpolicy segment1-allow-envoy-to-platform-backends -o yaml
kubectl --context <ctx> get namespace longhorn-system --show-labels
```

The `longhorn-frontend` Service exposes port 80 but targets the Longhorn UI pods on TCP/8000. Calico enforces NetworkPolicy on the translated pod destination, so the Longhorn ingress policy and Segment1 Envoy egress policy must both permit TCP/8000. The `longhorn-system` namespace must also carry `segment1.ingress/allow-backend=true`. An Envoy response containing `upstream connect error ... connection timeout` with a Valid HTTPProxy is a strong indicator that the backend policy path should be checked.

## 11. HTTPProxy `invalid`

Contour marks the object invalid when the desired route cannot be constructed. Check:

```bash
kubectl --context <ctx> -n <ns> describe httpproxy <name>
kubectl --context <ctx> -n <ns> get svc,secret,certificate
```

Typical causes:

- referenced Service does not exist;
- referenced service port is wrong;
- TLS Secret does not exist/has not become Ready;
- invalid schema/route field;
- wrong ingress class;
- dependency has not yet created the backend.

For Keycloak, the standby site intentionally does **not** render the HTTPProxy while `keycloakInstances=0`. If an old standby proxy remains from a prior deployment, confirm Fleet has reconciled the current branch and desired state.

## 12. Istio troubleshooting

### `istio-base` or `istiod` shows `Modified`

Inspect Fleet diff details. Istio injects validating-webhook CA data at runtime; the repository uses field-specific comparison rules for that expected mutation. A new or different drift field should be investigated rather than ignored globally.

### East-west gateway fails Helm schema validation

The Istio Gateway chart version in this baseline does not accept obsolete root `hub`/`tag` values. Those image settings are provided through supported Istio configuration. If schema errors reappear, verify the deployed branch and values against the packaged chart schema.

### Cross-cluster traffic failure

Check east-west gateway VIP, Gateway/Service readiness, Istio remote Secrets, trust material, network routing, and explicit namespace injection state.

## 13. Kiali troubleshooting

Kiali can be Running while external metrics are unavailable. Check:

- Kiali pod/readiness;
- Kiali HTTPProxy/Certificate;
- external Prometheus URL/readiness;
- external Grafana URL/readiness;
- `kiali-grafana-credentials` Secret/RBAC;
- connectivity and CA trust from Kiali to those external endpoints.

## 14. Keycloak / CloudNativePG troubleshooting

Validate site roles first:

```bash
./scripts/deploy-platform.sh validate-identity-ha
```

Check:

```bash
kubectl --context j64seg1opdev -n opkeycloak get pods,svc,httpproxy,certificate
kubectl --context j64seg1opdev -n oppostgres get pods,pvc
kubectl --context j52seg1opdev -n oppostgres get pods,pvc
```

Common failure domains:

- Longhorn PVC not Bound;
- CNPG operator or cluster not Ready;
- CloudNativePG operator blocked from an instance-manager status endpoint on TCP/8000;
- CNPG replica join/bootstrap pod timing out to the primary `*-rw` Service on TCP/5432 because an ingress NetworkPolicy selected the primary without allowing local CNPG cluster members;
- PgBouncer NetworkPolicy/PDB selectors not matching CNPG-owned `cnpg.io/poolerName` / `cnpg.io/podRole=pooler` labels;
- replication TLS/Secret missing;
- Keycloak backend Service absent;
- `opkeycloak` namespace missing `segment1.ingress/allow-backend=true`;
- standby/active labels inconsistent;
- ingress certificate or HTTPProxy invalid;
- DNS still targets the wrong site after failover.

For a CNPG status-path failure, inspect the operator log and policies together:

```bash
kubectl --context j64seg1opdev -n oppostgres logs -l app.kubernetes.io/name=cloudnative-pg --tail=200
kubectl --context j64seg1opdev -n oppostgres get networkpolicy -o yaml
kubectl --context j64seg1opdev -n oppostgres get pods --show-labels
```

The repository explicitly permits the CNPG operator to reach database instance-manager TCP/8000. It also pre-applies local CNPG cluster-member ingress on TCP/5432 before the PostgreSQL Cluster bundle starts, because Kubernetes NetworkPolicy isolation is additive: once any ingress policy selects the primary pod, replica join traffic through the `*-rw` Service must be explicitly allowed. Default-deny policies are workload-scoped so they do not unintentionally isolate the Keycloak or CloudNativePG operators that share the application namespaces.

Never promote the secondary by ad-hoc database or label changes. Use the controlled failover process and required fencing.

## 15. Elastic Agent troubleshooting

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If one cluster fails, confirm:

- the cluster's specific enrollment token file was used;
- Fleet URL resolves/routes from the cluster;
- certificate SAN matches the Fleet URL;
- CA file is correct;
- the policy exists and is intended for that cluster;
- the Elastic Agent Secret was seeded.

## 16. `helm-operation-*` pods

Rancher creates temporary Helm operation pods for system-chart work. A failed `1/2` operation can block Rancher provisioning/import workflows.

Use the Rancher system validator/repair workflow to capture their logs and clean up failed temporary operations safely:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh repair-rancher-system
```

Do not indiscriminately delete all Helm operation resources while Rancher is actively reconciling.

## 17. Escalation package for systems engineering

Tier 2 should include:

1. diagnostic archive from `collect-gitops-logs.sh`;
2. affected cluster/context;
3. Git branch and local commit;
4. live Fleet GitRepo branch/commit;
5. `validate-package` result if a recent code change is involved;
6. relevant `describe` output for HTTPProxy/PVC/Pod/Bundle;
7. exact timestamps and recent change window;
8. whether GitLab, KubeHarbor, DNS, NTP, CA, Elastic, or network teams have confirmed their services healthy.

## 18. Engineering recovery rules

- Prefer Git correction/revert for Fleet-owned resources.
- Prefer supported repair scripts for Rancher/Fleet state.
- Do not disable TLS verification as a permanent fix.
- Do not manually format/repair Longhorn disks through the preflight tool; it is validation-only.
- Do not delete Chrony without the supported restore path.
- Do not manually reverse identity role labels.
- Capture evidence before destructive actions.
- After remediation, rerun the applicable validator and confirm dependent Fleet bundles return Active.


### Fleet GitRepo shows `Stalled=True` after a successful reconciliation

A transient Git server or network timeout can leave an older `Stalled=True` condition visible even when the same GitRepo later reports `Ready=True`, `GitPolling=True`, a current commit, and all BundleDeployments Ready. Treat the workload state and condition timestamps separately. The repository validator warns and continues only when those current-health signals are all present; an active stall still fails validation.

For the downstream GitRepo, first verify GitLab DNS/HTTPS reachability from the management cluster, then force a new Fleet sync with `./scripts/deploy-platform.sh fleet`. Do not delete healthy Bundles merely to clear the UI condition.

A Rancher count such as `25/27 Bundles ready` can also be expected in the normal primary-site topology when the secondary Keycloak and PostgreSQL-replica bundles are intentionally targetless (`0/0`). Confirm the BundleDeployments and resource counts before treating that ratio as a deployment failure.

### Keycloak Operator reports `409 Conflict` while Keycloak server Pods are healthy

Run exactly one `opkeycloak-operator` replica for a given watched namespace. The Keycloak server remains highly available through the Keycloak CR `spec.instances`; scaling the Operator controller itself creates multiple reconcilers updating the same CR and can produce resource-version/status conflicts. The CIS renderer and generated Operator manifest intentionally preserve one Operator replica.

The Keycloak CR `unsupported.podTemplate` must also avoid overriding the Operator-owned container name or command/args. Use it only for the additional volumes, mounts, and container security context required by the runtime keytab/provider integration.

### Keycloak JDBC timeout to CloudNativePG / PgBouncer

If `opkeycloak-0` reports `Unable to obtain isolated JDBC connection` or `The connection attempt failed` while the CNPG cluster and PgBouncer pods are Ready, verify the NetworkPolicy selectors on both sides of TCP/5432. The Keycloak Operator owns the server labels (`app=keycloak`, `app.kubernetes.io/instance=opkeycloak`, and `app.kubernetes.io/managed-by=keycloak-operator`). Do not authorize PostgreSQL ingress with `app=opkeycloak`; that label is not an operator-owned contract. The prerequisite `oppostgres-resources` bundle installs the Keycloak-to-PgBouncer ingress rule before the Keycloak CR starts. Repository-managed NetworkPolicies own Keycloak traffic, so the operator-generated Keycloak NetworkPolicy is disabled.

### Keycloak replicas start, stop, or continuously reform the cache cluster

If the JDBC error is resolved but the three `opkeycloak-*` pods repeatedly transition between startup/readiness states, inspect JGroups/Infinispan messages and pod events. With `cache-stack=jdbc-ping`, the database is used for peer discovery, while Keycloak members still communicate directly over TCP/7800 and TCP/57800. Because the repository applies an ingress/egress default deny to the Keycloak application pods, both ports must be explicitly allowed from Keycloak server pods to Keycloak server pods. The `opkeycloak-allow-cluster` NetworkPolicy owns this path in both identity-site bundles.

Useful checks:

```bash
kubectl -n opkeycloak get networkpolicy opkeycloak-allow-cluster -o yaml
kubectl -n opkeycloak get pods -l app=keycloak -o wide
kubectl -n opkeycloak logs opkeycloak-0 --previous | egrep -i 'jgroups|infinispan|cluster|suspect|7800|57800|failure'
```

