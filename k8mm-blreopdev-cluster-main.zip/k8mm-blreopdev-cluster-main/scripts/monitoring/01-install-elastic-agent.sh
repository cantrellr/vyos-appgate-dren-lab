#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/cis.sh
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"

ELASTIC_VERSION="9.4.2"
KSM_CHART_VERSION="6.1.0"
NODE_NAMESPACE="elastic-agent-system"
CLUSTER_NAMESPACE="elastic-agent-cluster-system"
METRICS_NAMESPACE="elastic-monitoring"
FLEET_SECRET="elastic-agent-fleet-enrollment"
FLEET_CA_SECRET="devlocal-ca-bundle-secret"
FLEET_CA_KEY="ca.crt"

NODE_RELEASE="${SITE}${CLUSTER}-elastic-node"
CLUSTER_RELEASE="${SITE}${CLUSTER}-elastic-cluster"
KSM_RELEASE="${SITE}${CLUSTER}-kube-state-metrics"

ELASTIC_CHART="${HELM_PACKAGES_DIR}/elastic-agent-${ELASTIC_VERSION}.tgz"
KSM_CHART="${HELM_PACKAGES_DIR}/kube-state-metrics-${KSM_CHART_VERSION}.tgz"
NODE_VALUES="${YAML_DIR}/monitoring/elastic-agent-per-node-${ELASTIC_VERSION}-values.yaml"
CLUSTER_VALUES="${YAML_DIR}/monitoring/elastic-agent-cluster-wide-${ELASTIC_VERSION}-values.yaml"
KSM_VALUES="${YAML_DIR}/monitoring/kube-state-metrics-${KSM_CHART_VERSION}-values.yaml"
CA_BUNDLE_FILE="${YAML_DIR}/resources/devlocal-opdev-ca-bundle-secret-v1.yaml"

: "${FLEET_URL:?Set FLEET_URL to the Fleet Server URL, for example https://fleet.example.mil:8220}"
: "${FLEET_ENROLLMENT_TOKEN:?Set FLEET_ENROLLMENT_TOKEN to the Fleet enrollment token provided by the ELK administrator}"

FLEET_INSECURE="${FLEET_INSECURE:-false}"

case "${FLEET_INSECURE}" in
  true|false) ;;
  *) die "FLEET_INSECURE must be true or false." ;;
esac

if [[ "${FLEET_INSECURE}" == "true" ]]; then
  warn "FLEET_INSECURE=true disables Fleet Server certificate verification and is not recommended for production."
fi

require_kubernetes_tools
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

for required_file in \
  "${ELASTIC_CHART}" \
  "${KSM_CHART}" \
  "${NODE_VALUES}" \
  "${CLUSTER_VALUES}" \
  "${KSM_VALUES}" \
  "${CA_BUNDLE_FILE}"; do
  ensure_file "${required_file}"
done

log "Creating CIS-aware namespaces for Elastic monitoring..."
ensure_cis_namespace "${NODE_NAMESPACE}" true privileged
ensure_cis_namespace "${CLUSTER_NAMESPACE}" true privileged
ensure_cis_namespace "${METRICS_NAMESPACE}" true restricted

ensure_registry_secret "${NODE_NAMESPACE}"
ensure_registry_secret "${CLUSTER_NAMESPACE}"
ensure_registry_secret "${METRICS_NAMESPACE}"

log "Applying shared devlocal OPDEV CA bundle to Elastic Agent namespaces..."
apply_file_in_namespace "${NODE_NAMESPACE}" "${CA_BUNDLE_FILE}"
apply_file_in_namespace "${CLUSTER_NAMESPACE}" "${CA_BUNDLE_FILE}"

for namespace in "${NODE_NAMESPACE}" "${CLUSTER_NAMESPACE}"; do
  kubectl get secret "${FLEET_CA_SECRET}" -n "${namespace}" >/dev/null \
    || die "Required Fleet CA Secret ${namespace}/${FLEET_CA_SECRET} was not created."
  kubectl get secret "${FLEET_CA_SECRET}" -n "${namespace}" -o jsonpath="{.data.${FLEET_CA_KEY//./\\.}}" | grep -q . \
    || die "Required CA key ${FLEET_CA_KEY} is missing from ${namespace}/${FLEET_CA_SECRET}."
done

create_fleet_secret() {
  local namespace="$1"

  log "Creating/updating Fleet enrollment Secret in ${namespace}..."
  kubectl create secret generic "${FLEET_SECRET}" \
    --namespace "${namespace}" \
    --from-literal=FLEET_URL="${FLEET_URL}" \
    --from-literal=FLEET_ENROLLMENT_TOKEN="${FLEET_ENROLLMENT_TOKEN}" \
    --dry-run=client -o yaml \
    | kubectl apply -f - >/dev/null
}

create_fleet_secret "${NODE_NAMESPACE}"
create_fleet_secret "${CLUSTER_NAMESPACE}"

ELASTIC_HELM_EXTRA_ARGS=(
  --set "agent.fleet.insecure=${FLEET_INSECURE}"
  --set "agent.fleet.ca.valueFromSecret.name=${FLEET_CA_SECRET}"
  --set "agent.fleet.ca.valueFromSecret.key=${FLEET_CA_KEY}"
)

log "Installing kube-state-metrics ${KSM_CHART_VERSION} in restricted namespace ${METRICS_NAMESPACE}..."
helm_upgrade_install \
  "${KSM_RELEASE}" \
  "${KSM_CHART}" \
  "${METRICS_NAMESPACE}" \
  "${KSM_VALUES}"

log "Installing Fleet-managed Elastic Agent ${ELASTIC_VERSION} per-node DaemonSet..."
helm_upgrade_install \
  "${NODE_RELEASE}" \
  "${ELASTIC_CHART}" \
  "${NODE_NAMESPACE}" \
  "${NODE_VALUES}" \
  "${ELASTIC_HELM_EXTRA_ARGS[@]}"

log "Installing Fleet-managed Elastic Agent ${ELASTIC_VERSION} cluster-wide Deployment..."
helm_upgrade_install \
  "${CLUSTER_RELEASE}" \
  "${ELASTIC_CHART}" \
  "${CLUSTER_NAMESPACE}" \
  "${CLUSTER_VALUES}" \
  "${ELASTIC_HELM_EXTRA_ARGS[@]}"

log "Validating deployed workloads..."
kubectl get daemonset -n "${NODE_NAMESPACE}" -l app.kubernetes.io/name=elastic-agent
kubectl get deployment -n "${CLUSTER_NAMESPACE}" -l app.kubernetes.io/name=elastic-agent
kubectl get deployment,service -n "${METRICS_NAMESPACE}" -l app.kubernetes.io/name=kube-state-metrics

cat <<EOF

Elastic monitoring deployment completed for context ${K8_CONTEXT}.

Pinned versions:
  Elastic Agent: ${ELASTIC_VERSION}
  Elastic Agent chart package: elastic-agent-${ELASTIC_VERSION}.tgz
  kube-state-metrics chart: ${KSM_CHART_VERSION}
  kube-state-metrics image: v2.16.0

Namespaces:
  ${NODE_NAMESPACE}           privileged PSA exception; per-node Elastic Agent DaemonSet
  ${CLUSTER_NAMESPACE}   privileged PSA exception; cluster-wide Elastic Agent Deployment
  ${METRICS_NAMESPACE}          restricted PSA; kube-state-metrics only

Fleet TLS trust:
  Shared CA manifest: yaml/resources/devlocal-opdev-ca-bundle-secret-v1.yaml
  Secret: ${FLEET_CA_SECRET}
  Key: ${FLEET_CA_KEY}
  TLS verification: $([[ "${FLEET_INSECURE}" == "false" ]] && echo enabled || echo disabled)

Fleet policy requirements:
  1. Use the Fleet enrollment token associated with the Kubernetes metrics policy.
  2. Configure kube-state-metrics host as:
       http://kube-state-metrics.${METRICS_NAMESPACE}.svc.cluster.local:8080
  3. Keep node-local kubelet/system datasets assigned to per-node agents.
  4. Keep cluster-wide Kubernetes state datasets assigned to the cluster-wide agent.
  5. Verify enrolled agents and metrics in Kibana/Fleet.

Required KubeHarbor images:
  kubeharbor.dev.kube/elastic/elastic-agent:${ELASTIC_VERSION}
  kubeharbor.dev.kube/kube-state-metrics/kube-state-metrics:v2.16.0

See docs/Elastic-Stack-Monitoring.md for Fleet, TLS, air-gap, CIS, and validation guidance.
EOF