#!/usr/bin/env bash
set -Eeuo pipefail

ELASTIC_VERSION="${ELASTIC_VERSION:-9.4.2}"
KSM_CHART_VERSION="${KSM_CHART_VERSION:-6.1.0}"
KSM_IMAGE_VERSION="${KSM_IMAGE_VERSION:-v2.16.0}"
OUTPUT_DIR="${OUTPUT_DIR:-$(pwd)/elastic-airgap-artifacts-${ELASTIC_VERSION}}"

require_cmd() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "[ERROR] Required command not found: $1" >&2
    exit 1
  }
}

require_cmd git
require_cmd helm

mkdir -p "${OUTPUT_DIR}/helm" "${OUTPUT_DIR}/images"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR}"' EXIT

printf '[INFO] Downloading Elastic Agent source at v%s...\n' "${ELASTIC_VERSION}"
git clone --depth 1 --branch "v${ELASTIC_VERSION}" \
  https://github.com/elastic/elastic-agent.git \
  "${TMP_DIR}/elastic-agent"

CHART_DIR="${TMP_DIR}/elastic-agent/deploy/helm/elastic-agent"

printf '[INFO] Building Elastic Agent Helm dependencies...\n'
helm dependency build "${CHART_DIR}"

printf '[INFO] Packaging Elastic Agent chart as production version %s...\n' "${ELASTIC_VERSION}"
helm package "${CHART_DIR}" \
  --version "${ELASTIC_VERSION}" \
  --app-version "${ELASTIC_VERSION}" \
  --destination "${OUTPUT_DIR}/helm"

printf '[INFO] Downloading kube-state-metrics chart %s...\n' "${KSM_CHART_VERSION}"
helm pull prometheus-community/kube-state-metrics \
  --repo https://prometheus-community.github.io/helm-charts \
  --version "${KSM_CHART_VERSION}" \
  --destination "${OUTPUT_DIR}/helm"

cat >"${OUTPUT_DIR}/images/required-images.txt" <<EOF
docker.elastic.co/elastic-agent/elastic-agent:${ELASTIC_VERSION}
registry.k8s.io/kube-state-metrics/kube-state-metrics:${KSM_IMAGE_VERSION}
EOF

cat >"${OUTPUT_DIR}/README.txt" <<EOF
Elastic monitoring air-gap artifacts for blreopdev-cluster

Elastic Stack version: ${ELASTIC_VERSION}
Elastic Agent chart: elastic-agent-${ELASTIC_VERSION}.tgz
kube-state-metrics chart: kube-state-metrics-${KSM_CHART_VERSION}.tgz

Required images:
  docker.elastic.co/elastic-agent/elastic-agent:${ELASTIC_VERSION}
  registry.k8s.io/kube-state-metrics/kube-state-metrics:${KSM_IMAGE_VERSION}

Recommended KubeHarbor mirrors:
  kubeharbor.dev.kube/elastic/elastic-agent:${ELASTIC_VERSION}
  kubeharbor.dev.kube/kube-state-metrics/kube-state-metrics:${KSM_IMAGE_VERSION}
EOF

printf '\n[INFO] Artifact preparation complete: %s\n' "${OUTPUT_DIR}"
printf '[INFO] Helm packages:\n'
find "${OUTPUT_DIR}/helm" -maxdepth 1 -type f -name '*.tgz' -print | sort
printf '[INFO] Required image list: %s\n' "${OUTPUT_DIR}/images/required-images.txt"
