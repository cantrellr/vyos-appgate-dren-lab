#!/usr/bin/env bash
# shellcheck shell=bash
#
# Shared installer functions for k8s-mystical-mesh.
#
# This file is intended to be sourced by scripts under /scripts. It keeps
# registry handling, namespace hygiene, validation, Helm behavior, and
# restricted-domain NetworkPolicy rendering consistent across the repo.

if [[ -n "${KMM_COMMON_SH_LOADED:-}" ]]; then
  return 0 2>/dev/null || exit 0
fi
export KMM_COMMON_SH_LOADED=1

KMM_COMMON_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export ROOT_DIR="${KMM_ROOT_DIR:-$(cd "${KMM_COMMON_DIR}/../.." && pwd)}"
export BUILD_DIR="${ROOT_DIR}"
export INSTALL_DIR="${BUILD_DIR}/scripts"
export YAML_DIR="${BUILD_DIR}/yaml"
export MONITORING_DIR="${YAML_DIR}/monitoring"
export HELM_CHARTS_DIR="${ROOT_DIR}/helm/charts"
export HELM_PACKAGES_DIR="${ROOT_DIR}/helm/packages"
export MISC_FILES="${ROOT_DIR}/misc"

export REGISTRY_HOST="${REGISTRY_HOST:-kubeharbor.dev.kube}"
export REGISTRY_SECRET="${REGISTRY_SECRET:-regcred-kubeharbor}"
export REGISTRY_SOURCE_NAMESPACE="${REGISTRY_SOURCE_NAMESPACE:-kube-system}"
export HELM_TIMEOUT="${HELM_TIMEOUT:-10m}"
export KUBECTL_TIMEOUT="${KUBECTL_TIMEOUT:-600s}"
export SEGMENT1_NAMESPACE="${SEGMENT1_NAMESPACE:-segment1}"
export SEGMENT1_INGRESS_ALLOWED_CIDRS="${SEGMENT1_INGRESS_ALLOWED_CIDRS:-1.0.0.0/23}"

log() {
  printf '[INFO] %s\n' "$*"
}

warn() {
  printf '[WARN] %s\n' "$*" >&2
}

die() {
  printf '[ERROR] %s\n' "$*" >&2
  exit 1
}

require_cmd() {
  local cmd="$1"
  command -v "${cmd}" >/dev/null 2>&1 || die "Required command not found in PATH: ${cmd}"
}

require_kubectl() {
  require_cmd kubectl
}

require_helm() {
  require_cmd helm
}

require_kubernetes_tools() {
  require_kubectl
  require_helm
}

usage_site_cluster() {
  local script_name="${1:-$0}"
  local example_site="${2:-j64}"
  local example_cluster="${3:-manager}"
  cat >&2 <<USAGE
Usage: ${script_name} <site> <cluster>
Example: ${script_name} ${example_site} ${example_cluster}
USAGE
}

require_site_cluster_args() {
  local argc="$1"
  local script_name="${2:-$0}"
  local example_site="${3:-j64}"
  local example_cluster="${4:-manager}"

  if [[ "${argc}" -lt 2 ]]; then
    usage_site_cluster "${script_name}" "${example_site}" "${example_cluster}"
    exit 2
  fi
}

init_site_cluster() {
  require_site_cluster_args "$#" "$0"
  export SITE="$1"
  export CLUSTER="$2"
  export K8_CONTEXT="${SITE}${CLUSTER}"
}

site_cluster_options_dir() {
  local site="$1"
  local cluster="$2"
  printf '%s/%s/%s-cluster' "${YAML_DIR}" "${site}" "${cluster}"
}

use_context() {
  local context="$1"
  log "Switching kubectl context to ${context}..."
  kubectl config use-context "${context}" >/dev/null
}

validate_context_access() {
  local context="$1"
  kubectl --context "${context}" cluster-info >/dev/null 2>&1 \
    || die "kubectl context ${context} is not reachable. Confirm kubeconfig and cluster API access before running this installer."
}

ensure_namespace() {
  local namespace="$1"

  kubectl get namespace "${namespace}" >/dev/null 2>&1 || kubectl create namespace "${namespace}" >/dev/null
  kubectl label --overwrite namespace "${namespace}" kubernetes.io/metadata.name="${namespace}" >/dev/null
}

label_restricted_namespace() {
  local namespace="$1"
  kubectl label --overwrite namespace "${namespace}" segment1.kmm.dev/restricted="true" >/dev/null
  kubectl label --overwrite namespace "${namespace}" kmm.dev/network-zone="restricted" >/dev/null
}

ensure_registry_secret() {
  local namespace="$1"
  local source_namespace="${2:-${REGISTRY_SOURCE_NAMESPACE}}"
  local secret_name="${3:-${REGISTRY_SECRET}}"

  require_cmd jq

  if ! kubectl get secret "${secret_name}" -n "${source_namespace}" >/dev/null 2>&1; then
    die "Registry secret ${source_namespace}/${secret_name} was not found. Run build/install/core/00-bootstrap-kubeharbor-regcred.sh before installing workloads."
  fi

  if [[ "${namespace}" == "${source_namespace}" ]]; then
    log "Registry secret ${source_namespace}/${secret_name} already exists."
    return 0
  fi

  log "Syncing registry secret ${source_namespace}/${secret_name} into namespace ${namespace}..."
  kubectl get secret "${secret_name}" -n "${source_namespace}" -o json \
    | jq --arg namespace "${namespace}" '
        del(
          .metadata.uid,
          .metadata.resourceVersion,
          .metadata.creationTimestamp,
          .metadata.selfLink,
          .metadata.ownerReferences,
          .metadata.managedFields,
          .metadata.annotations["kubectl.kubernetes.io/last-applied-configuration"]
        )
        | .metadata.namespace = $namespace
      ' \
    | kubectl apply -f - >/dev/null
}

ensure_file() {
  local path="$1"
  [[ -f "${path}" ]] || die "Required file not found: ${path}"
}

ensure_dir() {
  local path="$1"
  [[ -d "${path}" ]] || die "Required directory not found: ${path}"
}

ensure_chart_package() {
  local chart_path="$1"
  ensure_file "${chart_path}"
}

validate_yaml_file() {
  local file="$1"
  ensure_file "${file}"

  if command -v yq >/dev/null 2>&1; then
    yq e '.' "${file}" >/dev/null || die "YAML validation failed: ${file}"
  elif command -v python3 >/dev/null 2>&1; then
    python3 - "${file}" <<'PY'
import sys
from pathlib import Path
try:
    import yaml
except Exception:
    sys.exit(0)
for p in sys.argv[1:]:
    with Path(p).open('r', encoding='utf-8') as fh:
        list(yaml.safe_load_all(fh))
PY
  fi
}

validate_yaml_dir() {
  local dir="$1"
  ensure_dir "${dir}"
  local file=""

  while IFS= read -r -d '' file; do
    validate_yaml_file "${file}"
  done < <(find "${dir}" -type f \( -name '*.yaml' -o -name '*.yml' \) -print0)
}

helm_upgrade_install() {
  local release="$1"
  local chart_path="$2"
  local namespace="$3"
  local values_file="$4"
  shift 4

  ensure_chart_package "${chart_path}"
  validate_yaml_file "${values_file}"

  log "Installing/upgrading Helm release ${release} in namespace ${namespace}..."
  helm upgrade --install "${release}" "${chart_path}" \
    --namespace "${namespace}" \
    --values "${values_file}" \
    --atomic \
    --wait \
    --timeout "${HELM_TIMEOUT}" \
    "$@"
}

helm_release_exists() {
  local release="$1"
  local namespace="$2"
  helm status "${release}" --namespace "${namespace}" >/dev/null 2>&1
}

apply_file() {
  local file="$1"
  validate_yaml_file "${file}"
  kubectl apply -f "${file}"
}

apply_file_in_namespace() {
  local namespace="$1"
  local file="$2"
  validate_yaml_file "${file}"
  kubectl apply -n "${namespace}" -f "${file}"
}

apply_dir() {
  local dir="$1"
  validate_yaml_dir "${dir}"
  kubectl apply -f "${dir}"
}

apply_dir_in_namespace() {
  local namespace="$1"
  local dir="$2"
  validate_yaml_dir "${dir}"
  kubectl apply -n "${namespace}" -f "${dir}"
}

wait_for_deployment_available() {
  local namespace="$1"
  local deployment="$2"
  local timeout="${3:-${KUBECTL_TIMEOUT}}"
  kubectl wait --for=condition=available --timeout="${timeout}" deployment/"${deployment}" --namespace "${namespace}"
}

wait_for_statefulset_rollout() {
  local namespace="$1"
  local statefulset="$2"
  local timeout="${3:-${KUBECTL_TIMEOUT}}"
  kubectl rollout status statefulset/"${statefulset}" --namespace "${namespace}" --timeout="${timeout}"
}

wait_for_deployment_rollout() {
  local namespace="$1"
  local deployment="$2"
  local timeout="${3:-${KUBECTL_TIMEOUT}}"
  kubectl rollout status deployment/"${deployment}" --namespace "${namespace}" --timeout="${timeout}"
}

require_crd() {
  local crd="$1"
  kubectl get crd "${crd}" >/dev/null 2>&1 || die "Required CRD is missing: ${crd}"
}

wait_for_crd() {
  local crd="$1"
  local timeout="${2:-${KUBECTL_TIMEOUT}}"
  kubectl wait --for=create "crd/${crd}" --timeout="${timeout}" >/dev/null \
    || die "Timed out waiting for CRD: ${crd}"
}

ensure_prometheus_operator_crds() {
  local timeout="${1:-${KUBECTL_TIMEOUT}}"
  wait_for_crd prometheusrules.monitoring.coreos.com "${timeout}"
  wait_for_crd servicemonitors.monitoring.coreos.com "${timeout}"
  wait_for_crd podmonitors.monitoring.coreos.com "${timeout}"
}

render_segment1_network_policies() {
  local namespace="${1:-${SEGMENT1_NAMESPACE}}"
  local output_file="$2"
  local kube_api_ip=""

  kube_api_ip="$(kubectl get service kubernetes -n default -o jsonpath='{.spec.clusterIP}')"
  [[ -n "${kube_api_ip}" ]] || die "Unable to detect kubernetes.default service ClusterIP for NetworkPolicy API egress."

  cat >"${output_file}" <<YAML
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-default-deny
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector: {}
  policyTypes:
    - Ingress
    - Egress
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-dns-and-kubernetes-api
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector: {}
  policyTypes:
    - Egress
  egress:
    - to:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: kube-system
          podSelector:
            matchExpressions:
              - key: k8s-app
                operator: In
                values:
                  - kube-dns
                  - rke2-coredns-rke2-coredns
      ports:
        - protocol: UDP
          port: 53
        - protocol: TCP
          port: 53
    - to:
        - ipBlock:
            cidr: ${kube_api_ip}/32
      ports:
        - protocol: TCP
          port: 443
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-approved-ingress-to-envoy
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes:
    - Ingress
  ingress:
    - from:
YAML

  local cidr=""
  IFS=',' read -ra _segment1_cidrs <<<"${SEGMENT1_INGRESS_ALLOWED_CIDRS}"
  for cidr in "${_segment1_cidrs[@]}"; do
    cidr="$(printf '%s' "${cidr}" | xargs)"
    [[ -z "${cidr}" ]] && continue
    cat >>"${output_file}" <<YAML
        - ipBlock:
            cidr: ${cidr}
YAML
  done

  cat >>"${output_file}" <<YAML
      ports:
        - protocol: TCP
          port: 80
        - protocol: TCP
          port: 443
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-envoy-to-contour-xds
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: contour
  policyTypes:
    - Ingress
  ingress:
    - from:
        - podSelector:
            matchLabels:
              app.kubernetes.io/component: envoy
      ports:
        - protocol: TCP
          port: 8001
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-envoy-egress-to-contour-xds
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes:
    - Egress
  egress:
    - to:
        - podSelector:
            matchLabels:
              app.kubernetes.io/component: contour
      ports:
        - protocol: TCP
          port: 8001
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-monitoring-scrapes
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector:
    matchExpressions:
      - key: app.kubernetes.io/component
        operator: In
        values:
          - contour
          - envoy
  policyTypes:
    - Ingress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              kubernetes.io/metadata.name: monitoring
      ports:
        - protocol: TCP
          port: 8000
        - protocol: TCP
          port: 8002
        - protocol: TCP
          port: 9001
---
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: segment1-allow-envoy-to-approved-backends
  namespace: ${namespace}
  labels:
    app.kubernetes.io/part-of: k8s-mystical-mesh
    kmm.dev/security-zone: restricted
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/component: envoy
  policyTypes:
    - Egress
  egress:
    - to:
        - namespaceSelector:
            matchLabels:
              segment1.ingress/allow-backend: "true"
      ports:
        - protocol: TCP
          port: 80
        - protocol: TCP
          port: 443
        - protocol: TCP
          port: 8080
        - protocol: TCP
          port: 8443
        - protocol: TCP
          port: 9000
YAML
}

apply_segment1_network_policies() {
  local namespace="${1:-${SEGMENT1_NAMESPACE}}"
  local tmp_file=""

  tmp_file="$(mktemp)"
  render_segment1_network_policies "${namespace}" "${tmp_file}"
  validate_yaml_file "${tmp_file}"
  log "Applying restricted NetworkPolicy package for namespace ${namespace}..."
  kubectl apply -f "${tmp_file}"
  rm -f "${tmp_file}"
}
