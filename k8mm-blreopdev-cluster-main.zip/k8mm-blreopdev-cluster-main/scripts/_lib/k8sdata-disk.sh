#!/usr/bin/env bash
set -euo pipefail

# Detect one unused whole disk, format it as XFS, and persistently mount it at /mnt/k8sdata.

MOUNT_POINT="${MOUNT_POINT:-/mnt/k8sdata}"
FSTAB="/etc/fstab"

[[ $EUID -eq 0 ]] || { echo "ERROR: Run as root." >&2; exit 1; }

for cmd in lsblk mkfs.xfs blkid findmnt mount systemctl awk; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "ERROR: Required command not found: $cmd" >&2
    [[ "$cmd" == "mkfs.xfs" ]] && echo "Install it with: apt install -y xfsprogs" >&2
    exit 1
  }
done

# Idempotent exit when the target is already mounted.
if findmnt --mountpoint "$MOUNT_POINT" >/dev/null 2>&1; then
  echo "Already mounted:"
  findmnt "$MOUNT_POINT"
  exit 0
fi

# If an fstab entry already exists, validate and mount it instead of formatting another disk.
if awk -v mp="$MOUNT_POINT" '$1 !~ /^#/ && $2 == mp { found=1 } END { exit !found }' "$FSTAB"; then
  systemctl daemon-reload
  findmnt --verify --verbose
  mount -a
  findmnt --mountpoint "$MOUNT_POINT"
  exit 0
fi

# Find raw whole disks only: no child devices, filesystem, or detectable disk signature.
mapfile -t DISKS < <(
  while read -r disk type; do
    [[ "$type" == "disk" ]] || continue
    [[ $(lsblk -nrpo NAME "$disk" | wc -l) -eq 1 ]] || continue
    [[ -z $(lsblk -dnpo FSTYPE "$disk") ]] || continue
    blkid "$disk" >/dev/null 2>&1 && continue
    printf '%s\n' "$disk"
  done < <(lsblk -dnpo NAME,TYPE)
)

if [[ ${#DISKS[@]} -eq 0 ]]; then
  echo "ERROR: No unused whole disk detected." >&2
  exit 1
elif [[ ${#DISKS[@]} -gt 1 ]]; then
  echo "ERROR: Multiple unused whole disks detected; refusing to guess:" >&2
  printf '  %s\n' "${DISKS[@]}" >&2
  exit 1
fi

DISK="${DISKS[0]}"
echo "Using disk: $DISK"

mkfs.xfs -f "$DISK"
mkdir -p "$MOUNT_POINT"

UUID=$(blkid -s UUID -o value "$DISK")
[[ -n "$UUID" ]] || { echo "ERROR: Unable to determine filesystem UUID." >&2; exit 1; }

cp -a "$FSTAB" "${FSTAB}.bak.$(date -u +%Y%m%dT%H%M%SZ)"
printf 'UUID=%s %s xfs defaults,nofail 0 0\n' "$UUID" "$MOUNT_POINT" >> "$FSTAB"

systemctl daemon-reload
findmnt --verify --verbose
mount -a

if ! findmnt --mountpoint "$MOUNT_POINT" >/dev/null 2>&1; then
  echo "ERROR: $MOUNT_POINT is not mounted after updating $FSTAB." >&2
  exit 1
fi

echo "Success:"
findmnt "$MOUNT_POINT"
df -hT "$MOUNT_POINT"
