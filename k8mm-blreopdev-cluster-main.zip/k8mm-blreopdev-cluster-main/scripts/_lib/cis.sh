#!/usr/bin/env bash
# shellcheck shell=bash
#
# CIS/Pod Security Admission helpers for K8MM-BLREOPDEV-Cluster installers.
#
# This library is intentionally separate from common.sh so CIS policy remains an
# explicit workload concern. Callers must source common.sh first.

if [[ -n "${KMM_CIS_SH_LOADED:-}" ]]; then
  return 0 2>/dev/null || exit 0
fi
export KMM_CIS_SH_LOADED=1

if ! declare -F ensure_namespace >/dev/null 2>&1; then
  printf '[ERROR] cis.sh requires scripts/_lib/common.sh to be sourced first.\n' >&2
  return 1 2>/dev/null || exit 1
fi

validate_pod_security_level() {
  case "${1:-}" in
    restricted|baseline|privileged) return 0 ;;
    *) die "Unsupported Pod Security Admission level '${1:-<empty>}'. Expected restricted, baseline, or privileged." ;;
  esac
}

configure_namespace_pod_security() {
  local namespace="$1"
  local level="$2"

  validate_pod_security_level "${level}"

  log "Applying Pod Security Admission profile '${level}' to namespace ${namespace}..."
  kubectl label --overwrite namespace "${namespace}" \
    "pod-security.kubernetes.io/enforce=${level}" \
    "pod-security.kubernetes.io/enforce-version=latest" \
    "pod-security.kubernetes.io/audit=${level}" \
    "pod-security.kubernetes.io/audit-version=latest" \
    "pod-security.kubernetes.io/warn=${level}" \
    "pod-security.kubernetes.io/warn-version=latest" \
    "k8mm.dev/cis-managed=true" \
    "k8mm.dev/pod-security-profile=${level}" >/dev/null

  if [[ "${level}" == "privileged" ]]; then
    kubectl label --overwrite namespace "${namespace}" \
      "k8mm.dev/cis-psa-exception=true" >/dev/null
  else
    kubectl label namespace "${namespace}" \
      "k8mm.dev/cis-psa-exception-" >/dev/null 2>&1 || true
  fi
}

harden_default_service_account() {
  local namespace="$1"
  local attempt=""

  for attempt in $(seq 1 30); do
    if kubectl -n "${namespace}" get serviceaccount default >/dev/null 2>&1; then
      log "Disabling automatic API token mounting on ${namespace}/default ServiceAccount..."
      kubectl -n "${namespace}" patch serviceaccount default \
        --type merge \
        -p '{"automountServiceAccountToken":false}' >/dev/null
      return 0
    fi
    sleep 1
  done

  die "Timed out waiting for ${namespace}/default ServiceAccount so CIS token hardening could be applied."
}

ensure_cis_namespace() {
  local namespace="$1"
  local level="${3:-${2:-restricted}}"

  # Preserve compatibility with existing three-argument callers whose middle
  # boolean argument is no longer used by the namespace helper.
  if [[ "${level}" == "true" || "${level}" == "false" ]]; then
    level="restricted"
  fi

  ensure_namespace "${namespace}"
  configure_namespace_pod_security "${namespace}" "${level}"
  harden_default_service_account "${namespace}"
}
