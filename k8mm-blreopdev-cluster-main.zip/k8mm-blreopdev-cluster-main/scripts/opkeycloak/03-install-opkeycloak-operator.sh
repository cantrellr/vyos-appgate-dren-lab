#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"
NAMESPACE="opkeycloak"
RELEASE="opkeycloak-operator"

RESOURCE_DIR="${YAML_DIR}/opkeycloak/resources"
CRDS_FILE="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-crds-v1.yaml"
OPERATOR_FILE="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-operator-v1.yaml"
ROOT_CA_FILE="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-root-ca-certificates.yaml"
REALMIMPORTS_FILE="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-realmimports-v1.yaml"
CIS_RENDERER="${ROOT_DIR}/scripts/security/render-keycloak-operator-cis.py"

require_kubectl
require_cmd jq
require_cmd python3
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"

ensure_dir "${RESOURCE_DIR}"
ensure_file "${CRDS_FILE}"
ensure_file "${OPERATOR_FILE}"
ensure_file "${ROOT_CA_FILE}"
ensure_file "${REALMIMPORTS_FILE}"
ensure_file "${CIS_RENDERER}"

log "Applying Keycloak support resources..."
apply_file_in_namespace "${NAMESPACE}" "${ROOT_CA_FILE}"
apply_file "${CRDS_FILE}"
apply_file_in_namespace "${NAMESPACE}" "${REALMIMPORTS_FILE}"

log "Rendering Keycloak operator manifest with restricted-PSA security contexts..."
rendered_operator="$(mktemp)"
trap 'rm -f "${rendered_operator:-}"' EXIT
python3 "${CIS_RENDERER}" "${OPERATOR_FILE}" >"${rendered_operator}"
validate_yaml_file "${rendered_operator}"

log "Applying CIS-hardened Keycloak operator manifests..."
apply_file_in_namespace "${NAMESPACE}" "${rendered_operator}"
wait_for_deployment_rollout "${NAMESPACE}" opkeycloak-operator "${KUBECTL_TIMEOUT}"

log "${RELEASE} and opkeycloak resources installed with restricted Pod Security Admission enforcement."
