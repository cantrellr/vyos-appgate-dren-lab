#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"

NAMESPACE="${NAMESPACE:-oppostgres}"
RELEASE="${CNPG_CLUSTER_RELEASE:-oppostgres}"
RESOURCE_DIR="${YAML_DIR}/oppostgres/resources"

CHART="cluster-0.7.0.tgz"
CHART_PATH="${CNPG_CLUSTER_CHART:-${HELM_PACKAGES_DIR}/${CHART}}"
VALUES="${YAML_DIR}/oppostgres/values/oppostgres-cnpg-keycloak-db-${CLUSTER}-values-v1.yaml"
PGBOUNCER_PDB="${RESOURCE_DIR}/oppostgres-${CLUSTER}-pgbouncer-pdb-v1.yaml"

CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"
POSTGRES_DATABASE="${POSTGRES_DATABASE:-opkeycloak}"

require_kubernetes_tools
require_cmd jq
require_cmd openssl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

log "Ensuring required folders and files..."
ensure_dir "${RESOURCE_DIR}"
ensure_file "${VALUES}"
ensure_file "${PGBOUNCER_PDB}"
ensure_file "${CHART_PATH}"

log "Creating and CIS-hardening namespace ${NAMESPACE}..."
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"

#log "Preparing runtime-generated PostgreSQL and Keycloak Secrets..."
#"${SCRIPT_DIR}/00-prepare-opkeycloak-runtime-secrets.sh" "${SITE}" "${CLUSTER}"

log "Installing the three-instance CloudNativePG cluster and three-instance PgBouncer access tier..."
helm_upgrade_install \
  "${RELEASE}" \
  "${CHART_PATH}" \
  "${NAMESPACE}" \
  "${VALUES}"

log "Applying PgBouncer PodDisruptionBudget..."
apply_file_in_namespace "${NAMESPACE}" "${PGBOUNCER_PDB}"

kubectl -n "${NAMESPACE}" wait "cluster/${CLUSTER_NAME}" --for=condition=Ready --timeout=15m
kubectl -n "${NAMESPACE}" wait "deployment/${POOLER_NAME}" --for=condition=Available --timeout=5m

kubectl -n "${NAMESPACE}" get cluster "${CLUSTER_NAME}"
kubectl -n "${NAMESPACE}" get pooler "${POOLER_NAME}"
kubectl -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME}" -o wide
kubectl -n "${NAMESPACE}" get pods -l "app.kubernetes.io/name=${CLUSTER_NAME}-pgbouncer" -o wide
kubectl -n "${NAMESPACE}" get svc "${POOLER_NAME}"

cat <<SUMMARY
Keycloak CNPG PostgreSQL HA install complete.
PostgreSQL namespace: ${NAMESPACE}
PostgreSQL Helm release: ${RELEASE}
PostgreSQL database: ${POSTGRES_DATABASE}
Application endpoint (PgBouncer): ${POOLER_NAME}.${NAMESPACE}.svc.cluster.local:5432
Direct CNPG RW service (internal backend only): ${CLUSTER_NAME}-rw.${NAMESPACE}.svc.cluster.local:5432
Pod Security Admission: restricted
SUMMARY

log "${RELEASE} installed with PgBouncer as the application database access tier and restricted PSA enforcement."
