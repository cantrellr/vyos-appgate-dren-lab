#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

POSTGRES_NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
KEYCLOAK_NAMESPACE="${KEYCLOAK_NAMESPACE:-opkeycloak}"
RELEASE="${CNPG_CLUSTER_RELEASE:-oppostgres}"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"
APP_SECRET="${POSTGRES_APP_SECRET:-opkeycloak-postgresql-credentials}"
BOOTSTRAP_ADMIN_SECRET="${KEYCLOAK_BOOTSTRAP_ADMIN_SECRET:-opkeycloak-bootstrap-admin}"
DELETE_SECRETS="${DELETE_SECRETS:-false}"
DELETE_POLICIES="${DELETE_POLICIES:-true}"

require_kubectl
require_helm

if [[ "${DELETE_POLICIES}" == "true" ]]; then
  "${SCRIPT_DIR}/04-install-opkeycloak-networkpolicies.sh" delete || true
fi

kubectl -n "${POSTGRES_NAMESPACE}" delete pod pg-test-client --ignore-not-found=true >/dev/null 2>&1 || true
kubectl -n "${POSTGRES_NAMESPACE}" delete poddisruptionbudget "${POOLER_NAME}" --ignore-not-found=true || true
helm -n "${POSTGRES_NAMESPACE}" uninstall "${RELEASE}" || true

if [[ "${DELETE_SECRETS}" == "true" ]]; then
  kubectl -n "${POSTGRES_NAMESPACE}" delete secret "${APP_SECRET}" --ignore-not-found=true
  kubectl -n "${KEYCLOAK_NAMESPACE}" delete secret "${APP_SECRET}" --ignore-not-found=true
  kubectl -n "${KEYCLOAK_NAMESPACE}" delete secret "${BOOTSTRAP_ADMIN_SECRET}" --ignore-not-found=true
fi

cat <<SUMMARY
CNPG Keycloak PostgreSQL release removed.
PostgreSQL namespace: ${POSTGRES_NAMESPACE}
PostgreSQL release: ${RELEASE}
CNPG cluster: ${CLUSTER_NAME}
PgBouncer pooler: ${POOLER_NAME}
Secret deletion: ${DELETE_SECRETS}
NetworkPolicy deletion: ${DELETE_POLICIES}
PVCs were intentionally left in place. Review retained PVCs for cluster ${CLUSTER_NAME} before any manual storage cleanup.
SUMMARY
