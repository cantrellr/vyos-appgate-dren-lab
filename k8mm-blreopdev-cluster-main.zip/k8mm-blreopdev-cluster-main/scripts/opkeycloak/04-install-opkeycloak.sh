#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"
NAMESPACE="${KEYCLOAK_NAMESPACE:-opkeycloak}"
POSTGRES_NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
RELEASE="opkeycloak"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"

RESOURCE_DIR="${YAML_DIR}/opkeycloak/resources"
CA_ROOT_SECRET="${YAML_DIR}/resources/devlocal-${CLUSTER}-ca-bundle-secret-v1.yaml"

ROOT_CA_FILE="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-root-ca-certificates.yaml"
RESOURCES1="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-resources-v1.yaml"
KEYCLOAK_CR="${RESOURCE_DIR}/opkeycloak-${CLUSTER}-cr-v1.yaml"

MISC_KEYTAB_FILE="devkeycloak-${CLUSTER}.keytab"
MISC_PROVIDER_FILE="keycloak-azure-upn-linker-1.1.0.jar"

require_kubectl
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"

#log "Preparing and synchronizing runtime-generated Keycloak/PostgreSQL Secrets..."
#"${SCRIPT_DIR}/00-prepare-opkeycloak-runtime-secrets.sh" "${SITE}" "${CLUSTER}"

kubectl -n "${POSTGRES_NAMESPACE}" get service "${POOLER_NAME}" >/dev/null 2>&1 \
  || die "Required PgBouncer service ${POSTGRES_NAMESPACE}/${POOLER_NAME} was not found. Install OPPostgreSQL before OPKeycloak."

log "Applying Keycloak trust and support resources..."
apply_file_in_namespace "${NAMESPACE}" "${CA_ROOT_SECRET}" || true
apply_file_in_namespace "${NAMESPACE}" "${ROOT_CA_FILE}" || true

ensure_file "${MISC_FILES}/${MISC_KEYTAB_FILE}"
kubectl -n "${NAMESPACE}" create secret generic opkeycloak-keytab \
  --from-file=opkeycloak.keytab="${MISC_FILES}/${MISC_KEYTAB_FILE}" \
  --dry-run=client -o yaml | kubectl apply -f -

ensure_file "${MISC_FILES}/${MISC_PROVIDER_FILE}"
kubectl -n "${NAMESPACE}" create secret generic opkeycloak-provider \
  --from-file=keycloak-azure-upn-linker-1.1.0.jar="${MISC_FILES}/${MISC_PROVIDER_FILE}" \
  --dry-run=client -o yaml | kubectl apply -f -

log "Applying Keycloak support resources and custom resource..."
apply_file_in_namespace "${NAMESPACE}" "${RESOURCES1}"
apply_file_in_namespace "${NAMESPACE}" "${KEYCLOAK_CR}"

log "Waiting for ${RELEASE}-0 pod to become Ready..."
until kubectl -n "${NAMESPACE}" get pod "${RELEASE}-0" >/dev/null 2>&1; do
  sleep 5
done
kubectl -n "${NAMESPACE}" wait --for=condition=Ready --timeout="${KUBECTL_TIMEOUT}" "pod/${RELEASE}-0"

log "${RELEASE} installed with restricted PSA enforcement and configured to use PgBouncer at ${POOLER_NAME}.${POSTGRES_NAMESPACE}.svc.cluster.local:5432."
