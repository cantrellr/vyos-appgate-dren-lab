#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"

NAMESPACE="oppostgres"
RELEASE="oppostgres-operator"
CHART="cloudnative-pg-0.29.0.tgz"
VALUES="${YAML_DIR}/oppostgres/values/cnpg-operator-values.yaml"
CHART_PATH="${CNPG_CHART:-${HELM_PACKAGES_DIR}/${CHART}}"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${NAMESPACE}" true restricted
ensure_registry_secret "${NAMESPACE}"

helm_upgrade_install "${RELEASE}" \
  "${CHART_PATH}" \
  "${NAMESPACE}" \
  "${VALUES}"

wait_for_deployment_rollout "${NAMESPACE}" "${RELEASE}" "${KUBECTL_TIMEOUT}"

log "${RELEASE} installed in namespace ${NAMESPACE} with restricted Pod Security Admission enforcement."
