#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"

ACTION="${1:-apply}"
POLICY_DIR="${YAML_DIR}/opkeycloak/networkpolicies"

usage() {
  cat <<USAGE
Usage: $0 [apply|delete]

Applies or deletes the OPKeycloak, PgBouncer, and OPPostgreSQL NetworkPolicy package.

Policy directory:
  ${POLICY_DIR}

Scope:
  - opkeycloak Keycloak pods
  - oppostgres PgBouncer pods for oppostgres-opkeycloak-db-pooler-rw
  - oppostgres CloudNativePG pods for oppostgres-opkeycloak-db
USAGE
}

render_runtime_networkpolicies() {
  local output_file="$1"
  local kube_api_ip=""

  kube_api_ip="$(kubectl get service kubernetes -n default -o jsonpath='{.spec.clusterIP}')"
  [[ -n "${kube_api_ip}" ]] || die "Unable to detect kubernetes.default service ClusterIP for NetworkPolicy API egress."

  cat >"${output_file}" <<YAML
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: oppostgres-allow-kubernetes-api-egress
  namespace: oppostgres
  labels:
    app.kubernetes.io/part-of: opkeycloak
    app.kubernetes.io/component: networkpolicy
    blreopdev.dev.kube/policy-scope: postgresql
spec:
  podSelector:
    matchLabels:
      cnpg.io/cluster: oppostgres-opkeycloak-db
  policyTypes:
    - Egress
  egress:
    - to:
        - ipBlock:
            cidr: ${kube_api_ip}/32
      ports:
        - protocol: TCP
          port: 443
YAML
}

if [[ "${ACTION}" != "apply" && "${ACTION}" != "delete" ]]; then
  usage
  exit 2
fi

require_kubectl
validate_yaml_dir "${POLICY_DIR}"

log "Action: ${ACTION}"
log "Policy directory: ${POLICY_DIR}"

if [[ "${ACTION}" == "apply" ]]; then
  runtime_policy="$(mktemp)"
  trap 'rm -f "${runtime_policy:-}"' EXIT

  log "Rendering runtime NetworkPolicy rules that require cluster-discovered values..."
  render_runtime_networkpolicies "${runtime_policy}"
  validate_yaml_file "${runtime_policy}"

  log "Applying OPKeycloak/PgBouncer/OPPostgreSQL static NetworkPolicies..."
  kubectl apply -f "${POLICY_DIR}"

  log "Applying runtime OPPostgreSQL Kubernetes API egress NetworkPolicy..."
  kubectl apply -f "${runtime_policy}"

  log "Applied OPKeycloak, PgBouncer, and OPPostgreSQL NetworkPolicies."
else
  log "Deleting OPKeycloak/PgBouncer/OPPostgreSQL static NetworkPolicies..."
  kubectl delete -f "${POLICY_DIR}" --ignore-not-found

  log "Deleting runtime OPPostgreSQL Kubernetes API egress NetworkPolicy..."
  kubectl delete networkpolicy oppostgres-allow-kubernetes-api-egress \
    -n oppostgres \
    --ignore-not-found

  log "Deleted OPKeycloak, PgBouncer, and OPPostgreSQL NetworkPolicies."
fi
