#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"

POSTGRES_NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
KEYCLOAK_NAMESPACE="${KEYCLOAK_NAMESPACE:-opkeycloak}"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
POOLER_NAME="${CNPG_POOLER_NAME:-${CLUSTER_NAME}-pooler-rw}"
APP_SECRET="${POSTGRES_APP_SECRET:-opkeycloak-postgresql-credentials}"
EXPECTED_POSTGRES_INSTANCES="${EXPECTED_POSTGRES_INSTANCES:-3}"
EXPECTED_POOLER_INSTANCES="${EXPECTED_POOLER_INSTANCES:-3}"
REGISTRY_HOST="${REGISTRY_HOST:-kubeharbor.dev.kube}"
REGISTRY_SECRET="${REGISTRY_SECRET:-regcred-kubeharbor}"
EXPECTED_POOLER_HOST="${POOLER_NAME}.${POSTGRES_NAMESPACE}.svc.cluster.local"

require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

fail() {
  printf '[FAIL] %s\n' "$*" >&2
  exit 1
}

pass() {
  printf '[PASS] %s\n' "$*"
}

echo "== Cluster status =="
kubectl -n "${POSTGRES_NAMESPACE}" get cluster "${CLUSTER_NAME}" -o wide

ready_instances="$(kubectl -n "${POSTGRES_NAMESPACE}" get cluster "${CLUSTER_NAME}" -o jsonpath='{.status.readyInstances}')"
[[ "${ready_instances:-0}" == "${EXPECTED_POSTGRES_INSTANCES}" ]] \
  || fail "Expected ${EXPECTED_POSTGRES_INSTANCES} ready PostgreSQL instances, found ${ready_instances:-0}."
pass "All ${EXPECTED_POSTGRES_INSTANCES} PostgreSQL instances are ready."

echo
echo "== Current primary =="
kubectl -n "${POSTGRES_NAMESPACE}" get cluster "${CLUSTER_NAME}" -o jsonpath='{.status.currentPrimary}{"\n"}'

echo
echo "== PostgreSQL pods =="
kubectl -n "${POSTGRES_NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME}" -o wide

echo
echo "== PgBouncer pooler =="
kubectl -n "${POSTGRES_NAMESPACE}" get pooler "${POOLER_NAME}"
kubectl -n "${POSTGRES_NAMESPACE}" get deployment "${POOLER_NAME}" -o wide

available_poolers="$(kubectl -n "${POSTGRES_NAMESPACE}" get deployment "${POOLER_NAME}" -o jsonpath='{.status.availableReplicas}')"
[[ "${available_poolers:-0}" == "${EXPECTED_POOLER_INSTANCES}" ]] \
  || fail "Expected ${EXPECTED_POOLER_INSTANCES} available PgBouncer instances, found ${available_poolers:-0}."
pass "All ${EXPECTED_POOLER_INSTANCES} PgBouncer instances are available."

echo
echo "== Services =="
kubectl -n "${POSTGRES_NAMESPACE}" get svc "${POOLER_NAME}" "${CLUSTER_NAME}-rw"

echo
echo "== PVCs =="
kubectl -n "${POSTGRES_NAMESPACE}" get pvc | grep "${CLUSTER_NAME}" || true

echo
echo "== Runtime credential consistency =="
postgres_user_data="$(kubectl -n "${POSTGRES_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.username}')"
postgres_password_data="$(kubectl -n "${POSTGRES_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.password}')"
keycloak_user_data="$(kubectl -n "${KEYCLOAK_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.username}')"
keycloak_password_data="$(kubectl -n "${KEYCLOAK_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.password}')"

[[ -n "${postgres_user_data}" && -n "${postgres_password_data}" ]] \
  || fail "PostgreSQL application Secret is missing required data."
[[ "${postgres_user_data}" == "${keycloak_user_data}" ]] \
  || fail "PostgreSQL and Keycloak username data differ."
[[ "${postgres_password_data}" == "${keycloak_password_data}" ]] \
  || fail "PostgreSQL and Keycloak password data differ."

unset postgres_user_data postgres_password_data keycloak_user_data keycloak_password_data
pass "PostgreSQL and Keycloak namespace credential Secrets match."

keycloak_db_host="$(kubectl -n "${KEYCLOAK_NAMESPACE}" get keycloak opkeycloak -o jsonpath='{.spec.db.host}')" \
  || fail "Keycloak CR opkeycloak not found in namespace ${KEYCLOAK_NAMESPACE}."
[[ "${keycloak_db_host}" == "${EXPECTED_POOLER_HOST}" ]] \
  || fail "Keycloak database host is ${keycloak_db_host}; expected ${EXPECTED_POOLER_HOST}."
pass "Keycloak is configured to use the PgBouncer service."

echo
echo "== PgBouncer connection test =="
kubectl -n "${POSTGRES_NAMESPACE}" delete pod pg-test-client --ignore-not-found=true >/dev/null 2>&1 || true
kubectl apply -f - <<MANIFEST
apiVersion: v1
kind: Pod
metadata:
  name: pg-test-client
  namespace: ${POSTGRES_NAMESPACE}
  labels:
    app.kubernetes.io/name: pg-test-client
    app.kubernetes.io/component: database-test
    app.kubernetes.io/part-of: k8s-blreopdev-cluster
spec:
  restartPolicy: Never
  automountServiceAccountToken: false
  securityContext:
    runAsNonRoot: true
    seccompProfile:
      type: RuntimeDefault
  imagePullSecrets:
    - name: ${REGISTRY_SECRET}
  containers:
    - name: psql
      image: ${REGISTRY_HOST}/library/postgres:17
      imagePullPolicy: IfNotPresent
      securityContext:
        allowPrivilegeEscalation: false
        runAsNonRoot: true
        capabilities:
          drop:
            - ALL
      command:
        - sleep
        - "3600"
      env:
        - name: PGHOST
          value: ${EXPECTED_POOLER_HOST}
        - name: PGPORT
          value: "5432"
        - name: PGDATABASE
          value: opkeycloak
        - name: PGUSER
          valueFrom:
            secretKeyRef:
              name: ${APP_SECRET}
              key: username
        - name: PGPASSWORD
          valueFrom:
            secretKeyRef:
              name: ${APP_SECRET}
              key: password
MANIFEST
kubectl -n "${POSTGRES_NAMESPACE}" wait pod/pg-test-client --for=condition=Ready --timeout=2m
kubectl -n "${POSTGRES_NAMESPACE}" exec pg-test-client -- \
  psql -v ON_ERROR_STOP=1 \
    -c 'select now(), current_database(), current_user;' >/dev/null
pass "Authenticated SQL query through ${EXPECTED_POOLER_HOST}:5432 succeeded."

cat <<SUMMARY

CNPG HA verification complete.
PostgreSQL instances: ${EXPECTED_POSTGRES_INSTANCES}
PgBouncer instances: ${EXPECTED_POOLER_INSTANCES}
Application endpoint: ${EXPECTED_POOLER_HOST}:5432
Credential parity: verified without printing secret values
SQL authentication through PgBouncer: verified
PSA compatibility: pg-test-client uses restricted-compatible security settings
SUMMARY
