#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/cis.sh
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"
NAMESPACE="${LONGHORN_NAMESPACE:-longhorn-system}"
RELEASE="${LONGHORN_RELEASE:-${CLUSTER}-longhorn}"
CHART="${LONGHORN_CHART:-longhorn-1.12.0.tgz}"
VALUES="longhorn-${CLUSTER}-values-v1.yaml"
RESOURCES1="longhorn-${CLUSTER}-resources-v2.yaml"
RESOURCES2="longhorn-${CLUSTER}-snapshotclass-v1.yaml"
RESOURCES3="longhorn-${CLUSTER}-storageclasses-v1.yaml"
DATA_PATH="${LONGHORN_DATA_PATH:-/mnt/k8sdata}"
DEFAULT_REPLICA_COUNT="${LONGHORN_DEFAULT_REPLICA_COUNT:-3}"
DEFAULT_FS_TYPE="${LONGHORN_DEFAULT_FS_TYPE:-xfs}"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

log "Ensure folders and files..."
ensure_file "${YAML_DIR}/values/${VALUES}"
ensure_file "${YAML_DIR}/resources/${RESOURCES1}"
ensure_file "${YAML_DIR}/resources/${RESOURCES2}"
ensure_file "${YAML_DIR}/resources/${RESOURCES3}"
ensure_chart_package "${HELM_PACKAGES_DIR}/${CHART}"

log "Validate folders and files..."
validate_yaml_file "${YAML_DIR}/values/${VALUES}"
validate_yaml_file "${YAML_DIR}/resources/${RESOURCES1}"
validate_yaml_file "${YAML_DIR}/resources/${RESOURCES2}"
validate_yaml_file "${YAML_DIR}/resources/${RESOURCES3}"

log "Creating namespace ${NAMESPACE} with the required privileged PSA exception for Longhorn node/CSI workloads..."
ensure_cis_namespace "${NAMESPACE}" true privileged
ensure_registry_secret "${NAMESPACE}"

log "Longhorn will use ${DATA_PATH} as the default node data path."
log "Preflight expectation: ${DATA_PATH} is already mounted and writable on every Kubernetes node."
kubectl get nodes -o custom-columns=NAME:.metadata.name --no-headers | while read -r node_name; do
  [[ -n "${node_name}" ]] || continue
  log "Storage-path preflight required on node: ${node_name} -> ${DATA_PATH}"
done

log "Installing/upgrading Longhorn ${RELEASE} from offline chart ${HELM_PACKAGES_DIR}/${CHART}..."
helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${YAML_DIR}/values/${VALUES}" \
  --set "defaultSettings.defaultDataPath=${DATA_PATH}" \
  --set "persistence.defaultClassReplicaCount=${DEFAULT_REPLICA_COUNT}" \
  --set-string "persistence.defaultFsType=${DEFAULT_FS_TYPE}"

log "Waiting for Longhorn manager and UI components..."
kubectl rollout status daemonset/longhorn-manager --namespace "${NAMESPACE}" --timeout "${KUBECTL_TIMEOUT}"
kubectl rollout status deployment/longhorn-ui --namespace "${NAMESPACE}" --timeout "${KUBECTL_TIMEOUT}"

log "Waiting for Longhorn CSI driver components to register..."
sleep 30s
kubectl rollout status daemonset/longhorn-csi-plugin --namespace "${NAMESPACE}" --timeout "${KUBECTL_TIMEOUT}"

log "Applying Longhorn resources..."
apply_file "${YAML_DIR}/resources/${RESOURCES1}"

log "Applying Longhorn StorageClasses..."
apply_file "${YAML_DIR}/resources/${RESOURCES3}"

if kubectl get crd volumesnapshotclasses.snapshot.storage.k8s.io >/dev/null 2>&1; then
  log "Applying Longhorn VolumeSnapshotClass..."
  apply_file "${YAML_DIR}/resources/${RESOURCES2}"
else
  warn "VolumeSnapshotClass CRD is not installed. Skipping ${RESOURCES2}."
fi

log "Longhorn install complete. Current StorageClasses:"
kubectl get storageclass | grep -E '^(longhorn|longhorn-rwo-critical|longhorn-rwo-standard|longhorn-postgres-ha|longhorn-rwx-standard)' || true
