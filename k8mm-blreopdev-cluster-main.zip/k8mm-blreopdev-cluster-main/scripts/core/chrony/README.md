# Chrony DaemonSet Deployment

**Documentation Version:** 1.5
**Last Reviewed:** May 22, 2026

This directory contains a Kubernetes DaemonSet manifest for node time synchronization using Chrony.

## File

- `chrony-daemonset.yaml`: Deploys `chrony-client` to all nodes in `kube-system` using host networking and privileged access.

## What This Deploys

- A DaemonSet named `chrony-client` in `kube-system`
- An init container that disables `systemd-timesyncd` on each host to prevent NTP conflicts
- A Chrony container configured by environment variables
- Liveness and readiness probes using `chronyc tracking`

## Prerequisites

- Cluster-admin access to the target cluster
- `kubectl` configured for the target cluster context
- Access to registry images referenced in the manifest:
  - `kubeharbor.dev.kube/ultimate-k8s-toolbox:v1.0.1`
  - `kubeharbor.dev.kube/chrony-air-gapped:v0.1.4`

## Configure NTP Server(s)

Edit `NTP_SERVERS` in `chrony-daemonset.yaml` before deployment.

Current default:

```yaml
- name: NTP_SERVERS
  value: "10.231.0.1"
```

You can provide one or more servers (space- or comma-separated, depending on container parsing behavior).

## Deploy

```bash
kubectl apply -f build/misc/chrony/chrony-daemonset.yaml
```

## Verify

```bash
kubectl -n kube-system get daemonset chrony-client
kubectl -n kube-system get pods -l app=chrony-client -o wide
kubectl -n kube-system logs -l app=chrony-client --tail=100
```

Optional deep check:

```bash
kubectl -n kube-system exec -it <chrony-pod> -- chronyc tracking
```

## Rollback

```bash
kubectl delete -f build/misc/chrony/chrony-daemonset.yaml
```

## Notes

- This workload runs privileged and uses `hostNetwork: true` and `hostPID: true`.
- It tolerates all taints and is designed to run on control-plane and worker nodes.
- The manifest includes a commented ConfigMap example for alternate NTP server profiles.
