#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/cis.sh
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"

NAMESPACE="segment1"
RELEASE="ingress-${SITE}${CLUSTER}-seg1"
CHART="contour-21.1.4.tgz"
VALUES="ingress-${CLUSTER}-seg1-values-v1.yaml"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

ensure_dir "${YAML_DIR}"
ensure_file "${YAML_DIR}/values/${VALUES}"
ensure_chart_package "${HELM_PACKAGES_DIR}/${CHART}"

log "Creating restricted CIS/PSA namespace ${NAMESPACE}..."
ensure_cis_namespace "${NAMESPACE}" true restricted
label_restricted_namespace "${NAMESPACE}"
ensure_registry_secret "${NAMESPACE}"

log "Installing ${RELEASE} from ${REGISTRY_HOST} image sources..."
helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${YAML_DIR}/values/${VALUES}"

log "Waiting for ${RELEASE} to be ready..."
wait_for_deployment_available "${NAMESPACE}" "${NAMESPACE}-contour"

log "Applying restricted segment1 NetworkPolicy package..."
apply_segment1_network_policies "${NAMESPACE}"

log "${RELEASE} installed with restricted Pod Security Admission and restricted-domain NetworkPolicy posture."
