#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/cis.sh
source "${SCRIPT_DIR}/../_lib/cis.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"
NAMESPACE="metallb-system"
RELEASE="metallb"
CHART="metallb-0.15.2.tgz"
VALUES="metallb-${CLUSTER}-values-v0152-v1.yaml"
RESOURCES1="metallb-${CLUSTER}-resources-v1.yaml"

require_kubernetes_tools
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

log "Creating namespace ${NAMESPACE} with the required privileged PSA exception for MetalLB speaker/FRR..."
ensure_cis_namespace "${NAMESPACE}" true privileged
ensure_registry_secret "${NAMESPACE}"

helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${YAML_DIR}/values/${VALUES}"

log "Waiting for ${RELEASE} controller to be ready..."
wait_for_deployment_available "${NAMESPACE}" "metallb-controller" "${KUBECTL_TIMEOUT}"

log "Applying ${RELEASE} IPAddressPool and L2Advertisement resources..."
apply_file "${YAML_DIR}/resources/${RESOURCES1}"

log "${RELEASE} installed with an explicit privileged PSA exception required by the speaker network workload."
