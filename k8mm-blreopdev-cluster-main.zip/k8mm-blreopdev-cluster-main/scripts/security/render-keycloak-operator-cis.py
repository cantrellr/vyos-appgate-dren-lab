#!/usr/bin/env python3
"""Render the Keycloak operator manifest with restricted-PSA security contexts.

The source operator YAML is generated upstream and intentionally left intact.
This renderer modifies only the opkeycloak-operator Deployment pod template so
that the applied manifest satisfies Kubernetes Restricted Pod Security Standards.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

try:
    import yaml
except ImportError as exc:  # pragma: no cover - runtime guard
    raise SystemExit("PyYAML is required. Install python3-yaml before running this renderer.") from exc


def die(message: str) -> None:
    raise SystemExit(f"ERROR: {message}")


def harden_deployment(document: dict[str, Any]) -> bool:
    if document.get("kind") != "Deployment":
        return False

    metadata = document.get("metadata") or {}
    if metadata.get("name") != "opkeycloak-operator":
        return False

    try:
        pod_spec = document["spec"]["template"]["spec"]
        containers = pod_spec["containers"]
    except (KeyError, TypeError) as exc:
        die(f"Malformed opkeycloak-operator Deployment: {exc}")

    pod_security = pod_spec.setdefault("securityContext", {})
    pod_security["runAsNonRoot"] = True
    pod_security["seccompProfile"] = {"type": "RuntimeDefault"}

    # The operator requires Kubernetes API access through its dedicated ServiceAccount.
    pod_spec["automountServiceAccountToken"] = True

    matched = False
    for container in containers:
        if container.get("name") != "opkeycloak-operator":
            continue
        matched = True
        security = container.setdefault("securityContext", {})
        security["allowPrivilegeEscalation"] = False
        security["runAsNonRoot"] = True
        security["privileged"] = False
        security["capabilities"] = {"drop": ["ALL"]}
        security["seccompProfile"] = {"type": "RuntimeDefault"}

    if not matched:
        die("opkeycloak-operator container was not found in the Deployment")

    return True


def main() -> int:
    if len(sys.argv) != 2:
        die(f"Usage: {Path(sys.argv[0]).name} <operator-manifest.yaml>")

    source = Path(sys.argv[1])
    if not source.is_file():
        die(f"Manifest not found: {source}")

    with source.open("r", encoding="utf-8") as handle:
        documents = list(yaml.safe_load_all(handle))

    hardened = False
    for document in documents:
        if isinstance(document, dict) and harden_deployment(document):
            hardened = True

    if not hardened:
        die("Deployment/opkeycloak-operator was not found in the manifest")

    yaml.safe_dump_all(
        documents,
        sys.stdout,
        explicit_start=True,
        default_flow_style=False,
        sort_keys=False,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
