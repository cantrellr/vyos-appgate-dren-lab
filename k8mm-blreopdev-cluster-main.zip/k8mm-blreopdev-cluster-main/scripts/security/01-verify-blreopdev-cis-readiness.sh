#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"

require_site_cluster_args "$#" "$0" blre opdev
SITE="$1"
CLUSTER="$2"
K8_CONTEXT="${SITE}${CLUSTER}"

require_kubectl
require_cmd jq
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

failures=0
warnings=0

pass() {
  printf '[PASS] %s\n' "$*"
}

fail() {
  printf '[FAIL] %s\n' "$*" >&2
  failures=$((failures + 1))
}

warn_only() {
  printf '[WARN] %s\n' "$*" >&2
  warnings=$((warnings + 1))
}

declare -A EXPECTED_PSA=(
  [cert-manager]=restricted
  [metallb-system]=privileged
  [segment1]=restricted
  [oppostgres]=restricted
  [opkeycloak]=restricted
  [longhorn-system]=privileged
  [elastic-monitoring]=restricted
  [elastic-agent-system]=privileged
  [elastic-agent-cluster-system]=privileged
)

verify_namespace_policy() {
  local namespace="$1"
  local expected="$2"
  local key=""
  local actual=""

  if ! kubectl get namespace "${namespace}" >/dev/null 2>&1; then
    fail "Namespace ${namespace} does not exist."
    return
  fi

  for key in enforce audit warn; do
    actual="$(kubectl get namespace "${namespace}" -o "jsonpath={.metadata.labels.pod-security\\.kubernetes\\.io/${key}}")"
    if [[ "${actual}" == "${expected}" ]]; then
      pass "${namespace}: pod-security.kubernetes.io/${key}=${expected}"
    else
      fail "${namespace}: expected pod-security.kubernetes.io/${key}=${expected}, found '${actual:-<unset>}'."
    fi
  done

  actual="$(kubectl get namespace "${namespace}" -o 'jsonpath={.metadata.labels.k8mm\.dev/cis-managed}')"
  [[ "${actual}" == "true" ]] \
    && pass "${namespace}: managed by the repo CIS namespace policy helper" \
    || fail "${namespace}: k8mm.dev/cis-managed=true is missing."

  if [[ "${expected}" == "privileged" ]]; then
    actual="$(kubectl get namespace "${namespace}" -o 'jsonpath={.metadata.labels.k8mm\.dev/cis-psa-exception}')"
    [[ "${actual}" == "true" ]] \
      && pass "${namespace}: privileged PSA exception is explicitly documented by label" \
      || fail "${namespace}: privileged namespace is missing k8mm.dev/cis-psa-exception=true."
  fi

  actual="$(kubectl -n "${namespace}" get serviceaccount default -o jsonpath='{.automountServiceAccountToken}' 2>/dev/null || true)"
  [[ "${actual}" == "false" ]] \
    && pass "${namespace}: default ServiceAccount token automount is disabled" \
    || fail "${namespace}: default ServiceAccount automountServiceAccountToken must be false; found '${actual:-<unset>}'."
}

verify_restricted_pods() {
  local namespace="$1"
  local pod_count=0
  local host_violations='[]'
  local container_violations='[]'

  pod_count="$(kubectl -n "${namespace}" get pods -o json | jq '.items | length')"
  if [[ "${pod_count}" -eq 0 ]]; then
    warn_only "${namespace}: no pods are currently deployed, so runtime Restricted PSS validation was skipped."
    return
  fi

  host_violations="$(kubectl -n "${namespace}" get pods -o json | jq -c '
    [
      .items[]
      | select(
          (.spec.hostNetwork // false) == true
          or (.spec.hostPID // false) == true
          or (.spec.hostIPC // false) == true
          or any((.spec.volumes // [])[]?; has("hostPath"))
        )
      | {
          pod: .metadata.name,
          hostNetwork: (.spec.hostNetwork // false),
          hostPID: (.spec.hostPID // false),
          hostIPC: (.spec.hostIPC // false),
          hostPathVolumes: [(.spec.volumes // [])[]? | select(has("hostPath")) | .name]
        }
    ]
  ')"

  if [[ "$(jq 'length' <<<"${host_violations}")" -gt 0 ]]; then
    fail "${namespace}: restricted pods use forbidden host namespaces or hostPath volumes: ${host_violations}"
  else
    pass "${namespace}: no host namespace or hostPath violations detected"
  fi

  container_violations="$(kubectl -n "${namespace}" get pods -o json | jq -c '
    [
      .items[] as $pod
      | ($pod.spec.securityContext.runAsNonRoot // false) as $podRunAsNonRoot
      | ($pod.spec.securityContext.seccompProfile.type // "") as $podSeccomp
      | (($pod.spec.initContainers // []) + ($pod.spec.containers // []) + ($pod.spec.ephemeralContainers // []))[]
      | . as $container
      | (($container.securityContext.seccompProfile.type // "")) as $containerSeccomp
      | select(
          ($container.securityContext.privileged // false) == true
          or ($container.securityContext.allowPrivilegeEscalation != false)
          or (($podRunAsNonRoot or ($container.securityContext.runAsNonRoot // false)) != true)
          or (((($podSeccomp == "RuntimeDefault") or ($podSeccomp == "Localhost") or ($containerSeccomp == "RuntimeDefault") or ($containerSeccomp == "Localhost"))) | not)
          or (((($container.securityContext.capabilities.drop // []) | index("ALL")) == null))
          or (((($container.securityContext.capabilities.add // []) | map(select(. != "NET_BIND_SERVICE")) | length) > 0))
        )
      | {
          pod: $pod.metadata.name,
          container: $container.name,
          privileged: ($container.securityContext.privileged // false),
          allowPrivilegeEscalation: $container.securityContext.allowPrivilegeEscalation,
          runAsNonRoot: ($container.securityContext.runAsNonRoot // $podRunAsNonRoot),
          seccomp: (if $containerSeccomp != "" then $containerSeccomp else $podSeccomp end),
          capabilitiesDrop: ($container.securityContext.capabilities.drop // []),
          capabilitiesAdd: ($container.securityContext.capabilities.add // [])
        }
    ]
  ')"

  if [[ "$(jq 'length' <<<"${container_violations}")" -gt 0 ]]; then
    fail "${namespace}: Restricted PSS container violations detected: ${container_violations}"
  else
    pass "${namespace}: deployed containers satisfy the repository Restricted PSS checks"
  fi
}

printf '== Namespace CIS/PSA policy ==\n'
for namespace in cert-manager metallb-system segment1 oppostgres opkeycloak longhorn-system elastic-monitoring elastic-agent-system elastic-agent-cluster-system; do
  verify_namespace_policy "${namespace}" "${EXPECTED_PSA[${namespace}]}"
done

printf '\n== Restricted namespace runtime pod checks ==\n'
for namespace in cert-manager segment1 oppostgres opkeycloak elastic-monitoring; do
  if kubectl get namespace "${namespace}" >/dev/null 2>&1; then
    verify_restricted_pods "${namespace}"
  fi
done

printf '\n== Result ==\n'
printf 'Failures: %d\nWarnings: %d\n' "${failures}" "${warnings}"

if [[ "${failures}" -gt 0 ]]; then
  exit 1
fi

pass "BLREOPDEV namespace and deployed-pod CIS readiness checks completed without failures."
