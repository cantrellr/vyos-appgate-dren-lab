```text
 _  __  ___    __  __ __  __    ____  _     ____  _____ ___  ____  ____  _______     __
| |/ / ( _ )  |  \/  |  \/  |  | __ )| |   |  _ \| ____/ _ \|  _ \|  _ \| ____\ \   / /
| ' /  / _ \  | |\/| | |\/| |  |  _ \| |   | |_) |  _|| | | | |_) | | | |  _|  \ \ / / 
| . \ | (_) | | |  | | |  | |  | |_) | |___|  _ <| |__| |_| |  __/| |_| | |___  \ V /  
|_|\_\ \___/  |_|  |_|_|  |_|  |____/|_____|_| \_\_____|\___/|_|   |____/|_____|  \_/   
```

# K8MM-BLREOPDEV-Cluster

Repo slug: k8mm-blreopdev-cluster  
Cluster name: blreopdev-cluster  
Version: 0.12.0  
Date: July 15, 2026

This repository manages the K8MM-BLREOPDEV-Cluster platform baseline.

This is a single RKE2 multi-node cluster deployment for the BLRE-OnPrem Segment 1 environment. It is not a multi-cluster deployment.

## Cluster Identity

Cluster name: blreopdev-cluster  
Site: blre  
Environment: opdev  
Kubernetes context: blreopdev

> Current installer scripts still use the two-argument convention `blre opdev`. The canonical cluster name is `blreopdev-cluster`.

## Platform Scope

- RKE2 control-plane nodes: BLREOPDEV-CTRL01, BLREOPDEV-CTRL02, and BLREOPDEV-CTRL03.
- RKE2 worker nodes: BLREOPDEV-WORK01, BLREOPDEV-WORK02, and BLREOPDEV-WORK03.
- opkeycloak: Keycloak identity workloads and deployment flow.
- oppostgres: CloudNativePG PostgreSQL HA data services for opkeycloak.
- monitoring: Fleet-managed Elastic Agent 9.4.2 metrics collection for the enterprise Elastic Stack.
- segment1: Contour/Envoy restricted ingress boundary for published services.
- kubeharbor: private registry for disconnected image pulls.

## Repository Layout

- scripts/: Bash installers and utilities.
- scripts/_lib/: shared Bash libraries, including CIS namespace-policy helpers.
- scripts/core/: core platform services for blreopdev.
- scripts/opkeycloak/: ordered opkeycloak and oppostgres deployment scripts.
- scripts/monitoring/: Elastic 9.4.2 air-gap preparation and Helm-based monitoring installers.
- scripts/security/: CIS rendering and verification utilities.
- yaml/: Kubernetes resources and Helm values files.
- docs/: operator-facing documentation.
- diagrams/: Mermaid source and diagram sync metadata.
- archive/: unused or superseded files retained for reference.

## CIS Readiness

The repository is prepared for deployment to an RKE2 cluster started with `profile: cis` by explicitly managing Pod Security Admission and default ServiceAccount token posture for its workload namespaces.

Namespace contract:

| Namespace | Component | PSA profile |
| --- | --- | --- |
| `cert-manager` | cert-manager | `restricted` |
| `metallb-system` | MetalLB speaker/controller/FRR | `privileged` exception |
| `segment1` | Contour/Envoy | `restricted` |
| `oppostgres` | CloudNativePG/PostgreSQL/PgBouncer | `restricted` |
| `opkeycloak` | Keycloak operator and Keycloak | `restricted` |
| `longhorn-system` | Longhorn manager/CSI/storage engine | `privileged` exception |
| `elastic-agent-system` | Fleet-managed Elastic Agent per-node DaemonSet | `privileged` exception |
| `elastic-agent-cluster-system` | Fleet-managed Elastic Agent cluster-wide Deployment | `privileged` exception |
| `elastic-monitoring` | kube-state-metrics | `restricted` |

Every installer-managed namespace also has `automountServiceAccountToken: false` applied to its `default` ServiceAccount.

Elastic Agent workloads are intentionally isolated from the restricted `elastic-monitoring` namespace. This keeps kube-state-metrics under Restricted PSS while explicitly documenting the privileged exceptions required for Elastic Agent host-level and Fleet-managed workload behavior.

Validate the deployed posture with:

```bash
bash scripts/security/01-verify-blreopdev-cis-readiness.sh blre opdev
```

See `docs/CIS-Readiness.md` for the component analysis, RKE2 bootstrap boundary, privileged-exception rationale, rollout plan, and acceptance criteria.

## OPKeycloak / OPPostgreSQL Deployment Flow

The active deployment flow is intentionally grouped under the opkeycloak script family because PostgreSQL exists to support the Keycloak workload.

- scripts/opkeycloak/00-install-oppostgres-cnpg-operator.sh
- scripts/opkeycloak/00-prepare-opkeycloak-runtime-secrets.sh
- scripts/opkeycloak/01-install-oppostgres-cnpg-keycloak-db.sh
- scripts/opkeycloak/02-install-opkeycloak-operator.sh
- scripts/opkeycloak/03-install-opkeycloak.sh
- scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh
- scripts/opkeycloak/05-verify-cnpg-ha.sh
- scripts/opkeycloak/06-uninstall-keycloak-postgresql-cnpg.sh

The PostgreSQL and Keycloak install scripts invoke the runtime-secret preparation script automatically. Credentials are generated only when absent, are never printed, and are not stored in Git. The PostgreSQL application Secret is authoritative in the `oppostgres` namespace and is mirrored into `opkeycloak` because Kubernetes Secret references are namespace-scoped.

The active PostgreSQL cluster name is `oppostgres-opkeycloak-db`. OPKeycloak connects through the three-instance PgBouncer service:

```text
oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432
```

The direct CNPG RW service remains an internal PgBouncer backend and is not the application endpoint.

## OPPostgreSQL HA Posture

- Three PostgreSQL instances with required hostname anti-affinity.
- Quorum synchronous replication to one standby with `dataDurability: preferred` to favor service continuity if synchronous standbys are temporarily unavailable.
- Separate Longhorn volumes for PGDATA and WAL.
- CNPG-managed HA replication slots with an explicit WAL-retention cap.
- Three PgBouncer instances with required hostname anti-affinity and a `minAvailable: 2` PodDisruptionBudget.
- PgBouncer session pooling as the conservative compatibility baseline for the Keycloak JDBC/Hibernate workload.

## Monitoring Flow

The active monitoring path is Fleet-managed Elastic Agent pinned to the enterprise ELK version `9.4.2`.

The deployment uses official Helm charts and three releases:

```text
blreopdev-elastic-node
blreopdev-elastic-cluster
blreopdev-kube-state-metrics
```

Runtime architecture:

- `elastic-agent-system`: `perNode` Elastic Agent 9.4.2 DaemonSet.
- `elastic-agent-cluster-system`: `clusterWide` Elastic Agent 9.4.2 Deployment.
- `elastic-monitoring`: kube-state-metrics chart 6.1.0 / image v2.16.0.
- Fleet URL and enrollment token are injected through runtime-created Kubernetes Secrets and are never stored in Git.
- Optional private Fleet CA trust is supported through `FLEET_CA_FILE`.

Required KubeHarbor images:

```text
kubeharbor.dev.kube/elastic/elastic-agent:9.4.2
kubeharbor.dev.kube/kube-state-metrics/kube-state-metrics:v2.16.0
```

Prepare air-gap artifacts on an Internet-connected host:

```bash
bash scripts/monitoring/00-download-elastic-agent-airgap-artifacts.sh
```

Then copy these chart packages into `helm/packages/`:

```text
elastic-agent-9.4.2.tgz
kube-state-metrics-6.1.0.tgz
```

Install with:

```bash
export FLEET_URL='https://fleet.example.mil:8220'
export FLEET_ENROLLMENT_TOKEN='<token-provided-by-elk-admin>'
export FLEET_INSECURE='false'

bash scripts/monitoring/01-install-elastic-agent.sh blre opdev
```

For an internally issued Fleet certificate:

```bash
export FLEET_CA_FILE='/path/to/fleet-ca.crt'
```

The Fleet policy must include the Kubernetes integration and point cluster-wide state collection to:

```text
http://kube-state-metrics.elastic-monitoring.svc.cluster.local:8080
```

See `docs/Elastic-Stack-Monitoring.md` for full version, Fleet, TLS, air-gap, CIS, and validation guidance.

## NetworkPolicy Flow

Run this single policy script to enforce OPKeycloak and OPPostgreSQL policies:

```bash
scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh apply
```

The policy package enforces the application database path as:

```text
OPKeycloak -> PgBouncer -> CNPG PostgreSQL primary
```

Direct OPKeycloak-to-CNPG database traffic is not allowed. PgBouncer has its own default-deny policy, explicit Keycloak ingress, explicit CNPG egress, and DNS egress. The script also renders the runtime PostgreSQL Kubernetes API egress rule with the live `kubernetes.default` service ClusterIP.

## Active Helm Package Contract

The active scripts reference these package names under `helm/packages`:

- cert-manager-1.5.14.tgz
- metallb-0.15.2.tgz
- contour-21.1.4.tgz
- longhorn-1.12.0.tgz
- cloudnative-pg-0.29.0.tgz
- cluster-0.7.0.tgz
- elastic-agent-9.4.2.tgz
- kube-state-metrics-6.1.0.tgz

Any other chart archive in `helm/packages` is not part of the active blreopdev deployment contract and should be treated as removable dead weight.

## Documentation Index

- docs/README.md
- docs/Cluster-Identity.md
- docs/System-Design-Document.md
- docs/System-Design-Diagrams.md
- docs/CIS-Readiness.md
- docs/Elastic-Stack-Monitoring.md
- docs/OPPostgreSQL-CNPG-HA.md
- docs/How-to-deploy-K8MM-BLREOPDEV-cluster.md
- diagrams/README.md
- diagrams/DIAGRAM-INDEX.md
