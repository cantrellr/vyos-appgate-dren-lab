# K8MM-BLREOPDEV-Cluster Documentation

Cluster name: blreopdev-cluster.  
Operational context: blreopdev.

This repo is a single RKE2 multi-node cluster deployment for BLRE-OnPrem Segment 1.

## Documentation Map

- Cluster-Identity.md
- System-Design-Document.md
- System-Design-Diagrams.md
- CIS-Readiness.md
- Monitoring-and-NetworkPolicy-Gap-Analysis.md
- OPPostgreSQL-CNPG-HA.md
- How-to-deploy-K8MM-BLREOPDEV-cluster.md
- DIAGRAM-SYNC-REPORT.md

## Diagram Map

- ../diagrams/README.md
- ../diagrams/DIAGRAM-INDEX.md
- ../diagrams/mermaid-source/

## Active Standards

- Installers live under scripts/ and source scripts/_lib/common.sh.
- CIS-aware installers also source scripts/_lib/cis.sh to apply explicit namespace PSA labels and harden default ServiceAccounts.
- CIS rendering and runtime verification utilities live under scripts/security/.
- OPKeycloak and OPPostgreSQL install flow lives under scripts/opkeycloak/.
- OPKeycloak resources live under yaml/opkeycloak/resources/.
- OPPostgreSQL resources live under yaml/oppostgres/.
- NetworkPolicies live under yaml/opkeycloak/networkpolicies/ and are applied by scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh.
- Prometheus Agent values live under yaml/monitoring/.
- Mermaid diagram source lives under diagrams/mermaid-source/ and is embedded in docs/System-Design-Diagrams.md.
