# Diagram Sync Report

Date: July 8, 2026  
Cluster name: blreopdev-cluster  
Operational context: blreopdev

## Summary

Converted the handwritten BLRE-OnPrem design into the System Overview Mermaid drawing and added a matching Services Overview drawing for the PostgreSQL/Keycloak HA deployment.

## Current diagrams

| Diagram | Purpose |
| ---: | --- |
| 1 | System Overview: KUBEADMIN, KUBEHARBOR, BLREOPDEV control-plane nodes, BLREOPDEV worker nodes, platform services, published services, and the canonical cluster name `blreopdev-cluster`. |
| 2 | Services Overview: OPKeycloak and OPPostgreSQL CloudNativePG HA design, including ingress, TLS, Keycloak replicas, PostgreSQL primary/replicas, Longhorn storage, monitoring, alerts, and the canonical cluster name `blreopdev-cluster`. |

## Files retained or added

- `docs/System-Design-Diagrams.md`
- `diagrams/README.md`
- `diagrams/DIAGRAM-INDEX.md`
- `diagrams/DIAGRAM-INDEX.json`
- `diagrams/mermaid-source/blreopdev-system-overview.mmd`
- `diagrams/mermaid-source/blreopdev-services-overview.mmd`
- `diagrams/sync-mermaid-markdown.py`
- `diagrams/apply-diagram-updates.sh`

## Files removed

The old `blreopdev-cluster-overview` diagram files were removed so this branch has BLREOPDEV-specific diagrams only.

## Alignment basis

The diagrams are aligned to these repository contracts:

- single RKE2 multi-node cluster: `blreopdev-cluster`
- operational context: `blreopdev`
- site/environment script arguments: `blre opdev`
- six cluster nodes: three control-plane nodes and three worker nodes
- private registry: KUBEHARBOR / `kubeharbor.dev.kube`
- registry pull secret: `regcred-kubeharbor`
- administrative access through `KUBEADMIN`
- published services: `longhorn.dev.jde.cybercom.ic.gov` and `keycloak.dev.jde.cybercom.ic.gov`

## Recommended follow-on drawings

- NetworkPolicy and traffic boundary drawing
- Storage and backup/restore drawing
- Monitoring and alerting drawing
- Certificate, DNS, and ingress drawing
- Deployment sequence drawing
- Failure-domain and maintenance drawing

## Run locally

```bash
python3 diagrams/sync-mermaid-markdown.py .
```

or:

```bash
bash diagrams/apply-diagram-updates.sh .
```
