# OPPostgreSQL CloudNativePG HA Runbook

Platform: K8MM-BLREOPDEV-Cluster  
Repo slug: k8mm-blreopdev-cluster  
Cluster name: blreopdev-cluster  
Operational context: blreopdev  
Site: blre  
Environment: opdev  
Date: July 10, 2026

## Purpose

This runbook installs and validates the OPPostgreSQL CloudNativePG HA deployment used by OPKeycloak on the single multi-node RKE2 cluster `blreopdev-cluster`.

The production application path is:

```text
OPKeycloak -> three-instance PgBouncer RW tier -> three-instance CNPG PostgreSQL cluster
```

## Naming Contract

| Item | Required Value |
| --- | --- |
| RKE2 cluster name | blreopdev-cluster |
| Kubernetes context | blreopdev |
| PostgreSQL namespace | oppostgres |
| Keycloak namespace | opkeycloak |
| CNPG operator Helm release | oppostgres-operator |
| PostgreSQL Helm release | oppostgres |
| CNPG Cluster | oppostgres-opkeycloak-db |
| PgBouncer Pooler | oppostgres-opkeycloak-db-pooler-rw |
| Application database service | oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local |
| Direct CNPG RW backend | oppostgres-opkeycloak-db-rw.oppostgres.svc.cluster.local |
| Port | 5432 |
| Database | opkeycloak |
| Database Secret | opkeycloak-postgresql-credentials |
| Keycloak bootstrap Secret | opkeycloak-bootstrap-admin |
| StorageClass | longhorn-postgres-ha |

## Active File Layout

| Path | Purpose |
| --- | --- |
| scripts/opkeycloak/00-install-oppostgres-cnpg-operator.sh | Installs the CloudNativePG operator. |
| scripts/opkeycloak/00-prepare-opkeycloak-runtime-secrets.sh | Generates/preserves runtime credentials and mirrors the database credential into the Keycloak namespace. |
| scripts/opkeycloak/01-install-oppostgres-cnpg-keycloak-db.sh | Installs the OPPostgreSQL CNPG cluster, PgBouncer tier, and PgBouncer PDB. |
| scripts/opkeycloak/03-install-opkeycloak.sh | Reconciles runtime Secrets before applying the Keycloak CR. |
| scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh | Enforces OPKeycloak, PgBouncer, and OPPostgreSQL NetworkPolicies. |
| scripts/opkeycloak/05-verify-cnpg-ha.sh | Validates PostgreSQL HA, PgBouncer HA, Secret parity, Keycloak endpoint selection, and SQL authentication. |
| yaml/oppostgres/values/oppostgres-cnpg-keycloak-db-opdev-values-v1.yaml | Canonical CNPG/PgBouncer values. |
| yaml/oppostgres/resources/oppostgres-opdev-pgbouncer-pdb-v1.yaml | PgBouncer PodDisruptionBudget. |
| yaml/oppostgres/resources/test-client-pod.yaml | PgBouncer SQL test client. |
| yaml/oppostgres/resources/oppostgres-monitoring.yaml | PostgreSQL PodMonitor. |
| yaml/oppostgres/monitoring/ | PostgreSQL PrometheusRule resources. |
| yaml/opkeycloak/networkpolicies/ | Canonical NetworkPolicy package for OPKeycloak, PgBouncer, and OPPostgreSQL. |

## Runtime Secret Lifecycle

Credentials are intentionally excluded from Git.

The runtime-secret script:

1. Creates `oppostgres/opkeycloak-postgresql-credentials` only when it does not already exist.
2. Uses `openssl rand -hex 32` for a 256-bit generated password.
3. Preserves the existing database Secret on normal reruns.
4. Mirrors the exact Secret data into `opkeycloak/opkeycloak-postgresql-credentials`, because the Keycloak CR cannot reference a Secret from another namespace.
5. Creates `opkeycloak/opkeycloak-bootstrap-admin` only when absent.
6. Verifies database credential parity across namespaces without printing or decoding password values.
7. Refuses `REGENERATE_RUNTIME_SECRETS=true` when the CNPG cluster already exists, preventing an accidental Secret-only rotation that would desynchronize Kubernetes from the live PostgreSQL role password.

For a fresh pre-database deployment, runtime Secrets can be intentionally regenerated with:

```bash
REGENERATE_RUNTIME_SECRETS=true \
  scripts/opkeycloak/00-prepare-opkeycloak-runtime-secrets.sh blre opdev
```

Do not use that switch against an existing CNPG cluster. Live database password rotation requires a coordinated PostgreSQL role-password update and Secret rollout.

## HA Configuration

### PostgreSQL

- Three instances.
- Required pod anti-affinity across `kubernetes.io/hostname`.
- CNPG PodDisruptionBudget enabled.
- Quorum synchronous replication with `method: any`, `number: 1`, and `dataDurability: preferred`.
- CNPG-managed HA replication slots explicitly enabled.
- `max_slot_wal_keep_size: 10GB` to cap WAL retained by lagging replication slots.
- 50 Gi PGDATA and 25 Gi WAL volumes per instance on `longhorn-postgres-ha`.
- Primary rolling updates use switchover and unsupervised orchestration.

`dataDurability: preferred` is intentional for this identity workload: when at least one standby is available, writes are synchronously replicated; if no synchronous standby is available, the service can continue rather than indefinitely blocking writes.

### PgBouncer

- Three RW pooler instances.
- Required pod anti-affinity across `kubernetes.io/hostname`.
- `minAvailable: 2` PodDisruptionBudget.
- Session pooling as the conservative Keycloak compatibility baseline.
- Private PgBouncer image from KUBEHARBOR.

Transaction pooling can be considered later, but only after explicit Keycloak JDBC/Hibernate validation for session state and prepared-statement behavior.

## Install

Run from the repository root:

```bash
scripts/opkeycloak/00-install-oppostgres-cnpg-operator.sh blre opdev
scripts/opkeycloak/01-install-oppostgres-cnpg-keycloak-db.sh blre opdev
scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh apply
```

The database installer automatically prepares runtime Secrets before Helm deploys the CNPG cluster.

## Expected Kubernetes Objects

The `blreopdev` cluster should contain:

- namespace/oppostgres
- cluster.postgresql.cnpg.io/oppostgres-opkeycloak-db
- pooler.postgresql.cnpg.io/oppostgres-opkeycloak-db-pooler-rw
- deployment/oppostgres-opkeycloak-db-pooler-rw with three available replicas
- service/oppostgres-opkeycloak-db-pooler-rw
- service/oppostgres-opkeycloak-db-rw
- poddisruptionbudget/oppostgres-opkeycloak-db-pooler-rw
- secret/opkeycloak-postgresql-credentials in both `oppostgres` and `opkeycloak`, with identical data
- podmonitor.monitoring.coreos.com/oppostgres-opkeycloak-db
- prometheusrule.monitoring.coreos.com/oppostgres-cnpg-alerts
- OPPostgreSQL/PgBouncer NetworkPolicies applied from `yaml/opkeycloak/networkpolicies/`

## Storage Expectations

The cluster uses `longhorn-postgres-ha` for both data and WAL. Do not use RWX storage for PostgreSQL primary data or WAL.

Because the cluster requires PostgreSQL pod anti-affinity by hostname, three schedulable nodes must be available for the three database instances.

## Keycloak Database Endpoint

Keycloak must use PgBouncer:

```text
oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432
```

The direct CNPG RW service is not the Keycloak application endpoint:

```text
oppostgres-opkeycloak-db-rw.oppostgres.svc.cluster.local:5432
```

## Validation

Run:

```bash
scripts/opkeycloak/05-verify-cnpg-ha.sh blre opdev
```

The verification script fails closed if:

- fewer than three PostgreSQL instances are ready;
- fewer than three PgBouncer replicas are available;
- PostgreSQL and Keycloak namespace Secrets differ;
- the Keycloak CR does not point to the PgBouncer service; or
- an authenticated SQL query through PgBouncer fails.

## NetworkPolicy

The deployment uses default deny plus explicit allows for:

- OPKeycloak -> PgBouncer TCP/5432;
- PgBouncer -> CNPG PostgreSQL TCP/5432;
- CNPG peer traffic TCP/5432 and TCP/8000;
- monitoring -> CNPG metrics TCP/9187;
- CNPG and PgBouncer -> CoreDNS TCP/UDP 53; and
- CNPG -> Kubernetes API TCP/443 through a runtime-rendered service ClusterIP rule.

Direct OPKeycloak-to-CNPG database access is intentionally not allowed.

## Backup and Restore

Backup object-store resources are not enabled in this baseline because the final object-store target is environment-specific.
