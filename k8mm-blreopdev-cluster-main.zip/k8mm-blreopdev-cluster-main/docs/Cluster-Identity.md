# Cluster Identity

Repo: k8mm-blreopdev-cluster  
Cluster name: blreopdev-cluster  
Operational context: blreopdev  
Site: blre  
Environment: opdev  
Date: July 10, 2026

## Scope

This repository targets one RKE2 multi-node cluster for BLRE-OnPrem Segment 1.

## Naming Contract

| Item | Value |
| --- | --- |
| Cluster name | blreopdev-cluster |
| Site | blre |
| Environment | opdev |
| Script site argument | blre |
| Script cluster/environment argument | opdev |
| Kubernetes context | blreopdev |
| Control-plane nodes | BLREOPDEV-CTRL01, BLREOPDEV-CTRL02, BLREOPDEV-CTRL03 |
| Worker nodes | BLREOPDEV-WORK01, BLREOPDEV-WORK02, BLREOPDEV-WORK03 |
| Registry | kubeharbor.dev.kube |
| Registry pull secret | regcred-kubeharbor |
| Restricted ingress namespace | segment1 |
| Restricted ingress class | segment1 |
| Longhorn hostname | longhorn.dev.jde.cybercom.ic.gov |
| Keycloak hostname | opkeycloak.dev.jde.cybercom.ic.gov |
| Keycloak namespace | opkeycloak |
| PostgreSQL namespace | oppostgres |
| CNPG operator Helm release | oppostgres-operator |
| CNPG cluster Helm release | oppostgres |
| CNPG Cluster | oppostgres-opkeycloak-db |
| PgBouncer application service | oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local |
| Direct CNPG RW backend service | oppostgres-opkeycloak-db-rw.oppostgres.svc.cluster.local |
| Runtime database Secret | opkeycloak-postgresql-credentials |
| Prometheus Agent namespace | monitoring |
| Prometheus remote-write URL | https://blreopdev-prometheus-rw.dev.kube/api/v1/write |

## Hard Rules

1. The canonical RKE2 cluster name is `blreopdev-cluster`.
2. Use `blre opdev` for this repo's install scripts unless the script model is refactored later.
3. OPKeycloak uses PgBouncer as its database endpoint; the direct CNPG RW service is an internal backend only.
4. Database and bootstrap credentials are runtime Kubernetes Secrets and must not be committed to Git.
5. Keep OPKeycloak and OPPostgreSQL NetworkPolicy enforcement centralized in `scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh`.
6. Keep monitoring resources workload-owned, but apply them only after Prometheus Operator CRDs exist.
7. Keep node and service naming aligned to the BLREOPDEV system overview diagrams.
