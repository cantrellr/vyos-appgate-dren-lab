# CIS Readiness for K8MM-BLREOPDEV-Cluster

Version: 1.2  
Date: July 10, 2026  
Cluster: `blreopdev-cluster`  
Kubernetes context: `blreopdev`

## Executive Summary

The `blreopdev-cluster` platform can run on RKE2 nodes started with `profile: cis`, but the workload repository must explicitly own the Pod Security Admission (PSA) posture of its namespaces and must not assume that every platform component can run under the Kubernetes `restricted` Pod Security Standard.

This repository uses the following operating model:

- `restricted` is the default posture for application and controller namespaces that can satisfy Restricted Pod Security Standards.
- `privileged` is an explicit, documented exception only for components whose core function requires host access or elevated network/storage privileges.
- Every repository-managed namespace has `enforce`, `audit`, and `warn` PSA labels set explicitly.
- The `default` ServiceAccount in every repository-managed namespace has `automountServiceAccountToken: false`.
- Runtime verification checks deployed pods in restricted namespaces for host access, privilege escalation, non-root execution, seccomp, and Linux capability posture.
- Monitoring keeps the Prometheus Agent, Prometheus Operator, and kube-state-metrics in a restricted namespace while isolating node-exporter in its own privileged namespace.

The expected privileged exceptions are:

1. `metallb-system` because MetalLB speaker/FRR requires elevated network privileges.
2. `longhorn-system` because Longhorn manager and CSI/node workloads require privileged execution and host-path access.
3. `monitoring-node-exporter` because node-exporter uses `hostNetwork`, `hostPID`, and host filesystem mounts.

These exceptions are narrow, namespace-scoped workload exceptions that must remain explicit and auditable.

## RKE2 CIS Bootstrap Boundary

This repository manages workloads after the Kubernetes cluster is available. It does not configure the operating system or start RKE2.

Before deploying this repository, the node bootstrap process must already satisfy the RKE2 CIS host prerequisites, including:

- `profile: cis` in the RKE2 configuration.
- Required CIS kernel parameters applied before RKE2 starts.
- The host-level `etcd` user and group present on every RKE2 server node.
- RKE2 able to start successfully with `protect-kernel-defaults` enabled by the CIS profile.

The `rke2-node-init` repository supports passing `profile` into generated RKE2 configuration. The BLREOPDEV deployment should not proceed until the multi-node bootstrap path has been verified to satisfy the RKE2 host-level CIS prerequisites as well as passing `profile: cis` through to RKE2.

Setting `profile: cis` is necessary, but it is not a substitute for preparing the host operating system.

## Namespace Security Contract

| Namespace | Component | PSA Enforce | Exception | Rationale |
| --- | --- | --- | --- | --- |
| `cert-manager` | cert-manager | `restricted` | No | Bitnami cert-manager 1.5.14 security contexts are compatible with Restricted PSS. |
| `metallb-system` | MetalLB controller/speaker/FRR | `privileged` | Yes | Speaker networking requires elevated permissions. |
| `segment1` | Contour/Envoy | `restricted` | No | Current values use non-root execution, RuntimeDefault seccomp, denied privilege escalation, and minimal capabilities. |
| `oppostgres` | CloudNativePG/PostgreSQL/PgBouncer | `restricted` | No | CloudNativePG does not require privileged/root execution and applies hardened security defaults. |
| `opkeycloak` | Keycloak operator and Keycloak | `restricted` | No | Keycloak and operator deployment paths are hardened for Restricted PSS. |
| `longhorn-system` | Longhorn manager/CSI/storage engine | `privileged` | Yes | Longhorn manager is privileged and mounts node host paths by design. |
| `monitoring` | Prometheus Agent/operator/kube-state-metrics | `restricted` | No | Monitoring control-plane components remain isolated from host-level exporters. |
| `monitoring-node-exporter` | Prometheus node-exporter | `privileged` | Yes | Node exporter uses host networking, host PID namespace, and host filesystem mounts. |

The helper `scripts/_lib/cis.sh` applies this contract and labels privileged namespaces with:

```text
k8mm.dev/cis-psa-exception=true
```

All managed namespaces receive:

```text
k8mm.dev/cis-managed=true
k8mm.dev/pod-security-profile=<restricted|privileged>
```

## Pod Security Admission Labels

The repo applies all three PSA modes explicitly:

```text
pod-security.kubernetes.io/enforce=<profile>
pod-security.kubernetes.io/enforce-version=latest
pod-security.kubernetes.io/audit=<profile>
pod-security.kubernetes.io/audit-version=latest
pod-security.kubernetes.io/warn=<profile>
pod-security.kubernetes.io/warn-version=latest
```

Using explicit labels makes namespace intent visible and prevents deployment behavior from depending only on cluster-wide admission defaults.

## Default ServiceAccount Hardening

Every namespace created through `ensure_cis_namespace` is patched to:

```yaml
automountServiceAccountToken: false
```

Workloads that legitimately need Kubernetes API access must use a dedicated ServiceAccount. Controllers such as the Keycloak operator retain their dedicated ServiceAccounts and are not forced onto the hardened `default` account.

## Component Analysis

### cert-manager

**Target posture:** `restricted`

The packaged Bitnami cert-manager chart uses non-root execution, denied privilege escalation, dropped Linux capabilities, RuntimeDefault seccomp, and read-only root filesystems for the controller, webhook, and cainjector. The installer applies restricted PSA before Helm creates pods.

### MetalLB

**Target posture:** `privileged` exception

The `metallb-system` namespace cannot be labeled `restricted` in this deployment model. MetalLB speaker performs low-level networking operations, and the repository enables FRR. The installer therefore creates a deliberate privileged PSA exception rather than relying on an implicit bypass.

Keep the exception namespace-scoped and do not place unrelated workloads in `metallb-system`.

### Contour and Envoy

**Target posture:** `restricted`

The current values define:

- `runAsNonRoot: true`
- UID `65534`
- `seccompProfile.type: RuntimeDefault`
- `allowPrivilegeEscalation: false`
- `capabilities.drop: [ALL]`
- Envoy adds only `NET_BIND_SERVICE`

The installer applies restricted PSA to `segment1` before deployment. Existing restricted-zone NetworkPolicies remain in place.

### OPPostgreSQL / CloudNativePG / PgBouncer

**Target posture:** `restricted`

CloudNativePG operates without privileged or root containers and applies hardened security defaults to PostgreSQL pods. The repository keeps `oppostgres` under restricted PSA enforcement.

The HA verification script creates `pg-test-client` with:

- `automountServiceAccountToken: false`
- `runAsNonRoot: true`
- RuntimeDefault seccomp
- `allowPrivilegeEscalation: false`
- `capabilities.drop: [ALL]`

### OPKeycloak

**Target posture:** `restricted`

The Keycloak custom resource requests non-root execution, RuntimeDefault seccomp, denied privilege escalation, and all Linux capabilities dropped.

The generated Keycloak operator manifest is not modified in place. Instead, `scripts/security/render-keycloak-operator-cis.py` renders the upstream-generated manifest with a Restricted-PSS-compatible pod/container security context before the installer applies it.

### Longhorn

**Target posture:** `privileged` exception

Longhorn is not Restricted-PSS compatible by design. Longhorn 1.12.0 runs `longhorn-manager` privileged and mounts host paths including `/boot`, `/dev`, `/proc`, `/etc`, and `/var/lib/longhorn`.

The installer applies an explicit privileged namespace exception before Helm deployment. Do not place application workloads in `longhorn-system`.

### Monitoring and node-exporter

**Target posture:** split restricted/privileged model

The Prometheus Agent stack is split by privilege requirement:

- `monitoring` is `restricted` and contains Prometheus Agent/operator and kube-state-metrics.
- `monitoring-node-exporter` is `privileged` and contains only node-exporter.

The values file sets:

```yaml
prometheus-node-exporter:
  namespaceOverride: monitoring-node-exporter
```

This avoids making the entire monitoring control-plane namespace privileged just because node-exporter needs host access.

## NetworkPolicy Considerations

RKE2 CIS profile creates NetworkPolicies for Kubernetes built-in namespaces, but custom namespaces remain an operator responsibility.

The current repository already owns NetworkPolicy packages for:

- `segment1`
- `opkeycloak`
- `oppostgres`

This change intentionally does **not** impose generic default-deny policies on MetalLB, Longhorn, or node-exporter. Those components have host networking, CSI, webhook, node-level, and metrics communication paths that must be modeled explicitly before deny-by-default is enabled.

The next network-policy phase should:

1. Inventory pod-to-pod, pod-to-node, Kubernetes API, DNS, webhook, storage, metrics, and external registry flows.
2. Render policies from the exact packaged chart versions.
3. Validate them in a non-production CIS-enabled cluster.
4. Enable default-deny only after positive-path and failure-path testing.

## Deployment Order

The normal deployment order remains unchanged. CIS namespace policy is applied by each installer before workload pods are created.

```bash
scripts/core/02-install-blreopdev-cert-manager.sh blre opdev
scripts/core/03-install-blreopdev-metallb.sh blre opdev
scripts/core/04-install-blreopdev-seg1-ingress.sh blre opdev
scripts/core/05-install-blreopdev-longhorn-storage.sh blre opdev

scripts/opkeycloak/00-install-oppostgres-cnpg-operator.sh blre opdev
scripts/opkeycloak/01-install-oppostgres-cnpg-keycloak-db.sh blre opdev
scripts/opkeycloak/02-install-opkeycloak-operator.sh blre opdev
scripts/opkeycloak/03-install-opkeycloak.sh blre opdev

scripts/monitoring/01-install-prometheus-agents.sh blre opdev
```

## Validation

Run after all platform components are deployed:

```bash
bash scripts/security/01-verify-blreopdev-cis-readiness.sh blre opdev
```

The verifier checks:

- expected `enforce`, `audit`, and `warn` PSA labels;
- repository CIS management labels;
- explicit privileged-exception labels;
- `automountServiceAccountToken: false` on each namespace's `default` ServiceAccount;
- host namespaces and `hostPath` use in restricted namespaces;
- privileged containers;
- privilege escalation;
- non-root execution;
- seccomp profile; and
- dropped and added capabilities.

A nonzero exit code means the deployment is not ready to be accepted under this repository's CIS policy contract.

## Rollout Plan

### Phase 1 - Node bootstrap validation

- Confirm all RKE2 servers and agents are built from the intended `rke2-node-init` flow.
- Confirm server nodes have the host-level `etcd` user/group before RKE2 startup.
- Confirm CIS sysctls are applied before RKE2 starts.
- Confirm generated RKE2 configuration contains `profile: cis`.
- Confirm all nodes become `Ready` without `protect-kernel-defaults` failures.

### Phase 2 - Namespace admission policy

- Deploy using the updated installers.
- Verify all eight namespace PSA profiles.
- Verify privileged exceptions are only `metallb-system`, `longhorn-system`, and `monitoring-node-exporter` unless a separately approved waiver exists.
- Verify default ServiceAccount token automount is disabled.

### Phase 3 - Workload runtime verification

- Validate cert-manager under restricted PSA.
- Validate Contour/Envoy under restricted PSA.
- Validate CNPG PostgreSQL and PgBouncer under restricted PSA.
- Validate Keycloak operator and Keycloak pods under restricted PSA.
- Validate Prometheus Agent/operator and kube-state-metrics under restricted PSA.
- Validate MetalLB networking, Longhorn storage behavior, and node-exporter metrics under their explicit privileged exceptions.

### Phase 4 - NetworkPolicy expansion

- Traffic-map cert-manager, MetalLB, Longhorn, and monitoring.
- Add narrowly scoped policies only after communication paths are verified.
- Re-run end-to-end service, storage, ingress, identity, metrics, and HA tests.

### Phase 5 - Acceptance evidence

Capture and retain:

- RKE2 server/agent configuration showing `profile: cis`.
- Node readiness and RKE2 service health.
- Namespace labels.
- Default ServiceAccount settings.
- CIS readiness verifier output.
- MetalLB reachability tests.
- Contour/Envoy ingress tests.
- Longhorn PVC, attach, mount, snapshot, and failover tests.
- OPPostgreSQL HA/PgBouncer verification output.
- OPKeycloak login and backend connectivity tests.
- Prometheus Agent and node-exporter scrape health.
- CIS benchmark scan results appropriate to the deployed RKE2/Kubernetes version.

## Acceptance Criteria

The BLREOPDEV platform is ready for acceptance under this repository's CIS contract when:

1. All RKE2 nodes are healthy under `profile: cis`.
2. All eight managed namespaces have the expected PSA labels.
3. Only the three documented privileged namespaces are exempted.
4. Every managed namespace's `default` ServiceAccount has token automount disabled.
5. Restricted namespaces pass the runtime pod-security verifier.
6. Core networking, storage, ingress, identity, database HA, and monitoring tests pass.
7. The deployment evidence is captured for operational and security review.
