# K8MM-BLREOPDEV-Cluster System Design Diagrams

Version: 0.9.0  
Date: July 8, 2026  
Cluster name: blreopdev-cluster  
Operational context: blreopdev

This document contains the active system design drawings for the `k8mm-blreopdev-cluster` repository branch.

## Diagram 1: System Overview

```mermaid
flowchart TB
    title["K8s Mystical Mesh<br/>BLRE-OnPrem / Segment 1<br/>Cluster: blreopdev-cluster"]

    subgraph BLRE["BLRE-OnPrem"]
        direction LR

        subgraph RKE2["RKE2 Cluster<br/>name: blreopdev-cluster<br/>context: blreopdev"]
            direction TB

            subgraph CP["Control Plane"]
                direction LR
                CTRL01["BLREOPDEV-CTRL01<br/>RKE2 server / etcd"]
                CTRL02["BLREOPDEV-CTRL02<br/>RKE2 server / etcd"]
                CTRL03["BLREOPDEV-CTRL03<br/>RKE2 server / etcd"]
            end

            API["Kubernetes API<br/>6443"]

            subgraph WP["Workload Plane"]
                direction LR
                WORK01["BLREOPDEV-WORK01<br/>worker workloads"]
                WORK02["BLREOPDEV-WORK02<br/>worker workloads"]
                WORK03["BLREOPDEV-WORK03<br/>worker workloads"]
            end

            subgraph Platform["Platform Services"]
                direction LR
                MetalLB["MetalLB<br/>Segment 1 VIPs"]
                Contour["Contour / Envoy<br/>segment1 ingress"]
                Longhorn["Longhorn<br/>distributed storage"]
                CertManager["cert-manager<br/>internal PKI"]
            end
        end

        subgraph Mgmt["Management / Registry"]
            direction TB
            KubeAdmin["KUBEADMIN<br/>cluster administration<br/>kubectl + helm"]
            LonghornUI["Longhorn Management UI"]
            KubeHarbor["KUBEHARBOR<br/>private registry<br/>kubeharbor.dev.kube"]
        end
    end

    subgraph PublishedServices["Published Services"]
        direction TB
        LonghornSvc["longhorn.dev.jde.cybercom.ic.gov"]
        KeycloakSvc["keycloak.dev.jde.cybercom.ic.gov"]
    end

    title --- BLRE
    CTRL01 <-->|etcd quorum| CTRL02
    CTRL02 <-->|etcd quorum| CTRL03
    API --> CTRL01
    API --> CTRL02
    API --> CTRL03
    API --> WORK01
    API --> WORK02
    API --> WORK03
    KubeAdmin -->|admin path| API
    KubeHarbor -->|image pulls<br/>regcred-kubeharbor| CTRL01
    KubeHarbor -->|image pulls<br/>regcred-kubeharbor| WORK01
    KubeHarbor -->|image pulls<br/>regcred-kubeharbor| WORK02
    KubeHarbor -->|image pulls<br/>regcred-kubeharbor| WORK03
    WORK01 --> Longhorn
    WORK02 --> Contour
    WORK03 --> CertManager
    MetalLB --> Contour
    Contour --> LonghornSvc
    Contour --> KeycloakSvc
    LonghornUI --> Longhorn
```

> Diagram export: [SVG](../diagrams/svg/blreopdev-system-overview.svg) | [PNG](../diagrams/png/blreopdev-system-overview.png)

## Diagram 2: Services Overview - PostgreSQL / Keycloak HA

```mermaid
flowchart TB
    title["BLREOPDEV Services Overview<br/>PostgreSQL / Keycloak HA<br/>Cluster: blreopdev-cluster"]

    subgraph BLRE["BLRE-OnPrem / Segment 1"]
        direction LR

        subgraph RKE2["RKE2 Cluster<br/>name: blreopdev-cluster<br/>context: blreopdev"]
            direction TB

            subgraph IngressPlane["Ingress / Service Exposure"]
                direction LR
                MetalLB["MetalLB<br/>Segment 1 VIP"]
                Envoy["Contour Envoy<br/>segment1 ingress"]
                HTTPProxy["HTTPProxy<br/>keycloak.dev.jde.cybercom.ic.gov"]
                TLS["TLS secret<br/>cert-manager issued"]
            end

            subgraph WorkloadPlane["Workload Plane"]
                direction LR

                subgraph KCNS["namespace: opkeycloak"]
                    direction TB
                    KCService["opkeycloak-service<br/>8080"]
                    KC1["Keycloak pod 01"]
                    KC2["Keycloak pod 02"]
                    KC3["Keycloak pod 03"]
                    KCSecrets["bootstrap admin + DB credentials"]
                    KCHA["HA policy<br/>3 instances + anti-affinity<br/>topology spread + PDB"]
                end

                subgraph PGNS["namespace: oppostgres"]
                    direction TB
                    CNPGOperator["CloudNativePG operator"]
                    CNPGCluster["CNPG Cluster<br/>oppostgres-opkeycloak-db"]
                    RWSvc["RW service<br/>oppostgres-opkeycloak-db-rw:5432"]
                    PG1["PostgreSQL primary"]
                    PG2["PostgreSQL replica 01"]
                    PG3["PostgreSQL replica 02"]
                    PGHA["HA policy<br/>automatic failover<br/>streaming replication"]
                end
            end

            subgraph StorageMonitoring["Storage / Observability"]
                direction LR
                Longhorn["Longhorn StorageClass<br/>longhorn-postgres-ha"]
                PromAgent["Prometheus Agent<br/>ServiceMonitor + PodMonitor"]
                Alerts["PostgreSQL / Keycloak alerts"]
            end
        end
    end

    title --- BLRE
    MetalLB --> Envoy
    Envoy --> HTTPProxy
    TLS --> HTTPProxy
    HTTPProxy --> KCService
    KCService --> KC1
    KCService --> KC2
    KCService --> KC3
    KCSecrets --> KC1
    KCSecrets --> KC2
    KCSecrets --> KC3
    KCHA -.scheduling guardrails.-> KC1
    KCHA -.scheduling guardrails.-> KC2
    KCHA -.scheduling guardrails.-> KC3
    KC1 -->|JDBC 5432| RWSvc
    KC2 -->|JDBC 5432| RWSvc
    KC3 -->|JDBC 5432| RWSvc
    CNPGOperator --> CNPGCluster
    CNPGCluster --> PG1
    CNPGCluster --> PG2
    CNPGCluster --> PG3
    RWSvc --> PG1
    PG1 <-->|streaming replication| PG2
    PG1 <-->|streaming replication| PG3
    PGHA -.failover control.-> CNPGCluster
    PG1 --> Longhorn
    PG2 --> Longhorn
    PG3 --> Longhorn
    PromAgent --> KCService
    PromAgent --> CNPGCluster
    Alerts --> PromAgent
```

> Diagram export: [SVG](../diagrams/svg/blreopdev-services-overview.svg) | [PNG](../diagrams/png/blreopdev-services-overview.png)

## Diagram 3: Platform Overview

```mermaid
%% BLRE On-Prem Development Kubernetes Platform

flowchart TB
    classDef external fill:#f8fafc,stroke:#64748b,stroke-width:1px,color:#0f172a
    classDef platform fill:#e0f2fe,stroke:#0284c7,stroke-width:1.5px,color:#082f49
    classDef plane fill:#dbeafe,stroke:#1d4ed8,stroke-width:1.5px,color:#172554
    classDef service fill:#dcfce7,stroke:#16a34a,stroke-width:1.5px,color:#052e16
    classDef app fill:#fef3c7,stroke:#d97706,stroke-width:1.5px,color:#451a03

    %%API["Kubernetes API<br/>6443"]:::platform

        subgraph Management["Management"]
            direction TB
            KubeAdmin["KUBEADMIN<br/>kubectl + helm"]:::external
            KubeHarbor["KUBEHARBOR<br/>private registry"]:::external
        end

    subgraph BLRE["BLOODREAPER On-Prem"]
        direction TB
            subgraph CoreServices["Core Services"]
                direction TB
                MetalLB["MetalLB<br/>Segment 1 VIPs"]:::service
                Envoy["Contour / Envoy<br/>restricted ingress"]:::service
                Longhorn["Longhorn<br/>distributed storage"]:::service
                CertManager["cert-manager<br/>internal PKI"]:::service
                Prometheus["Monitoring Agent<br/>remote write"]:::service
            end
%%            subgraph CoreServices["Core Platform Services"]
%%                direction TB
%%                MetalLB["MetalLB<br/>Segment 1 VIPs"]:::service
%%                Envoy["Contour / Envoy<br/>restricted ingress"]:::service
%%                Longhorn["Longhorn<br/>distributed storage"]:::service
%%                CertManager["cert-manager<br/>internal PKI"]:::service
%%                Prometheus["Monitoring Agent<br/>remote write"]:::service
%%            end


            subgraph ControlPlane["Control Plane / etcd Quorum"]
                direction LR
                CTRL01["RKE2 server + etcd"]:::plane
                CTRL02["RKE2 server + etcd"]:::plane
                CTRL03["RKE2 server + etcd"]:::plane
            end

            subgraph WorkloadPlane["Workload Plane"]
                direction LR
                WORK01["RKE2 worker"]:::plane
                WORK02["RKE2 worker"]:::plane
                WORK03["RKE2 worker"]:::plane
            end
    end

    Published["Published Platform Services<br/>OPKeycloak + Longhorn UI"]:::app
    CentralMonitoring["Central Monitoring Endpoint<br/>remote write target"]:::external


    ControlPlane -->|control| CoreServices
    WorkloadPlane -->|workload| CoreServices

    Management -->|administration| BLRE
    BLRE -->|services| Published
    BLRE -->|monitoring| CentralMonitoring

    %%CTRL01 <-->|etcd quorum| CTRL02
    %%CTRL02 <-->|etcd quorum| CTRL03

    %%KubeAdmin -->|administration path| API
    %%KubeHarbor -->|disconnected image pulls| RKE2
    %%MetalLB --> Envoy
    %%Envoy --> Published
    %%Longhorn --> WorkloadPlane
    %%CertManager --> Envoy
    %%Montitor_Agent -->|remote write| CentralMonitoring
```

> Diagram export: [SVG](../diagrams/svg/blreopdev-platform-overview.svg) | [PNG](../diagrams/png/blreopdev-platform-overview.png)

## Diagram 4: Services Overview - PostgreSQL / Keycloak HA

```mermaid
flowchart TB
    classDef external fill:#f8fafc,stroke:#64748b,stroke-width:1px,color:#0f172a
    classDef ingress fill:#e0f2fe,stroke:#0284c7,stroke-width:1.5px,color:#082f49
    classDef app fill:#dcfce7,stroke:#16a34a,stroke-width:1.5px,color:#052e16
    classDef data fill:#fef3c7,stroke:#d97706,stroke-width:1.5px,color:#451a03
    classDef storage fill:#ede9fe,stroke:#7c3aed,stroke-width:1.5px,color:#2e1065
    classDef guardrail fill:#fee2e2,stroke:#dc2626,stroke-width:1.5px,color:#450a0a
    classDef hidden fill:transparent,stroke:transparent,color:transparent

    subgraph Applications["Applications & Services"]
        direction TB
        KeycloakAPP["Keycloak"]:::app
    end

        subgraph Ingress["namespace: ingress"]
            direction TB

              subgraph InPods["Contour HTTPProxy"]
                    VIP["MetalLB VIP"]:::ingress
                    TLS["cert-manager TLS Secret"]:::ingress
                    Envoy["Contour / Envoy<br/>HTTPProxy"]:::ingress
                    VIP --> Envoy
                    TLS --> Envoy
              end
        end

    subgraph Runtime["Runtime Tier"]
        direction LR

        subgraph LeftColumn["namespace: keycloak"]
            direction TB
            LeftAnchor[" "]:::hidden

                subgraph KCPods["Keycloak HA Set"]
                    direction TB
                    KC1["Replica 01"]:::app
                    KC2["Replica 02"]:::app
                    KC3["Replica 03"]:::app
                end
        end

        subgraph RightColumn["namespace: postgres"]
            direction TB
            RightAnchor[" "]:::hidden

%%            subgraph postgres["PgBouncer RW Service<br/>TCP 5432"]
%%                direction TB

                subgraph PgBouncer["PgBouncer HA Access Tier"]
                    direction TB
                    PB1["PgBouncer 01"]:::data
                    PB2["PgBouncer 02"]:::data
                    PB3["PgBouncer 03"]:::data
                end

                subgraph PGPods["PostgreSQL HA Database"]
                    direction TB
                    PG1["Primary"]:::data
                    PG2["Replica 01"]:::data
                    PG3["Replica 02"]:::data
                end

                %%PGSafety["Synchronous replication<br/>Required anti-affinity<br/>CNPG failover"]:::guardrail

                %%PgSvc --> PB1
                %%PgSvc --> PB2
                %%PgSvc --> PB3
                %%PB1 --> PG1
                %%PB2 --> PG1
                %%PB3 --> PG1
                %%PG1 <-->|streaming replication| PG2
                %%PG1 <-->|streaming replication| PG3
                %%PGSafety -.-> PG1
            end

        end
            Monitoring["Monitoring Agent<br/>Keycloak + CNPG metrics"]:::external
            Longhorn["Longhorn StorageClass<br/>longhorn-postgres-ha"]:::storage

        LeftAnchor ~~~ RightAnchor
%%    end

    
    PgBouncer -->|jdbc 5432| PGPods
    KeycloakAPP -->|https| Envoy
    Ingress -->|ingress| LeftColumn
    KCPods --->|jdbc 5432| PgBouncer
    Runtime -->|observability| Monitoring
    Runtime -->|storage/backup| Longhorn
```

> Diagram export: [SVG](../diagrams/svg/blreopdev-services-keycloak-postgres-overview.svg) | [PNG](../diagrams/png/blreopdev-services-keycloak-postgres-overview.png)
