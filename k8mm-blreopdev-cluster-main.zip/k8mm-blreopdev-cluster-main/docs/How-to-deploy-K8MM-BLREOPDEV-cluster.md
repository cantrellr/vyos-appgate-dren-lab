# How to Deploy K8MM-BLREOPDEV-Cluster

Version: 0.11.0  
Date: July 10, 2026  
Cluster name: blreopdev-cluster  
Operational context: blreopdev

This is the current deployment runbook for the single RKE2 multi-node cluster managed by this repo.

## 1. Administrator Workstation Prerequisites

Use the KUBEADMIN administration host with:

```bash
sudo apt-get update
sudo apt-get install -y bash curl git jq yq unzip python3 python3-yaml openssl ca-certificates kubectl helm
```

Required access:

- kubectl context blreopdev
- RKE2 cluster name blreopdev-cluster
- pull access to the KUBEHARBOR registry
- local clone of this repository
- local packaged Helm charts under helm/packages

Validate cluster access:

```bash
kubectl --context blreopdev get nodes -o wide
kubectl --context blreopdev get pods -A
```

## 2. CIS Bootstrap Preflight

When this cluster is deployed with the RKE2 CIS profile, confirm the node bootstrap layer is complete before installing workloads.

Required gates:

- RKE2 configuration contains `profile: cis`.
- CIS kernel parameters were applied before RKE2 started.
- The host-level `etcd` user/group exists on every RKE2 server node.
- All control-plane and worker nodes are `Ready` without `protect-kernel-defaults` failures.

This repository does not remediate the host operating system. It owns workload namespace PSA labels, default ServiceAccount token posture, workload security contexts, and runtime validation after Kubernetes is available.

See:

```text
docs/CIS-Readiness.md
```

## 3. Registry Pull Secret Bootstrap

Create or rotate the registry pull secret before installing workloads:

```bash
scripts/core/00-bootstrap-blreopdev-kubeharbor-regcred.sh blre opdev --sync-default-namespaces
```

Validate:

```bash
kubectl --context blreopdev -n kube-system get secret regcred-kubeharbor
```

## 4. Core Platform Services

Install core services in this order:

```bash
scripts/core/01-patch-blreopdev-coredns.sh blre opdev
scripts/core/02-install-blreopdev-cert-manager.sh blre opdev
scripts/core/03-install-blreopdev-metallb.sh blre opdev
scripts/core/04-install-blreopdev-seg1-ingress.sh blre opdev
scripts/core/05-install-blreopdev-longhorn-storage.sh blre opdev
```

The installers apply this CIS/PSA namespace contract before workload pods are created:

| Namespace | PSA profile |
| --- | --- |
| `cert-manager` | `restricted` |
| `metallb-system` | `privileged` exception |
| `segment1` | `restricted` |
| `longhorn-system` | `privileged` exception |

Validate:

```bash
kubectl --context blreopdev get pods -A | egrep 'cert-manager|metallb|segment1|longhorn' || true
kubectl --context blreopdev get storageclass
kubectl --context blreopdev get ingressclass
```

## 5. OPPostgreSQL and OPKeycloak

Install the CloudNativePG operator, PostgreSQL HA database with PgBouncer, Keycloak operator, and Keycloak custom resource:

```bash
scripts/opkeycloak/00-install-oppostgres-cnpg-operator.sh blre opdev
scripts/opkeycloak/01-install-oppostgres-cnpg-keycloak-db.sh blre opdev
scripts/opkeycloak/02-install-opkeycloak-operator.sh blre opdev
scripts/opkeycloak/03-install-opkeycloak.sh blre opdev
```

Both `oppostgres` and `opkeycloak` are configured for `restricted` PSA enforcement.

The database and Keycloak installers automatically invoke:

```bash
scripts/opkeycloak/00-prepare-opkeycloak-runtime-secrets.sh blre opdev
```

That script creates credentials only when absent, preserves them on reruns, mirrors the PostgreSQL application credential from `oppostgres` into `opkeycloak`, never prints password values, and also enforces the CIS namespace posture when run directly. No database or Keycloak bootstrap password is stored in Git.

The Keycloak operator installer renders the generated operator manifest through:

```text
scripts/security/render-keycloak-operator-cis.py
```

The renderer adds Restricted-PSS-compatible pod and container security contexts without modifying the upstream-generated source manifest in place.

Validate:

```bash
kubectl --context blreopdev -n oppostgres get cluster,pooler,pods,svc,pdb
kubectl --context blreopdev -n opkeycloak get pods,svc,httpproxy
```

Expected application database endpoint:

```text
oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432
```

The direct CNPG RW service below is an internal PgBouncer backend and is not the OPKeycloak application endpoint:

```text
oppostgres-opkeycloak-db-rw.oppostgres.svc.cluster.local:5432
```

## 6. OPKeycloak and OPPostgreSQL NetworkPolicies

Apply all OPKeycloak, PgBouncer, and OPPostgreSQL policies through the single policy script:

```bash
scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh apply
```

Validate:

```bash
kubectl --context blreopdev get networkpolicy -A | grep -E 'opkeycloak|oppostgres'
```

The intended application path is:

```text
OPKeycloak -> PgBouncer -> CNPG PostgreSQL primary
```

Direct OPKeycloak-to-CNPG database traffic is not allowed by the policy package.

To remove the package:

```bash
scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh delete
```

## 7. OPPostgreSQL HA Validation

Run the CNPG validation script:

```bash
scripts/opkeycloak/05-verify-cnpg-ha.sh blre opdev
```

The script validates:

- all three PostgreSQL instances are ready;
- all three PgBouncer instances are available;
- the database credential Secret matches across `oppostgres` and `opkeycloak` without printing the values;
- the Keycloak CR points to the PgBouncer service;
- an authenticated SQL query through PgBouncer succeeds; and
- the temporary database test pod is compatible with Restricted PSS.

## 8. Prometheus Agent Monitoring

Install the Prometheus Agent after cert-manager and workload CRDs are ready:

```bash
scripts/monitoring/01-install-prometheus-agents.sh blre opdev
```

The monitoring installer applies this least-privilege namespace split:

| Namespace | Component | PSA profile |
| --- | --- | --- |
| `monitoring` | Prometheus Agent/operator and kube-state-metrics | `restricted` |
| `monitoring-node-exporter` | node-exporter | `privileged` exception |

The packaged kube-prometheus-stack 82.1.0 chart uses prometheus-node-exporter 4.51.1, which supports `namespaceOverride`. Node exporter is isolated because its default deployment uses host networking, host PID namespace, and host filesystem mounts.

The agent remote-writes to:

```text
https://blreopdev-prometheus-rw.dev.kube/api/v1/write
```

Validate monitoring resources:

```bash
kubectl --context blreopdev -n monitoring get pods,prometheus
kubectl --context blreopdev -n monitoring-node-exporter get pods
kubectl --context blreopdev -n oppostgres get podmonitor,prometheusrule
kubectl --context blreopdev get servicemonitor,podmonitor,prometheusrule -A
```

## 9. Platform Metrics Enablement

After the Prometheus Agent is installed, enable ServiceMonitor integrations for pre-existing platform services:

```bash
scripts/monitoring/02-enable-platform-metrics-after-prometheus.sh blre opdev
```

Validate:

```bash
kubectl --context blreopdev get servicemonitor -A | egrep 'cert|metallb|contour|envoy|coredns' || true
```

## 10. CIS Workload Readiness Validation

After core services, OPPostgreSQL, OPKeycloak, and monitoring are deployed, run:

```bash
bash scripts/security/01-verify-blreopdev-cis-readiness.sh blre opdev
```

The verifier checks:

- expected PSA `enforce`, `audit`, and `warn` labels for all eight managed namespaces;
- explicit privileged-exception labels;
- `automountServiceAccountToken: false` on every managed namespace's `default` ServiceAccount;
- host namespace and `hostPath` violations in restricted namespaces;
- privileged execution and privilege escalation;
- non-root execution;
- seccomp posture; and
- Linux capability drops/additions.

A nonzero exit code is an acceptance blocker.

## 11. Active Helm Packages

The active scripts reference these local chart packages:

- cert-manager-1.5.14.tgz
- metallb-0.15.2.tgz
- contour-21.1.4.tgz
- longhorn-1.12.0.tgz
- cloudnative-pg-0.29.0.tgz
- cluster-0.7.0.tgz
- kube-prometheus-stack-82.1.0.tgz

Treat any other chart archive in helm/packages as unused unless a new active script references it.
