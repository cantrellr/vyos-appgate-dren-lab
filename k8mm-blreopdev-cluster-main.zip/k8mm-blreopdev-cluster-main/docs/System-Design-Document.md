# K8MM-BLREOPDEV-Cluster System Design Document

Version: 0.11.0  
Date: July 10, 2026  
Repo slug: k8mm-blreopdev-cluster  
Cluster name: blreopdev-cluster  
Operational context: blreopdev

## Executive Summary

K8MM-BLREOPDEV-Cluster is a disconnected RKE2 Kubernetes platform baseline for one six-node BLRE-OnPrem Segment 1 cluster named `blreopdev-cluster`.

The current workload focus is OPKeycloak backed by a three-instance CloudNativePG PostgreSQL cluster and a three-instance PgBouncer access tier, with Longhorn distributed storage, Contour/Envoy restricted ingress, runtime-generated credentials, NetworkPolicy segmentation, and Prometheus Agent monitoring.

## Cluster Model

Cluster name: blreopdev-cluster  
Site: blre  
Environment: opdev  
Kubernetes context: blreopdev

Node model:

- BLREOPDEV-CTRL01, BLREOPDEV-CTRL02, BLREOPDEV-CTRL03: RKE2 server/control-plane and etcd quorum.
- BLREOPDEV-WORK01, BLREOPDEV-WORK02, BLREOPDEV-WORK03: RKE2 worker/workload plane.

## Repository Layout

- scripts/: Bash installers and utilities.
- scripts/_lib/common.sh: shared Bash library.
- scripts/core/: core blreopdev platform services.
- scripts/opkeycloak/: ordered OPKeycloak and OPPostgreSQL deployment flow.
- scripts/monitoring/: Prometheus Agent and metrics enablement flow.
- scripts/security/: CIS readiness and workload-security validation.
- yaml/: Kubernetes resources and values files.
- docs/: operator-facing documentation.
- diagrams/: Mermaid source and diagram index metadata.

## System Overview

The System Overview drawing in docs/System-Design-Diagrams.md captures the BLRE-OnPrem Segment 1 layout from the handwritten design: one RKE2 cluster named `blreopdev-cluster`, six nodes, KUBEADMIN, KUBEHARBOR, Longhorn Management UI, and published Longhorn/Keycloak services.

## OPPostgreSQL HA Design

OPPostgreSQL uses CloudNativePG 1.30 through Helm chart `cluster-0.7.0.tgz` to run a three-instance PostgreSQL 17 cluster for Keycloak-backed identity services.

Required values:

- Namespace: oppostgres
- CNPG operator Helm release: oppostgres-operator
- CNPG cluster Helm release: oppostgres
- CNPG Cluster: oppostgres-opkeycloak-db
- Application endpoint: oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432
- Direct CNPG RW backend: oppostgres-opkeycloak-db-rw.oppostgres.svc.cluster.local:5432
- StorageClass: longhorn-postgres-ha
- Client namespace: opkeycloak
- Database: opkeycloak

HA posture:

- Three PostgreSQL instances.
- Required pod anti-affinity on `kubernetes.io/hostname`, preventing two PostgreSQL instances from sharing a node.
- CNPG PodDisruptionBudget enabled.
- Quorum synchronous replication to one standby with `dataDurability: preferred`, preserving synchronous durability while available but prioritizing service continuity when no synchronous standby is available.
- CNPG-managed HA replication slots explicitly enabled.
- `max_slot_wal_keep_size` capped at 10 GB to limit unbounded WAL retention from lagging replication slots.
- Separate 50 Gi PGDATA and 25 Gi WAL volumes per PostgreSQL instance.
- Primary rolling updates use switchover with unsupervised orchestration.

## PgBouncer Database Access Tier

OPKeycloak does not connect directly to the CNPG RW service. All application database traffic follows:

```text
OPKeycloak -> PgBouncer RW service -> CNPG PostgreSQL primary
```

PgBouncer posture:

- Three PgBouncer instances.
- Required hostname anti-affinity.
- `minAvailable: 2` PodDisruptionBudget.
- Session pooling as the conservative compatibility baseline for Keycloak JDBC/Hibernate behavior.
- Private air-gapped PgBouncer image from KUBEHARBOR.
- NetworkPolicy default deny with explicit Keycloak ingress, CNPG egress, and DNS egress.

## Runtime Secret Design

Database and Keycloak bootstrap credentials are not stored in Git.

`scripts/opkeycloak/00-prepare-opkeycloak-runtime-secrets.sh` implements the credential lifecycle:

1. Generate the PostgreSQL application Secret in `oppostgres` only when absent.
2. Preserve an existing Secret on reruns, maintaining installer idempotency and avoiding accidental database-password rotation.
3. Mirror the exact username/password data into a same-named Secret in `opkeycloak`, because Kubernetes Secret references are namespace-scoped.
4. Generate the Keycloak bootstrap administrator Secret only when absent.
5. Verify credential parity without decoding or printing password values.
6. Refuse forced database-secret regeneration while the CNPG cluster exists; live password rotation requires a coordinated database role/password rotation workflow.

## OPKeycloak Design

OPKeycloak runs three instances in the `opkeycloak` namespace and is exposed through Contour HTTPProxy using the `segment1` ingress class.

Required values:

- Namespace: opkeycloak
- Hostname: opkeycloak.dev.jde.cybercom.ic.gov
- Ingress class: segment1
- Backend service: opkeycloak-service
- Backend port: 8080
- Database endpoint: oppostgres-opkeycloak-db-pooler-rw.oppostgres.svc.cluster.local:5432
- Replicas: 3
- Availability posture: anti-affinity, topology spread, PDB, and PostgreSQL-backed cache discovery.

## Monitoring Design

The blreopdev Prometheus Agent is installed from kube-prometheus-stack-82.1.0.tgz with agentMode enabled.

Remote write target:

```text
https://blreopdev-prometheus-rw.dev.kube/api/v1/write
```

Expected scrape coverage:

- Kubernetes nodes and kubelet/cAdvisor from kube-prometheus-stack.
- kube-state-metrics from kube-prometheus-stack.
- node-exporter from kube-prometheus-stack.
- OPPostgreSQL CNPG pods from yaml/oppostgres/resources/oppostgres-monitoring.yaml.
- OPPostgreSQL alerts from yaml/oppostgres/monitoring/oppostgres-cnpg-alerts.yaml.
- OPKeycloak metrics from the Keycloak CR ServiceMonitor setting.

## NetworkPolicy Design

The single enforcement entrypoint is:

```bash
scripts/opkeycloak/04-install-opkeycloak-networkpolicies.sh apply
```

Core policy model:

- segment1 Envoy to OPKeycloak: allow TCP/8080.
- monitoring to OPKeycloak: allow TCP/9000.
- OPKeycloak to PgBouncer: allow TCP/5432 only.
- PgBouncer to CNPG PostgreSQL: allow TCP/5432 only.
- Direct OPKeycloak-to-CNPG database traffic: not allowed.
- OPKeycloak to DNS: allow TCP/UDP 53 to CoreDNS.
- OPKeycloak to on-premises AD DS / Global Catalog: allow TCP/636 and TCP/3269 to the approved directory-server addresses.
- OPPostgreSQL peer traffic: allow TCP/5432 and TCP/8000 among CNPG pods.
- monitoring to OPPostgreSQL: allow TCP/9187.
- CNPG and PgBouncer to DNS: allow TCP/UDP 53 to CoreDNS.
- OPPostgreSQL to Kubernetes API: rendered dynamically by the policy script using the live `kubernetes.default` ClusterIP.

## Active Helm Package Contract

The active deployment scripts reference these packages under helm/packages:

- cert-manager-1.5.14.tgz
- metallb-0.15.2.tgz
- contour-21.1.4.tgz
- longhorn-1.12.0.tgz
- cloudnative-pg-0.29.0.tgz
- cluster-0.7.0.tgz
- kube-prometheus-stack-82.1.0.tgz

Packages outside this list are not part of the active blreopdev deployment contract.

## Known Gaps

- Confirm the final KUBEHARBOR registry FQDN before locking REGISTRY_HOST; the drawing shows kubeharbor.dev.kube.
- Add Grafana dashboards for PostgreSQL HA after metric names are confirmed in the live Prometheus target page.
- Add backup and restore manifests after the object-store target is finalized.
- Add a NetworkPolicy drawing and storage backup drawing as follow-on architecture artifacts.
