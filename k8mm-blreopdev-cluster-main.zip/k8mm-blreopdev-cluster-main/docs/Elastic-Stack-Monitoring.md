# Elastic Stack Monitoring for blreopdev-cluster

## Overview

The active monitoring path for `blreopdev-cluster` is Elastic Stack 9.4.2 through Fleet-managed Elastic Agent. Prometheus and Grafana are not part of the target architecture.

The deployment uses official Helm charts pinned to the ELK environment version, keeps Fleet credentials out of Git, and reuses the same OPDEV CA already trusted by the cluster.

## Version contract

| Component | Version |
| --- | --- |
| Elastic Stack / Fleet | `9.4.2` |
| Elastic Agent image | `9.4.2` |
| Elastic Agent Helm chart source | Elastic Agent tag `v9.4.2`, packaged locally as `elastic-agent-9.4.2.tgz` |
| kube-state-metrics Helm chart | `6.1.0` |
| kube-state-metrics image | `v2.16.0` |

Required KubeHarbor images:

```text
kubeharbor.dev.kube/elastic/elastic-agent:9.4.2
kubeharbor.dev.kube/kube-state-metrics/kube-state-metrics:v2.16.0
```

No additional image is required unless optional chart features are explicitly enabled.

## Architecture

```text
RKE2 nodes
   |
   +--> elastic-agent-system
   |      Fleet-managed Elastic Agent 9.4.2
   |      perNode preset / DaemonSet
   |      PSA: privileged exception
   |
   +--> elastic-agent-cluster-system
   |      Fleet-managed Elastic Agent 9.4.2
   |      clusterWide preset / Deployment
   |      PSA: privileged exception
   |
   +--> elastic-monitoring
          kube-state-metrics 2.16.0
          PSA: restricted

Elastic Agents --> Fleet Server 9.4.2 --> Elasticsearch --> Kibana
```

The cluster-wide Agent is intentionally kept outside the restricted kube-state-metrics namespace. Elastic Agent managed deployments may run as root or require host-level access depending on enabled integrations. The repository therefore uses explicit privileged PSA exceptions for Elastic Agent namespaces rather than claiming restricted compliance that the workload may not satisfy.

## Why three namespaces

| Namespace | Component | PSA profile | Rationale |
| --- | --- | --- | --- |
| `elastic-agent-system` | per-node Elastic Agent DaemonSet | `privileged` | Node-local metrics and host access can require host networking, host paths, and root execution. |
| `elastic-agent-cluster-system` | cluster-wide Elastic Agent Deployment | `privileged` | Keeps the managed Agent outside the restricted namespace and allows Fleet policy evolution without breaking PSA enforcement. |
| `elastic-monitoring` | kube-state-metrics | `restricted` | kube-state-metrics does not need privileged host access and is hardened through chart values. |

The installer uses the repository CIS helper to label each namespace and disables token automounting on the default ServiceAccount.

## Air-gap artifact preparation

Run the following on an Internet-connected host:

```bash
bash scripts/monitoring/00-download-elastic-agent-airgap-artifacts.sh
```

The helper downloads the Elastic Agent source at tag `v9.4.2`, builds the chart dependency tree, packages the chart as production version `9.4.2`, downloads kube-state-metrics chart `6.1.0`, and writes the exact required image list.

Expected Helm packages:

```text
elastic-agent-9.4.2.tgz
kube-state-metrics-6.1.0.tgz
```

Copy both packages into:

```text
helm/packages/
```

The helper also writes:

```text
images/required-images.txt
```

with these source images:

```text
docker.elastic.co/elastic-agent/elastic-agent:9.4.2
registry.k8s.io/kube-state-metrics/kube-state-metrics:v2.16.0
```

Mirror them into KubeHarbor as:

```text
kubeharbor.dev.kube/elastic/elastic-agent:9.4.2
kubeharbor.dev.kube/kube-state-metrics/kube-state-metrics:v2.16.0
```

## Fleet enrollment Secret

The Fleet URL and enrollment token are runtime inputs and are never committed to Git.

Set:

```bash
export FLEET_URL='https://fleet.example.mil:8220'
export FLEET_ENROLLMENT_TOKEN='<token-provided-by-elk-admin>'
export FLEET_INSECURE='false'
```

The installer creates the same Secret name in both Elastic Agent namespaces because Kubernetes Secrets are namespace-scoped:

```text
elastic-agent-fleet-enrollment
```

with keys:

```text
FLEET_URL
FLEET_ENROLLMENT_TOKEN
```

The Helm values reference those Secret keys through the chart's native `urlFromSecret` and `tokenFromSecret` settings.

## Fleet TLS trust and shared OPDEV CA

The ELK administrator confirmed that Fleet Server uses the same CA as `blreopdev-cluster`.

The authoritative CA manifest is:

```text
yaml/resources/devlocal-opdev-ca-bundle-secret-v1.yaml
```

It creates this Kubernetes Secret:

```text
Secret name: devlocal-ca-bundle-secret
CA key:      ca.crt
```

Before installing either Elastic Agent release, the installer applies that existing CA Secret into both Agent namespaces:

```text
elastic-agent-system/devlocal-ca-bundle-secret
elastic-agent-cluster-system/devlocal-ca-bundle-secret
```

Both Elastic Agent values files use the chart-native Fleet CA reference:

```yaml
agent:
  fleet:
    ca:
      valueFromSecret:
        name: devlocal-ca-bundle-secret
        key: ca.crt
```

TLS certificate verification remains enabled by default:

```text
FLEET_INSECURE=false
```

Do not set `FLEET_INSECURE=true` for production merely to bypass certificate validation. The expected production path is validated TLS using the shared devlocal OPDEV CA.

## Installation

Required files:

```text
helm/packages/elastic-agent-9.4.2.tgz
helm/packages/kube-state-metrics-6.1.0.tgz
yaml/monitoring/elastic-agent-per-node-9.4.2-values.yaml
yaml/monitoring/elastic-agent-cluster-wide-9.4.2-values.yaml
yaml/monitoring/kube-state-metrics-6.1.0-values.yaml
yaml/resources/devlocal-opdev-ca-bundle-secret-v1.yaml
```

Run:

```bash
export FLEET_URL='https://fleet.example.mil:8220'
export FLEET_ENROLLMENT_TOKEN='<token-provided-by-elk-admin>'
export FLEET_INSECURE='false'

bash scripts/monitoring/01-install-elastic-agent.sh blre opdev
```

No separate `FLEET_CA_FILE` input is required. The installer reuses `devlocal-ca-bundle-secret` directly.

## Helm releases

The installer creates three releases:

```text
blreopdev-elastic-node
blreopdev-elastic-cluster
blreopdev-kube-state-metrics
```

The Elastic Agent releases use the official Elastic Agent 9.4.2 chart with different Fleet presets:

```text
perNode      -> DaemonSet
clusterWide  -> Deployment
```

The bundled kube-state-metrics dependency is disabled in both Elastic Agent releases. kube-state-metrics is installed separately from its official 6.1.0 chart so it can remain in the restricted `elastic-monitoring` namespace.

## Fleet policy requirements

The enrollment token must map to an Elastic Agent policy containing the Kubernetes integration.

Configure cluster-wide state collection to use:

```text
http://kube-state-metrics.elastic-monitoring.svc.cluster.local:8080
```

Keep node-local kubelet/system datasets assigned to per-node Agents and cluster-wide Kubernetes state datasets assigned to the cluster-wide Agent.

This repository is scoped to metrics. Do not enable broad container log ingestion unless it is an explicit requirement.

## Validation

Check the shared CA Secrets:

```bash
kubectl -n elastic-agent-system get secret devlocal-ca-bundle-secret
kubectl -n elastic-agent-cluster-system get secret devlocal-ca-bundle-secret
```

Check Helm releases:

```bash
helm list -n elastic-agent-system
helm list -n elastic-agent-cluster-system
helm list -n elastic-monitoring
```

Check per-node Agents:

```bash
kubectl -n elastic-agent-system get daemonset,pods -o wide
```

Check the cluster-wide Agent:

```bash
kubectl -n elastic-agent-cluster-system get deployment,pods -o wide
```

Check kube-state-metrics:

```bash
kubectl -n elastic-monitoring get deployment,service,pods -l app.kubernetes.io/name=kube-state-metrics
```

Check Agent logs:

```bash
kubectl -n elastic-agent-system logs daemonset/blreopdev-elastic-node-elastic-agent --tail=200
```

Exact workload names can vary by chart naming logic; use `kubectl get daemonset,deployment -A | grep elastic` to discover rendered names if needed.

Validate enrollment in Kibana under Fleet > Agents and confirm Kubernetes metrics arrive in the expected Elastic data streams.

## Operational guidance

- Pin Elastic Agent to `9.4.2` to match the enterprise ELK environment.
- Use a dedicated Fleet policy for `blreopdev-cluster` or clusters with identical collection requirements.
- Keep Fleet tokens and output credentials out of Git.
- Preserve TLS verification and reuse the shared devlocal OPDEV CA instead of introducing duplicate CA Secrets.
- Mirror only the two required images unless optional features are deliberately enabled.
- Revalidate image inventory whenever the chart version or enabled features change.