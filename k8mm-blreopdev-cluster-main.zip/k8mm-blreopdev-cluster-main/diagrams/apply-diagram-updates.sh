#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   bash diagrams/apply-diagram-updates.sh /path/to/k8mm-blreopdev-cluster
#
# Applies the complete diagram synchronization unit:
#   1. Render every canonical Mermaid source to SVG and PNG.
#   2. Synchronize Markdown Mermaid blocks and export links.
#   3. Refresh JSON/Markdown diagram indexes and node/edge metadata.
#   4. Validate sources, consumers, and rendered exports.
#   5. Stage and commit the complete unit when changes exist.

REPO_DIR="${1:-}"
if [[ -z "${REPO_DIR}" || ! -d "${REPO_DIR}/.git" ]]; then
  echo "ERROR: Provide the path to a local clone of cantrellr/k8mm-blreopdev-cluster." >&2
  exit 2
fi

REPO_DIR="$(cd "${REPO_DIR}" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${REPO_DIR}"

bash "${SCRIPT_DIR}/render-diagrams.sh" "${REPO_DIR}"

git status --short

git add \
  diagrams/mermaid-source \
  diagrams/svg \
  diagrams/png \
  diagrams/DIAGRAM-INDEX.json \
  diagrams/DIAGRAM-INDEX.md \
  diagrams/README.md \
  diagrams/render-diagrams.sh \
  diagrams/sync-mermaid-markdown.py \
  diagrams/validate-diagram-contract.py \
  diagrams/apply-diagram-updates.sh \
  docs/System-Design-Diagrams.md

if [[ -s .diagram-sync-updated-files.txt ]]; then
  while IFS= read -r file_path; do
    [[ -n "${file_path}" ]] && git add "${file_path}"
  done < .diagram-sync-updated-files.txt
fi
rm -f .diagram-sync-updated-files.txt

if git diff --cached --quiet; then
  echo "No changes staged. Mermaid sources, SVG/PNG exports, indexes, and Markdown are already synchronized."
else
  git commit -m "Synchronize Mermaid diagrams and rendered exports"
fi
