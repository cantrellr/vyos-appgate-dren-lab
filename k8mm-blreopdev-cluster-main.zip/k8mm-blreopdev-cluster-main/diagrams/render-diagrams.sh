#!/usr/bin/env bash
set -euo pipefail

# Render every Mermaid source declared in diagrams/DIAGRAM-INDEX.json to SVG and PNG.
#
# Usage:
#   bash diagrams/render-diagrams.sh /path/to/k8mm-blreopdev-cluster
#
# Optional environment overrides:
#   MMDC_BIN=/path/to/mmdc
#   MERMAID_WIDTH=1568
#   MERMAID_SCALE=1
#   MERMAID_BACKGROUND=transparent
#   PUPPETEER_CONFIG=/path/to/puppeteer-config.json

REPO_DIR="${1:-$(pwd)}"
if [[ ! -d "${REPO_DIR}/.git" ]]; then
  echo "ERROR: ${REPO_DIR} does not look like a Git repository." >&2
  exit 2
fi

REPO_DIR="$(cd "${REPO_DIR}" && pwd)"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INDEX_JSON="${REPO_DIR}/diagrams/DIAGRAM-INDEX.json"

if [[ ! -f "${INDEX_JSON}" ]]; then
  echo "ERROR: Missing diagram index: ${INDEX_JSON}" >&2
  exit 2
fi

MERMAID_WIDTH="${MERMAID_WIDTH:-1568}"
MERMAID_SCALE="${MERMAID_SCALE:-1}"
MERMAID_BACKGROUND="${MERMAID_BACKGROUND:-transparent}"

if [[ -n "${MMDC_BIN:-}" ]]; then
  MMDC_CMD=("${MMDC_BIN}")
elif command -v mmdc >/dev/null 2>&1; then
  MMDC_CMD=(mmdc)
elif command -v npx >/dev/null 2>&1; then
  # Pinned for reproducible local and CI rendering. Existing mmdc installs take precedence.
  MMDC_CMD=(npx --yes @mermaid-js/mermaid-cli@11.16.0)
else
  echo "ERROR: Mermaid CLI was not found. Install mmdc or Node.js/npm so npx can run @mermaid-js/mermaid-cli." >&2
  exit 2
fi

mkdir -p "${REPO_DIR}/diagrams/svg" "${REPO_DIR}/diagrams/png"

MMDC_COMMON_ARGS=(-b "${MERMAID_BACKGROUND}" -w "${MERMAID_WIDTH}")
if [[ -n "${PUPPETEER_CONFIG:-}" ]]; then
  MMDC_COMMON_ARGS+=(-p "${PUPPETEER_CONFIG}")
fi

if ! DIAGRAM_ROWS_RAW="$(
  python3 - "${INDEX_JSON}" <<'PY'
import json
import sys
from pathlib import Path

index_path = Path(sys.argv[1])
entries = json.loads(index_path.read_text(encoding="utf-8"))
for entry in sorted(entries, key=lambda item: item["diagram_number"]):
    base = entry["base_name"]
    source = entry["mermaid_source"]
    svg = entry.get("svg", f"diagrams/svg/{base}.svg")
    png = entry.get("png", f"diagrams/png/{base}.png")
    print(f"{source}\t{svg}\t{png}")
PY
)"; then
  echo "ERROR: Failed to read diagram index: ${INDEX_JSON}" >&2
  exit 2
fi

mapfile -t DIAGRAM_ROWS <<< "${DIAGRAM_ROWS_RAW}"

if [[ ${#DIAGRAM_ROWS[@]} -eq 0 ]]; then
  echo "ERROR: No diagrams are declared in ${INDEX_JSON}." >&2
  exit 2
fi

rendered=0
for row in "${DIAGRAM_ROWS[@]}"; do
  IFS=$'\t' read -r source_rel svg_rel png_rel <<< "${row}"
  source_path="${REPO_DIR}/${source_rel}"
  svg_path="${REPO_DIR}/${svg_rel}"
  png_path="${REPO_DIR}/${png_rel}"

  if [[ ! -s "${source_path}" ]]; then
    echo "ERROR: Missing or empty Mermaid source: ${source_rel}" >&2
    exit 2
  fi

  mkdir -p "$(dirname "${svg_path}")" "$(dirname "${png_path}")"

  echo "Rendering ${source_rel}"
  "${MMDC_CMD[@]}" -i "${source_path}" -o "${svg_path}" "${MMDC_COMMON_ARGS[@]}" -s "${MERMAID_SCALE}"
  "${MMDC_CMD[@]}" -i "${source_path}" -o "${png_path}" "${MMDC_COMMON_ARGS[@]}" -s "${MERMAID_SCALE}"

  if [[ ! -s "${svg_path}" || ! -s "${png_path}" ]]; then
    echo "ERROR: Renderer did not produce both exports for ${source_rel}." >&2
    exit 2
  fi

  rendered=$((rendered + 1))
done

python3 "${SCRIPT_DIR}/sync-mermaid-markdown.py" "${REPO_DIR}"

if [[ -f "${SCRIPT_DIR}/validate-diagram-contract.py" ]]; then
  python3 "${SCRIPT_DIR}/validate-diagram-contract.py" "${REPO_DIR}" --require-exports
fi

echo "Rendered ${rendered} Mermaid diagrams to SVG and PNG."
