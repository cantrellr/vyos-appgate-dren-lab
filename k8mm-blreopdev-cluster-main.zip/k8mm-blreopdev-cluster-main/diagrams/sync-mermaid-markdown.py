#!/usr/bin/env python3
"""Synchronize Mermaid source, Markdown consumers, and diagram export indexes.

The repository contract is:
- diagrams/mermaid-source/*.mmd is canonical.
- diagrams/svg/*.svg and diagrams/png/*.png are generated exports.
- diagrams/DIAGRAM-INDEX.json records source and export paths.
- Markdown consumers embed the canonical Mermaid source and link to both exports.
"""
from __future__ import annotations

import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

MERMAID_BLOCK = re.compile(
    r"```mermaid\n(?P<body>.*?)\n```"
    r"(?:\n\n> Diagram export: \[SVG\]\([^)]+\) \| \[PNG\]\([^)]+\))?",
    flags=re.DOTALL,
)

SKIP_PREFIXES = (
    "%%",
    "flowchart",
    "sequenceDiagram",
    "subgraph",
    "end",
    "direction",
    "participant",
    "Note",
    "style",
    "classDef",
)


def load_index(repo_dir: Path) -> tuple[Path, list[dict]]:
    index_path = repo_dir / "diagrams" / "DIAGRAM-INDEX.json"
    if not index_path.exists():
        raise FileNotFoundError(f"Missing diagram index: {index_path}")
    entries = json.loads(index_path.read_text(encoding="utf-8"))
    return index_path, entries


def normalize_entry(entry: dict) -> None:
    base = entry["base_name"]
    entry.setdefault("svg", f"diagrams/svg/{base}.svg")
    entry.setdefault("png", f"diagrams/png/{base}.png")


def count_nodes_edges(mmd_text: str) -> tuple[int, int]:
    node_ids: set[str] = set()
    edge_count = 0

    for raw_line in mmd_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(SKIP_PREFIXES):
            continue

        node_match = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*[\[\{\(]", line)
        if node_match:
            node_ids.add(node_match.group(1))

        if re.search(r"(<-->|-->|-.+?->|==>|---|->>|-->>|--x|--o)", line):
            edge_count += 1

    return len(node_ids), edge_count


def relative_markdown_link(document: Path, target: Path) -> str:
    return os.path.relpath(target, start=document.parent).replace(os.sep, "/")


def sync_markdown_consumers(repo_dir: Path, entries: list[dict]) -> list[str]:
    changed_files: list[str] = []
    by_source_file: dict[str, list[dict]] = defaultdict(list)

    for entry in entries:
        by_source_file[entry["source_file"]].append(entry)

    for source_file, source_entries in by_source_file.items():
        md_path = repo_dir / source_file
        if not md_path.exists():
            raise FileNotFoundError(f"Missing Markdown consumer: {md_path}")

        source_entries.sort(key=lambda item: item["diagram_number"])
        original = md_path.read_text(encoding="utf-8")
        matches = list(MERMAID_BLOCK.finditer(original))

        if len(matches) != len(source_entries):
            raise ValueError(
                f"{source_file} contains {len(matches)} Mermaid blocks, "
                f"but the diagram index declares {len(source_entries)} diagrams for that file."
            )

        replacements: list[str] = []
        for entry in source_entries:
            source_path = repo_dir / entry["mermaid_source"]
            if not source_path.exists():
                raise FileNotFoundError(f"Missing Mermaid source: {source_path}")

            source_body = source_path.read_text(encoding="utf-8").strip()
            svg_link = relative_markdown_link(md_path, repo_dir / entry["svg"])
            png_link = relative_markdown_link(md_path, repo_dir / entry["png"])
            replacements.append(
                "```mermaid\n"
                + source_body
                + "\n```\n\n"
                + f"> Diagram export: [SVG]({svg_link}) | [PNG]({png_link})"
            )

        output: list[str] = []
        cursor = 0
        for match, replacement in zip(matches, replacements):
            output.append(original[cursor : match.start()])
            output.append(replacement)
            cursor = match.end()
        output.append(original[cursor:])
        updated = "".join(output)

        if updated != original:
            md_path.write_text(updated, encoding="utf-8")
            changed_files.append(str(md_path.relative_to(repo_dir)))

    return changed_files


def refresh_indexes(repo_dir: Path, index_path: Path, entries: list[dict]) -> list[str]:
    changed_files: list[str] = []
    original_json = index_path.read_text(encoding="utf-8")

    for entry in entries:
        normalize_entry(entry)
        source_path = repo_dir / entry["mermaid_source"]
        if not source_path.exists():
            raise FileNotFoundError(f"Missing Mermaid source: {source_path}")
        nodes, edges = count_nodes_edges(source_path.read_text(encoding="utf-8"))
        entry["nodes"] = nodes
        entry["edges"] = edges

    entries.sort(key=lambda item: item["diagram_number"])
    updated_json = json.dumps(entries, indent=2) + "\n"
    if updated_json != original_json:
        index_path.write_text(updated_json, encoding="utf-8")
        changed_files.append(str(index_path.relative_to(repo_dir)))

    index_md = repo_dir / "diagrams" / "DIAGRAM-INDEX.md"
    original_md = index_md.read_text(encoding="utf-8") if index_md.exists() else ""
    lines = [
        "# Diagram Export Index",
        "",
        "Mermaid sources are canonical under `diagrams/mermaid-source/`; SVG and PNG files are generated exports.",
        "",
        "| Source file | Diagram | Title | Mermaid source | SVG | PNG | Nodes | Edges |",
        "| --- | ---: | --- | --- | --- | --- | ---: | ---: |",
    ]

    for entry in entries:
        base = entry["base_name"]
        lines.append(
            f"| `{entry['source_file']}` | {entry['diagram_number']} | {entry.get('title', base)} | "
            f"[`{base}.mmd`](mermaid-source/{base}.mmd) | "
            f"[SVG](svg/{base}.svg) | [PNG](png/{base}.png) | "
            f"{entry['nodes']} | {entry['edges']} |"
        )

    updated_md = "\n".join(lines) + "\n"
    if updated_md != original_md:
        index_md.write_text(updated_md, encoding="utf-8")
        changed_files.append(str(index_md.relative_to(repo_dir)))

    return changed_files


def main() -> int:
    repo_dir = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd().resolve()
    if not (repo_dir / ".git").exists():
        print(f"ERROR: {repo_dir} does not look like a Git repository.", file=sys.stderr)
        return 2

    try:
        index_path, entries = load_index(repo_dir)
        for entry in entries:
            normalize_entry(entry)

        changed: list[str] = []
        changed.extend(sync_markdown_consumers(repo_dir, entries))
        changed.extend(refresh_indexes(repo_dir, index_path, entries))
    except (FileNotFoundError, KeyError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

    unique_changed = list(dict.fromkeys(changed))
    marker = repo_dir / ".diagram-sync-updated-files.txt"
    marker.write_text("\n".join(unique_changed) + ("\n" if unique_changed else ""), encoding="utf-8")

    if unique_changed:
        print("Updated Markdown/index files:")
        for path in unique_changed:
            print(f"  - {path}")
    else:
        print("No Markdown/index files required changes.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
