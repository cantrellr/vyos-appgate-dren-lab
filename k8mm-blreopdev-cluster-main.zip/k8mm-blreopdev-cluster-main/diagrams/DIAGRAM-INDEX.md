# Diagram Export Index

Mermaid sources are canonical under `diagrams/mermaid-source/`; SVG and PNG files are generated exports.

| Source file | Diagram | Title | Mermaid source | SVG | PNG | Nodes | Edges |
| --- | ---: | --- | --- | --- | --- | ---: | ---: |
| `docs/System-Design-Diagrams.md` | 1 | System Overview | [`blreopdev-system-overview.mmd`](mermaid-source/blreopdev-system-overview.mmd) | [SVG](svg/blreopdev-system-overview.svg) | [PNG](png/blreopdev-system-overview.png) | 17 | 21 |
| `docs/System-Design-Diagrams.md` | 2 | Services Overview - PostgreSQL / Keycloak HA | [`blreopdev-services-overview.mmd`](mermaid-source/blreopdev-services-overview.mmd) | [SVG](svg/blreopdev-services-overview.svg) | [PNG](png/blreopdev-services-overview.png) | 21 | 31 |
| `docs/System-Design-Diagrams.md` | 3 | Platform Overview | [`blreopdev-platform-overview.mmd`](mermaid-source/blreopdev-platform-overview.mmd) | [SVG](svg/blreopdev-platform-overview.svg) | [PNG](png/blreopdev-platform-overview.png) | 15 | 5 |
| `docs/System-Design-Diagrams.md` | 4 | Services Overview - PostgreSQL / Keycloak HA | [`blreopdev-services-keycloak-postgres-overview.mmd`](mermaid-source/blreopdev-services-keycloak-postgres-overview.mmd) | [SVG](svg/blreopdev-services-keycloak-postgres-overview.svg) | [PNG](png/blreopdev-services-keycloak-postgres-overview.png) | 17 | 8 |
