#!/usr/bin/env python3
"""Validate the Mermaid source, Markdown, and optional rendered-export contract."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo_dir", nargs="?", default=".", help="Path to the repository clone")
    parser.add_argument(
        "--require-exports",
        action="store_true",
        help="Require every indexed SVG and PNG export to exist and be non-empty",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo = Path(args.repo_dir).resolve()
    index_path = repo / "diagrams" / "DIAGRAM-INDEX.json"
    errors: list[str] = []

    if not index_path.is_file():
        print(f"ERROR: missing diagram index: {index_path}", file=sys.stderr)
        return 1

    try:
        entries = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: invalid diagram index JSON: {exc}", file=sys.stderr)
        return 1

    source_documents: dict[str, str] = {}

    for entry in entries:
        base = entry.get("base_name", "<unknown>")
        required_keys = ("source_file", "diagram_number", "base_name", "mermaid_source")
        missing_keys = [key for key in required_keys if key not in entry]
        for key in missing_keys:
            errors.append(f"{base}: missing index key: {key}")
        if missing_keys:
            continue

        source_path = repo / entry["mermaid_source"]
        if not source_path.is_file():
            errors.append(f"{base}: missing source: {entry['mermaid_source']}")
        elif not source_path.read_text(encoding="utf-8").strip():
            errors.append(f"{base}: empty source: {entry['mermaid_source']}")

        source_file = entry["source_file"]
        if source_file not in source_documents:
            doc_path = repo / source_file
            source_documents[source_file] = (
                doc_path.read_text(encoding="utf-8") if doc_path.is_file() else ""
            )
            if not source_documents[source_file]:
                errors.append(f"{base}: missing or empty Markdown consumer: {source_file}")

        title = entry.get("title", base)
        if title not in source_documents[source_file]:
            errors.append(f"{base}: diagram title missing from {source_file}: {title}")

        if args.require_exports:
            for export_type in ("svg", "png"):
                export_rel = entry.get(export_type, f"diagrams/{export_type}/{base}.{export_type}")
                export_path = repo / export_rel
                if not export_path.is_file() or export_path.stat().st_size == 0:
                    errors.append(f"{base}: missing or empty {export_type.upper()} export: {export_rel}")

    if errors:
        for error in errors:
            print(f"ERROR: {error}", file=sys.stderr)
        return 1

    export_status = " with SVG/PNG exports" if args.require_exports else ""
    print(f"PASS: {len(entries)} Mermaid diagrams satisfy the repository contract{export_status}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
