# K8MM-BLREOPDEV-Cluster Diagrams

This folder contains the active system drawings for the `blreopdev` RKE2 cluster. Canonical Mermaid source files are rendered to committed SVG and PNG exports so the same architecture content is available through GitHub-native Mermaid rendering and static image formats.

## Diagram contract

- `diagrams/mermaid-source/*.mmd` is the source of truth.
- `diagrams/svg/*.svg` and `diagrams/png/*.png` are generated outputs and must not be edited manually.
- `docs/System-Design-Diagrams.md` embeds the canonical Mermaid source and links to both static exports.
- `diagrams/DIAGRAM-INDEX.json` records source and export paths for automation.
- `diagrams/DIAGRAM-INDEX.md` provides clickable Mermaid, SVG, and PNG links plus node/edge metadata.
- `diagrams/sync-mermaid-markdown.py` keeps Markdown consumers and index metadata synchronized with Mermaid source.
- `diagrams/validate-diagram-contract.py` validates source/document consistency; `--require-exports` also validates rendered SVG/PNG files.

## Current diagram set

1. System Overview
2. Services Overview - PostgreSQL / Keycloak HA

## Recommended next drawings

- NetworkPolicy and traffic boundary drawing
- Storage and backup/restore drawing
- Monitoring and alerting drawing
- Certificate, DNS, and ingress drawing
- Deployment sequence drawing
- Failure-domain and node maintenance drawing

## Render SVG and PNG exports

From a local clone:

```bash
bash diagrams/render-diagrams.sh .
```

The renderer uses `mmdc` when it is already installed. Otherwise, when Node.js/npm is available, it falls back to a pinned Mermaid CLI invocation through `npx`.

Optional environment overrides:

```bash
MMDC_BIN=/path/to/mmdc \
MERMAID_WIDTH=1568 \
MERMAID_SCALE=1 \
MERMAID_BACKGROUND=transparent \
bash diagrams/render-diagrams.sh .
```

For hosts where Puppeteer must use a specific browser configuration:

```bash
PUPPETEER_CONFIG=/path/to/puppeteer-config.json \
bash diagrams/render-diagrams.sh .
```

## Synchronize without rendering

Use this when Mermaid sources already exist and only Markdown/index metadata needs refresh:

```bash
python3 diagrams/sync-mermaid-markdown.py .
python3 diagrams/validate-diagram-contract.py .
```

## Apply the complete update unit

The wrapper renders all indexed diagrams, synchronizes Markdown and indexes, validates the full export contract, stages the complete change set, and creates a local commit when changes exist:

```bash
bash diagrams/apply-diagram-updates.sh .
```

This keeps Mermaid source, static exports, Markdown consumers, and index metadata from drifting independently.
