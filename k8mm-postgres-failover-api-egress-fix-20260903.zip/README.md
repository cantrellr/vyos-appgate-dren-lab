# PostgreSQL failover API-egress correction

## Confirmed failure

The J52 CloudNativePG bootstrap and PgBouncer processes cannot reach the
Kubernetes API Service at `10.96.0.1:443`. The repository's default-deny
policies select all CNPG-managed database, bootstrap, and Pooler pods, but the
allow policies only permit DNS and PostgreSQL traffic. The result is:

- `pgbasebackup` exits before it can read its `Cluster` resource;
- PgBouncer exits before it can read its `Pooler` resource or bind port 5432;
- the J52 cluster remains `Setting up primary` / `NotReady`;
- `opkeycloak-secondary` remains blocked by its `oppostgres-replica` dependency;
- controlled failover cannot pass its warm-standby preflight.

The primary site has the same latent restart exposure. Its current processes
were established before the restrictive policy was applied, so they remain
healthy until a pod is recreated.

## Included repository changes

- `fleet/bundles/51-postgresql-ha-resources/kubernetes-api-networkpolicy.yaml`
  allows CNPG-managed J64 workloads to reach `10.94.0.1:443` and the
  `1.0.0.141-143:6443` API endpoints.
- `fleet/bundles/51-postgresql-replica/chart/templates/networkpolicies.yaml`
  allows CNPG-managed J52 workloads to reach `10.96.0.1:443` and the
  `1.0.0.161-163:6443` API endpoints.
- `scripts/validate-fleet-layout.sh` rejects either missing site-specific API
  exception.
- `docs/TROUBLESHOOTING-AND-SUPPORT.md` documents the failure domain.

Copy the files below `repo-files/` over the same paths in the repository,
commit them, and let Fleet reconcile the commit.

## Immediate J52 recovery before the merge

If the environment needs to recover before Fleet deploys the commit, apply the
same additive policy directly. This does not promote PostgreSQL or change any
identity role.

```bash
kubectl --context j52seg1opdev apply -f - <<'EOF'
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: oppostgres-allow-kubernetes-api
  namespace: oppostgres
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/managed-by: cloudnative-pg
  policyTypes:
    - Egress
  egress:
    - to:
        - ipBlock:
            cidr: 10.96.0.1/32
      ports:
        - protocol: TCP
          port: 443
    - to:
        - ipBlock:
            cidr: 1.0.0.161/32
        - ipBlock:
            cidr: 1.0.0.162/32
        - ipBlock:
            cidr: 1.0.0.163/32
      ports:
        - protocol: TCP
          port: 6443
EOF
```

PgBouncer will recover on its next restart and the active `pgbasebackup` job
will retry API access. Monitor the convergence:

```bash
kubectl --context j52seg1opdev -n oppostgres get pods -w
kubectl --context j52seg1opdev -n oppostgres \
  wait --for=condition=Ready \
  cluster.postgresql.cnpg.io/oppostgres-opkeycloak-db --timeout=30m
./scripts/deploy-platform.sh validate-identity-ha
```

If no new `pgbasebackup` attempt appears within five minutes after the policy
is present, remove only the failed bootstrap Job so the CNPG operator can
recreate it. Do not delete either PVC.

```bash
kubectl --context j52seg1opdev -n oppostgres \
  delete job oppostgres-opkeycloak-db-1-pgbasebackup
```

## Failover gate

Do not initiate failover until `validate-identity-ha` passes and confirms J52
is in recovery mode. For a planned transition:

```bash
IDENTITY_FAILOVER_CONFIRM=j52seg1opdev \
IDENTITY_FAILOVER_MODE=planned \
./scripts/deploy-platform.sh failover-identity
```

The current diagnostic state is a failed standby bootstrap, not a promoted
secondary. Promoting it now would be unsafe.
