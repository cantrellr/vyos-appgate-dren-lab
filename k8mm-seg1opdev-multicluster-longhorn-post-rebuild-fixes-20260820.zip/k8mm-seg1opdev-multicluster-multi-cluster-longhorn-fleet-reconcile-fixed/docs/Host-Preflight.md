# Host preflight

> Documentation baseline: v2.1 — August 20, 2026.

Host preflight validates operating-system dependencies that cannot be managed safely by Fleet. The v2.1 workflow separates dependency installation from cluster onboarding: packages are installed once in the Ubuntu 24.04 amd64 golden image, while deployed nodes are validation-only targets.

## Golden-image package installation

The release artifact is `host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz`. It contains 16 pinned `.deb` packages, an installer, a package manifest, and per-package SHA-256 checksums.

Build or reproduce it on a connected Ubuntu 24.04 amd64 staging host:

```bash
scripts/management/preflight/build-longhorn-host-deps-bundle.sh
sha256sum --check host-packages/longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz.sha256
```

After transferring the archive inside the air gap, install it on the golden image:

```bash
tar -xzf longhorn-host-deps-ubuntu-24.04-amd64-v2.1.tar.gz
cd longhorn-host-deps-ubuntu-24.04-amd64
sudo ./install.sh --verify-only
sudo ./install.sh
```

The installer verifies Ubuntu 24.04/amd64 and all checksums, installs local files with `dpkg`, loads `iscsi_tcp`, enables `iscsid`, validates the required commands, and records the installed manifest under `/var/lib/k8mm`. It does not invoke apt, contact a package repository, or touch the Longhorn data disk.

## Deployed-node validation

```bash
scripts/deploy-platform.sh prepare-longhorn-nodes
# or
scripts/management/preflight/longhorn-storage-preflight.sh --all
```

Use `--context <name>` to target one cluster and `--continue-on-error` to audit every worker in one run.

For each non-control-plane worker, the script:

1. resolves the node InternalIP and connects with strict SSH host-key checking;
2. verifies `open-iscsi`, `nfs-common`, `cryptsetup`, `dmsetup`, and `xfsprogs` are already installed;
3. verifies `iscsiadm`, `mount.nfs`, `cryptsetup`, `dmsetup`, `findmnt`, and `xfs_info`;
4. loads `iscsi_tcp` and ensures `iscsid` is enabled and active;
5. disables active `multipathd` service/socket units because multipath can claim Longhorn devices;
6. verifies `/mnt/k8sdata` is a read-write XFS mount with at least 240 GiB and shared root mount propagation;
7. performs and removes a write probe; and
8. labels the passing node `node.longhorn.io/create-default-disk=true`.

The routine contains no apt call and never formats, partitions, mounts, unmounts, or erases storage. A missing package is a golden-image defect and fails the preflight.

Configuration overrides are `LONGHORN_DATA_PATH`, `LONGHORN_DATA_FILESYSTEM`, and `LONGHORN_MIN_DISK_GIB`.

## Ordering

`onboard` and `all` run Chrony and Longhorn storage validation before Fleet registration. This prevents Longhorn and persistent workloads from reconciling before worker storage is ready.
