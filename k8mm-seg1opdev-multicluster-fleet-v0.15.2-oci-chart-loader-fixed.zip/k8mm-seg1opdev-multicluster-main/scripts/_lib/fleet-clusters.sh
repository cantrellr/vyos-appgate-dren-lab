#!/usr/bin/env bash
# shellcheck shell=bash

# Resolve a Rancher display name to the actual clusters.fleet.cattle.io object.
# Rancher may name that object with an internal c-* ID, so the visible name is
# correlated through the management/provisioning cluster resources when needed.

fleet_cluster_inventory() {
  local context="${1:-${RANCHER_CONTEXT:-j64seg1opman}}"
  local inventory_json=""

  inventory_json="$(kubectl --context "${context}" get clusters.fleet.cattle.io -A -o json 2>/dev/null || true)"
  [[ -n "${inventory_json}" ]] || return 0

  warn "Fleet clusters visible through context ${context}:"
  jq -r '
    .items
    | sort_by(.metadata.namespace, .metadata.name)
    | .[]
    | [
        (.metadata.namespace // "-"),
        (.metadata.name // "-"),
        (.metadata.labels["management.cattle.io/cluster-display-name"] // .spec.displayName // "-"),
        (.metadata.labels["management.cattle.io/cluster-name"] // "-"),
        (.status.agent.lastSeen // "-")
      ]
    | @tsv
  ' <<<"${inventory_json}" | while IFS=$'\t' read -r workspace resource display management_id last_seen; do
    warn "  ${workspace}/${resource} display=${display} management-id=${management_id} last-seen=${last_seen}"
  done
}

fleet_cluster_resource() {
  local namespace="${1:?Fleet workspace namespace is required}"
  local display_name="${2:?Fleet cluster display name is required}"
  local context="${3:-${RANCHER_CONTEXT:-j64seg1opman}}"
  local fleet_json="" management_json="" provisioning_json="" all_fleet_json="" rancher_ids_json=""
  local -a matches=() rancher_ids=() all_matches=()

  require_cmd kubectl
  require_cmd jq

  fleet_json="$(kubectl --context "${context}" -n "${namespace}" get clusters.fleet.cattle.io -o json 2>/dev/null)" || \
    die "Unable to read Fleet clusters in ${namespace} through context ${context}."

  mapfile -t matches < <(jq -r --arg display "${display_name}" '
    [
      .items[]
      | select(
          .metadata.name == $display or
          .spec.displayName == $display or
          .metadata.labels["management.cattle.io/cluster-display-name"] == $display or
          .metadata.annotations["management.cattle.io/cluster-display-name"] == $display or
          .metadata.labels["provisioning.cattle.io/management-cluster-display-name"] == $display or
          .metadata.annotations["provisioning.cattle.io/management-cluster-display-name"] == $display or
          .metadata.labels["kmm.dev/context"] == $display
        )
      | .metadata.name
    ]
    | unique[]
  ' <<<"${fleet_json}")

  if (( ${#matches[@]} == 1 )); then
    printf '%s\n' "${matches[0]}"
    return 0
  fi
  (( ${#matches[@]} == 0 )) || die "Fleet display name ${display_name} matches multiple resources in ${namespace}: ${matches[*]}"

  # fleet-local contains the single Rancher management cluster. Its visible
  # display name may be customized independently of the Fleet resource name.
  if [[ "${namespace}" == "fleet-local" ]] && [[ "$(jq '.items | length' <<<"${fleet_json}")" == "1" ]]; then
    matches=("$(jq -r '.items[0].metadata.name' <<<"${fleet_json}")")
    warn "Using the only Fleet local-cluster resource ${namespace}/${matches[0]} for ${display_name}."
    printf '%s\n' "${matches[0]}"
    return 0
  fi

  # Resolve the visible Rancher name to its internal management cluster ID.
  management_json="$(kubectl --context "${context}" get clusters.management.cattle.io -o json 2>/dev/null || true)"
  if [[ -n "${management_json}" ]]; then
    mapfile -t rancher_ids < <(jq -r --arg display "${display_name}" '
      [
        .items[]
        | select(
            .metadata.name == $display or
            .spec.displayName == $display or
            .metadata.labels["management.cattle.io/cluster-display-name"] == $display or
            .metadata.annotations["management.cattle.io/cluster-display-name"] == $display
          )
        | .metadata.name
      ]
      | unique[]
    ' <<<"${management_json}")
  fi

  provisioning_json="$(kubectl --context "${context}" get clusters.provisioning.cattle.io -A -o json 2>/dev/null || true)"
  if [[ -n "${provisioning_json}" ]]; then
    while IFS= read -r id; do
      [[ -n "${id}" ]] && rancher_ids+=("${id}")
    done < <(jq -r --arg display "${display_name}" '
      [
        .items[]
        | select(
            .metadata.name == $display or
            .metadata.labels["management.cattle.io/cluster-display-name"] == $display or
            .metadata.annotations["provisioning.cattle.io/management-cluster-display-name"] == $display
          )
        | .status.clusterName,
          .metadata.labels["provisioning.cattle.io/management-cluster-name"]
        | select(. != null and . != "")
      ]
      | unique[]
    ' <<<"${provisioning_json}")
  fi

  if (( ${#rancher_ids[@]} > 0 )); then
    rancher_ids_json="$(printf '%s\n' "${rancher_ids[@]}" | sort -u | jq -R -s 'split("\n") | map(select(length > 0))')"
    mapfile -t matches < <(jq -r --argjson ids "${rancher_ids_json}" '
      [
        .items[]
        | .metadata.name as $resource_name
        | (.metadata.labels["management.cattle.io/cluster-name"] // "") as $management_id
        | select(
            (($ids | index($resource_name)) != null) or
            (($ids | index($management_id)) != null)
          )
        | .metadata.name
      ]
      | unique[]
    ' <<<"${fleet_json}")
  fi

  if (( ${#matches[@]} == 1 )); then
    warn "Resolved Rancher cluster ${display_name} to Fleet resource ${namespace}/${matches[0]}."
    printf '%s\n' "${matches[0]}"
    return 0
  fi
  (( ${#matches[@]} == 0 )) || die "Rancher cluster ${display_name} maps to multiple Fleet resources in ${namespace}: ${matches[*]}"

  all_fleet_json="$(kubectl --context "${context}" get clusters.fleet.cattle.io -A -o json 2>/dev/null || true)"
  if [[ -n "${all_fleet_json}" ]]; then
    mapfile -t all_matches < <(jq -r --arg display "${display_name}" '
      [
        .items[]
        | select(
            .metadata.name == $display or
            .spec.displayName == $display or
            .metadata.labels["management.cattle.io/cluster-display-name"] == $display
          )
        | "\(.metadata.namespace)/\(.metadata.name)"
      ]
      | unique[]
    ' <<<"${all_fleet_json}")
  fi

  fleet_cluster_inventory "${context}"
  if (( ${#all_matches[@]} > 0 )); then
    die "Fleet cluster ${display_name} is in the wrong workspace: ${all_matches[*]}; expected ${namespace}."
  fi
  if (( ${#rancher_ids[@]} > 0 )); then
    die "Rancher knows cluster ${display_name}, but its Fleet cluster object is missing from ${namespace}. Verify Fleet is enabled and the cluster is assigned to that workspace."
  fi
  die "Rancher/Fleet does not contain cluster ${display_name} in ${namespace}. Import the cluster into Rancher or correct its display name in fleet-bootstrap.env."
}

fleet_cluster_json() {
  local namespace="${1:?Fleet workspace namespace is required}"
  local display_name="${2:?Fleet cluster display name is required}"
  local context="${3:-${RANCHER_CONTEXT:-j64seg1opman}}"
  local resource=""

  resource="$(fleet_cluster_resource "${namespace}" "${display_name}" "${context}")"
  kubectl --context "${context}" -n "${namespace}" get cluster.fleet.cattle.io "${resource}" -o json
}
