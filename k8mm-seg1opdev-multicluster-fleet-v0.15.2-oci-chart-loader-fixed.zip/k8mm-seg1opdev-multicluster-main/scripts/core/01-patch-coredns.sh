#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"

init_site_cluster "$@"
NAMESPACE="kube-system"
RESOURCES1="coredns-configmap-rke2-patch-v1.yaml"

require_kubectl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_registry_secret "${NAMESPACE}"

log "Applying CoreDNS metrics/config patch..."
apply_file_in_namespace "${NAMESPACE}" "${YAML_DIR}/resources/${RESOURCES1}"

log "Restarting CoreDNS deployment so the patch is active..."
kubectl rollout restart deployment/rke2-coredns-rke2-coredns -n "${NAMESPACE}" >/dev/null
wait_for_deployment_rollout "${NAMESPACE}" "rke2-coredns-rke2-coredns" "${KUBECTL_TIMEOUT}"

log "CoreDNS patched."
