#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
load_kmm_runtime_config "${CONFIG_FILE}"
require_cmd kubectl
require_cmd jq

PRIMARY_CONTEXT=j64seg1opdev
SECONDARY_CONTEXT=j52seg1opdev
NAMESPACE=oppostgres
CLUSTER_NAME=oppostgres-opkeycloak-db
CNPG_CLUSTER_RESOURCE=clusters.postgresql.cnpg.io
GITREPO_NAME=k8mm-seg1opdev-multicluster-downstream

[[ "${IDENTITY_FAILOVER_CONFIRM:-}" == "${SECONDARY_CONTEXT}" ]] || die "Set IDENTITY_FAILOVER_CONFIRM=${SECONDARY_CONTEXT} to acknowledge the identity failover."

pause_fleet() {
  kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default patch gitrepo "${GITREPO_NAME}" --type merge -p '{"spec":{"paused":true}}' >/dev/null
}

unpause_fleet() {
  kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default patch gitrepo "${GITREPO_NAME}" --type merge -p '{"spec":{"paused":false}}' >/dev/null
}

run_failover_hook() {
  local phase="$1"
  if [[ -z "${IDENTITY_FAILOVER_HOOK:-}" ]]; then
    [[ "${mode}" != "unplanned" || "${phase}" != "fence-primary" ]] || \
      die "Unplanned failover requires IDENTITY_FAILOVER_HOOK to fence the old site before promotion."
    return 0
  fi
  [[ -x "${IDENTITY_FAILOVER_HOOK}" ]] || die "IDENTITY_FAILOVER_HOOK is not executable: ${IDENTITY_FAILOVER_HOOK}"
  IDENTITY_FAILOVER_PHASE="${phase}" \
  IDENTITY_FAILOVER_SOURCE_CONTEXT="${PRIMARY_CONTEXT}" \
  IDENTITY_FAILOVER_SOURCE_IP="${IDENTITY_PRIMARY_INGRESS_IP:-1.0.0.215}" \
  IDENTITY_FAILOVER_TARGET_CONTEXT="${SECONDARY_CONTEXT}" \
  IDENTITY_FAILOVER_TARGET_IP="${IDENTITY_SECONDARY_INGRESS_IP:-1.0.0.225}" \
  IDENTITY_FAILOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST:-opkeycloak.dev.jde.cybercom.ic.gov}" \
    "${IDENTITY_FAILOVER_HOOK}"
}

wait_for_no_pods() {
  local context="$1" namespace="$2" selector="$3" deadline=$((SECONDS + 600)) count
  while :; do
    count="$(kubectl --context "${context}" -n "${namespace}" get pods -l "${selector}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${count}" == "0" ]] && return 0
    (( SECONDS < deadline )) || die "Timed out waiting for ${context}/${namespace} pods to stop (${selector})."
    sleep 5
  done
}

secondary_sql() {
  local sql="$1" pod
  pod="$(kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME},role=primary" -o jsonpath='{.items[0].metadata.name}')"
  kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" exec "${pod}" -- psql -U postgres -d postgres -Atqc "${sql}"
}

primary_available=false
if kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" >/dev/null 2>&1; then
  primary_available=true
fi

mode="${IDENTITY_FAILOVER_MODE:-auto}"
if [[ "${mode}" == "auto" ]]; then
  [[ "${primary_available}" == "true" ]] && mode=planned || mode=unplanned
fi
[[ "${mode}" == "planned" || "${mode}" == "unplanned" ]] || die "IDENTITY_FAILOVER_MODE must be auto, planned, or unplanned."
if [[ "${mode}" == "planned" && "${primary_available}" != "true" ]]; then
  die "Planned failover requires the primary cluster to be reachable."
fi
if [[ "${mode}" == "unplanned" && "${IDENTITY_ALLOW_UNPLANNED_FAILOVER:-false}" != "true" ]]; then
  die "Unplanned failover can lose transactions. Set IDENTITY_ALLOW_UNPLANNED_FAILOVER=true to proceed."
fi

secondary_enabled="$(kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" -o jsonpath='{.spec.replica.enabled}')"
[[ "${secondary_enabled}" == "true" ]] || die "The j52 PostgreSQL cluster is not an enabled replica; refusing failover."
[[ "$(secondary_sql 'select pg_is_in_recovery()')" == "t" ]] || die "The j52 PostgreSQL cluster is not in recovery mode."

paused=false
completed=false
cleanup() {
  if [[ "${completed}" != "true" && "${paused}" == "true" ]]; then
    echo "ERROR: Failover did not complete. Fleet remains paused at fleet-default/${GITREPO_NAME}. Resolve the failure before unpausing." >&2
  fi
}
trap cleanup EXIT

pause_fleet
paused=true
log "Fleet downstream reconciliation paused for the identity role transition."

if [[ "${primary_available}" == "true" ]]; then
  kubectl --context "${PRIMARY_CONTEXT}" -n opkeycloak patch keycloak opkeycloak --type merge -p '{"spec":{"instances":0}}' >/dev/null || true
  wait_for_no_pods "${PRIMARY_CONTEXT}" opkeycloak 'app.kubernetes.io/instance=opkeycloak'
fi

# Remove the old site from client traffic before any database promotion. For an
# unplanned failover this external fencing step is mandatory because the old
# cluster might still be alive behind a partition.
run_failover_hook fence-primary

if [[ "${mode}" == "planned" ]]; then
  primary_pod="$(kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME},role=primary" -o jsonpath='{.items[0].metadata.name}')"
  kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" exec "${primary_pod}" -- \
    psql -U postgres -d postgres -v ON_ERROR_STOP=1 -qc 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS false'
  kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" exec "${primary_pod}" -- \
    psql -U postgres -d postgres -v ON_ERROR_STOP=1 -qc \
      "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='opkeycloak' AND pid <> pg_backend_pid()"
  kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" exec "${primary_pod}" -- \
    psql -U postgres -d postgres -v ON_ERROR_STOP=1 -qc 'CHECKPOINT'
  target_lsn="$(kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" exec "${primary_pod}" -- psql -U postgres -d postgres -Atqc 'select pg_current_wal_lsn()')"
  deadline=$((SECONDS + 900))
  until [[ "$(secondary_sql "select pg_wal_lsn_diff(pg_last_wal_replay_lsn(), '${target_lsn}'::pg_lsn) >= 0")" == "t" ]]; do
    (( SECONDS < deadline )) || die "Secondary did not replay through ${target_lsn} before timeout."
    sleep 5
  done
  log "Secondary replay reached the fenced primary WAL target ${target_lsn}."
fi

primary_resource="$(fleet_cluster_resource fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
secondary_resource="$(fleet_cluster_resource fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
[[ -n "${primary_resource}" && -n "${secondary_resource}" ]] || die "Unable to resolve both Fleet cluster resources."

kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default label cluster.fleet.cattle.io "${primary_resource}" --overwrite \
  kmm.dev/identity-active=false kmm.dev/keycloak-instances=0 kmm.dev/postgres-hibernation=on >/dev/null
kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default label cluster.fleet.cattle.io "${secondary_resource}" --overwrite \
  kmm.dev/identity-active=true kmm.dev/keycloak-instances=3 kmm.dev/postgres-replica-enabled=false >/dev/null

if [[ "${primary_available}" == "true" ]]; then
  kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" annotate "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" cnpg.io/hibernation=on --overwrite >/dev/null
  wait_for_no_pods "${PRIMARY_CONTEXT}" "${NAMESPACE}" "cnpg.io/cluster=${CLUSTER_NAME}"
else
  log "Primary is unreachable; Fleet labels will hibernate and scale it down when it reconnects."
fi

kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" patch "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" --type merge -p '{"spec":{"replica":{"enabled":false,"source":"oppostgres-j64"}}}' >/dev/null
deadline=$((SECONDS + 900))
until [[ "$(secondary_sql 'select pg_is_in_recovery()')" == "f" ]]; do
  (( SECONDS < deadline )) || die "Timed out waiting for j52 PostgreSQL promotion."
  sleep 5
done
secondary_sql 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true'

kubectl --context "${SECONDARY_CONTEXT}" -n opkeycloak patch keycloak opkeycloak --type merge -p '{"spec":{"instances":3}}' >/dev/null
kubectl --context "${SECONDARY_CONTEXT}" -n opkeycloak wait --for=condition=Ready keycloak/opkeycloak --timeout=15m

if [[ -n "${IDENTITY_FAILOVER_HOOK:-}" ]]; then
  run_failover_hook activate-secondary
else
  log "Direct ${IDENTITY_CANONICAL_HOST:-opkeycloak.dev.jde.cybercom.ic.gov} to ${IDENTITY_SECONDARY_INGRESS_IP:-1.0.0.225}."
fi

unpause_fleet
paused=false
completed=true
log "Identity failover completed. j52 is writable and active; j64 is fenced. Rebuild j64 as a replica before any failback."
