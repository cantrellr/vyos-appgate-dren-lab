#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
RANCHER_IMPORT_TIMEOUT_SECONDS="${RANCHER_IMPORT_TIMEOUT_SECONDS:-900}"
WAIT_FOR_READY=false

usage() {
  cat <<USAGE
Usage: $0 [--wait]

Validate that every imported downstream cluster is connected to Rancher and its
cattle-cluster-agent Deployment is available. Use --wait during rebuilds to
allow Rancher registration and controller reconciliation to converge.
USAGE
}

while (($#)); do
  case "$1" in
    --wait) WAIT_FOR_READY=true ;;
    -h|--help) usage; exit 0 ;;
    *) die "Unknown option: $1" ;;
  esac
  shift
done

require_cmd kubectl
require_cmd jq
validate_context_access "${RANCHER_CONTEXT}"

FLEET_J64_APP_DISPLAY_NAME="${FLEET_J64_APP_DISPLAY_NAME:-j64seg1opdev}"
FLEET_J52_APP_DISPLAY_NAME="${FLEET_J52_APP_DISPLAY_NAME:-j52seg1opdev}"
FLEET_R01_APP_DISPLAY_NAME="${FLEET_R01_APP_DISPLAY_NAME:-r01seg1opdev}"

management_cluster_json() {
  local display_name="$1"
  kubectl --context "${RANCHER_CONTEXT}" get clusters.management.cattle.io -o json | jq -c \
    --arg display "${display_name}" '
      [ .items[]
        | select(
            .metadata.name == $display or
            .spec.displayName == $display or
            .metadata.labels["management.cattle.io/cluster-display-name"] == $display
          )
      ] as $matches
      | if ($matches | length) == 1 then $matches[0]
        elif ($matches | length) == 0 then empty
        else error("multiple Rancher cluster objects matched " + $display)
        end
    '
}

cluster_connected() {
  local display_name="$1" cluster_json=""
  cluster_json="$(management_cluster_json "${display_name}" 2>/dev/null || true)"
  [[ -n "${cluster_json}" ]] || return 1
  jq -e '
    any((.status.conditions // [])[]?; .type == "Connected" and .status == "True")
  ' <<<"${cluster_json}" >/dev/null
}

agent_available() {
  local context="$1"
  kubectl --context "${context}" -n cattle-system get deployment cattle-cluster-agent -o json | jq -e '
    (.metadata.generation // 0) <= (.status.observedGeneration // 0) and
    (.status.availableReplicas // 0) >= 1 and
    (.status.unavailableReplicas // 0) == 0
  ' >/dev/null
}

print_cluster_diagnostics() {
  local display_name="$1" context="$2" cluster_json=""
  cluster_json="$(management_cluster_json "${display_name}" 2>/dev/null || true)"
  if [[ -n "${cluster_json}" ]]; then
    jq -r --arg display "${display_name}" '
      .status.conditions[]?
      | select(.type == "Connected" or .type == "Ready")
      | [$display, .type, .status, (.reason // "-"), (.message // "-"), (.lastUpdateTime // "-")]
      | @tsv
    ' <<<"${cluster_json}" >&2 || true
  else
    warn "Rancher management cluster object not found for ${display_name}."
  fi

  kubectl --context "${context}" -n cattle-system get deployment,pods -o wide >&2 2>/dev/null || true
  kubectl --context "${context}" -n cattle-system logs deployment/cattle-cluster-agent \
    --tail=120 2>/dev/null | grep -Ei \
    'connected to proxy|connecting to proxy|remotedialer|403|bad handshake|unexpected EOF|closed network|x509|connection refused|error' \
    | tail -80 >&2 || true
}

validate_target() {
  local display_name="$1" context="$2"
  local deadline=$((SECONDS + RANCHER_IMPORT_TIMEOUT_SECONDS))

  validate_context_access "${context}"
  while true; do
    if cluster_connected "${display_name}" && agent_available "${context}"; then
      printf '[PASS] %s is Connected in Rancher and %s/cattle-system/cattle-cluster-agent is available\n' \
        "${display_name}" "${context}"
      return 0
    fi
    [[ "${WAIT_FOR_READY}" == true ]] || break
    (( SECONDS < deadline )) || break
    sleep 5
  done

  warn "${display_name} is not fully connected to Rancher or its cluster agent is unavailable."
  print_cluster_diagnostics "${display_name}" "${context}"
  return 1
}

failures=0
validate_target "${FLEET_J64_APP_DISPLAY_NAME}" j64seg1opdev || failures=$((failures + 1))
validate_target "${FLEET_J52_APP_DISPLAY_NAME}" j52seg1opdev || failures=$((failures + 1))
validate_target "${FLEET_R01_APP_DISPLAY_NAME}" r01seg1opdev || failures=$((failures + 1))

(( failures == 0 )) || die "Rancher imported-cluster validation failed for ${failures} cluster(s)."
log "All imported downstream clusters are connected and their Rancher agents are available."
