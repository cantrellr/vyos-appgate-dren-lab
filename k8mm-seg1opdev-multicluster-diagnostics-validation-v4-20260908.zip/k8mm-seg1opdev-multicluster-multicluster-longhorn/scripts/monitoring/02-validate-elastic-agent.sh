#!/usr/bin/env bash
set -Eeuo pipefail

MONITORING_VALIDATION_REVISION="2026-09-08.4"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"

CONTEXTS=()
LOG_TAIL="${ELASTIC_AGENT_LOG_TAIL:-500}"
LOG_SINCE="${ELASTIC_AGENT_LOG_SINCE:-2m}"
FAILURES=0
WARNINGS=0
printf 'Monitoring validation revision: %s\n' "${MONITORING_VALIDATION_REVISION}"

usage() {
  cat <<USAGE
Usage: $0 [--all | --context <context> ...]

Validates the Fleet-owned single-DaemonSet Elastic monitoring topology.
The default target is all four supported contexts.
USAGE
}

while (($#)); do
  case "$1" in
    --all) CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}"); shift ;;
    --context)
      [[ $# -ge 2 ]] || die "--context requires a value."
      CONTEXTS+=("$2"); shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) usage >&2; die "Unknown argument: $1" ;;
  esac
done
((${#CONTEXTS[@]})) || CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")

require_cmd kubectl
require_cmd jq

pass() { printf '[PASS] %s\n' "$*"; }
warn_check() { printf '[WARN] %s\n' "$*" >&2; WARNINGS=$((WARNINGS + 1)); }
fail() { printf '[FAIL] %s\n' "$*" >&2; FAILURES=$((FAILURES + 1)); }

extract_agent_messages() {
  # Elastic Agent emits large JSON monitoring snapshots that can contain unrelated
  # dataset names and error counters on the same line. Searching the raw line can
  # therefore correlate unrelated tokens (for example kube-state-metrics + an
  # unrelated "no such host") and create a false failure. Restrict validation to
  # each JSON record's message field. Plain-text lines are preserved as-is.
  jq -Rr '. as $raw | try (fromjson | if type == "object" then (.message // "") else tostring end) catch $raw'
}

print_matches() {
  local pattern="$1" input="$2"
  grep -Ei -- "$pattern" <<<"${input}" | head -n 8 | sed 's/^/       /' >&2 || true
}

secret_has_key() {
  local context="$1" namespace="$2" secret="$3" key="$4"
  kubectl --context "${context}" -n "${namespace}" get secret "${secret}" \
    -o "jsonpath={.data.${key//./\\.}}" 2>/dev/null | grep -q .
}

check_policy_selector() {
  local context="$1" namespace="$2" name="$3"
  if ! kubectl --context "${context}" -n "${namespace}" get networkpolicy "${name}" >/dev/null 2>&1; then
    warn_check "${context}: ${namespace}/${name} is absent; namespace may not host that application."
    return
  fi
  local values
  values="$(kubectl --context "${context}" -n "${namespace}" get networkpolicy "${name}" \
    -o 'jsonpath={range .spec.ingress[*].from[*]}{.namespaceSelector.matchLabels.k8mm\.dev/monitoring-agent}{"\n"}{end}' 2>/dev/null || true)"
  if grep -qx true <<<"${values}"; then
    pass "${context}: ${namespace}/${name} selects monitoring-agent namespaces"
  else
    fail "${context}: ${namespace}/${name} does not select k8mm.dev/monitoring-agent=true"
  fi
}

for context in "${CONTEXTS[@]}"; do
  printf '\n=== %s ===\n' "${context}"
  validate_supported_context "${context}"
  if ! kubectl --context "${context}" cluster-info >/dev/null 2>&1; then
    fail "${context}: cluster is unreachable"
    continue
  fi

  for namespace in elastic-agent-system elastic-monitoring; do
    if kubectl --context "${context}" get namespace "${namespace}" >/dev/null 2>&1; then
      pass "${context}: namespace ${namespace} exists"
    else
      fail "${context}: namespace ${namespace} is missing"
    fi
  done

  label="$(kubectl --context "${context}" get namespace elastic-agent-system \
    -o go-template='{{ with index .metadata.labels "k8mm.dev/monitoring-agent" }}{{ . }}{{ end }}' 2>/dev/null || true)"
  [[ "${label}" == true ]] && pass "${context}: monitoring namespace label is correct" \
    || fail "${context}: elastic-agent-system lacks k8mm.dev/monitoring-agent=true"

  if secret_has_key "${context}" elastic-agent-system elastic-agent-fleet-enrollment FLEET_URL \
    && secret_has_key "${context}" elastic-agent-system elastic-agent-fleet-enrollment FLEET_ENROLLMENT_TOKEN; then
    pass "${context}: Fleet enrollment Secret contains URL and token"
  else
    fail "${context}: Fleet enrollment Secret is missing or incomplete"
  fi
  if secret_has_key "${context}" elastic-agent-system devlocal-ca-bundle-secret ca.crt; then
    pass "${context}: Fleet CA Secret contains ca.crt"
  else
    fail "${context}: Fleet CA Secret is missing ca.crt"
  fi

  if kubectl --context "${context}" -n elastic-monitoring get deployment kube-state-metrics >/dev/null 2>&1; then
    available="$(kubectl --context "${context}" -n elastic-monitoring get deployment kube-state-metrics -o jsonpath='{.status.availableReplicas}' 2>/dev/null || echo 0)"
    [[ "${available:-0}" -ge 1 ]] && pass "${context}: kube-state-metrics is available" \
      || fail "${context}: kube-state-metrics has no available replicas"

    ksm_resources_arg="$(kubectl --context "${context}" -n elastic-monitoring get deployment kube-state-metrics -o json 2>/dev/null | \
      jq -r '.spec.template.spec.containers[]? | select(.name == "kube-state-metrics") | .args[]? | select(startswith("--resources="))' | head -n1 || true)"
    ksm_resources="${ksm_resources_arg#--resources=}"
    if [[ -n "${ksm_resources_arg}" ]] \
      && grep -Eq '(^|,)endpointslices(,|$)' <<<"${ksm_resources}" \
      && ! grep -Eq '(^|,)endpoints(,|$)' <<<"${ksm_resources}"; then
      pass "${context}: kube-state-metrics uses discovery.k8s.io/v1 EndpointSlice and not deprecated Endpoints"
    else
      fail "${context}: kube-state-metrics resources must include endpointslices and exclude deprecated endpoints (resources=${ksm_resources:-missing})"
    fi
  else
    fail "${context}: kube-state-metrics Deployment is missing"
  fi

  alias_target="$(kubectl --context "${context}" -n elastic-agent-system get service kube-state-metrics -o jsonpath='{.spec.externalName}' 2>/dev/null || true)"
  [[ "${alias_target}" == kube-state-metrics.elastic-monitoring.svc.cluster.local ]] \
    && pass "${context}: kube-state-metrics alias is correct" \
    || fail "${context}: kube-state-metrics alias is missing or incorrect"

  if kubectl --context "${context}" -n elastic-agent-system get daemonset agent-pernode-elastic-agent-node >/dev/null 2>&1; then
    desired="$(kubectl --context "${context}" -n elastic-agent-system get daemonset agent-pernode-elastic-agent-node -o jsonpath='{.status.desiredNumberScheduled}')"
    ready="$(kubectl --context "${context}" -n elastic-agent-system get daemonset agent-pernode-elastic-agent-node -o jsonpath='{.status.numberReady}')"
    [[ "${desired:-0}" -gt 0 && "${desired}" == "${ready}" ]] \
      && pass "${context}: Elastic Agent DaemonSet ready ${ready}/${desired}" \
      || fail "${context}: Elastic Agent DaemonSet ready ${ready:-0}/${desired:-0}"
  else
    fail "${context}: Elastic Agent DaemonSet is missing"
  fi

  if kubectl --context "${context}" get namespace elastic-agent-cluster-system >/dev/null 2>&1; then
    fail "${context}: stale split-topology namespace elastic-agent-cluster-system exists"
  else
    pass "${context}: no stale split-topology namespace exists"
  fi

  check_policy_selector "${context}" segment1 segment1-allow-monitoring-scrapes
  kubectl --context "${context}" get namespace opkeycloak >/dev/null 2>&1 \
    && check_policy_selector "${context}" opkeycloak opkeycloak-ingress-from-monitoring
  kubectl --context "${context}" get namespace oppostgres >/dev/null 2>&1 \
    && check_policy_selector "${context}" oppostgres oppostgres-allow-monitoring

  logs="$(kubectl --context "${context}" -n elastic-agent-system logs daemonset/agent-pernode-elastic-agent-node \
    --all-pods=true --all-containers=true --since="${LOG_SINCE}" --tail="${LOG_TAIL}" 2>/dev/null || true)"
  if [[ -z "${logs}" ]]; then
    warn_check "${context}: Elastic Agent logs were unavailable"
  else
    agent_messages="$(extract_agent_messages <<<"${logs}")"

    tls_pattern='x509: certificate signed by unknown authority|unable to get local issuer certificate'
    dns_pattern='kube-state-metrics[^[:cntrl:]]*(no such host|server misbehaving)|((no such host|server misbehaving)[^[:cntrl:]]*kube-state-metrics)'
    fleet_pattern='enroll[^[:cntrl:]]*(fail|error)|fleet[^[:cntrl:]]*(unreachable|connection refused)'

    if grep -Eiq -- "${tls_pattern}" <<<"${agent_messages}"; then
      fail "${context}: Elastic Agent message fields contain recent TLS trust failures"
      print_matches "${tls_pattern}" "${agent_messages}"
    else
      pass "${context}: no recent TLS trust failures in Agent message fields"
    fi

    if grep -Eiq -- "${dns_pattern}" <<<"${agent_messages}"; then
      fail "${context}: Elastic Agent message fields contain recent kube-state-metrics DNS failures"
      print_matches "${dns_pattern}" "${agent_messages}"
    else
      pass "${context}: no recent kube-state-metrics DNS failures in Agent message fields"
    fi

    if grep -Eiq -- "${fleet_pattern}" <<<"${agent_messages}"; then
      fail "${context}: Elastic Agent message fields contain recent Fleet enrollment/connectivity failures"
      print_matches "${fleet_pattern}" "${agent_messages}"
    else
      pass "${context}: no recent Fleet enrollment/connectivity failures in Agent message fields"
    fi
  fi
done

printf '\nElastic monitoring validation summary: failures=%d warnings=%d\n' "${FAILURES}" "${WARNINGS}"
((FAILURES == 0)) || exit 1
log "Elastic Agent and kube-state-metrics validation passed across ${#CONTEXTS[@]} cluster(s)."
