# Diagnostics and Monitoring Validation Revision 2026-09-08.4

## Why this revision exists

Revision 2026-09-08.3 corrected Fleet Bundle readiness, the kube-state-metrics DNS alias, and EndpointSlice validation. Post-fix validation still produced eight false monitoring failures because Elastic Agent writes very large JSON monitoring records. A raw regular-expression scan could match `kube-state-metrics` or `fleet-controller` dataset names and then match an unrelated error string elsewhere on the same record.

## Monitoring validator behavior

`scripts/monitoring/02-validate-elastic-agent.sh` now parses Elastic Agent JSON log records and evaluates the `.message` field only. Plain-text records are retained. When a TLS, kube-state-metrics DNS, or Fleet connectivity condition fails, the validator prints up to eight exact matching message lines.

The default inspection window remains `ELASTIC_AGENT_LOG_SINCE=2m`. The validator also checks the live kube-state-metrics Deployment and requires `endpointslices` while rejecting legacy `endpoints`.

## Diagnostics error index behavior

`error-index.txt` is now intentionally high-signal. It indexes only:

- `current-blockers.txt`;
- cluster-wide Kubernetes Warning/event failure records; and
- current container logs with high-severity levels or concrete runtime failure signatures, capped at 20 matching lines per file by default.

Bulk YAML/JSON object dumps and previous-container logs are excluded from indexing. They remain in the archive for deeper forensic analysis.

This separation keeps the archive comprehensive while preventing configuration fields such as `failureThreshold`, `timeoutSeconds`, empty `*Error` fields, and benign historical text from dominating first-pass triage.
