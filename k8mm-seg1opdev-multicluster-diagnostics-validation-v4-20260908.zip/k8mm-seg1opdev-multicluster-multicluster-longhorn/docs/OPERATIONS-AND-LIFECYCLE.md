# Operations and Lifecycle

> **Baseline:** v2.2 — August 28, 2026  
> **Audience:** platform operators, systems administrators, SRE/operations personnel, and escalation engineers.

## 1. Operating model

Normal steady-state changes follow this loop:

1. change the intended Git branch;
2. run `validate-package`;
3. push to GitLab;
4. allow Fleet to reconcile;
5. validate BundleDeployment readiness and service-specific health;
6. revert Git if the change is not acceptable.

Do not treat Rancher UI red states as a reason to manually delete Bundles. First identify the failing dependency and the Git commit/branch Fleet is actually reconciling.

## 2. Daily health checks

Recommended daily/shift checks:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For storage-sensitive operations also run:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

`prepare-longhorn-nodes` is non-destructive and verifies the host storage contract.

## 3. Rancher and Fleet operations

### Fleet readiness

Healthy steady state means the intended GitRepos are Ready and all intended BundleDeployments are Active. Bundle dependencies are expressed by `kmm.dev/bundle` labels.

Inspect GitRepos:

```bash
kubectl --context j64seg1opman -A get gitrepos.fleet.cattle.io
```

Inspect bundles by workspace:

```bash
kubectl --context j64seg1opman -n fleet-local get bundles.fleet.cattle.io
kubectl --context j64seg1opman -n fleet-default get bundles.fleet.cattle.io
```

Inspect the actual branch/commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

### Kubernetes 1.35 Fleet compatibility

The baseline requires `KUBE_FEATURE_WatchListClient=false` on Fleet controllers and agents. Apply/verify with:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Do not remove this control until the pinned Rancher/Fleet combination is upgraded and the replacement has been validated against RKE2/Kubernetes 1.35 behavior.

### Rancher system repair

Use:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow validates the registry, refreshes CoreDNS/registry credentials, restores Rancher ingress, repairs PSA namespace labels, applies GitJob RBAC, enforces the WatchListClient compatibility setting, waits for Rancher/Fleet components, and forces GitRepo rescan. It intentionally avoids deleting healthy Rancher/Fleet resources.

## 4. GitOps deployment flow

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

Operational principle: correct the **source of truth** or the external dependency causing reconciliation failure. Direct changes to Fleet-owned resources are break-glass actions and may be reverted automatically.

## 5. Chrony operations

Chrony owns the host clock while deployed. It runs as a privileged DaemonSet and records the prior `systemd-timesyncd` state under `/var/lib/k8mm/chrony`.

Validate all clusters:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target one cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

View compact telemetry:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=50
```

A healthy node reports a selected source, positive stratum, and `Leap status: Normal`. The installer emits detailed `tracking`, `sources`, `ntpdata`, log, and event information when synchronization fails.

Supported removal:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

Do not delete the DaemonSet manually as the standard removal method; the supported command restores the saved host time-service state.

## 6. Longhorn operations

### Host contract

Default worker contract:

- path: `/mnt/k8sdata`;
- filesystem: XFS;
- minimum capacity: `240 GiB`;
- iSCSI available and active;
- shared root mount propagation;
- multipath disabled where it can claim Longhorn devices.

Validate:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

### Kubernetes checks

```bash
kubectl --context j64seg1opdev -n longhorn-system get pods -o wide
kubectl --context j64seg1opdev get storageclass
kubectl --context j64seg1opdev get pvc -A
```

The stateful identity workloads use `longhorn-xfs-retain`.

### Longhorn UI

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://longhorn-man.dev.kube` |
| `j64seg1opdev` | `https://longhorn-j64.dev.kube` |
| `j52seg1opdev` | `https://longhorn-j52.dev.kube` |
| `r01seg1opdev` | `https://longhorn-r01.dev.kube` |

Fleet creates the HTTPProxy/certificate. The proxy allows only source addresses in `1.0.0.0/23` and sends traffic to `longhorn-frontend:80`.

Use Longhorn snapshots/replicas for in-cluster operational recovery, but maintain a separately approved disaster-recovery/backup strategy if off-cluster recovery is required.

## 7. Istio and Kiali operations

Validate mesh components and namespace injection:

```bash
./scripts/istio/04-check-istio-system.sh --all
./scripts/istio/05-audit-namespace-injection.sh --all
```

Kiali URLs:

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://kiali-man.dev.kube` |
| `j64seg1opdev` | `https://kiali-j64.dev.kube` |
| `j52seg1opdev` | `https://kiali-j52.dev.kube` |
| `r01seg1opdev` | `https://kiali-r01.dev.kube` |

Kiali depends on the external Prometheus and Grafana endpoints configured in its values. A healthy Kiali pod can therefore still show degraded metrics if those external services or the Grafana credential Secret are unavailable.

Istio webhook CA fields are controller-managed runtime data. Fleet comparison rules intentionally ignore only the expected `caBundle` mutation rather than suppressing entire webhook objects.

## 8. Identity operations

The normal role is J64 writable/active and J52 streaming/standby. Both databases are members of one CloudNativePG distributed topology. Planned switchovers remain reversible; an **unplanned** promotion can require rebuilding the former primary from the surviving site before full HA is restored. Only one database site may be writable and only that site's Keycloak may have active instances and a published HTTPProxy.

Distributed-topology enrollment is deliberately staged. A new or repaired standby first runs as a standalone streaming replica. After its local CNPG replication certificate exists and peer trust has been synchronized, Fleet turns on distributed mode. Because this deployment uses the same Kubernetes `Cluster` object name (`oppostgres-opkeycloak-db`) on both sites, the unique site identity comes from `spec.replica.self`; therefore both `j64seg1opdev` and `j52seg1opdev` must be present in `spec.externalClusters` whenever distributed mode is enabled. This is an admission-time requirement in CloudNativePG, not merely a replication connectivity preference.

### Replication and certificate gate

Run the automated checks before/after maintenance and before every planned role transition:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

The replication verifier derives the active and standby sites from Fleet labels and requires all of the following:

| Check | Healthy result |
| --- | --- |
| source/target role | source `pg_is_in_recovery()=f`; target `t` |
| replication DNS | every A record resolved from both database sites equals the configured source replication VIP |
| TCP/database probe | target can reach the configured source endpoint on TCP/5432 |
| receiver status | target `pg_stat_wal_receiver.status=streaming` |
| source sender status | at least one `pg_stat_replication` sender is `streaming` |
| receiver identity | sender host/port match the configured source replication endpoint |
| receiver message age | no more than `IDENTITY_MAX_REPLICATION_MESSAGE_AGE_SECONDS` |
| source-to-replay / receive-to-replay lag | no more than `IDENTITY_MAX_REPLICATION_LAG_BYTES` |
| replication TLS | copied certificate/CA fingerprints match the source Secrets and remain valid for at least `IDENTITY_REPLICATION_CERT_MIN_VALIDITY_SECONDS` |

Defaults are 30 seconds, 16 MiB, five minutes of retry time, five-second polling, and seven days of minimum certificate validity. Timeout and polling values must be greater than zero. The helper selects the CloudNativePG-reported `status.currentPrimary`; it does not assume the first Pod is the primary.

For manual evidence, use the CNPG-reported primary rather than the obsolete `role=primary` selector:

```bash
STANDBY=j52seg1opdev # use j64seg1opdev after failover
STANDBY_POD="$(kubectl --context "$STANDBY" -n oppostgres   get cluster/oppostgres-opkeycloak-db -o jsonpath='{.status.currentPrimary}')"
kubectl --context "$STANDBY" -n oppostgres exec "$STANDBY_POD" --   psql -U postgres -d postgres -P pager=off -x -c '
SELECT pg_is_in_recovery(), pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn();
SELECT status, sender_host, sender_port, slot_name,
       clock_timestamp() - last_msg_receipt_time AS message_age
FROM pg_stat_wal_receiver;'
```

### Transactional planned switchover

For J64 → J52:

```bash
./scripts/deploy-platform.sh verify-database-replication
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
./scripts/deploy-platform.sh failover-identity
unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
```

For J52 → J64, use the same engine in the opposite direction:

```bash
./scripts/deploy-platform.sh verify-database-replication
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned
./scripts/deploy-platform.sh failback-identity
unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_SWITCHOVER_MODE
```

The switchover is journaled in `fleet-default/kmm-identity-transition-journal` and protected by a Kubernetes Lease. It preserves the GitRepo's original paused state. Planned execution separates `quiesce-source-traffic` from database demotion so a true disaster fence cannot accidentally run before the final WAL position and demotion token are captured. The supported phase-specific external hooks are:

- `IDENTITY_QUIESCE_SOURCE_HOOK`
- `IDENTITY_HARD_FENCE_SOURCE_HOOK`
- `IDENTITY_ACTIVATE_TARGET_HOOK`
- `IDENTITY_RESTORE_SOURCE_HOOK`

`IDENTITY_SWITCHOVER_HOOK` and `IDENTITY_FAILOVER_HOOK` remain compatibility aliases only. The transition is not complete merely because the database promoted: it also requires the target Keycloak resources to become Ready, the canonical DNS name to resolve **only** to the target ingress VIP, the target HTTPProxy/certificate path to be healthy, an HTTPS Keycloak OIDC discovery request to succeed with `CA_CERT_FILE`, Fleet reconciliation to complete, and the reversed replication/HA gates to pass.

If a run stops, inspect the journal rather than manually changing labels:

```bash
./scripts/deploy-platform.sh identity-transition-status
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
```

A planned transition can be rolled back automatically only **before** database demotion:

```bash
./scripts/deploy-platform.sh rollback-identity-transition
```

After demotion/promotion, recovery must follow the recorded state; do not improvise with `replica.enabled`, DNS, or Fleet-label patches.

### Unplanned failover and degraded mode

Unplanned promotion can lose acknowledged transactions because cross-site replication is asynchronous. It requires all three controls:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<target-site>
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
```

An executable `IDENTITY_HARD_FENCE_SOURCE_HOOK` (or compatibility hook) is also mandatory. Before promotion the workflow records the target replay position/receiver evidence and hard-fences the old source. Completion is deliberately reported as `complete-degraded` until the former primary is rebuilt and strict HA is restored.

`validate-identity-ha` is strict by default: an absent/hibernated standby is a failure. Use `--allow-degraded` only for an explicitly accepted disaster-recovery interval:

```bash
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
```

### Rebuild the former primary as a standby

When an unplanned promotion makes the old primary unsafe to rejoin, rebuild it from the surviving writable site. The workflow is destructive to the old CNPG Cluster/PVC objects and therefore has two explicit gates:

```bash
export IDENTITY_REBUILD_CONFIRM=<standby-site>
export IDENTITY_REBUILD_DELETE_STORAGE=true
./scripts/deploy-platform.sh rebuild-identity-standby <standby-site>
unset IDENTITY_REBUILD_CONFIRM IDENTITY_REBUILD_DELETE_STORAGE
```

Before deletion, the script proves the peer is the writable Fleet primary, copies replication TLS, launches a one-time certificate-authenticated `sslmode=verify-ca` probe to the source replication VIP, and then sets `kmm.dev/postgres-bootstrap-mode=pg_basebackup`. The standby is recreated with `postgres-distributed-topology=false` first so it can complete `pg_basebackup` and generate fresh local CNPG TLS material without a circular dependency on its own distributed-topology identity. The J64 chart now supports this standalone `pg_basebackup` rebuild mode; its normal default remains `initdb`. The secondary chart also uses a clean `pg_basebackup.source` contract without initdb-only fields. Longhorn `Retain` PVs are intentionally not deleted by the workflow so the old data remains a recovery artifact until an operator deliberately disposes of it.

After the rebuilt standby is Ready and confirmed read-only, the workflow copies its **new** replication certificate back to the surviving site, re-enables distributed topology on the rebuilt site, and waits for `replica.self`/`replica.primary` to converge before running replication and strict HA validation. The rebuild does not succeed until all of those gates pass.

## 9. Elastic observability operations

The default model uses one Elastic Agent DaemonSet and one kube-state-metrics Deployment per cluster, with one Fleet enrollment policy/token per cluster. A compatibility `ExternalName` Service named `kube-state-metrics` is placed in `elastic-agent-system` so the Elastic Kubernetes integration's short-name scrape target resolves to `kube-state-metrics.elastic-monitoring.svc.cluster.local`. kube-state-metrics explicitly collects `endpointslices` instead of the deprecated core/v1 `endpoints` resource on Kubernetes v1.33+.

Validate:

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If enrollment fails, confirm Fleet Server URL, CA/SAN correctness, token-to-policy mapping, network reachability, and the `elastic-agent` Secret seeded on the affected cluster.

## 10. GitLab Runner operations

The Runner is Fleet-owned in `gitlab-runner-system` on `j64seg1opman`.

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get pods
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

Rotate the runner authentication token or GitLab CA by updating the protected input file and rerunning `./scripts/deploy-platform.sh seed-secrets`. Do not commit the `glrt-*` token. GitLab controls the runner tag, protected status, locking, and project/group scope; the cluster bundle controls runtime version, executor policy, and the exact approved Harbor job-image allowlist.

Every pipeline now starts with `runner:canary`. That job intentionally proves the Kubernetes executor path rather than only manager registration: job Pod admission, helper pull, approved Ansible image pull, repository clone, restricted security context/RBAC, and artifact upload must all work before `validate:gitops-package` runs. Validation selects a Python interpreter by importing the required PyYAML APIs in isolated mode and then executes repository Python checks with safe-path isolation; a shadow `yaml` module in the checkout must not be accepted.

## 11. Certificate operations

cert-manager uses the Segment1 ClusterIssuer seeded through the protected CA material. Check certificate status:

```bash
kubectl --context j64seg1opman get certificates -A
kubectl --context j64seg1opman get clusterissuer
```

Repeat for the affected cluster. Do not disable TLS verification to work around CA-chain failures; fix trust or certificate identity.

Cross-site PostgreSQL replication certificates are also an operational lifecycle item. `verify-database-replication` compares the generated source certificate/CA fingerprints with the copied peer Secrets and rejects certificates inside the configured minimum-validity window. Rotate the source certificate through the approved certificate process, rerun the identity Secret synchronization/enablement path, and prove fingerprint agreement plus bidirectional replication before a maintenance window. Do not wait for switchover day to discover an expired replication certificate.

## 12. Ingress and HTTPProxy operations

List Contour proxies:

```bash
kubectl --context j64seg1opdev get httpproxy -A
```

Inspect a proxy:

```bash
kubectl --context j64seg1opdev -n <namespace> describe httpproxy <name>
```

An `invalid` HTTPProxy usually indicates a missing backend Service/port, missing TLS Secret, invalid route definition, or ingress-class/dependency problem. Resolve the underlying reference rather than deleting the proxy.

## 13. CIS/PodSecurity lifecycle

Rancher/Fleet and several platform components require scoped privileged PSA namespaces. Keep exceptions limited to system namespaces and prepare Rancher/Fleet namespaces before cluster import. Application namespaces should remain restricted unless a reviewed workload requirement says otherwise.

## 14. Upgrade lifecycle

For every component upgrade:

1. confirm RKE2/Rancher/Fleet compatibility;
2. obtain/promote images through the approved air-gap workflow;
3. stage the exact Helm chart archive;
4. update the package allowlist, OCI inventory, and checksums;
5. review chart defaults for newly introduced transitive images;
6. update values and compatibility controls;
7. run `validate-package`;
8. publish immutable OCI charts;
9. deploy through Git/Fleet;
10. validate all service-specific gates.

The shared Helm wrapper requires Helm 4 and uses `--rollback-on-failure`; the deprecated `--atomic` CLI alias is not part of the supported wrapper path.

## 15. Backup and recovery boundaries

- GitLab: back up repository data and branch history according to GitLab operations policy.
- KubeHarbor: preserve registry projects/artifacts and CA configuration.
- Rancher/Fleet: preserve Rancher state according to the management-cluster recovery plan.
- RKE2: maintain the approved etcd snapshot/recovery process outside this repository.
- Longhorn: snapshots/replicas are in-cluster; define off-cluster backup separately where required.
- Identity: cross-site replication and Longhorn are **not** substitutes for off-cluster backup/PITR. This repository does not invent an object-store target or credentials; production authorization requires an approved off-cluster CloudNativePG backup destination, retention policy, restore test, and documented PITR RPO/RTO. Until that is supplied, this remains an explicit recovery-control gap rather than a silently fabricated configuration.
- protected configuration: securely back up credential files, CA material, and Istio CA directories outside Git.

## 16. Change-management evidence

For significant changes retain:

- Git commit and branch deployed;
- `validate-package` output;
- Fleet GitRepo commit and bundle state;
- relevant Rancher/Fleet/Longhorn/identity validation output;
- diagnostic bundle for failed changes;
- security/exception review when privileged namespace or certificate behavior changes.
