# Troubleshooting and Support

> **Baseline:** v2.5 — September 9, 2026  
> **Audience:** help desk, support technicians, platform support, systems engineers, and senior escalation engineers.

## 1. Support model

The support objective is to identify the **failure domain** before changing the environment. Most visible failures fall into one of four categories:

1. client/access problem;
2. Kubernetes workload/platform problem;
3. GitOps/source-of-truth problem; or
4. external dependency problem such as GitLab, KubeHarbor, DNS, NTP, CA, Elastic, or network routing.

```mermaid
flowchart TD
  ALERT[User report or monitoring alert]
  T1[Help Desk - Tier 1\nIdentify cluster, URL, symptom, time, scope]
  BASIC[Check Rancher reachability, DNS, certificate, and known status]
  RESTORE{Known client or access issue?}
  T2[Platform Support - Tier 2\nCheck Fleet, pods, events, HTTPProxy, Longhorn, Chrony]
  DIAG[Run collect-gitops-logs.sh and targeted validation]
  OWNER{Failure domain identified?}
  T3[Systems Engineering - Tier 3\nGitOps source, Rancher/Fleet, mesh, identity, storage]
  EXT[External dependency owner\nGitLab, KubeHarbor, DNS, NTP, CA, Elastic, network]
  CHANGE[Correct source of truth or external dependency]
  VERIFY[Run validation and confirm all bundles / services healthy]
  CLOSE[Document resolution and close incident]

  ALERT --> T1
  T1 --> BASIC
  BASIC --> RESTORE
  RESTORE -->|yes| CLOSE
  RESTORE -->|no| T2
  T2 --> DIAG
  DIAG --> OWNER
  OWNER -->|platform| T3
  OWNER -->|external| EXT
  T3 --> CHANGE
  EXT --> CHANGE
  CHANGE --> VERIFY
  VERIFY -->|pass| CLOSE
  VERIFY -->|fail| T3
```

## 2. Incident information required from the help desk

Tier 1 should capture the following before escalation:

- user/customer and callback/contact path;
- date/time and timezone of the failure;
- affected service/URL;
- affected cluster if known;
- exact error message or screenshot;
- whether the issue affects one user, one site, one cluster, or everyone;
- whether it ever worked and the last known-good time;
- recent maintenance/change window if known;
- browser/client source network and source IP when relevant to restricted UIs;
- ticket severity and business impact.

Do **not** ask Tier 1 to delete pods, change Fleet bundles, modify Helm releases, or edit cluster labels.

## 3. Tier 1 — Help Desk checklist

### Rancher or administrative UI unavailable

1. Verify the hostname resolves to the expected Segment1 VIP.
2. Verify the client is on an allowed network.
3. Check whether the browser reports DNS, TCP timeout, HTTP error, or certificate error.
4. Try another known-good administrative URL to determine whether the problem is service-specific or the entire ingress path.
5. Escalate with the exact URL, source network, time, and browser error.

Administrative URLs:

| Service | Management | j64 | j52 | r01 |
| --- | --- | --- | --- | --- |
| Longhorn | `longhorn-man.dev.kube` | `longhorn-j64.dev.kube` | `longhorn-j52.dev.kube` | `longhorn-r01.dev.kube` |
| Kiali | `kiali-man.dev.kube` | `kiali-j64.dev.kube` | `kiali-j52.dev.kube` | `kiali-r01.dev.kube` |

Rancher is `rancher.dev.kube`; identity is `opkeycloak.dev.jde.cybercom.ic.gov`.

### Important Longhorn UI behavior

The Longhorn HTTPProxy allows only `1.0.0.0/23` by design. A user outside the trusted Segment1 source range may be denied even when Longhorn is healthy. Treat that as an access-policy issue, not a storage outage.

## 4. Tier 2 — Platform Support first checks

Set the relevant kubeconfig context and start read-only:

```bash
kubectl --context j64seg1opman get nodes
kubectl --context j64seg1opman get pods -A
kubectl --context j64seg1opman get events -A --sort-by=.lastTimestamp | tail -100
```

Then run the platform validators appropriate to the symptom:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

Collect a diagnostic archive before disruptive changes:

```bash
./scripts/collect-gitops-logs.sh
```

Attach the generated archive to the incident/escalation.

## 5. Determine whether Fleet is reconciling the expected branch

A common and highly deceptive failure is editing one branch while Fleet is configured to reconcile another. Always check:

```bash
git branch --show-current
grep '^FLEET_REPO_BRANCH=' "$KMM_FLEET_CONFIG"
```

Then inspect the live GitRepo branch and commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
kubectl --context j64seg1opman -n fleet-local   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

If the live commit is not the intended Git commit, correct the Git/runtime configuration first. Deleting Bundles will only recreate the same undesired state.

## 6. Fleet Bundle states

### `ErrApplied` with `dependent bundle(s) are not ready`

The displayed bundle is usually **not** the root cause. Follow the named dependency upstream until the first bundle with a direct Helm/schema/resource error is found.

Example chain:

```text
kiali-resources -> kiali -> kiali-operator -> istiod
```

Investigate the first non-ready dependency rather than each downstream red bundle separately.

### `Modified`

`Modified` means the live resource differs from Fleet's normalized desired state. Determine whether this is expected controller mutation or real drift.

Known intentional normalization examples include Istio validating-webhook `caBundle` injection and narrowly scoped operator ownership-label mutation. Do not broadly ignore an entire resource when a field-specific comparison rule is sufficient.

### Missing bundle matching `kmm.dev/bundle=<name>`

Check the Git branch/commit first. Then check that the required bundle path is included in the correct GitRepo and carries the expected label. Retired dependencies such as old Trident bundle names should not exist in the Longhorn design.

## 7. Rancher/Fleet agent problems

### Cluster agent will not connect

Check:

- `rancher.dev.kube` DNS and TLS;
- Contour `rancher-httpproxy` validity;
- WebSocket path `wss://rancher.dev.kube/v3/connect/register`;
- `cattle-system` agent pod logs/events;
- firewall/proxy timeout behavior.

Use:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-rancher-imports
```

### PodSecurity rejection

Typical event:

```text
pods "fleet-agent-..." is forbidden: violates PodSecurity "restricted:latest"
```

Repair the scoped Rancher/Fleet system namespaces:

```bash
./scripts/deploy-platform.sh repair-rancher-psa
```

### Fleet watch-stream/cache problems on Kubernetes 1.35

Symptoms can include repeated watch decode/stream errors, BundleDeployments remaining in `WaitApplied`, or `preflight-fleet` reporting downstream Fleet Cluster resources that do not propagate `KUBE_FEATURE_WatchListClient=false` through `spec.agentEnvVars`.

Repair and verify the controller plus every downstream Fleet agent contract:

```bash
./scripts/deploy-platform.sh repair-rancher-agents
./scripts/deploy-platform.sh preflight-fleet
```

The expected control is `KUBE_FEATURE_WatchListClient=false` on the Fleet controller, `fleet-local`, and every `fleet-default` Cluster resource/agent. `preflight-fleet` now fails with the repair command instead of continuing with a partially configured Fleet runtime.

## 8. KubeHarbor and image/chart pull failures

Symptoms:

- `ImagePullBackOff` / `ErrImagePull`;
- Fleet OCI chart authentication/TLS failures;
- GitJob cannot resolve or authenticate to Harbor;
- Rancher Helm operation pods fail during disconnected bootstrap.

Checks:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh configure-management-dns
./scripts/deploy-platform.sh validate-fleet-oci
```

Confirm:

- DNS resolves `kubeharbor.dev.kube` from nodes **and pods**;
- CA chain is trusted;
- credentials are valid;
- required chart/image exists at the exact expected path/tag;
- node RKE2 `registries.yaml` trust/authentication is correct.

Do not bypass TLS validation to make the error disappear.

## 9. Chrony / time troubleshooting

### Pod Running but time is not synchronized

A Running Chrony container is not proof of synchronized host time.

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target a cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

Inspect one pod:

```bash
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc sources -v
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc tracking
kubectl --context j64seg1opdev -n kube-system exec <chrony-pod> -- chronyc ntpdata <ntp-server>
```

Healthy state requires a `^*` selected source, positive stratum, and `Leap status: Normal`.

### UDP/123 works but Chrony will not select the server

Check the **server's NTP status**, not just connectivity. A reply with leap indicator `unknown/unsynchronized` (`LI=3`) or stratum 0 is invalid as a synchronization source. Escalate to the NTP/AD time-service owner.

The `chrony-status` sidecar provides compact periodic state:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=100
```

## 10. Longhorn troubleshooting

### Longhorn bundle is Active but PVC will not bind

Check:

```bash
kubectl --context <ctx> -n longhorn-system get pods -o wide
kubectl --context <ctx> get nodes -L node.longhorn.io/create-default-disk
kubectl --context <ctx> get storageclass
kubectl --context <ctx> get pvc -A
kubectl --context <ctx> get events -A --sort-by=.lastTimestamp | tail -100
```

Run host validation:

```bash
./scripts/management/preflight/longhorn-storage-preflight.sh --context <ctx>
```

Common root causes include missing iSCSI packages/service, `/mnt/k8sdata` not XFS, insufficient capacity, incorrect mount propagation, multipath claiming devices, or the worker lacking the approved Longhorn disk label.

### Longhorn UI unavailable

Check DNS, source IP policy, `longhorn-ui` Certificate, `longhorn-ui` HTTPProxy, `longhorn-frontend` Service, Envoy, and both sides of the NetworkPolicy path:

```bash
kubectl --context <ctx> -n longhorn-system get certificate,httpproxy,svc,pods
kubectl --context <ctx> -n longhorn-system describe httpproxy longhorn-ui
kubectl --context <ctx> -n longhorn-system get networkpolicy longhorn-ui-allow-segment1-envoy -o yaml
kubectl --context <ctx> -n segment1 get networkpolicy segment1-allow-envoy-to-platform-backends -o yaml
kubectl --context <ctx> get namespace longhorn-system --show-labels
```

The `longhorn-frontend` Service exposes port 80 but targets the Longhorn UI pods on TCP/8000. Calico enforces NetworkPolicy on the translated pod destination, so the Longhorn ingress policy and Segment1 Envoy egress policy must both permit TCP/8000. The `longhorn-system` namespace must also carry `segment1.ingress/allow-backend=true`. An Envoy response containing `upstream connect error ... connection timeout` with a Valid HTTPProxy is a strong indicator that the backend policy path should be checked.

## 11. HTTPProxy `invalid`

Contour marks the object invalid when the desired route cannot be constructed. Check:

```bash
kubectl --context <ctx> -n <ns> describe httpproxy <name>
kubectl --context <ctx> -n <ns> get svc,secret,certificate
```

Typical causes:

- referenced Service does not exist;
- referenced service port is wrong;
- TLS Secret does not exist/has not become Ready;
- invalid schema/route field;
- wrong ingress class;
- dependency has not yet created the backend.

For Keycloak, the standby site intentionally keeps its Service, TLS Certificate, and HTTPProxy **pre-staged** while `keycloakInstances=0`; the route stays dark because there are zero ready Keycloak endpoints. Treat a Valid standby HTTPProxy with zero endpoints as expected. Treat standby ready endpoints as a possible dual-active condition, and treat a missing/invalid standby HTTPProxy or Certificate as degraded failover readiness.

## 12. Istio troubleshooting

### `istio-base` or `istiod` shows `Modified`

Inspect Fleet diff details. Istio injects validating-webhook CA data at runtime; the repository uses field-specific comparison rules for that expected mutation. A new or different drift field should be investigated rather than ignored globally.

### East-west gateway fails Helm schema validation

The Istio Gateway chart version in this baseline does not accept obsolete root `hub`/`tag` values. Those image settings are provided through supported Istio configuration. If schema errors reappear, verify the deployed branch and values against the packaged chart schema.

### Cross-cluster traffic failure

Check east-west gateway VIP, Gateway/Service readiness, Istio remote Secrets, trust material, network routing, and explicit namespace injection state.

## 13. Kiali troubleshooting

Kiali can be Running while external metrics are unavailable. Check:

- Kiali pod/readiness;
- Kiali HTTPProxy/Certificate;
- external Prometheus URL/readiness;
- external Grafana URL/readiness;
- `kiali-grafana-credentials` Secret/RBAC;
- connectivity and CA trust from Kiali to those external endpoints.

## 14. Keycloak / CloudNativePG troubleshooting

Validate site roles first:

```bash
./scripts/deploy-platform.sh validate-identity-ha
```

Check:

```bash
kubectl --context j64seg1opdev -n opkeycloak get pods,svc,httpproxy,certificate
kubectl --context j64seg1opdev -n oppostgres get pods,pvc
kubectl --context j52seg1opdev -n oppostgres get pods,pvc
```

Common failure domains:

- Longhorn PVC not Bound;
- CNPG operator or cluster not Ready;
- CloudNativePG operator blocked from an instance-manager status endpoint on TCP/8000;
- CNPG bootstrap, database, or PgBouncer instance manager blocked from the cluster-local Kubernetes API Service on TCP/443 or its post-DNAT control-plane endpoints on TCP/6443;
- CNPG replica join/bootstrap pod timing out to the local `*-rw` Service on TCP/5432 because a NetworkPolicy selected CNPG pods without allowing **both** local CNPG ingress and local CNPG egress;
- PgBouncer NetworkPolicy/PDB selectors not matching CNPG-owned `cnpg.io/poolerName` / `cnpg.io/podRole=pooler` labels;
- replication TLS/Secret missing;
- replication hostname missing from `dev.kube` or resolving to the wrong Segment1 VIP;
- WAL receiver absent, not `streaming`, connected to the wrong site, stale, or above the configured byte-lag limit;
- Keycloak backend Service absent;
- `opkeycloak` namespace missing `segment1.ingress/allow-backend=true`;
- standby/active labels inconsistent;
- ingress certificate or HTTPProxy invalid;
- DNS still targets the wrong site after failover.

For a CNPG status-path failure, inspect the operator log and policies together:

```bash
kubectl --context j64seg1opdev -n oppostgres logs -l app.kubernetes.io/name=cloudnative-pg --tail=200
kubectl --context j64seg1opdev -n oppostgres get networkpolicy -o yaml
kubectl --context j64seg1opdev -n oppostgres get pods --show-labels
```

The repository explicitly permits the CNPG operator to reach database instance-manager TCP/8000 and permits CNPG-managed workloads to reach both their site-local Kubernetes API Service on TCP/443 and its control-plane endpoints on TCP/6443. Both API representations are required because NetworkPolicy enforcement can occur before or after Service DNAT. It also pre-applies local CNPG cluster-member **ingress and egress** on TCP/5432 before the PostgreSQL Cluster bundle starts. Kubernetes NetworkPolicy is directional and additive: a connection is permitted only when the source egress policy and destination ingress policy both allow it. The September 2026 join failure was the concrete failure mode—DNS correctly resolved the local `*-rw` Service, ingress was present, but the CNPG pod was selected by an egress policy that omitted local database pods. Static validation now parses this policy semantically so an ingress-only regression cannot pass package validation. Default-deny policies remain workload-scoped so they do not unintentionally isolate the Keycloak or CloudNativePG operators that share the application namespaces.

Never promote the secondary by ad-hoc database or label changes. Use the controlled failover process and required fencing.

Run the supported replication diagnostic first:

```bash
./scripts/deploy-platform.sh verify-database-replication
```

The configured names are `j64seg1opdev-postgres-repl.dev.kube` (`1.0.0.216`) and `j52seg1opdev-postgres-repl.dev.kube` (`1.0.0.226`). A stale name such as `opkeycloak-postgres-j64.dev.kube` is not part of the contract. Confirm both records resolve from the database pods and that TCP/5432 is permitted in both directions. If `pg_stat_wal_receiver` has no row, inspect the standby Cluster's `spec.replica.source`, its matching `externalClusters` entry, replication TLS Secrets, CNPG logs, DNS, and NetworkPolicies.

### CloudNativePG `External cluster ... not found` admission failure

The following Fleet error is **remediable in place** and does not require rebuilding healthy Kubernetes clusters:

```text
spec.replicaCluster.self: Invalid value: "j64seg1opdev": External cluster j64seg1opdev not found
spec.replicaCluster.primary: Invalid value: "j64seg1opdev": External cluster j64seg1opdev not found
```

CloudNativePG distributed topology validates `spec.replica.self`, `spec.replica.primary`, and `spec.replica.source` against the topology names present in `spec.externalClusters`. When the Kubernetes `Cluster` object is named `oppostgres-opkeycloak-db` on both sites, the repository uses `replica.self` to provide unique site IDs. That means **both site IDs must be listed in `externalClusters` on both distributed Cluster definitions**, even though only the peer is used as the active streaming source at a given time.

The supported repair is:

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh fleet
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate
```

Do not delete the healthy J64 CNPG Cluster or rebuild the RKE2 clusters for this condition. `enable-identity-secondary` first forces the identity pair back to standalone streaming mode, creates/repairs J52 with `pg_basebackup`, exchanges replication TLS material, and only then enables the distributed topology. If final enrollment fails, it automatically reverts the Fleet topology labels to `false`, leaving J64 writable and J52 as a one-way replica instead of a permanent `ErrApplied` loop.

## 15. Elastic Agent troubleshooting

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If one cluster fails, confirm:

- the cluster's specific enrollment token file was used;
- Fleet URL resolves/routes from the cluster;
- certificate SAN matches the Fleet URL;
- CA file is correct;
- the policy exists and is intended for that cluster;
- the Elastic Agent Secret was seeded;
- `elastic-agent-system/kube-state-metrics` exists as an `ExternalName` Service pointing to `kube-state-metrics.elastic-monitoring.svc.cluster.local`;
- kube-state-metrics uses the `endpointslices` collector rather than the deprecated core/v1 `endpoints` collector on Kubernetes v1.33+.

If validation reports both `kube-state-metrics alias is missing or incorrect` and `Elastic Agent logs contain kube-state-metrics DNS failures` on every cluster, inspect the alias namespace first. The Elastic Kubernetes integration scrapes the short host `kube-state-metrics:8080`, so the compatibility alias must live in `elastic-agent-system`; an alias deployed to `kube-system` will be Fleet-Ready but will not resolve from the Agent namespace.

The validator evaluates Agent errors from the most recent two minutes by default (`ELASTIC_AGENT_LOG_SINCE=2m`) so already-remediated DNS/TLS errors do not remain blocking solely because they are still present in a large log tail. Override the window when investigating intermittent failures.

## 16. `helm-operation-*` pods

Rancher creates temporary Helm operation pods for system-chart work. A failed `1/2` operation can block Rancher provisioning/import workflows.

Use the Rancher system validator/repair workflow to capture their logs and clean up failed temporary operations safely:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh repair-rancher-system
```

Do not indiscriminately delete all Helm operation resources while Rancher is actively reconciling.

## 17. GitLab Runner troubleshooting

For a pending or failed `gitops-validation` job, check in order:

1. the GitLab runner is online, protected, locked to the intended scope, and tagged `gitops-validation`;
2. `gitlab-runner-system/gitlab-runner` is Ready and can verify its `glrt-*` token;
3. the GitLab CA Secret contains `gitlab001.dev.local.crt`;
4. KubeHarbor contains the pinned manager, helper, and Ansible validation images;
5. the job pod is admitted by restricted PodSecurity and can pull `regcred-kubeharbor`;
6. the `runner:canary` job actually creates an executor pod, clones the repository, pulls the helper and Ansible job images, and uploads its harmless artifact before package validation starts;
7. the job image exposes Bash and a Python interpreter whose imported `yaml` module implements `safe_load` and `safe_load_all`.

The Iron Bank UBI manager requires `/usr/local/bin/tini`, `useTini: true`, and UID/GID `1001`. If `/usr/local/bin/tini` is missing, verify the exact image before changing the chart command—the old Docker Hub manager image and the Iron Bank security contract must not be mixed.

The expected manager is `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner:v19.3.1`; the helper is `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1`. The runner allowlist is intentionally exact for the approved Ansible job image; depth-limited `kubeharbor.dev.kube/*` patterns are not accepted. A pull attempt against `kubeharbor.dev.kube/gitlab/...`, or a helper ending in `ubuntu-v19.3.1`, is stale.

If validation reports `yaml module is missing required PyYAML API: safe_load, safe_load_all`, treat it as Python module shadowing or the wrong interpreter—not as proof that PyYAML is absent. The pipeline now probes candidate interpreters in isolated mode, exports `PYTHONSAFEPATH=1`, creates a job-local wrapper that execs the exact interpreter that passed the PyYAML probe, and prints the selected interpreter plus the imported PyYAML file/version. A local repository file/module named `yaml` can no longer silently win over the approved PyYAML installation. The former `CI_PROJECT_DATA`/`phthon3` and hard-coded `/home/python/python-env/bin/activate` assumptions are invalid.

Collect evidence without printing Secret data:

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get deploy,pods,events
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner --since=30m
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

## 18. Escalation package for systems engineering

Tier 2 should include:

1. diagnostic archive from `collect-gitops-logs.sh`;
2. affected cluster/context;
3. Git branch and local commit;
4. live Fleet GitRepo branch/commit;
5. `validate-package` result if a recent code change is involved;
6. relevant `describe` output for HTTPProxy/PVC/Pod/Bundle;
7. exact timestamps and recent change window;
8. whether GitLab, KubeHarbor, DNS, NTP, CA, Elastic, or network teams have confirmed their services healthy.

### Diagnostic collector signal model

The diagnostic archive is deliberately broad, but `error-index.txt` is intentionally high-signal. The collector/validators use the following contract:

- Elastic Agent JSON records are evaluated by their `.message` field instead of raw whole-record regular expressions, which prevents unrelated dataset/configuration fields from creating false monitoring failures.
- Elastic Agent runtime error inspection defaults to `ELASTIC_AGENT_LOG_SINCE=2m`; widen the window only when investigating an intermittent condition.
- kube-state-metrics validation checks the live Deployment and requires the `endpointslices` collector rather than deprecated core/v1 `endpoints`.
- `error-index.txt` indexes current blockers, Kubernetes Warning/failure events, and current-container high-severity/runtime-failure lines. Bulk YAML/JSON object dumps and previous-container logs remain in the archive for forensic review but do not dominate first-pass triage.
- `current-blockers.txt` captures downstream/local Fleet pause state, the identity transition journal, the transition Lease, and active identity DNS status.
- The `segment1` namespace is collected so Contour/Envoy logs, events, Services, and NetworkPolicies are available when an HTTPProxy returns `no healthy upstream`.

This model keeps the archive comprehensive while preventing benign historical/configuration text such as `failureThreshold`, `timeoutSeconds`, or empty `*Error` fields from being treated as current blockers.

## 19. Engineering recovery rules

- Prefer Git correction/revert for Fleet-owned resources.
- Prefer supported repair scripts for Rancher/Fleet state.
- Do not disable TLS verification as a permanent fix.
- Do not manually format/repair Longhorn disks through the preflight tool; it is validation-only.
- Do not delete Chrony without the supported restore path.
- Do not manually reverse identity role labels.
- Capture evidence before destructive actions.
- After remediation, rerun the applicable validator and confirm dependent Fleet bundles return Active.


### Fleet GitRepo shows `Stalled=True` after a successful reconciliation

A transient Git server or network timeout can leave an older `Stalled=True` condition visible even when the same GitRepo later reports `Ready=True`, `GitPolling=True`, a current commit, and all BundleDeployments Ready. Treat the workload state and condition timestamps separately. The repository validator warns and continues only when those current-health signals are all present; an active stall still fails validation.

For the downstream GitRepo, first verify GitLab DNS/HTTPS reachability from the management cluster, then force a new Fleet sync with `./scripts/deploy-platform.sh fleet`. Do not delete healthy Bundles merely to clear the UI condition.

A Rancher count such as `25/27 Bundles ready` can also be expected in the normal primary-site topology when the secondary Keycloak and PostgreSQL-replica bundles are intentionally targetless (`0/0`). Confirm the BundleDeployments and resource counts before treating that ratio as a deployment failure.

### Keycloak Operator reports `409 Conflict` while Keycloak server Pods are healthy

Run exactly one `opkeycloak-operator` replica for a given watched namespace. The Keycloak server remains highly available through the Keycloak CR `spec.instances`; scaling the Operator controller itself creates multiple reconcilers updating the same CR and can produce resource-version/status conflicts. The CIS renderer and generated Operator manifest intentionally preserve one Operator replica.

The Keycloak CR `unsupported.podTemplate` must also avoid overriding the Operator-owned container name or command/args. Use it only for the additional volumes, mounts, and container security context required by the runtime keytab/provider integration.

### Keycloak JDBC timeout to CloudNativePG / PgBouncer

If `opkeycloak-0` reports `Unable to obtain isolated JDBC connection` or `The connection attempt failed` while the CNPG cluster and PgBouncer pods are Ready, verify the NetworkPolicy selectors on both sides of TCP/5432. The Keycloak Operator owns the server labels (`app=keycloak`, `app.kubernetes.io/instance=opkeycloak`, and `app.kubernetes.io/managed-by=keycloak-operator`). Do not authorize PostgreSQL ingress with `app=opkeycloak`; that label is not an operator-owned contract. The prerequisite `oppostgres-resources` bundle installs the Keycloak-to-PgBouncer ingress rule before the Keycloak CR starts. Repository-managed NetworkPolicies own Keycloak traffic, so the operator-generated Keycloak NetworkPolicy is disabled.

### Keycloak replicas start, stop, or continuously reform the cache cluster

If the JDBC error is resolved but the three `opkeycloak-*` pods repeatedly transition between startup/readiness states, inspect JGroups/Infinispan messages and pod events. With `cache-stack=jdbc-ping`, the database is used for peer discovery, while Keycloak members still communicate directly over TCP/7800 and TCP/57800. Because the repository applies an ingress/egress default deny to the Keycloak application pods, both ports must be explicitly allowed from Keycloak server pods to Keycloak server pods. The `opkeycloak-allow-cluster` NetworkPolicy owns this path in both identity-site bundles.

Useful checks:

```bash
kubectl -n opkeycloak get networkpolicy opkeycloak-allow-cluster -o yaml
kubectl -n opkeycloak get pods -l app=keycloak -o wide
kubectl -n opkeycloak logs opkeycloak-0 --previous | egrep -i 'jgroups|infinispan|cluster|suspect|7800|57800|failure'
```

### Replication healthy but planned identity failover says topology is not enrolled

`verify-database-replication` validates the data path; it does not by itself mean Fleet has enrolled both CNPG clusters in the promotion-capable distributed topology. If Fleet labels show `kmm.dev/postgres-distributed-topology=false`, run:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate-identity-ha
```

The initial planned J64 → J52 `failover-identity` path can perform that enrollment automatically after `IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev` is supplied. Failback does not auto-enroll a missing topology; restore/rebuild the warm standby first. When querying the CNPG object manually, use the fully qualified resource `clusters.postgresql.cnpg.io/oppostgres-opkeycloak-db`; `cluster/...` can resolve to Rancher's `clusters.management.cattle.io` CRD on the management plane.

### Planned identity failover fails while creating the transition Lease

If `failover-identity` successfully verifies streaming replication and distributed-topology enrollment but then exits with an API error similar to:

```text
error when creating "STDIN": Lease in version "v1" cannot be handled as a Lease:
parsing time "...Z" as "2006-01-02T15:04:05.000000Z07:00": cannot parse "Z" as ".000000"
```

the database has not been demoted or promoted yet. The failure is in the Kubernetes transition-lock object, not PostgreSQL. `coordination.k8s.io/v1` Lease `acquireTime` and `renewTime` are Kubernetes `MicroTime` fields and require six fractional digits. The supported switchover script emits values such as `2026-09-08T16:55:29.000000Z` for both create and renew operations. Update the script/package rather than bypassing the safety lock. After updating, start the planned transition again with the normal confirmation variables. If a journal exists, inspect `./scripts/deploy-platform.sh identity-transition-status` before choosing a new transition versus `resume-identity-transition`.


### Planned identity transition stops at `fleet-paused` with `phase: unbound variable`

If `switchover-identity.sh` stops with an error similar to `line 191: phase: unbound variable` and `identity-transition-status` reports `stage=fleet-paused`, the transition has not yet fenced WAL or demoted/promoted either PostgreSQL site. The failure is a Bash `set -u` initialization defect in an older `run_phase_hook` implementation where `legacy_phase` referenced `phase` in the same `local` command. Update to the corrected package, preserve the existing journal and Fleet pause state, set `IDENTITY_SWITCHOVER_CONFIRM` to the recorded target, and use `./scripts/deploy-platform.sh resume-identity-transition`. Do not start a second transition and do not manually unpause Fleet.

### Planned identity transition stops at `fleet-labels-switched` with target TLS Certificate not Ready

A planned transition that has already reached `target-promoted` or `fleet-labels-switched` is **past database demotion/promotion**. Do not start a second failover and do not use the pre-demotion rollback path. If the downstream Fleet GitRepo is still paused, the old failover sequencing can deadlock: the controller changes the Fleet role labels while paused and then waits for the target Keycloak Certificate/HTTPProxy, even though those resources are Fleet-owned and cannot reconcile until Fleet resumes.

The corrected workflow inserts a `fleet-target-reconciled` stage between `fleet-labels-switched` and `target-keycloak-ready`. It restores the GitRepo's original active state, waits for `oppostgres`, `oppostgres-replica`, `opkeycloak`, and `opkeycloak-secondary` to become Ready under the new role labels, validates the target Certificate and HTTPProxy, and then performs a direct HTTPS/OIDC health probe against the target Segment1 VIP using `curl --resolve`. Canonical DNS/hosts cutover is not accepted until that pre-cutover target health gate passes.

For a journal already stopped at `fleet-labels-switched`, update to the corrected package, preserve the journal and Lease, then run:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
./scripts/deploy-platform.sh resume-identity-transition
unset IDENTITY_SWITCHOVER_CONFIRM
```

Do not manually patch the PostgreSQL role back to J64. At this stage J52 is intentionally writable and J64 is the warm replica.

The Keycloak Certificate and HTTPProxy are now pre-staged on **both** identity sites even when `keycloak-instances=0`. This removes certificate issuance from the outage-critical path and lets a new planned transition fail its exposure preflight before source traffic is quiesced.

### Kiali repeatedly reports `FailedToRetrieveImagePullSecret` for `map[name:regcred-kubeharbor]`

If Kiali or the Kiali Operator pod spec contains:

```yaml
imagePullSecrets:
  - name: map[name:regcred-kubeharbor]
```

then the real registry Secret is not missing. The Kiali Helm/Kiali CR values supplied the secret as a mapping instead of a secret-name string. Kiali 2.x expects the pull-secret lists to contain strings. The supported values are:

```yaml
# kiali-operator
image:
  pullSecrets:
    - regcred-kubeharbor

# kiali server / Kiali CR-compatible chart values
deployment:
  image_pull_secrets:
    - regcred-kubeharbor
```

After Fleet reconciles these values, the Kiali and Kiali Operator workloads roll with `imagePullSecrets[].name=regcred-kubeharbor`; the recurring kubelet warning should stop.


### Keycloak `no healthy upstream` during/after identity switch

First identify whether the request used the canonical FQDN. The Keycloak `HTTPProxy` matches `opkeycloak.dev.jde.cybercom.ic.gov`; browsing a raw ingress IP is not a valid route/TLS health check because the required FQDN/SNI is missing. Run:

```bash
./scripts/deploy-platform.sh identity-exposure-status all
```

The active site must report three ready endpoints, a Ready Certificate, a valid HTTPProxy whose VIP equals the site ingress VIP, and `directOIDC=healthy`. The warm standby is intentionally dark: `keycloak-instances=0` and zero ready endpoints are expected, while its Service, Certificate, and HTTPProxy remain pre-staged for faster switchover. A published standby HTTPProxy with **zero** ready endpoints is therefore a healthy HA state, not a validation error.

If the target direct OIDC gate has passed, the next production gate is the DNS Admin CNAME change. The normal journal state is `status=waiting-external`, `stage=dns-cutover-pending`. Run:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-dns-status <target>
```

`identity-dns-status` queries each configured Segment1 DNS server in `IDENTITY_DNS_SERVERS` directly. Require `segment1DnsConsensus=match`: every configured resolver should return the target ingress CNAME and only the target ingress VIP when `IDENTITY_DNS_REQUIRE_ALL_SERVERS=true` (the default). The deployment controller's own resolver is shown as `controllerResolvedIPv4` / `controllerCanonicalOIDC` for diagnostics only; it is **not** the production DNS gate.

After DNS Admins change `opkeycloak.dev.jde.cybercom.ic.gov` from the source ingress alias to the target alias (`j64seg1opdev-ingress` or `j52seg1opdev-ingress`), set `IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<recorded-target>` and resume the **same** journal. Do not start another switch, do not manually reverse database roles, and do not use raw ingress-IP browsing as the route test.


### Planned switchback fails at `source-wal-fenced` with `promotionToken is only allowed for primary clusters`

This is the failure signature seen when the **first** planned switchover succeeds but the reverse-direction switchback fails immediately after the final WAL replay gate. The API error may reference `spec.replicaCluster.token` or `spec.replica.promotionToken` and state that the promotion token is only allowed for primary clusters.

Root cause: the site promoted during the prior switchover still has the one-shot token stored in `spec.replica.promotionToken`. A JSON merge patch that changes only `replica.primary` preserves that field. CloudNativePG then evaluates the resulting object as a replica that still carries a promotion token and correctly rejects it. Diagnostic evidence typically looks like:

```text
sourceReplicaPrimary=<source-site> sourcePromotionToken=present sourceLastPromotionToken=present
stage=source-wal-fenced
... promotionToken is only allowed for primary clusters
```

The current controller fixes this in two places: source demotion removes any consumed token **in the same API patch** that changes the distributed-topology primary, and successful target promotion waits for `status.lastPromotionToken` to match before deleting `spec.replica.promotionToken`. `validate-identity-ha` then rejects any stale steady-state token so the problem is caught before the next maintenance window.

If an older package already stopped at `source-wal-fenced`, keep the journal/Fleet pause state intact, deploy the corrected scripts, set `IDENTITY_SWITCHOVER_CONFIRM` to the recorded target, and use `resume-identity-transition`. Do not start an opposite transition and do not hand-edit the CloudNativePG token unless performing a documented break-glass recovery.

For a fresh rebuild, acceptance must include **both directions**: J64 -> J52 and J52 -> J64. A single successful first switchover does not prove reversible failover.

### Identity switch decision matrix

Use this matrix before taking action on a failed identity move:

| Observed state | Correct action |
| --- | --- |
| No journal / terminal journal; source reachable; replication healthy | Start a planned `switch-identity <target>` after normal preflight. |
| Journal `running` or `failed` at any non-terminal stage | Do **not** start another switch. Set `IDENTITY_SWITCHOVER_CONFIRM` to the journal's recorded target and run `resume-identity-transition`. |
| Journal `waiting-external` / `dns-cutover-pending` | Target DB/Keycloak is prepared. DNS Admin changes the canonical CNAME; run `identity-dns-status <target>` and require `segment1DnsConsensus=match`, then set `IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<target>` and resume the same journal. |
| Planned journal before `source-demoted` and the change must be abandoned | `rollback-identity-transition` is supported. |
| Journal at/after `source-demoted` or `target-promoted` | Do not rollback manually. Resume the recorded transition. |
| Current primary/site is lost or untrustworthy | Use unplanned mode only after hard-fencing the old source and accepting asynchronous-replication RPO risk. |
| Unplanned transition completes `complete-degraded` | Keep the old source fenced/hibernated; validate with `--allow-degraded`; rebuild the former primary before planned failback. |
| Active site canonical FQDN works but standby reports `no healthy upstream` | Expected when standby Keycloak instances are `0`; Service/TLS/HTTPProxy are intentionally pre-staged while endpoints remain zero. |
| Canonical FQDN fails on the site that `identity-active-site` reports active | Run `identity-exposure-status all`; inspect active site's endpoints, Certificate, HTTPProxy, direct OIDC result, Envoy/Contour logs/events, and traffic mapping. |

### Unplanned identity failover does not start

The unplanned path intentionally has more safety gates than a planned switchover. Verify all of the following are set for the intended target:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<target-site>
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/approved/executable/fence-source.sh
```

The hard-fence hook is mandatory because the old primary must not be able to return and accept writes after the surviving target is promoted. If the hook is missing, non-executable, or does not prove source isolation, fix the fencing mechanism instead of bypassing the check.

The target must also have a trustworthy replay LSN. The workflow records the target's replay LSN and WAL receiver snapshot before pausing Fleet and promoting. If the target has no usable replay position, do not force promotion; determine whether the replica was ever successfully initialized and what recovery source is available.

### After unplanned promotion, former primary comes back online

Do not simply unhibernate/reconnect it. The former primary may be on a divergent timeline. Keep it fenced and use the supported rebuild workflow from the surviving writable site:

```bash
export IDENTITY_REBUILD_CONFIRM=<former-primary-site>
export IDENTITY_REBUILD_DELETE_STORAGE=true
./scripts/deploy-platform.sh rebuild-identity-standby <former-primary-site>
```

After rebuild, require both of these to pass before planned failback:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```



### Identity failover appears stuck / convergence message does not change

Use the controller diagnostics before changing cluster state:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics
./scripts/deploy-platform.sh identity-dns-status <recorded-target>
```

The failover controller uses bounded Kubernetes and DNS operations; long waits print `WAIT gate=... elapsed=... remaining=...` with the blocking state. In the production `dns-admin` model, after target OIDC health is proven the controller journals `dns-cutover-pending`, prints `DNS ADMIN ACTION REQUIRED`, releases the transition lock, and exits successfully.

After DNS Admin acknowledgement, the controller validates the canonical record directly against the configured Segment1 DNS servers. With the shipped 30-second TTL it warns after the 90-second convergence grace. `IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS` defaults to 180 seconds. If Segment1 DNS still does not converge in that window, the transition returns to `status=waiting-external`, keeps the promoted database/Keycloak state intact, releases the lock, and exits without turning an external DNS dependency into a ten-minute blocking/failure loop. Correct DNS and resume the same journal again.

A healthy DNS gate looks like:

```text
dnsServer=<segment1-dns-1> ... status=match
dnsServer=<segment1-dns-2> ... status=match
segment1DnsConsensus=match
directTargetOIDC=healthy
controllerResolverGate=false
```

If one Segment1 resolver is `mismatch` while another is `match`, treat it as partial DNS convergence/replication and correct the DNS service before completing the transition. Do not lower `IDENTITY_DNS_REQUIRE_ALL_SERVERS` merely to force a switchover through a split DNS view.

### DNS is correct for Segment1 clients but failover reports `unresolved`

Older failover packages gated the DNS transition on the deployment controller's local resolver. That creates a false negative when the controller is not configured to resolve the enterprise identity zone even though Segment1 clients and the target ingress are healthy. Typical evidence is:

- direct target OIDC is healthy through `curl --resolve`;
- a Segment1 client resolves `opkeycloak.dev.jde.cybercom.ic.gov` to the target ingress alias/VIP and can load Keycloak; but
- transition output repeatedly shows `observedCNAME=unresolved`, `controllerDNS=unresolved`, and `canonicalOIDC=unhealthy`.

Use the current package and configure the protected runtime file with the DNS servers that Segment1 clients use for this zone:

```bash
IDENTITY_DNS_SERVERS="<segment1-dns-1> <segment1-dns-2>"
IDENTITY_DNS_REQUIRE_ALL_SERVERS=true
IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS=180
```

Then verify and resume the existing transition:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-dns-status <recorded-target>
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target>
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<recorded-target>
./scripts/deploy-platform.sh resume-identity-transition
unset IDENTITY_SWITCHOVER_CONFIRM IDENTITY_TRAFFIC_CUTOVER_CONFIRM
./scripts/deploy-platform.sh validate-identity-ha
```

Do **not** start a second `switch-identity` and do **not** manually promote/demote PostgreSQL if the journal is already at/after `target-promoted`. The existing journal is the recovery control point.

