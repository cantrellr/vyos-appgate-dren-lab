# Operations and Lifecycle

> **Baseline:** v2.5 — September 9, 2026  
> **Audience:** platform operators, systems administrators, SRE/operations personnel, and escalation engineers.

## 1. Operating model

Normal steady-state changes follow this loop:

1. change the intended Git branch;
2. run `validate-package`;
3. push to GitLab;
4. allow Fleet to reconcile;
5. validate BundleDeployment readiness and service-specific health;
6. revert Git if the change is not acceptable.

Do not treat Rancher UI red states as a reason to manually delete Bundles. First identify the failing dependency and the Git commit/branch Fleet is actually reconciling.

## 2. Daily health checks

Recommended daily/shift checks:

```bash
./scripts/deploy-platform.sh validate-rancher-system
./scripts/deploy-platform.sh validate-cluster-time
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

For storage-sensitive operations also run:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

`prepare-longhorn-nodes` is non-destructive and verifies the host storage contract.

## 3. Rancher and Fleet operations

### Fleet readiness

Healthy steady state means the intended GitRepos are Ready and all intended BundleDeployments are Active. Bundle dependencies are expressed by `kmm.dev/bundle` labels.

Inspect GitRepos:

```bash
kubectl --context j64seg1opman -A get gitrepos.fleet.cattle.io
```

Inspect bundles by workspace:

```bash
kubectl --context j64seg1opman -n fleet-local get bundles.fleet.cattle.io
kubectl --context j64seg1opman -n fleet-default get bundles.fleet.cattle.io
```

Inspect the actual branch/commit:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

### Kubernetes 1.35 Fleet compatibility

The baseline requires `KUBE_FEATURE_WatchListClient=false` on Fleet controllers and agents. Apply/verify with:

```bash
./scripts/deploy-platform.sh configure-fleet-watchlist
```

Do not remove this control until the pinned Rancher/Fleet combination is upgraded and the replacement has been validated against RKE2/Kubernetes 1.35 behavior.

### Rancher system repair

Use:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```

The repair workflow validates the registry, refreshes CoreDNS/registry credentials, restores Rancher ingress, repairs PSA namespace labels, applies GitJob RBAC, enforces the WatchListClient compatibility setting, waits for Rancher/Fleet components, and forces GitRepo rescan. It intentionally avoids deleting healthy Rancher/Fleet resources.

## 4. GitOps deployment flow

```mermaid
flowchart LR
  OP[Operator changes configuration]
  REPO[GitLab branch]
  JOB[Fleet GitJob]
  BUNDLE[Fleet Bundles]
  TARGETS[Cluster targets and labels]
  HELM[OCI Helm charts in KubeHarbor]
  SECRET[Runtime secrets seeded outside Git]
  APPLY[BundleDeployments]
  VERIFY[Validation gates]

  subgraph C[j64seg1opman]
    R[Rancher]
    F[Fleet]
  end

  subgraph D[Managed clusters]
    P[Platform components]
    I[Istio and Kiali]
    L[Longhorn]
    K[Identity stack]
    E[Elastic Agent]
  end

  OP --> REPO
  REPO --> JOB
  R --> F
  F --> JOB
  JOB --> BUNDLE
  TARGETS --> BUNDLE
  HELM --> BUNDLE
  SECRET --> APPLY
  BUNDLE --> APPLY
  APPLY --> P
  APPLY --> I
  APPLY --> L
  APPLY --> K
  APPLY --> E
  P --> VERIFY
  I --> VERIFY
  L --> VERIFY
  K --> VERIFY
  E --> VERIFY
  VERIFY -->|healthy| DONE[Active]
  VERIFY -->|failure| TRIAGE[Collect diagnostics and correct source of truth]
  TRIAGE --> REPO
```

Operational principle: correct the **source of truth** or the external dependency causing reconciliation failure. Direct changes to Fleet-owned resources are break-glass actions and may be reverted automatically.

## 5. Chrony operations

Chrony owns the host clock while deployed. It runs as a privileged DaemonSet and records the prior `systemd-timesyncd` state under `/var/lib/k8mm/chrony`.

Validate all clusters:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

Target one cluster:

```bash
./scripts/management/preflight/cluster-time.sh --context j64seg1opdev --verify-only
```

View compact telemetry:

```bash
kubectl --context j64seg1opdev -n kube-system   logs -l app=chrony-client -c chrony-status --tail=50
```

A healthy node reports a selected source, positive stratum, and `Leap status: Normal`. The installer emits detailed `tracking`, `sources`, `ntpdata`, log, and event information when synchronization fails.

Supported removal:

```bash
./scripts/deploy-platform.sh uninstall-cluster-time
```

Do not delete the DaemonSet manually as the standard removal method; the supported command restores the saved host time-service state.

## 6. Longhorn operations

### Host contract

Default worker contract:

- path: `/mnt/k8sdata`;
- filesystem: XFS;
- minimum capacity: `240 GiB`;
- iSCSI available and active;
- shared root mount propagation;
- multipath disabled where it can claim Longhorn devices.

Validate:

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

### Kubernetes checks

```bash
kubectl --context j64seg1opdev -n longhorn-system get pods -o wide
kubectl --context j64seg1opdev get storageclass
kubectl --context j64seg1opdev get pvc -A
```

The stateful identity workloads use `longhorn-xfs-retain`.

### Longhorn UI

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://longhorn-man.dev.kube` |
| `j64seg1opdev` | `https://longhorn-j64.dev.kube` |
| `j52seg1opdev` | `https://longhorn-j52.dev.kube` |
| `r01seg1opdev` | `https://longhorn-r01.dev.kube` |

Fleet creates the HTTPProxy/certificate. The proxy allows only source addresses in `1.0.0.0/23` and sends traffic to `longhorn-frontend:80`.

Use Longhorn snapshots/replicas for in-cluster operational recovery, but maintain a separately approved disaster-recovery/backup strategy if off-cluster recovery is required.

## 7. Istio and Kiali operations

Validate mesh components and namespace injection:

```bash
./scripts/istio/04-check-istio-system.sh --all
./scripts/istio/05-audit-namespace-injection.sh --all
```

Kiali URLs:

| Context | URL |
| --- | --- |
| `j64seg1opman` | `https://kiali-man.dev.kube` |
| `j64seg1opdev` | `https://kiali-j64.dev.kube` |
| `j52seg1opdev` | `https://kiali-j52.dev.kube` |
| `r01seg1opdev` | `https://kiali-r01.dev.kube` |

Kiali depends on the external Prometheus and Grafana endpoints configured in its values. A healthy Kiali pod can therefore still show degraded metrics if those external services or the Grafana credential Secret are unavailable.

Istio webhook CA fields are controller-managed runtime data. Fleet comparison rules intentionally ignore only the expected `caBundle` mutation rather than suppressing entire webhook objects.

## 8. Identity operations

### Identity HA operating model

The identity service is **bidirectional active/warm-standby** across J64 and J52. Either site can be the active site after a successful planned switchover. Only one PostgreSQL site is writable and only one Keycloak site serves user traffic at a time.

| Site | Segment1 ingress VIP | DNS ingress alias | PostgreSQL replication VIP | Runtime role |
| --- | --- | --- | --- | --- |
| `j64seg1opdev` | `1.0.0.215` | `j64seg1opdev-ingress` | `1.0.0.216` | active or warm standby |
| `j52seg1opdev` | `1.0.0.225` | `j52seg1opdev-ingress` | `1.0.0.226` | active or warm standby |

The canonical user endpoint is:

```text
https://opkeycloak.dev.jde.cybercom.ic.gov
```

**DNS is not owned by the failover scripts.** DNS Admins manually change the canonical record as a CNAME between the two ingress aliases:

```text
J64 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
J52 active: opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
TTL: 30 seconds
```

The failover controller treats this as an external change-management gate. It prepares and validates the target first, journals `dns-cutover-pending`, releases the transition lock, prints the exact DNS Admin action, and exits successfully. After DNS Admins make the CNAME change, the operator resumes the **same journal** with an explicit traffic confirmation.

The controller validates the record by querying the configured **Segment1/JDE DNS servers directly** (`IDENTITY_DNS_SERVERS`). By default every configured resolver must return the target ingress CNAME and only the target VIP. The controller host's local resolver is displayed for diagnostics but is not a failover gate. This is important because the deployment controller may not be configured to resolve `dev.jde.cybercom.ic.gov` even while Segment1 clients resolve it correctly.

The static Fleet label `kmm.dev/identity=primary|secondary` is a **physical site/bundle-family selector** and is not swapped. Runtime ownership is controlled by `kmm.dev/identity-active`, `kmm.dev/keycloak-instances`, `kmm.dev/postgres-primary-site`, and the CloudNativePG distributed-topology fields.

Contour routes Keycloak by the canonical FQDN/SNI. A raw request to an ingress IP is not a valid Keycloak health test. The inactive site normally has zero Keycloak endpoints and may return `no healthy upstream`; that is expected. The canonical Keycloak `Certificate` and `HTTPProxy` are pre-staged on both sites, while Keycloak replicas remain `0` on the standby until it becomes the switchover target.

### Command quick reference

```bash
# Role, exposure, DNS and journal state
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics

# Database/HA validation
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha

# Planned bidirectional switch
./scripts/deploy-platform.sh switch-identity j64
./scripts/deploy-platform.sh switch-identity j52

# Recover an interrupted/waiting transition
./scripts/deploy-platform.sh resume-identity-transition
./scripts/deploy-platform.sh rollback-identity-transition   # planned, pre-demotion only

# Disaster recovery after an unplanned promotion
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
./scripts/deploy-platform.sh rebuild-identity-standby <site>
```

`failover-identity` and `failback-identity` remain compatibility commands. New work should use `switch-identity j64|j52` so the target is explicit.

### Required runtime DNS settings

The baseline configuration is:

```bash
IDENTITY_TRAFFIC_CUTOVER_MODE=dns-admin
IDENTITY_PRIMARY_INGRESS_CNAME=j64seg1opdev-ingress
IDENTITY_SECONDARY_INGRESS_CNAME=j52seg1opdev-ingress
IDENTITY_PRIMARY_INGRESS_IP=1.0.0.215
IDENTITY_SECONDARY_INGRESS_IP=1.0.0.225
IDENTITY_DNS_TTL_SECONDS=30
IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS=90
IDENTITY_DNS_SERVERS="1.0.1.30 1.0.1.31"   # override with the actual Segment1/JDE resolver set
IDENTITY_DNS_REQUIRE_ALL_SERVERS=true
IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS=180
IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS=600
```

`dns-admin` is the production/default operating mode for this environment. Legacy `manual` and `dns` values both migrate to `dns-admin`, which prevents older runtime configs or journals from silently re-entering the controller-waits-for-DNS behavior. Use explicit `controller-dns` only in an environment where DNS is automated by the controller or a hook.

The 90-second convergence grace is three times the configured 30-second TTL. In `dns-admin` mode, the post-acknowledgement DNS validation window defaults to 180 seconds. If the Segment1 DNS servers still do not agree by then, the workflow does **not** fail the database transition or hold the Lease for ten minutes; it records `waiting-external` at `dns-cutover-pending`, releases the transition lock, prints resolver-specific diagnostics, and exits safely so DNS can be corrected and the same journal resumed. The 600-second traffic timeout remains available for `controller-dns` mode and direct target OIDC gating.

### Preflight before every planned switchover

Run:

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
```

Required conditions:

1. The journal is absent or terminal (`complete`, `complete-degraded`, or `rolled-back`). A non-terminal journal must be resumed before any opposite-direction switch.
2. Fleet is active/reconciled; planned failover refuses to start if the downstream GitRepo was already paused.
3. The current source PostgreSQL site is reachable and writable.
4. The target PostgreSQL site is in recovery and streaming from the source within the configured thresholds.
5. Both sites are enrolled in the distributed CloudNativePG topology. `validate-identity-ha` also requires steady-state `spec.replica.promotionToken` to be absent on both sites; a leftover token indicates an incomplete/older switchover implementation and would break the next demotion.
6. The target Service, Certificate, and HTTPProxy already exist and are valid. The warm site may have zero Keycloak endpoints until activation.
7. DNS Admins are available to perform the CNAME change when the workflow reaches `dns-cutover-pending`.

If distributed-topology enrollment is missing during initial J64 -> J52 setup:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate-identity-ha
```

### What the planned workflow does

The planned workflow is journaled in `fleet-default/kmm-identity-transition-journal`; a Kubernetes Lease prevents competing transitions.

1. Verify replication and distributed-topology readiness.
2. Verify the target's pre-staged Service/Certificate/HTTPProxy.
3. Pause downstream Fleet and record its original state.
4. Quiesce source Keycloak and scale source Keycloak to zero.
5. Fence application writes, checkpoint PostgreSQL, and wait for the target to replay the final source WAL LSN.
6. Demote the source and obtain the CloudNativePG demotion token. The source-demotion patch atomically removes any previously consumed `spec.replica.promotionToken` while changing `replica.primary`; this prevents the reverse-direction switchover from being rejected by CloudNativePG admission.
7. Promote the target using that token, wait until PostgreSQL is writable **and** CloudNativePG records the same value in `status.lastPromotionToken`, then remove the consumed token from the target spec. The status evidence remains available while the steady-state spec is clean for the next switchback.
8. Switch runtime Fleet role labels.
9. Restore Fleet and wait for post-promotion identity bundles to reconcile.
10. Start target Keycloak; verify endpoints, Certificate, HTTPProxy, and direct SNI/OIDC health.
11. Journal `stage=dns-cutover-pending`, `status=waiting-external`, release the lock, and print the DNS Admin CNAME change.
12. DNS Admin changes the canonical CNAME to the target ingress alias.
13. Operator resumes the same journal with `IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<target>`.
14. Controller queries every configured Segment1 DNS server for the canonical CNAME/A chain and requires the target-only VIP result; direct target SNI/OIDC must remain healthy. Controller-local DNS is informational only.
15. Verify reverse PostgreSQL replication and strict identity HA.
16. Mark the journal `complete` and release the transition Lease.

The failover script never changes authoritative DNS itself.

### Planned switchover: J64 to J52

Use this when `identity-active-site` reports `j64seg1opdev`.

**Step 1 - start the planned database/Keycloak transition:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned

./scripts/deploy-platform.sh switch-identity j52

unset IDENTITY_SWITCHOVER_MODE
```

The command intentionally stops after target J52 is healthy and prints:

```text
stage=dns-cutover-pending
status=waiting-external
DNS ADMIN ACTION REQUIRED
Change CNAME from: j64seg1opdev-ingress
Change CNAME to  : j52seg1opdev-ingress
Target ingress   : 1.0.0.225
```

**Step 2 - DNS Admin change:**

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
```

Do not point the canonical CNAME at a raw VIP; the operational contract is CNAME-to-ingress-alias.

**Step 3 - inspect DNS convergence:**

```bash
./scripts/deploy-platform.sh identity-dns-status j52
```

Expected end state includes:

```text
expectedCNAME=j52seg1opdev-ingress
expectedIngressIP=1.0.0.225
dnsValidationScope=segment1
dnsServer=1.0.1.30 observedCNAME=j52seg1opdev-ingress.dev.kube resolvedIPv4=1.0.0.225 cnameMatch=match ingressIPMatch=match status=match
dnsServer=1.0.1.31 observedCNAME=j52seg1opdev-ingress.dev.kube resolvedIPv4=1.0.0.225 cnameMatch=match ingressIPMatch=match status=match
segment1DnsConsensus=match
directTargetOIDC=healthy
controllerResolverGate=false
```

`dig`, `host`, or `nslookup` is required for authoritative per-server validation. The output contains one line per configured Segment1 resolver. With `IDENTITY_DNS_REQUIRE_ALL_SERVERS=true`, every resolver must return the expected CNAME and target-only A result. This intentionally catches a partially replicated DNS change before the identity transition is marked complete.

**Step 4 - resume the same journal:**

```bash
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev
./scripts/deploy-platform.sh resume-identity-transition

unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

Expected steady state:

- J52 PostgreSQL writable; Keycloak `3`; canonical Keycloak healthy through the J52 ingress alias.
- J64 PostgreSQL streaming replica; Keycloak `0`.
- Journal `status=complete`, `stage=complete`.

### Planned switchover: J52 back to J64

Do not start until the prior journal is terminal and reverse replication from J52 to J64 is healthy.

**Step 1:**

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j64seg1opdev
export IDENTITY_SWITCHOVER_MODE=planned

./scripts/deploy-platform.sh switch-identity j64

unset IDENTITY_SWITCHOVER_MODE
```

The workflow stops at `dns-cutover-pending` after J64 is directly healthy.

**Step 2 - DNS Admin change:**

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j64seg1opdev-ingress
```

**Step 3:**

```bash
./scripts/deploy-platform.sh identity-dns-status j64
```

**Step 4:**

```bash
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j64seg1opdev
./scripts/deploy-platform.sh resume-identity-transition

unset IDENTITY_SWITCHOVER_CONFIRM
unset IDENTITY_TRAFFIC_CUTOVER_CONFIRM
```

Expected steady state:

- J64 PostgreSQL writable; Keycloak `3`; canonical Keycloak healthy through the J64 ingress alias.
- J52 PostgreSQL streaming replica; Keycloak `0`.
- Journal `status=complete`, `stage=complete`.
- `validate-identity-ha` reports no stale CloudNativePG promotion token on either site.

For a newly rebuilt environment, **do not consider identity HA acceptance complete after only the first J64 -> J52 move**. Execute the full J64 -> J52 -> J64 round trip during the test window. The first direction proves promotion; the return direction proves that token cleanup, reverse replication, Fleet role reversal, DNS cutback, and resume logic are all reusable rather than one-shot.

### Built-in diagnostics and bounded waits

The controller prints the gate, elapsed time, remaining time, and the state actually blocking progress. DNS cutover progress resembles:

```text
[INFO] WAIT gate=dns-cname-tls-oidc elapsed=30s remaining=150s segment1DNS=mismatch expectedCNAME=j52seg1opdev-ingress expectedIP=1.0.0.225 directTargetOIDC=healthy controllerCanonicalOIDC=unhealthy details=resolver=1.0.1.30 ...; resolver=1.0.1.31 ...;
```

Use:

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-transition-diagnostics
./scripts/deploy-platform.sh identity-dns-status <active|j64|j52>
```

`identity-transition-status` and DNS/NSS/API probes are bounded. The status command reports `nextExternalAction` when the journal is waiting on the DNS Admin CNAME change.

Default waits:

| Gate | Default | Override |
| --- | ---: | --- |
| DNS-admin Segment1 resolver validation after acknowledgement | 180 s | `IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS` |
| Controller-DNS / target traffic timeout | 600 s | `IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS` |
| Expected DNS convergence warning | 90 s | `IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS` |
| Published DNS TTL | 30 s | `IDENTITY_DNS_TTL_SECONDS` |
| Target Keycloak/exposure | 900 s | `IDENTITY_TARGET_EXPOSURE_TIMEOUT_SECONDS` |
| Fleet post-role reconciliation | 900 s | `IDENTITY_FLEET_RECONCILE_TIMEOUT_SECONDS` |
| CNPG WAL/demotion/promotion | 900 s | `IDENTITY_DATABASE_TRANSITION_TIMEOUT_SECONDS` |
| Kubernetes API request | 10 s/request | `IDENTITY_KUBECTL_REQUEST_TIMEOUT` |
| DNS/NSS lookup | 5 s | `IDENTITY_DNS_LOOKUP_TIMEOUT_SECONDS` |
| Poll interval | 5 s | `IDENTITY_FAILOVER_POLL_INTERVAL_SECONDS` |
| Progress report interval | 30 s | `IDENTITY_FAILOVER_DIAGNOSTIC_INTERVAL_SECONDS` |

### Interrupted transition: resume versus rollback

Never start a second transition while the journal is non-terminal.

```bash
./scripts/deploy-platform.sh identity-transition-status
```

If the journal is `dns-cutover-pending` / `waiting-external`, complete the **recorded** CNAME change and resume the recorded target:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
```

If another non-terminal stage failed, resume the recorded target without creating a new operation:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=<recorded-target-site>
./scripts/deploy-platform.sh resume-identity-transition
```

Automatic rollback is supported only for a **planned** transition before source database demotion:

```bash
./scripts/deploy-platform.sh rollback-identity-transition
```

At or after `source-demoted` / `target-promoted`, do not manually reverse CNPG replica fields, Fleet role labels, Fleet pause state, or DNS merely to make the journal disappear. Resume the recorded operation.

### Post-planned-switchover validation

```bash
./scripts/deploy-platform.sh identity-transition-status
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate
```

The active site should show ready Keycloak endpoints, `certificateReady=True`, valid HTTPProxy, `directOIDC=healthy`, and `segment1DnsConsensus=match` for that site's ingress alias/VIP. The standby is expected to have zero Keycloak endpoints **while retaining a pre-staged Service, Ready Certificate, and Valid HTTPProxy**. That pre-staged standby exposure is healthy design state, not an HA validation error.

### Unplanned failover: source site unavailable

Use unplanned mode only when the current writable site is unavailable or cannot safely participate in a planned demotion. Cross-site PostgreSQL replication is asynchronous; unplanned promotion can lose recent acknowledged transactions. The workflow requires explicit RPO acknowledgement and a **hard fence** of the old source before target promotion.

The management cluster (`j64seg1opman`) must remain available because the controller journals the operation and changes Fleet state there. If the management plane is unavailable, restore management first; this repository does not implement management-less direct promotion.

Before promotion:

1. Determine the surviving target site.
2. Confirm the old source is unavailable/untrusted.
3. Review the target replay/WAL receiver evidence.
4. Provide an approved executable hard-fence hook that prevents the old source from returning writable.
5. Ensure DNS Admins are available for the final CNAME change.
6. Resume any existing non-terminal journal rather than starting another operation.

Example: J64 is lost and J52 must be promoted:

```bash
export IDENTITY_SWITCHOVER_CONFIRM=j52seg1opdev
export IDENTITY_SWITCHOVER_MODE=unplanned
export IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
export IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
export IDENTITY_HARD_FENCE_SOURCE_HOOK=/approved/path/fence-j64.sh

./scripts/deploy-platform.sh switch-identity j52
```

After hard fencing, target promotion, Fleet reconciliation and direct J52 OIDC health, the workflow stops at:

```text
status=waiting-external
stage=dns-cutover-pending
```

DNS Admin then changes:

```text
opkeycloak.dev.jde.cybercom.ic.gov CNAME -> j52seg1opdev-ingress
```

Resume:

```bash
export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=j52seg1opdev
./scripts/deploy-platform.sh resume-identity-transition
```

Example: J52 is lost while active and J64 must be promoted uses the same process with target `j64seg1opdev`, a J52 fence hook, and final CNAME `j64seg1opdev-ingress`.

A successful unplanned promotion ends intentionally as:

```text
status=complete-degraded
stage=complete-degraded
```

The former primary remains fenced/hibernated. Validate the surviving site with:

```bash
./scripts/deploy-platform.sh identity-active-site
./scripts/deploy-platform.sh identity-exposure-status all
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh validate-identity-ha --allow-degraded
```

### Rebuild the former primary after an unplanned promotion

Do not simply reconnect a former primary; it may be on a divergent timeline. Rebuild it from the surviving active site:

```bash
export IDENTITY_REBUILD_CONFIRM=<former-primary-site>
export IDENTITY_REBUILD_DELETE_STORAGE=true

./scripts/deploy-platform.sh rebuild-identity-standby <former-primary-site>

unset IDENTITY_REBUILD_CONFIRM IDENTITY_REBUILD_DELETE_STORAGE
```

Then require:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh identity-exposure-status all
```

Only after strict checks pass should another planned switch be attempted.

### Operational rules that prevent split brain or accidental outage

- Never start an opposite-direction switch while a non-terminal journal exists.
- Never delete the transition Lease or journal to bypass a failed stage.
- Never swap static `kmm.dev/identity=primary|secondary` labels.
- Never manually patch CNPG `replica.primary`, `replica.self`, promotion tokens, or demotion tokens during an active journal.
- DNS Admins change only the canonical CNAME; the failover controller never modifies authoritative DNS.
- Validate the canonical identity record against `IDENTITY_DNS_SERVERS` in Segment1; do not use the deployment controller's local resolver as the production DNS authority.
- Keep `IDENTITY_DNS_REQUIRE_ALL_SERVERS=true` unless an approved DNS design explicitly accepts partial resolver disagreement.
- Do not request the DNS CNAME change until the workflow reports `dns-cutover-pending` and direct target OIDC is healthy.
- After DNS change, resume the same journal with `IDENTITY_TRAFFIC_CUTOVER_CONFIRM` for the recorded target.
- A raw ingress IP is not a Keycloak health check; use the canonical FQDN/SNI or `curl --resolve`.
- `no healthy upstream` on the warm site is expected when Keycloak instances are `0`.
- Unplanned failover requires hard fencing before promotion; if the old writable site can return and accept writes, do not promote the peer.
- After unplanned promotion, rebuild the former primary before planned failback.

## 9. Elastic observability operations

The default model uses one Elastic Agent DaemonSet and one kube-state-metrics Deployment per cluster, with one Fleet enrollment policy/token per cluster. A compatibility `ExternalName` Service named `kube-state-metrics` is placed in `elastic-agent-system` so the Elastic Kubernetes integration's short-name scrape target resolves to `kube-state-metrics.elastic-monitoring.svc.cluster.local`. kube-state-metrics explicitly collects `endpointslices` instead of the deprecated core/v1 `endpoints` resource on Kubernetes v1.33+.

Validate:

```bash
./scripts/deploy-platform.sh validate-monitoring
```

If enrollment fails, confirm Fleet Server URL, CA/SAN correctness, token-to-policy mapping, network reachability, and the `elastic-agent` Secret seeded on the affected cluster.

## 10. GitLab Runner operations

The Runner is Fleet-owned in `gitlab-runner-system` on `j64seg1opman`.

```bash
kubectl --context j64seg1opman -n gitlab-runner-system get pods
kubectl --context j64seg1opman -n gitlab-runner-system logs deployment/gitlab-runner
kubectl --context j64seg1opman -n gitlab-runner-system exec deployment/gitlab-runner -- gitlab-runner verify
```

Rotate the runner authentication token or GitLab CA by updating the protected input file and rerunning `./scripts/deploy-platform.sh seed-secrets`. Do not commit the `glrt-*` token. GitLab controls the runner tag, protected status, locking, and project/group scope; the cluster bundle controls runtime version, executor policy, and the exact approved Harbor job-image allowlist.

Every pipeline now starts with `runner:canary`. That job intentionally proves the Kubernetes executor path rather than only manager registration: job Pod admission, helper pull, approved Ansible image pull, repository clone, restricted security context/RBAC, and artifact upload must all work before `validate:gitops-package` runs. Validation selects a Python interpreter by importing the required PyYAML APIs in isolated mode, wraps that exact runtime as the job-local `python3`, and then executes repository Python checks with safe-path isolation; a shadow `yaml` module in the checkout must not be accepted.

## 11. Certificate operations

cert-manager uses the Segment1 ClusterIssuer seeded through the protected CA material. Check certificate status:

```bash
kubectl --context j64seg1opman get certificates -A
kubectl --context j64seg1opman get clusterissuer
```

Repeat for the affected cluster. Do not disable TLS verification to work around CA-chain failures; fix trust or certificate identity.

Cross-site PostgreSQL replication certificates are also an operational lifecycle item. `verify-database-replication` compares the generated source certificate/CA fingerprints with the copied peer Secrets and rejects certificates inside the configured minimum-validity window. Rotate the source certificate through the approved certificate process, rerun the identity Secret synchronization/enablement path, and prove fingerprint agreement plus bidirectional replication before a maintenance window. Do not wait for switchover day to discover an expired replication certificate.

## 12. Ingress and HTTPProxy operations

List Contour proxies:

```bash
kubectl --context j64seg1opdev get httpproxy -A
```

Inspect a proxy:

```bash
kubectl --context j64seg1opdev -n <namespace> describe httpproxy <name>
```

An `invalid` HTTPProxy usually indicates a missing backend Service/port, missing TLS Secret, invalid route definition, or ingress-class/dependency problem. Resolve the underlying reference rather than deleting the proxy.

## 13. CIS/PodSecurity lifecycle

Rancher/Fleet and several platform components require scoped privileged PSA namespaces. Keep exceptions limited to system namespaces and prepare Rancher/Fleet namespaces before cluster import. Application namespaces should remain restricted unless a reviewed workload requirement says otherwise.

## 14. Upgrade lifecycle

For every component upgrade:

1. confirm RKE2/Rancher/Fleet compatibility;
2. obtain/promote images through the approved air-gap workflow;
3. stage the exact Helm chart archive;
4. update the package allowlist, OCI inventory, and checksums;
5. review chart defaults for newly introduced transitive images;
6. update values and compatibility controls;
7. run `validate-package`;
8. publish immutable OCI charts;
9. deploy through Git/Fleet;
10. validate all service-specific gates.

The shared Helm wrapper requires Helm 4 and uses `--rollback-on-failure`; the deprecated `--atomic` CLI alias is not part of the supported wrapper path.

## 15. Backup and recovery boundaries

- GitLab: back up repository data and branch history according to GitLab operations policy.
- KubeHarbor: preserve registry projects/artifacts and CA configuration.
- Rancher/Fleet: preserve Rancher state according to the management-cluster recovery plan.
- RKE2: maintain the approved etcd snapshot/recovery process outside this repository.
- Longhorn: snapshots/replicas are in-cluster; define off-cluster backup separately where required.
- Identity: cross-site replication and Longhorn are **not** substitutes for off-cluster backup/PITR. This repository does not invent an object-store target or credentials; production authorization requires an approved off-cluster CloudNativePG backup destination, retention policy, restore test, and documented PITR RPO/RTO. Until that is supplied, this remains an explicit recovery-control gap rather than a silently fabricated configuration.
- protected configuration: securely back up credential files, CA material, and Istio CA directories outside Git.

## 16. Change-management evidence

For significant changes retain:

- Git commit and branch deployed;
- `validate-package` output;
- Fleet GitRepo commit and bundle state;
- relevant Rancher/Fleet/Longhorn/identity validation output;
- diagnostic bundle for failed changes;
- security/exception review when privileged namespace or certificate behavior changes.
