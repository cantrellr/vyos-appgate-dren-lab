# Deployment and Configuration

> **Baseline:** v2.5 — September 9, 2026  
> **Audience:** deployment engineers, systems engineers, platform engineers, and release engineers.

## 1. Scope and assumptions

This runbook assumes the four RKE2 clusters and external KubeHarbor registry are created through the approved infrastructure process, kubeconfig contexts are available to `k8admin`, and the deployment host can reach the required internal services.

Supported contexts are exactly:

- `j64seg1opman`
- `j64seg1opdev`
- `j52seg1opdev`
- `r01seg1opdev`

The baseline is Rancher `2.15.0`, Fleet `0.15.2`, RKE2 `v1.35.6+rke2r1`, and Helm `4.0.0+`.

## Deployment flow at a glance

Use the deployment as a gated pipeline rather than a single opaque install. Each phase has a clear success condition and can be rerun safely after remediation.

| Phase | Operator action | Success gate |
| --- | --- | --- |
| 1. Configure | Create the protected runtime config, verify branch, DNS, CA, credentials, and offline artifacts | Required files exist; runtime config is `0600`; intended Git branch is explicit |
| 2. Validate package | `./scripts/deploy-platform.sh validate-package` and `validate-rancher-registry` | Static package validation passes; required Rancher images are available in KubeHarbor |
| 3. Bootstrap management | `./scripts/deploy-platform.sh bootstrap-management` | Rancher/Fleet management plane validates healthy |
| 4. Prepare/import clusters | `prepare-rancher-imports`, perform Rancher imports, then `validate-rancher-imports` | All three downstream cluster agents are connected |
| 5. Onboard platform | `./scripts/deploy-platform.sh onboard` | Runtime preflight/secrets, time, Longhorn node readiness, cluster labels, and GitRepos are established |
| 6. Reconcile GitOps | `./scripts/deploy-platform.sh validate` | Repository-owned Fleet Bundles are Ready |
| 7. Enable identity HA | `enable-identity-secondary`, then replication and HA validation | J64/J52 distributed PostgreSQL replication is healthy and only one Keycloak site is active |
| 8. Validate observability | `validate-monitoring` | Elastic Agent/kube-state-metrics checks pass on all clusters |
| 9. Release | Validate URLs, capture evidence, merge through protected-branch policy | Deployment evidence is complete and the watched branch is the intended release commit |

**Normal first deployment sequence after all clusters are built:**

```bash
./scripts/deploy-platform.sh validate-package
./scripts/deploy-platform.sh validate-rancher-registry
./scripts/deploy-platform.sh bootstrap-management
./scripts/deploy-platform.sh prepare-rancher-imports

# External/manual gate: import j64seg1opdev, j52seg1opdev and r01seg1opdev in Rancher.
./scripts/deploy-platform.sh validate-rancher-imports

./scripts/deploy-platform.sh onboard
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh validate-monitoring
```

If a phase fails, fix that gate and rerun the same phase. Do not restart from scratch unless the documented recovery procedure explicitly requires it. `./scripts/deploy-platform.sh all` is primarily a repeatable convergence command for an environment where all four kubeconfig contexts are already reachable; it is not the best first-run workflow because Rancher import is an external/manual boundary.

## 2. Pre-deployment dependencies

Before changing Kubernetes, verify:

- GitLab repository and the intended deployment branch exist and are reachable.
- KubeHarbor contains all required images and OCI charts.
- all nodes trust the KubeHarbor/Segment1 CA and have correct RKE2 `registries.yaml` authentication.
- private DNS resolves KubeHarbor, Rancher, identity, UIs, replication endpoints, and monitoring endpoints.
- approved NTP servers are synchronized and reachable on UDP/123.
- Longhorn worker disks are mounted at the approved path and meet filesystem/capacity requirements.
- the deployment user can SSH to workers with strict host-key checking and passwordless `sudo`.
- protected credential files and CA material exist outside Git.
- downstream clusters have sufficient resources for the intended platform and identity replicas.

## 3. Runtime configuration

Copy `config/fleet-bootstrap.example.env` to the protected runtime configuration location and set mode `0600`. The file contains paths to secret files, not plaintext secrets.

Typical setup:

```bash
export KMM_FLEET_CONFIG="$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev-v2.15.0.env"
chmod 600 "$KMM_FLEET_CONFIG"
# Compatibility: an existing $HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap.env
# is also auto-detected when KMM_FLEET_CONFIG is not set. If both files exist,
# set KMM_FLEET_CONFIG explicitly so the deployment cannot consume a stale copy.
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"
export NTP_SERVERS='1.0.1.34'
```

### Critical configuration groups

| Variables | Purpose |
| --- | --- |
| `FLEET_REPO_URL`, `FLEET_REPO_BRANCH`, `FLEET_POLLING_INTERVAL` | Git source and branch used by Fleet |
| `FLEET_GIT_*_FILE` | Git credentials |
| `FLEET_HELM_*_FILE`, `REGISTRY_*` | KubeHarbor OCI/image credentials and CA |
| `DEV_KUBE_DNS_SERVERS`, `JDE_DNS_SERVERS`, `JCP_DNS_SERVERS`, `IDENTITY_DNS_SERVERS` | CoreDNS private-zone forwarding and explicit Segment1 identity DNS validation |
| `RANCHER_VERSION`, `RANCHER_IMAGE_LIST_FILE`, `RANCHER_CA_FILE` | Rancher disconnected installation validation |
| `CA_CERT_FILE`, `CA_KEY_FILE` | cert-manager Segment1 issuer bootstrap |
| `LONGHORN_DATA_PATH`, `LONGHORN_DATA_FILESYSTEM`, `LONGHORN_MIN_DISK_GIB` | worker storage contract |
| identity username/password files and `IDENTITY_*` | two-site identity configuration |
| per-cluster `ELASTIC_FLEET_TOKEN_*_FILE` | Elastic enrollment isolation |
| `GITLAB_RUNNER_TOKEN_FILE`, `GITLAB_CA_FILE` | management-cluster runner authentication and GitLab trust |
| `ISTIO_CACERTS_DIR` | Istio trust material stored outside Git |

### Branch control is a deployment control

`FLEET_REPO_BRANCH` must name the exact Git branch intended for the environment. Fleet will continue reconciling the configured branch even if the operator has checked out or edited another branch locally. Always verify both before deployment:

```bash
git branch --show-current
grep '^FLEET_REPO_BRANCH=' "$KMM_FLEET_CONFIG"
```

## 4. Air-gap artifact preparation

### OCI charts

`helm/required-packages.txt`, `helm/required-oci-artifacts.txt`, `helm/fleet-oci-packages.txt`, and `helm/SHA256SUMS` form the chart-package contract.

Validate local package integrity:

```bash
cd helm
sha256sum --check SHA256SUMS
cd ..
```

Publish the Fleet charts to KubeHarbor:

```bash
./scripts/management/preflight/publish-fleet-charts.sh
```

Do not overwrite an existing OCI chart version with different bytes. Publish a new version and update Git in the same reviewed change.

### GitLab Runner artifacts

Promote these images into KubeHarbor before Fleet reconciliation:

- `registry1.dso.mil/ironbank/gitlab/gitlab-runner/gitlab-runner:v19.3.1` -> `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner:v19.3.1`
- `registry1.dso.mil/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1` -> `kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1`
- `registry1.dso.mil/ironbank/opensource/ansible/ansible:14.3.1` -> `kubeharbor.dev.kube/ironbank/opensource/ansible/ansible:14.3.1`

The packaged `gitlab-runner-0.92.1.tgz` chart must also be published to `oci://kubeharbor.dev.kube/k8mm-charts/gitlab-runner:0.92.1`.

The Iron Bank manager and helper run as UID/GID `1001`. The chart is configured with `useTini: true`, so the manager starts through `/usr/local/bin/tini`. Do not reuse the former Docker Hub paths, Ubuntu helper suffix, UID `999`, or `useTini: false` settings.

Create a protected project or group runner in GitLab with the `gitops-validation` tag, disable untagged jobs, lock it to the intended scope, copy its `glrt-*` authentication token to `GITLAB_RUNNER_TOKEN_FILE`, and place the GitLab issuing CA at `GITLAB_CA_FILE`.

### Rancher images

Rancher image acquisition/promotion is handled by the approved air-gap image workflow. Configure `RANCHER_IMAGE_LIST_FILE` to the staged list, then validate Harbor inventory and node pulls:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
```

This repository validates; it does not reach the public Internet to download Rancher images.

### Longhorn host packages

The golden image must contain the pinned Ubuntu 24.04 amd64 dependencies used by Longhorn. The deployed-node preflight is validation-only and will fail rather than invoke apt or modify disk layout.

## 5. Static package validation

Run before every deployment or release commit:

```bash
./scripts/deploy-platform.sh validate-package
```

This validates shell syntax, YAML parsing, chart readability/checksums, OCI inventory, Fleet bundle dependencies and targets, retired tokens, monitoring contracts, two-site identity configuration, Segment1 addressing, RKE2 CNI settings, Longhorn UI/Kiali naming, Chrony hardening, and documentation structure.

Do not proceed until it passes.

## 6. Management-cluster bootstrap

Bootstrap the management cluster:

```bash
./scripts/deploy-platform.sh bootstrap-management
```

The sequence establishes private registry credentials/trust, CoreDNS forwarding, cert-manager/CA, MetalLB/Segment1 pool, Contour/Envoy, Rancher, and the Rancher/Fleet compatibility controls required before Fleet can reconcile.

Validate the management plane independently:

```bash
./scripts/deploy-platform.sh validate-rancher-system
```

## 7. Prepare and import downstream clusters

Rancher/Fleet system agents can violate the RKE2 CIS default restricted PodSecurity profile. Prepare the required system namespaces **before** applying Rancher import manifests:

```bash
./scripts/deploy-platform.sh prepare-rancher-imports
```

Import or provision `j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev` in Rancher. Then validate connectivity:

```bash
./scripts/deploy-platform.sh validate-rancher-imports
```

If agents were already imported before PSA preparation, use:

```bash
./scripts/deploy-platform.sh repair-rancher-agents
```

## 8. Host preflight

### Chrony

Install and prove synchronized time across every node:

```bash
./scripts/deploy-platform.sh install-cluster-time
```

The command waits for Chrony and requires:

- selected source (`^*`);
- positive stratum;
- `Leap status: Normal`.

A Running pod is not considered success. A reachable NTP server that advertises unsynchronized/stratum 0 fails the gate.

Recheck without changing the deployment:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

### Longhorn worker storage

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

For each worker this verifies the required host packages/tools, iSCSI service/module, XFS mount, capacity, shared mount propagation, writeability, and Longhorn node label. It never formats or repartitions the disk.

## 9. Fleet runtime preflight and secret seeding

```bash
./scripts/deploy-platform.sh preflight-fleet
./scripts/deploy-platform.sh seed-secrets
```

If `preflight-fleet` reports downstream `fleet-default/<cluster>` resources missing `KUBE_FEATURE_WatchListClient=false`, repair the Rancher/Fleet agent contract first and rerun preflight:

```bash
./scripts/deploy-platform.sh repair-rancher-agents
./scripts/deploy-platform.sh preflight-fleet
```

Do not proceed to Fleet registration while that compatibility gate is red.

Runtime seeding creates the required registry, CA, identity, Elastic, Kiali/Grafana, and management GitLab Runner Secrets without placing secret values in Git. Runner token or CA rotation restarts only the existing Runner Deployment.

Keycloak binary runtime artifacts follow the same protected-input model. Set `KEYCLOAK_KEYTAB_FILE_001` and `KEYCLOAK_PROVIDER_FILE_001` to local files outside Git, then run `seed-secrets`. The workflow mirrors them to both identity sites as `opkeycloak-keytab` and `opkeycloak-provider`. Fleet mounts the keytab at `/etc/keycloak/keytabs/opkeycloak.keytab` and the provider at `/opt/keycloak/providers/kc-az-upn-linker.jar`. If either Secret payload changes while Keycloak is already running, `seed-secrets` recycles the Keycloak server Pods one ordinal at a time and waits for each replacement to become Ready. It deliberately does not patch the Operator-owned StatefulSet. This refreshes the provider `subPath` mount and Keycloak provider registry without creating controller field contention.

Changing only the protected `.env` file or one of these binary files is **not** a Git/Fleet change. Rerun `./scripts/deploy-platform.sh seed-secrets` after rotating either artifact. Commit/push is required only when the repository-managed Keycloak CR, Helm values, or other GitOps content changes.

For a new environment, prefer the repository's fail-fast onboarding orchestration instead of pasting a long sequence of independent shell commands:

```bash
./scripts/deploy-platform.sh onboard
```

Use the individual phases in this document for controlled recovery/re-entry when a specific gate needs remediation.

## 10. Register GitRepos and reconcile

```bash
./scripts/deploy-platform.sh fleet
./scripts/deploy-platform.sh validate
```

The `fleet` phase validates Rancher/Fleet first, labels the cluster resources, and creates/updates the GitRepos. The validation phase scopes readiness checks to bundles generated by this repository.

Verify the branch and commit in live Fleet when troubleshooting or after a branch change:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
kubectl --context j64seg1opman -n fleet-local   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

## 11. Enable the warm identity site

After the primary site and Fleet bundles are healthy:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
```

This is intentionally a **two-phase** operation. It first normalizes J64/J52 into safe one-way streaming mode (`postgres-distributed-topology=false`), copies J64 replication trust to J52, and waits for the J52 `pg_basebackup` Cluster to become Ready. Only after J52 has generated its own CloudNativePG replication TLS material does the workflow copy that trust back to J64 and enroll both existing Clusters in the reversible distributed topology. CloudNativePG validates every value used by `replica.self` and `replica.primary` against `externalClusters`, so each distributed chart now declares **both** `j64seg1opdev` and `j52seg1opdev`. The final gate requires live J64-to-J52 WAL replication to pass.

The command is re-entrant. If a prior attempt left Fleet labels at `postgres-distributed-topology=true` but admission rejected the Cluster patch, re-run the same command after deploying the fixed repository. It detects an already healthy topology and exits after verification; otherwise it safely returns to one-way streaming mode and completes enrollment. A failed final enrollment automatically resets the topology labels to `false` so Fleet does not remain stuck retrying an invalid distributed specification.

### Identity HA acceptance after a fresh rebuild

After the normal deployment gates pass, schedule a controlled test window and execute a **round-trip planned switchover**: J64 -> J52, then J52 -> J64, using the procedure in Operations and Lifecycle. This is now a release-acceptance requirement for a rebuilt environment. The return direction is specifically what proves CloudNativePG promotion-token cleanup, reverse replication, Fleet role reversal, Segment1 DNS cutback, and journal resume behavior.

After each direction run:

```bash
./scripts/deploy-platform.sh verify-database-replication
./scripts/deploy-platform.sh validate-identity-ha
./scripts/deploy-platform.sh identity-transition-diagnostics
```

The steady-state validation must show no `spec.replica.promotionToken` on either site. `status.lastPromotionToken` may remain as CloudNativePG evidence of the last controlled promotion; that status field is expected and is not reused as the next transition token.

## 12. Observability validation

```bash
./scripts/deploy-platform.sh validate-monitoring
```

Confirm that one Elastic Agent policy/token is associated with each cluster and that cluster identity/data-stream naming is unique.

## 13. Convergence and re-entry workflow

For an already-onboarded environment where all four clusters are reachable, the orchestrator can reconverge the complete platform:

```bash
./scripts/deploy-platform.sh all
```

For initial deployment or repair work, use the phase-specific flow at the top of this document. Re-entry rule: **rerun the smallest failed phase and its validation gate**. Examples:

- Rancher/Fleet agent connectivity problem: `repair-rancher-agents` -> `validate-rancher-imports` -> continue with `onboard`.
- Runtime Secret or Keycloak artifact rotation: `preflight-fleet` -> `seed-secrets` -> `validate`/`validate-identity-ha`; no cluster rebuild is required.
- Fleet source change: merge/push the intended branch -> `fleet` if labels/GitRepo definitions changed -> `validate`.
- Identity standby not initialized: `enable-identity-secondary` -> `verify-database-replication` -> `validate-identity-ha`.

Avoid deleting Bundles, namespaces, CNPG clusters, or Longhorn data as a generic recovery tactic. Use the troubleshooting document to identify the owning layer first.

## 14. DNS records

At minimum, the environment requires records for Rancher, KubeHarbor, identity, PostgreSQL replication, east-west mesh gateways, monitoring endpoints, and the administrative UI names below:

| Hostname | Cluster/VIP |
| --- | --- |
| `longhorn-man.dev.kube` | `j64seg1opman` / `1.0.0.205` |
| `longhorn-j64.dev.kube` | `j64seg1opdev` / `1.0.0.215` |
| `longhorn-j52.dev.kube` | `j52seg1opdev` / `1.0.0.225` |
| `longhorn-r01.dev.kube` | `r01seg1opdev` / `1.0.0.235` |
| `kiali-man.dev.kube` | `j64seg1opman` / `1.0.0.205` |
| `kiali-j64.dev.kube` | `j64seg1opdev` / `1.0.0.215` |
| `kiali-j52.dev.kube` | `j52seg1opdev` / `1.0.0.225` |
| `kiali-r01.dev.kube` | `r01seg1opdev` / `1.0.0.235` |
| `j64seg1opdev-postgres-repl.dev.kube` | J64 PostgreSQL replication / `1.0.0.216` |
| `j52seg1opdev-postgres-repl.dev.kube` | J52 PostgreSQL replication / `1.0.0.226` |
| `j64seg1opdev-ingress.dev.kube` | J64 identity ingress alias / `1.0.0.215` |
| `j52seg1opdev-ingress.dev.kube` | J52 identity ingress alias / `1.0.0.225` |
| `opkeycloak.dev.jde.cybercom.ic.gov` | CNAME to the currently active identity ingress alias |
| `j64seg1opman-prometheus.dev.kube` | External Prometheus endpoint used by Kiali; DNS/IP is owned by the monitoring service |
| `grafana.dev.kube` | External Grafana endpoint used by Kiali; DNS/IP is owned by the monitoring service |

Both PostgreSQL replication A records are required. They are fixed site endpoints, not aliases that move during failover. The canonical Keycloak record moves between the J64 and J52 ingress aliases; replication records never move. Kiali also depends on the external Prometheus/Grafana names resolving from cluster CoreDNS; unresolved monitoring names do not block identity failover but leave Kiali observability degraded and should be corrected before release acceptance.

Set `IDENTITY_DNS_SERVERS` in the protected runtime configuration to the Segment1 DNS servers that serve the identity zone. The example defaults to the same resolver pair as `JDE_DNS_SERVERS`. Identity status and failover commands query these servers directly:

```bash
./scripts/deploy-platform.sh identity-dns-status active
./scripts/deploy-platform.sh identity-dns-status j64
./scripts/deploy-platform.sh identity-dns-status j52
```

A healthy result shows one `dnsServer=...` line per configured resolver and `segment1DnsConsensus=match`. The deployment controller's own `getent`/resolver result is displayed only as `controllerResolvedIPv4` / `controllerCanonicalOIDC` and is not a failover gate.

## 15. Configuration and release rules

- Use `fleet/bundles` as the source of truth for normal Kubernetes desired state.
- Keep `yaml/` source/break-glass configuration aligned with Fleet equivalents.
- Do not put private material in `fleet/` or `yaml/`.
- Every Fleet chart requires an immutable local package, checksum, OCI inventory entry, target/dependency configuration, and validation rule.
- Every new application should receive its own numbered bundle and explicit target guard.
- Do not add another GitOps controller.
- Do not run direct Helm changes against Fleet-owned releases in normal operations.

### GitOps protected-branch governance

The Fleet-watched deployment branch must use merge-request governance. For the current `multicluster-longhorn` branch, use an exact protected-branch rule with Maintainers allowed to merge, **No one** allowed to push directly, force push disabled, and Code Owner approval enabled when supported. Review wildcard branch rules so a broader rule does not weaken the exact rule.

Required merge checks are **Pipelines must succeed** and **All discussions must be resolved**. Keep skipped pipelines from counting as successful. The recommended merge method is a merge commit with semi-linear history so the merge-request boundary remains auditable and the source branch must be current.

The Fleet-managed GitLab Runner on `j64seg1opman` is a validation runner only. It uses the `gitops-validation` tag, the non-privileged Kubernetes executor, Iron Bank GitLab Runner/Helper v19.3.1, and the pinned Iron Bank Ansible validation image. The runner must not receive kubeconfigs, cluster-admin/Rancher credentials, Harbor push credentials, Keycloak keytab/provider payloads, `CA_KEY_FILE`, or Fleet runtime Secret files. CI runs `validate-package`; it must not run deployment commands such as `kubectl apply`, `helm upgrade`, `deploy-platform.sh fleet`, or `seed-secrets`.

A production change therefore follows:

```text
feature/fix branch -> merge request -> runner canary -> validate-package -> review/approval -> merge -> Fleet polling/reconciliation
```

Fleet remains the sole steady-state deployment controller.

## 16. Rollback

For a bad Fleet change, revert the Git commit and let Fleet reconcile. For a bad runtime-secret rotation, restore the protected input file and rerun `seed-secrets`. For identity changes, use the documented HA workflow rather than reversing labels manually.

If Rancher system installation/reconciliation fails, use the supported repair command instead of deleting healthy resources:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```
