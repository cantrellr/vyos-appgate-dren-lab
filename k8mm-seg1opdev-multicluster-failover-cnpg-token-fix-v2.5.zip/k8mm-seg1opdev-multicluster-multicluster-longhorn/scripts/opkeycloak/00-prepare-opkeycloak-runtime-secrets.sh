#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../_lib/common.sh"
source "${SCRIPT_DIR}/../_lib/cis.sh"

init_site_cluster "$@"

POSTGRES_NAMESPACE="${POSTGRES_NAMESPACE:-oppostgres}"
KEYCLOAK_NAMESPACE="${KEYCLOAK_NAMESPACE:-opkeycloak}"
CLUSTER_NAME="${CNPG_CLUSTER_NAME:-oppostgres-opkeycloak-db}"
APP_SECRET="${POSTGRES_APP_SECRET:-opkeycloak-postgresql-credentials}"
APP_USERNAME="${POSTGRES_APP_USERNAME:-opkeycloak}"
BOOTSTRAP_ADMIN_SECRET="${KEYCLOAK_BOOTSTRAP_ADMIN_SECRET:-opkeycloak-bootstrap-admin}"
BOOTSTRAP_ADMIN_USERNAME="${KEYCLOAK_BOOTSTRAP_ADMIN_USERNAME:-bootstrap-admin}"
REGENERATE_RUNTIME_SECRETS="${REGENERATE_RUNTIME_SECRETS:-false}"

case "${REGENERATE_RUNTIME_SECRETS}" in
  true|false) ;;
  *) die "REGENERATE_RUNTIME_SECRETS must be true or false." ;;
esac

require_kubectl
require_cmd jq
require_cmd openssl
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_cis_namespace "${POSTGRES_NAMESPACE}" true restricted
ensure_cis_namespace "${KEYCLOAK_NAMESPACE}" true restricted
kubectl label namespace "${KEYCLOAK_NAMESPACE}" \
  segment1.ingress/allow-backend=true --overwrite >/dev/null
ensure_registry_secret "${POSTGRES_NAMESPACE}"
ensure_registry_secret "${KEYCLOAK_NAMESPACE}"

ensure_secret_keys() {
  local namespace="$1" secret_name="$2" key value
  shift 2
  kubectl -n "${namespace}" get secret "${secret_name}" >/dev/null 2>&1 || die "Required Secret ${namespace}/${secret_name} does not exist."
  for key in "$@"; do
    value="$(kubectl -n "${namespace}" get secret "${secret_name}" -o "jsonpath={.data.${key}}")"
    [[ -n "${value}" ]] || die "Secret ${namespace}/${secret_name} is missing non-empty key '${key}'."
  done
}

label_runtime_secret() {
  kubectl -n "$1" label secret "$2" --overwrite app.kubernetes.io/part-of=opkeycloak app.kubernetes.io/component="$3" k8mm.dev/secret-management=runtime >/dev/null
}

if [[ "${REGENERATE_RUNTIME_SECRETS}" == "true" ]]; then
  if kubectl get crd clusters.postgresql.cnpg.io >/dev/null 2>&1 && kubectl -n "${POSTGRES_NAMESPACE}" get "clusters.postgresql.cnpg.io/${CLUSTER_NAME}" >/dev/null 2>&1; then
    die "Refusing to regenerate database credentials while CNPG cluster ${POSTGRES_NAMESPACE}/${CLUSTER_NAME} exists."
  fi
  warn "Regenerating identity runtime Secrets because no CNPG cluster exists."
  kubectl -n "${POSTGRES_NAMESPACE}" delete secret "${APP_SECRET}" --ignore-not-found=true >/dev/null
  kubectl -n "${KEYCLOAK_NAMESPACE}" delete secret "${APP_SECRET}" --ignore-not-found=true >/dev/null
  kubectl -n "${KEYCLOAK_NAMESPACE}" delete secret "${BOOTSTRAP_ADMIN_SECRET}" --ignore-not-found=true >/dev/null
fi

if ! kubectl -n "${POSTGRES_NAMESPACE}" get secret "${APP_SECRET}" >/dev/null 2>&1; then
  log "Generating PostgreSQL application credentials at runtime..."
  db_password="$(openssl rand -hex 32)"
  kubectl -n "${POSTGRES_NAMESPACE}" create secret generic "${APP_SECRET}" --from-literal=username="${APP_USERNAME}" --from-literal=password="${db_password}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  unset db_password
else
  log "Preserving existing PostgreSQL application credentials."
fi
ensure_secret_keys "${POSTGRES_NAMESPACE}" "${APP_SECRET}" username password
label_runtime_secret "${POSTGRES_NAMESPACE}" "${APP_SECRET}" database-credentials

log "Mirroring PostgreSQL credentials into ${KEYCLOAK_NAMESPACE} without exposing values..."
kubectl -n "${POSTGRES_NAMESPACE}" get secret "${APP_SECRET}" -o json | jq --arg namespace "${KEYCLOAK_NAMESPACE}" --arg name "${APP_SECRET}" '{apiVersion:"v1",kind:"Secret",metadata:{name:$name,namespace:$namespace,labels:{"app.kubernetes.io/part-of":"opkeycloak","app.kubernetes.io/component":"database-credentials","k8mm.dev/secret-management":"runtime-mirror"}},type:(.type // "Opaque"),data:.data}' | kubectl apply -f - >/dev/null
ensure_secret_keys "${KEYCLOAK_NAMESPACE}" "${APP_SECRET}" username password
postgres_password_data="$(kubectl -n "${POSTGRES_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.password}')"
keycloak_password_data="$(kubectl -n "${KEYCLOAK_NAMESPACE}" get secret "${APP_SECRET}" -o jsonpath='{.data.password}')"
[[ "${postgres_password_data}" == "${keycloak_password_data}" ]] || die "Database credentials do not match across namespaces."
unset postgres_password_data keycloak_password_data

if ! kubectl -n "${KEYCLOAK_NAMESPACE}" get secret "${BOOTSTRAP_ADMIN_SECRET}" >/dev/null 2>&1; then
  log "Generating Keycloak bootstrap administrator credentials at runtime..."
  bootstrap_password="$(openssl rand -hex 32)"
  kubectl -n "${KEYCLOAK_NAMESPACE}" create secret generic "${BOOTSTRAP_ADMIN_SECRET}" --from-literal=username="${BOOTSTRAP_ADMIN_USERNAME}" --from-literal=password="${bootstrap_password}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  unset bootstrap_password
else
  log "Preserving existing Keycloak bootstrap administrator credentials."
fi
ensure_secret_keys "${KEYCLOAK_NAMESPACE}" "${BOOTSTRAP_ADMIN_SECRET}" username password
label_runtime_secret "${KEYCLOAK_NAMESPACE}" "${BOOTSTRAP_ADMIN_SECRET}" bootstrap-admin-credentials
log "Identity runtime Secret preparation complete; no credential values were printed or written to Git."
