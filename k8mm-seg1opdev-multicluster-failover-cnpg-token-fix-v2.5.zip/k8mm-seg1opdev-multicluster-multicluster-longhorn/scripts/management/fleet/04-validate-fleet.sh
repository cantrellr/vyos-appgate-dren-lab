#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"
require_cmd jq

FLEET_RECONCILE_TIMEOUT_SECONDS="${FLEET_RECONCILE_TIMEOUT_SECONDS:-1200}"
FLEET_RECONCILE_POLL_SECONDS="${FLEET_RECONCILE_POLL_SECONDS:-5}"
case "${FLEET_RECONCILE_TIMEOUT_SECONDS}" in ''|*[!0-9]*) die "FLEET_RECONCILE_TIMEOUT_SECONDS must be an integer." ;; esac
case "${FLEET_RECONCILE_POLL_SECONDS}" in ''|*[!0-9]*) die "FLEET_RECONCILE_POLL_SECONDS must be an integer." ;; esac
(( FLEET_RECONCILE_TIMEOUT_SECONDS > 0 )) || die "FLEET_RECONCILE_TIMEOUT_SECONDS must be greater than zero."
(( FLEET_RECONCILE_POLL_SECONDS > 0 )) || die "FLEET_RECONCILE_POLL_SECONDS must be greater than zero."

managed_repos=(
  "fleet-local/k8mm-seg1opdev-multicluster-local"
  "fleet-default/k8mm-seg1opdev-multicluster-downstream"
)

dump_gitrepo() {
  local namespace="$1" name="$2"
  kubectl -n "${namespace}" get gitrepo "${name}" -o json 2>/dev/null | jq '{
    namespace: .metadata.namespace,
    name: .metadata.name,
    generation: .metadata.generation,
    observedGeneration: .status.observedGeneration,
    commit: (.status.commit // .status.display.commit // ""),
    readyClusters: (.status.display.readyClusters // ""),
    state: ([.status.conditions[]? | select(.type == "Ready")][0].status // ""),
    resourceCounts: (.status.resourceCounts // {}),
    conditions: (.status.conditions // [])
  }' >&2 || true
}

dump_fleet_logs() {
  warn "Recent GitJob diagnostics:"
  kubectl -n cattle-fleet-system logs deployment/gitjob --all-containers=true --since=20m 2>/dev/null | \
    grep -Ei 'k8mm-seg1opdev|error|failed|authentication|denied|clone|checkout|bundle|path' | tail -120 >&2 || true
  warn "Recent Fleet controller diagnostics:"
  kubectl -n cattle-fleet-system logs deployment/fleet-controller --all-containers=true --since=20m 2>/dev/null | \
    grep -Ei 'k8mm-seg1opdev|error|failed|gitrepo|bundle' | tail -120 >&2 || true
}

wait_for_repo_bundles() {
  local repo="$1" namespace name deadline now last_notice=0 repo_json fatal_message commit bundle_count
  local stalled_status stalled_message ready_status git_polling_status stale_stall_warned=false
  namespace="${repo%%/*}"
  name="${repo##*/}"
  kubectl -n "${namespace}" get gitrepo "${name}" >/dev/null
  deadline=$((SECONDS + FLEET_RECONCILE_TIMEOUT_SECONDS))

  while (( SECONDS < deadline )); do
    repo_json="$(kubectl -n "${namespace}" get gitrepo "${name}" -o json)"
    commit="$(jq -r '.status.commit // .status.display.commit // ""' <<<"${repo_json}")"
    ready_status="$(jq -r '[.status.conditions[]? | select(.type == "Ready")][0].status // ""' <<<"${repo_json}")"
    git_polling_status="$(jq -r '[.status.conditions[]? | select(.type == "GitPolling")][0].status // ""' <<<"${repo_json}")"
    stalled_status="$(jq -r '[.status.conditions[]? | select(.type == "Stalled")][0].status // ""' <<<"${repo_json}")"
    stalled_message="$(jq -r '[.status.conditions[]? | select(.type == "Stalled")][0] | (.message // .reason // "unspecified Fleet error")' <<<"${repo_json}")"

    fatal_message="$(jq -r '
      [(.status.conditions // [])[]
       | select((.type == "Accepted" or .type == "GitPolling") and .status == "False")
       | (.type + "=" + .status + ": " + (.message // .reason // "unspecified Fleet error"))
      ] | join("; ")' <<<"${repo_json}")"
    if [[ -n "${fatal_message}" ]]; then
      dump_gitrepo "${namespace}" "${name}"
      dump_fleet_logs
      die "Fleet GitRepo ${repo} cannot reconcile: ${fatal_message}"
    fi

    if [[ "${stalled_status}" == "True" ]]; then
      if [[ "${ready_status}" == "True" && "${git_polling_status}" == "True" && -n "${commit}" ]]; then
        if [[ "${stale_stall_warned}" != "true" ]]; then
          warn "Fleet GitRepo ${repo} still carries Stalled=True after a later successful Ready/GitPolling state: ${stalled_message}. Treating it as a stale condition while current bundles are evaluated."
          stale_stall_warned=true
        fi
      else
        dump_gitrepo "${namespace}" "${name}"
        dump_fleet_logs
        die "Fleet GitRepo ${repo} is actively stalled: ${stalled_message}"
      fi
    fi

    bundle_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${name}" -o json | jq '.items | length')"
    if [[ -n "${commit}" && "${bundle_count}" -gt 0 ]]; then
      log "${repo}: Fleet fetched commit ${commit:0:12} and generated ${bundle_count} Bundle(s)."
      return 0
    fi

    now="${SECONDS}"
    if (( now - last_notice >= 30 )); then
      log "Waiting for ${repo} to fetch Git and generate Bundles (commit=${commit:-pending}, bundles=${bundle_count})..."
      last_notice="${now}"
    fi
    sleep "${FLEET_RECONCILE_POLL_SECONDS}"
  done

  dump_gitrepo "${namespace}" "${name}"
  dump_fleet_logs
  die "Timed out after ${FLEET_RECONCILE_TIMEOUT_SECONDS}s waiting for ${repo} to generate Fleet Bundles."
}

for repo in "${managed_repos[@]}"; do
  wait_for_repo_bundles "${repo}"
done

validate_gitlab_runner() {
  local namespace="gitlab-runner-system"
  local expected_manager_image="kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner:v19.3.1"
  local expected_helper_image="kubeharbor.dev.kube/ironbank/gitlab/gitlab-runner/gitlab-runner-helper:v19.3.1"
  local expected_job_image="kubeharbor.dev.kube/ironbank/opensource/ansible/ansible:14.3.1"
  local config_path="/home/gitlab-runner/.gitlab-runner/config.toml"
  local manager_image manager_command deadline now last_notice=0

  use_context "${RANCHER_CONTEXT:-j64seg1opman}"
  kubectl -n "${namespace}" get secret gitlab-runner-auth >/dev/null
  kubectl -n "${namespace}" get secret gitlab-runner-certs >/dev/null

  deadline=$((SECONDS + FLEET_RECONCILE_TIMEOUT_SECONDS))
  while ! kubectl -n "${namespace}" get deployment gitlab-runner >/dev/null 2>&1; do
    (( SECONDS < deadline )) || \
      die "Timed out waiting for Fleet to create ${namespace}/deployment/gitlab-runner. Inspect fleet-local/bundle/gitlab-runner and its BundleDeployment."
    now="${SECONDS}"
    if (( now - last_notice >= 30 )); then
      log "Waiting for Fleet to create ${namespace}/deployment/gitlab-runner..."
      last_notice="${now}"
    fi
    sleep "${FLEET_RECONCILE_POLL_SECONDS}"
  done

  if ! kubectl -n "${namespace}" rollout status deployment/gitlab-runner --timeout="${KUBECTL_TIMEOUT}"; then
    warn "GitLab Runner rollout failed. Current workload and image-pull evidence:"
    kubectl -n "${namespace}" get deployment,pods -o wide >&2 || true
    kubectl -n "${namespace}" get events --sort-by=.lastTimestamp 2>/dev/null | tail -40 >&2 || true
    die "GitLab Runner did not become Ready. Review the reported container command/start error, then confirm the images listed in helm/gitlab-runner-kubeharbor-images.txt exist in KubeHarbor."
  fi

  manager_image="$(kubectl -n "${namespace}" get deployment gitlab-runner \
    -o jsonpath='{.spec.template.spec.containers[0].image}')"
  [[ "${manager_image}" == "${expected_manager_image}" ]] || \
    die "GitLab Runner image mismatch: expected ${expected_manager_image}, found ${manager_image}."

  manager_command="$(kubectl -n "${namespace}" get deployment gitlab-runner \
    -o jsonpath='{.spec.template.spec.containers[0].command[0]}')"
  [[ "${manager_command}" == "/usr/local/bin/tini" ]] || \
    die "GitLab Runner command mismatch: expected /usr/local/bin/tini, found ${manager_command:-<empty>}. Ensure Iron Bank v19.3.1 and useTini=true are deployed together."

  kubectl -n "${namespace}" exec deployment/gitlab-runner -- gitlab-runner --version | \
    grep -Fq '19.3.1' || die "GitLab Runner manager does not report version 19.3.1."

  kubectl -n "${namespace}" exec deployment/gitlab-runner -- \
    grep -Fq '[[runners]]' "${config_path}" || \
    die "GitLab Runner config ${config_path} is missing or contains no [[runners]] entry."
  kubectl -n "${namespace}" exec deployment/gitlab-runner -- \
    gitlab-runner list --config "${config_path}" >/dev/null || \
    die "GitLab Runner could not load ${config_path}."
  kubectl -n "${namespace}" exec deployment/gitlab-runner -- \
    grep -Fq "${expected_helper_image}" "${config_path}" || \
    die "GitLab Runner config does not pin helper image ${expected_helper_image}."
  kubectl -n "${namespace}" exec deployment/gitlab-runner -- \
    grep -Fq "${expected_job_image}" "${config_path}" || \
    die "GitLab Runner config does not pin default job image ${expected_job_image}."
  kubectl -n "${namespace}" exec deployment/gitlab-runner -- \
    gitlab-runner verify --config "${config_path}"
  log "Management Iron Bank GitLab Runner v19.3.1 is Ready, configured, and authenticated."
}

validate_gitlab_runner

validate_storage_bundle_generation() {
  local namespace repo_name commit longhorn_count longhorn_config_count longhorn_ui_count stale_trident_count stale_dependency_count cnpg_dependency

  for namespace in fleet-local fleet-default; do
    if [[ "${namespace}" == "fleet-local" ]]; then
      repo_name="k8mm-seg1opdev-multicluster-local"
    else
      repo_name="k8mm-seg1opdev-multicluster-downstream"
    fi

    commit="$(kubectl -n "${namespace}" get gitrepo "${repo_name}" -o jsonpath='{.status.commit}' 2>/dev/null || true)"
    longhorn_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn" -o json | jq '.items | length')"
    longhorn_config_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn-config" -o json | jq '.items | length')"
    longhorn_ui_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn-ui" -o json | jq '.items | length')"
    stale_trident_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name}" -o json | jq '[.items[] | select(((.metadata.labels["kmm.dev/bundle"] // "") | test("^trident")))] | length')"
    stale_dependency_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name}" -o json | jq '[.items[] | select(any(.spec.dependsOn[]?; (((.selector.matchLabels["kmm.dev/bundle"] // "") | test("^trident")))))] | length')"

    if [[ "${longhorn_count}" != "1" || "${longhorn_config_count}" != "1" || "${longhorn_ui_count}" != "1" || "${stale_trident_count}" != "0" || "${stale_dependency_count}" != "0" ]]; then
      dump_gitrepo "${namespace}" "${repo_name}"
      die "Fleet ${namespace}/${repo_name} is serving incomplete/stale Longhorn content at commit ${commit:-unknown}: longhorn=${longhorn_count}, longhorn-config=${longhorn_config_count}, longhorn-ui=${longhorn_ui_count}, retired-trident-bundles=${stale_trident_count}, retired-trident-dependencies=${stale_dependency_count}. Commit and push the current Longhorn branch to ${FLEET_REPO_BRANCH}, then rerun './scripts/deploy-platform.sh fleet' and './scripts/deploy-platform.sh validate'."
    fi
  done

  cnpg_dependency="$(kubectl -n fleet-default get bundle oppostgres-operator -o json | jq -r '[.spec.dependsOn[]? | .selector.matchLabels["kmm.dev/bundle"] // empty] | join(",")')"
  [[ "${cnpg_dependency}" == "longhorn-config" ]] || \
    die "fleet-default/oppostgres-operator has unexpected storage dependency '${cnpg_dependency:-none}'; expected longhorn-config. The GitLab branch is not reconciled to the current repository content."

  log "Fleet storage transition validation passed: Longhorn storage/UI bundles are generated."
}

validate_storage_bundle_generation

managed_bundles_json="$({
  kubectl -n fleet-local get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-local \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
  kubectl -n fleet-default get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-downstream \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
} | sort -u | jq -R -s 'split("\n") | map(select(length > 0))')"

managed_count="$(jq 'length' <<<"${managed_bundles_json}")"
[[ "${managed_count}" -gt 0 ]] || die "No Fleet Bundles were generated for the two managed GitRepos."

# Wait for Fleet to create at least one BundleDeployment for each GitRepo and
# for every repository-owned BundleDeployment that exists to become Ready.
deadline=$((SECONDS + FLEET_RECONCILE_TIMEOUT_SECONDS))
last_notice=0
while (( SECONDS < deadline )); do
  bundledeployments_json="$(kubectl get bundledeployments.fleet.cattle.io -A -o json)"
  local_bd_count="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] == "fleet-local")
    ] | length' <<<"${bundledeployments_json}")"
  downstream_bd_count="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] == "fleet-default")
    ] | length' <<<"${bundledeployments_json}")"
  not_ready="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select(($bd.status.ready // false) != true)
    ] | length' <<<"${bundledeployments_json}")"

  if [[ "${local_bd_count}" -gt 0 && "${downstream_bd_count}" -gt 0 && "${not_ready}" == "0" ]]; then
    log "Fleet reconciliation validation passed for ${managed_count} repository-owned Bundle(s)."
    exit 0
  fi

  now="${SECONDS}"
  if (( now - last_notice >= 30 )); then
    log "Waiting for BundleDeployments (local=${local_bd_count}, downstream=${downstream_bd_count}, notReady=${not_ready})..."
    last_notice="${now}"
  fi
  sleep "${FLEET_RECONCILE_POLL_SECONDS}"
done

bundledeployments_json="$(kubectl get bundledeployments.fleet.cattle.io -A -o json)"
jq -r --argjson managed "${managed_bundles_json}" '
  .items[] as $bd
  | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
     ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
  | select($managed | index($bundle))
  | select(($bd.status.ready // false) != true)
  | [$bd.metadata.namespace, $bd.metadata.name, ($bd.status.message // "not Ready")] | @tsv' \
  <<<"${bundledeployments_json}" >&2
for repo in "${managed_repos[@]}"; do
  dump_gitrepo "${repo%%/*}" "${repo##*/}"
done
dump_fleet_logs
die "Timed out after ${FLEET_RECONCILE_TIMEOUT_SECONDS}s waiting for repository-owned BundleDeployments to become Ready."
