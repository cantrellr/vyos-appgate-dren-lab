# Diagnostics and Validation Revision — 2026-09-08.3

This revision hardens the post-deployment diagnostics and monitoring validation contract.

- `scripts/collect-gitops-logs.sh` reports Fleet Bundle readiness from the Fleet `Ready` condition, not `.status.display.state`.
- The collector writes `diagnostics-script-revision.txt` into every diagnostics archive and prints the same revision in `current-blockers.txt`.
- Diagnostics collect `discovery.k8s.io/v1` EndpointSlices rather than deprecated core/v1 Endpoints.
- The error index suppresses empty `*Error`, `*Failure`, and `*FailedAt` fields plus known timeout configuration fields.
- `scripts/monitoring/02-validate-elastic-agent.sh` defaults Elastic Agent log inspection to the most recent 2 minutes.
- Monitoring validation verifies the running kube-state-metrics Deployment includes `endpointslices` and excludes deprecated `endpoints`.
- `scripts/validate-fleet-layout.sh` enforces these diagnostics/validation contracts so stale or partially copied scripts fail package validation.
