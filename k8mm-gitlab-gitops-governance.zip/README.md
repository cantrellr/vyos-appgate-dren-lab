# k8mm GitLab GitOps Governance Bundle

This bundle contains:

- `.gitlab-ci.yml` — ready-to-copy static validation pipeline for merge requests targeting `multicluster-longhorn` and for the resulting post-merge branch commit.
- `docs/GITLAB-GITOPS-PROTECTED-BRANCH-POLICY.md` — protected-branch, merge-check, approval, runner-security, and GUI configuration guidance.

## Install

From the root of a working clone:

```bash
cp /path/to/bundle/.gitlab-ci.yml ./.gitlab-ci.yml
cp /path/to/bundle/docs/GITLAB-GITOPS-PROTECTED-BRANCH-POLICY.md ./docs/

git checkout -b feature/gitlab-gitops-validation
git add .gitlab-ci.yml docs/GITLAB-GITOPS-PROTECTED-BRANCH-POLICY.md
git commit -m "Add GitLab GitOps validation and branch policy"
git push -u origin feature/gitlab-gitops-validation
```

Create a merge request targeting `multicluster-longhorn`.

The CI runner must be tagged `gitops-validation` and have Bash, Python 3, PyYAML, and the standard core utilities used by the existing repository validation scripts.
