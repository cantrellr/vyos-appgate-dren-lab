# Keycloak runtime keytab and provider lifecycle

The keytab and custom provider JAR are protected runtime inputs. They are not Fleet/Git payloads and must not be committed to the repository.

## Runtime inputs

Set these paths in the protected Fleet runtime configuration:

```bash
KEYCLOAK_KEYTAB_FILE_001=/home/k8admin/.config/k8mm-seg1opdev-multicluster/files/devlocalkeycloak.keytab
KEYCLOAK_PROVIDER_FILE_001=/home/k8admin/.config/k8mm-seg1opdev-multicluster/files/kc-az-upn-linker-1.2.1.jar
```

The referenced files must exist and be non-empty. `preflight-fleet` validates them. If your active runtime file is named `fleet-bootstrap.env`, it is now auto-detected when the versioned default is absent. If both runtime files exist, set `KMM_FLEET_CONFIG` explicitly; the scripts fail closed rather than guessing which copy is current.

## Kubernetes objects and pod paths

`./scripts/deploy-platform.sh seed-secrets` creates or updates both Secrets on j64seg1opdev and j52seg1opdev:

- `opkeycloak/opkeycloak-keytab` with key `opkeycloak.keytab`
- `opkeycloak/opkeycloak-provider` with key `provider.jar`

The Fleet Keycloak CR mounts them as:

- `/etc/keycloak/keytabs/opkeycloak.keytab`
- `/opt/keycloak/providers/kc-az-upn-linker.jar`

`startOptimized: false` is retained. Keycloak therefore performs its normal non-optimized startup/re-augmentation, which allows the provider JAR present in `/opt/keycloak/providers` to be discovered during startup.

## Updating either file

1. Replace the protected local file.
2. Keep the same `.env` path, or update the path if the filename changed.
3. Run:

```bash
./scripts/deploy-platform.sh preflight-fleet
./scripts/deploy-platform.sh seed-secrets
```

The seeding workflow compares SHA-256 hashes without printing artifact contents. If either Secret payload changed and the Keycloak StatefulSet already exists, it performs `kubectl rollout restart statefulset/opkeycloak` and waits for the rollout.

A Git commit by itself does not copy local files into Kubernetes. Git/Fleet owns the Keycloak CR and its mounts; the protected runtime seeding workflow owns the Secret payloads.
