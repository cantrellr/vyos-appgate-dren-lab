# Deployment and Configuration

> **Baseline:** v2.1 — August 20, 2026  
> **Audience:** deployment engineers, systems engineers, platform engineers, and release engineers.

## 1. Scope and assumptions

This runbook assumes the four RKE2 clusters and external KubeHarbor registry are created through the approved infrastructure process, kubeconfig contexts are available to `k8admin`, and the deployment host can reach the required internal services.

Supported contexts are exactly:

- `j64seg1opman`
- `j64seg1opdev`
- `j52seg1opdev`
- `r01seg1opdev`

The baseline is Rancher `2.15.0`, Fleet `0.15.2`, RKE2 `v1.35.6+rke2r1`, and Helm `4.0.0+`.

## 2. Pre-deployment dependencies

Before changing Kubernetes, verify:

- GitLab repository and the intended deployment branch exist and are reachable.
- KubeHarbor contains all required images and OCI charts.
- all nodes trust the KubeHarbor/Segment1 CA and have correct RKE2 `registries.yaml` authentication.
- private DNS resolves KubeHarbor, Rancher, identity, UIs, replication endpoints, and monitoring endpoints.
- approved NTP servers are synchronized and reachable on UDP/123.
- Longhorn worker disks are mounted at the approved path and meet filesystem/capacity requirements.
- the deployment user can SSH to workers with strict host-key checking and passwordless `sudo`.
- protected credential files and CA material exist outside Git.
- downstream clusters have sufficient resources for the intended platform and identity replicas.

## 3. Runtime configuration

Copy `config/fleet-bootstrap.example.env` to the protected runtime configuration location and set mode `0600`. The file contains paths to secret files, not plaintext secrets.

Typical setup:

```bash
export KMM_FLEET_CONFIG="$HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap-seg1opdev-v2.15.0.env"
chmod 600 "$KMM_FLEET_CONFIG"
# Compatibility: an existing $HOME/.config/k8mm-seg1opdev-multicluster/fleet-bootstrap.env
# is also auto-detected when KMM_FLEET_CONFIG is not set. If both files exist,
# set KMM_FLEET_CONFIG explicitly so the deployment cannot consume a stale copy.
export SSH_USER=k8admin
export SSH_IDENTITY_FILE="$HOME/.ssh/k8mm-cluster-admin"
export NTP_SERVERS='1.0.1.34'
```

### Critical configuration groups

| Variables | Purpose |
| --- | --- |
| `FLEET_REPO_URL`, `FLEET_REPO_BRANCH`, `FLEET_POLLING_INTERVAL` | Git source and branch used by Fleet |
| `FLEET_GIT_*_FILE` | Git credentials |
| `FLEET_HELM_*_FILE`, `REGISTRY_*` | KubeHarbor OCI/image credentials and CA |
| `DEV_KUBE_DNS_SERVERS`, `JDE_DNS_SERVERS`, `JCP_DNS_SERVERS` | CoreDNS private-zone forwarding |
| `RANCHER_VERSION`, `RANCHER_IMAGE_LIST_FILE`, `RANCHER_CA_FILE` | Rancher disconnected installation validation |
| `CA_CERT_FILE`, `CA_KEY_FILE` | cert-manager Segment1 issuer bootstrap |
| `LONGHORN_DATA_PATH`, `LONGHORN_DATA_FILESYSTEM`, `LONGHORN_MIN_DISK_GIB` | worker storage contract |
| identity username/password files and `IDENTITY_*` | two-site identity configuration |
| per-cluster `ELASTIC_FLEET_TOKEN_*_FILE` | Elastic enrollment isolation |
| `ISTIO_CACERTS_DIR` | Istio trust material stored outside Git |

### Branch control is a deployment control

`FLEET_REPO_BRANCH` must name the exact Git branch intended for the environment. Fleet will continue reconciling the configured branch even if the operator has checked out or edited another branch locally. Always verify both before deployment:

```bash
git branch --show-current
grep '^FLEET_REPO_BRANCH=' "$KMM_FLEET_CONFIG"
```

## 4. Air-gap artifact preparation

### OCI charts

`helm/required-packages.txt`, `helm/required-oci-artifacts.txt`, `helm/fleet-oci-packages.txt`, and `helm/SHA256SUMS` form the chart-package contract.

Validate local package integrity:

```bash
cd helm
sha256sum --check SHA256SUMS
cd ..
```

Publish the Fleet charts to KubeHarbor:

```bash
./scripts/management/preflight/publish-fleet-charts.sh
```

Do not overwrite an existing OCI chart version with different bytes. Publish a new version and update Git in the same reviewed change.

### Rancher images

Rancher image acquisition/promotion is handled by the approved air-gap image workflow. Configure `RANCHER_IMAGE_LIST_FILE` to the staged list, then validate Harbor inventory and node pulls:

```bash
./scripts/deploy-platform.sh validate-rancher-registry
```

This repository validates; it does not reach the public Internet to download Rancher images.

### Longhorn host packages

The golden image must contain the pinned Ubuntu 24.04 amd64 dependencies used by Longhorn. The deployed-node preflight is validation-only and will fail rather than invoke apt or modify disk layout.

## 5. Static package validation

Run before every deployment or release commit:

```bash
./scripts/deploy-platform.sh validate-package
```

This validates shell syntax, YAML parsing, chart readability/checksums, OCI inventory, Fleet bundle dependencies and targets, retired tokens, monitoring contracts, two-site identity configuration, Segment1 addressing, RKE2 CNI settings, Longhorn UI/Kiali naming, Chrony hardening, and documentation structure.

Do not proceed until it passes.

## 6. Management-cluster bootstrap

Bootstrap the management cluster:

```bash
./scripts/deploy-platform.sh bootstrap-management
```

The sequence establishes private registry credentials/trust, CoreDNS forwarding, cert-manager/CA, MetalLB/Segment1 pool, Contour/Envoy, Rancher, and the Rancher/Fleet compatibility controls required before Fleet can reconcile.

Validate the management plane independently:

```bash
./scripts/deploy-platform.sh validate-rancher-system
```

## 7. Prepare and import downstream clusters

Rancher/Fleet system agents can violate the RKE2 CIS default restricted PodSecurity profile. Prepare the required system namespaces **before** applying Rancher import manifests:

```bash
./scripts/deploy-platform.sh prepare-rancher-imports
```

Import or provision `j64seg1opdev`, `j52seg1opdev`, and `r01seg1opdev` in Rancher. Then validate connectivity:

```bash
./scripts/deploy-platform.sh validate-rancher-imports
```

If agents were already imported before PSA preparation, use:

```bash
./scripts/deploy-platform.sh repair-rancher-agents
```

## 8. Host preflight

### Chrony

Install and prove synchronized time across every node:

```bash
./scripts/deploy-platform.sh install-cluster-time
```

The command waits for Chrony and requires:

- selected source (`^*`);
- positive stratum;
- `Leap status: Normal`.

A Running pod is not considered success. A reachable NTP server that advertises unsynchronized/stratum 0 fails the gate.

Recheck without changing the deployment:

```bash
./scripts/deploy-platform.sh validate-cluster-time
```

### Longhorn worker storage

```bash
./scripts/deploy-platform.sh prepare-longhorn-nodes
```

For each worker this verifies the required host packages/tools, iSCSI service/module, XFS mount, capacity, shared mount propagation, writeability, and Longhorn node label. It never formats or repartitions the disk.

## 9. Fleet runtime preflight and secret seeding

```bash
./scripts/deploy-platform.sh preflight-fleet
./scripts/deploy-platform.sh seed-secrets
```

Runtime seeding creates the required registry, CA, identity, Elastic, and Kiali/Grafana secrets without placing secret values in Git.

Keycloak binary runtime artifacts follow the same protected-input model. Set `KEYCLOAK_KEYTAB_FILE_001` and `KEYCLOAK_PROVIDER_FILE_001` to local files outside Git, then run `seed-secrets`. The workflow mirrors them to both identity sites as `opkeycloak-keytab` and `opkeycloak-provider`. Fleet mounts the keytab at `/etc/keycloak/keytabs/opkeycloak.keytab` and the provider at `/opt/keycloak/providers/kc-az-upn-linker.jar`. If either Secret payload changes while Keycloak is already running, `seed-secrets` performs an ordered StatefulSet restart so the provider `subPath` mount and Keycloak provider registry are refreshed.

Changing only the protected `.env` file or one of these binary files is **not** a Git/Fleet change. Rerun `./scripts/deploy-platform.sh seed-secrets` after rotating either artifact. Commit/push is required only when the repository-managed Keycloak CR, Helm values, or other GitOps content changes.

## 10. Register GitRepos and reconcile

```bash
./scripts/deploy-platform.sh fleet
./scripts/deploy-platform.sh validate
```

The `fleet` phase validates Rancher/Fleet first, labels the cluster resources, and creates/updates the GitRepos. The validation phase scopes readiness checks to bundles generated by this repository.

Verify the branch and commit in live Fleet when troubleshooting or after a branch change:

```bash
kubectl --context j64seg1opman -n fleet-default   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
kubectl --context j64seg1opman -n fleet-local   get gitrepo -o custom-columns=NAME:.metadata.name,BRANCH:.spec.branch,COMMIT:.status.commit
```

## 11. Enable the warm identity site

After the primary site and Fleet bundles are healthy:

```bash
./scripts/deploy-platform.sh enable-identity-secondary
./scripts/deploy-platform.sh validate
./scripts/deploy-platform.sh validate-identity-ha
```

This transfers/establishes the required CloudNativePG replication trust and enables the j52 warm standby according to the identity label contract.

## 12. Monitoring validation

```bash
./scripts/deploy-platform.sh validate-monitoring
```

Confirm that one Elastic Agent policy/token is associated with each cluster and that cluster identity/data-stream naming is unique.

## 13. Comprehensive workflow

For an environment where all four clusters are already reachable, the orchestrator can run the complete sequence:

```bash
./scripts/deploy-platform.sh all
```

Use individual phases during engineering work because they make failures easier to isolate and reduce unnecessary changes.

## 14. DNS records

At minimum, the environment requires records for Rancher, KubeHarbor, identity, PostgreSQL replication, east-west mesh gateways, monitoring endpoints, and the administrative UI names below:

| Hostname | Cluster/VIP |
| --- | --- |
| `longhorn-man.dev.kube` | `j64seg1opman` / `1.0.0.205` |
| `longhorn-j64.dev.kube` | `j64seg1opdev` / `1.0.0.215` |
| `longhorn-j52.dev.kube` | `j52seg1opdev` / `1.0.0.225` |
| `longhorn-r01.dev.kube` | `r01seg1opdev` / `1.0.0.235` |
| `kiali-man.dev.kube` | `j64seg1opman` / `1.0.0.205` |
| `kiali-j64.dev.kube` | `j64seg1opdev` / `1.0.0.215` |
| `kiali-j52.dev.kube` | `j52seg1opdev` / `1.0.0.225` |
| `kiali-r01.dev.kube` | `r01seg1opdev` / `1.0.0.235` |

## 15. Configuration and release rules

- Use `fleet/bundles` as the source of truth for normal Kubernetes desired state.
- Keep `yaml/` source/break-glass configuration aligned with Fleet equivalents.
- Do not put private material in `fleet/` or `yaml/`.
- Every Fleet chart requires an immutable local package, checksum, OCI inventory entry, target/dependency configuration, and validation rule.
- Every new application should receive its own numbered bundle and explicit target guard.
- Do not add another GitOps controller.
- Do not run direct Helm changes against Fleet-owned releases in normal operations.

## 16. Rollback

For a bad Fleet change, revert the Git commit and let Fleet reconcile. For a bad runtime-secret rotation, restore the protected input file and rerun `seed-secrets`. For identity changes, use the documented HA workflow rather than reversing labels manually.

If Rancher system installation/reconciliation fails, use the supported repair command instead of deleting healthy resources:

```bash
./scripts/deploy-platform.sh repair-rancher-system
```
