#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"
require_cmd jq

FLEET_RECONCILE_TIMEOUT_SECONDS="${FLEET_RECONCILE_TIMEOUT_SECONDS:-1200}"
FLEET_RECONCILE_POLL_SECONDS="${FLEET_RECONCILE_POLL_SECONDS:-5}"
case "${FLEET_RECONCILE_TIMEOUT_SECONDS}" in ''|*[!0-9]*) die "FLEET_RECONCILE_TIMEOUT_SECONDS must be an integer." ;; esac
case "${FLEET_RECONCILE_POLL_SECONDS}" in ''|*[!0-9]*) die "FLEET_RECONCILE_POLL_SECONDS must be an integer." ;; esac
(( FLEET_RECONCILE_TIMEOUT_SECONDS > 0 )) || die "FLEET_RECONCILE_TIMEOUT_SECONDS must be greater than zero."
(( FLEET_RECONCILE_POLL_SECONDS > 0 )) || die "FLEET_RECONCILE_POLL_SECONDS must be greater than zero."

managed_repos=(
  "fleet-local/k8mm-seg1opdev-multicluster-local"
  "fleet-default/k8mm-seg1opdev-multicluster-downstream"
)

dump_gitrepo() {
  local namespace="$1" name="$2"
  kubectl -n "${namespace}" get gitrepo "${name}" -o json 2>/dev/null | jq '{
    namespace: .metadata.namespace,
    name: .metadata.name,
    generation: .metadata.generation,
    observedGeneration: .status.observedGeneration,
    commit: (.status.commit // .status.display.commit // ""),
    readyClusters: (.status.display.readyClusters // ""),
    state: (.status.display.state // ""),
    resourceCounts: (.status.resourceCounts // {}),
    conditions: (.status.conditions // [])
  }' >&2 || true
}

dump_fleet_logs() {
  warn "Recent GitJob diagnostics:"
  kubectl -n cattle-fleet-system logs deployment/gitjob --all-containers=true --since=20m 2>/dev/null | \
    grep -Ei 'k8mm-seg1opdev|error|failed|authentication|denied|clone|checkout|bundle|path' | tail -120 >&2 || true
  warn "Recent Fleet controller diagnostics:"
  kubectl -n cattle-fleet-system logs deployment/fleet-controller --all-containers=true --since=20m 2>/dev/null | \
    grep -Ei 'k8mm-seg1opdev|error|failed|gitrepo|bundle' | tail -120 >&2 || true
}

wait_for_repo_bundles() {
  local repo="$1" namespace name deadline now last_notice=0 repo_json fatal_message commit bundle_count
  namespace="${repo%%/*}"
  name="${repo##*/}"
  kubectl -n "${namespace}" get gitrepo "${name}" >/dev/null
  deadline=$((SECONDS + FLEET_RECONCILE_TIMEOUT_SECONDS))

  while (( SECONDS < deadline )); do
    repo_json="$(kubectl -n "${namespace}" get gitrepo "${name}" -o json)"
    fatal_message="$(jq -r '
      [(.status.conditions // [])[]
       | select(
           (.type == "Stalled" and .status == "True") or
           ((.type == "Accepted" or .type == "GitPolling") and .status == "False")
         )
       | (.type + "=" + .status + ": " + (.message // .reason // "unspecified Fleet error"))
      ] | join("; ")' <<<"${repo_json}")"
    if [[ -n "${fatal_message}" ]]; then
      dump_gitrepo "${namespace}" "${name}"
      dump_fleet_logs
      die "Fleet GitRepo ${repo} cannot reconcile: ${fatal_message}"
    fi

    commit="$(jq -r '.status.commit // .status.display.commit // ""' <<<"${repo_json}")"
    bundle_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${name}" -o json | jq '.items | length')"
    if [[ -n "${commit}" && "${bundle_count}" -gt 0 ]]; then
      log "${repo}: Fleet fetched commit ${commit:0:12} and generated ${bundle_count} Bundle(s)."
      return 0
    fi

    now="${SECONDS}"
    if (( now - last_notice >= 30 )); then
      log "Waiting for ${repo} to fetch Git and generate Bundles (commit=${commit:-pending}, bundles=${bundle_count})..."
      last_notice="${now}"
    fi
    sleep "${FLEET_RECONCILE_POLL_SECONDS}"
  done

  dump_gitrepo "${namespace}" "${name}"
  dump_fleet_logs
  die "Timed out after ${FLEET_RECONCILE_TIMEOUT_SECONDS}s waiting for ${repo} to generate Fleet Bundles."
}

for repo in "${managed_repos[@]}"; do
  wait_for_repo_bundles "${repo}"
done

validate_storage_bundle_generation() {
  local namespace repo_name commit longhorn_count longhorn_config_count longhorn_ui_count stale_trident_count stale_dependency_count cnpg_dependency

  for namespace in fleet-local fleet-default; do
    if [[ "${namespace}" == "fleet-local" ]]; then
      repo_name="k8mm-seg1opdev-multicluster-local"
    else
      repo_name="k8mm-seg1opdev-multicluster-downstream"
    fi

    commit="$(kubectl -n "${namespace}" get gitrepo "${repo_name}" -o jsonpath='{.status.commit}' 2>/dev/null || true)"
    longhorn_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn" -o json | jq '.items | length')"
    longhorn_config_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn-config" -o json | jq '.items | length')"
    longhorn_ui_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name},kmm.dev/bundle=longhorn-ui" -o json | jq '.items | length')"
    stale_trident_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name}" -o json | jq '[.items[] | select(((.metadata.labels["kmm.dev/bundle"] // "") | test("^trident")))] | length')"
    stale_dependency_count="$(kubectl -n "${namespace}" get bundles.fleet.cattle.io \
      -l "fleet.cattle.io/repo-name=${repo_name}" -o json | jq '[.items[] | select(any(.spec.dependsOn[]?; (((.selector.matchLabels["kmm.dev/bundle"] // "") | test("^trident")))))] | length')"

    if [[ "${longhorn_count}" != "1" || "${longhorn_config_count}" != "1" || "${longhorn_ui_count}" != "1" || "${stale_trident_count}" != "0" || "${stale_dependency_count}" != "0" ]]; then
      dump_gitrepo "${namespace}" "${repo_name}"
      die "Fleet ${namespace}/${repo_name} is serving incomplete/stale Longhorn content at commit ${commit:-unknown}: longhorn=${longhorn_count}, longhorn-config=${longhorn_config_count}, longhorn-ui=${longhorn_ui_count}, retired-trident-bundles=${stale_trident_count}, retired-trident-dependencies=${stale_dependency_count}. Commit and push the current Longhorn branch to ${FLEET_REPO_BRANCH}, then rerun './scripts/deploy-platform.sh fleet' and './scripts/deploy-platform.sh validate'."
    fi
  done

  cnpg_dependency="$(kubectl -n fleet-default get bundle oppostgres-operator -o json | jq -r '[.spec.dependsOn[]? | .selector.matchLabels["kmm.dev/bundle"] // empty] | join(",")')"
  [[ "${cnpg_dependency}" == "longhorn-config" ]] || \
    die "fleet-default/oppostgres-operator has unexpected storage dependency '${cnpg_dependency:-none}'; expected longhorn-config. The GitLab branch is not reconciled to the current repository content."

  log "Fleet storage transition validation passed: Longhorn storage/UI bundles are generated."
}

validate_storage_bundle_generation

managed_bundles_json="$({
  kubectl -n fleet-local get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-local \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
  kubectl -n fleet-default get bundles.fleet.cattle.io \
    -l fleet.cattle.io/repo-name=k8mm-seg1opdev-multicluster-downstream \
    -o json | jq -r '.items[] | .metadata.namespace + "/" + .metadata.name'
} | sort -u | jq -R -s 'split("\n") | map(select(length > 0))')"

managed_count="$(jq 'length' <<<"${managed_bundles_json}")"
[[ "${managed_count}" -gt 0 ]] || die "No Fleet Bundles were generated for the two managed GitRepos."

# Wait for Fleet to create at least one BundleDeployment for each GitRepo and
# for every repository-owned BundleDeployment that exists to become Ready.
deadline=$((SECONDS + FLEET_RECONCILE_TIMEOUT_SECONDS))
last_notice=0
while (( SECONDS < deadline )); do
  bundledeployments_json="$(kubectl get bundledeployments.fleet.cattle.io -A -o json)"
  local_bd_count="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] == "fleet-local")
    ] | length' <<<"${bundledeployments_json}")"
  downstream_bd_count="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] == "fleet-default")
    ] | length' <<<"${bundledeployments_json}")"
  not_ready="$(jq -r --argjson managed "${managed_bundles_json}" '
    [ .items[] as $bd
      | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
         ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
      | select($managed | index($bundle))
      | select(($bd.status.ready // false) != true)
    ] | length' <<<"${bundledeployments_json}")"

  if [[ "${local_bd_count}" -gt 0 && "${downstream_bd_count}" -gt 0 && "${not_ready}" == "0" ]]; then
    log "Fleet reconciliation validation passed for ${managed_count} repository-owned Bundle(s)."
    exit 0
  fi

  now="${SECONDS}"
  if (( now - last_notice >= 30 )); then
    log "Waiting for BundleDeployments (local=${local_bd_count}, downstream=${downstream_bd_count}, notReady=${not_ready})..."
    last_notice="${now}"
  fi
  sleep "${FLEET_RECONCILE_POLL_SECONDS}"
done

bundledeployments_json="$(kubectl get bundledeployments.fleet.cattle.io -A -o json)"
jq -r --argjson managed "${managed_bundles_json}" '
  .items[] as $bd
  | (($bd.metadata.labels["fleet.cattle.io/bundle-namespace"] // "") + "/" +
     ($bd.metadata.labels["fleet.cattle.io/bundle-name"] // "")) as $bundle
  | select($managed | index($bundle))
  | select(($bd.status.ready // false) != true)
  | [$bd.metadata.namespace, $bd.metadata.name, ($bd.status.message // "not Ready")] | @tsv' \
  <<<"${bundledeployments_json}" >&2
for repo in "${managed_repos[@]}"; do
  dump_gitrepo "${repo%%/*}" "${repo##*/}"
done
dump_fleet_logs
die "Timed out after ${FLEET_RECONCILE_TIMEOUT_SECONDS}s waiting for repository-owned BundleDeployments to become Ready."
