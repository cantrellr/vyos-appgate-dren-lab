#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
require_cmd kubectl
require_cmd jq
require_cmd base64

PRIMARY_CONTEXT=j64seg1opdev
SECONDARY_CONTEXT=j52seg1opdev
CLUSTER_NAME=oppostgres-opkeycloak-db
CNPG_CLUSTER_RESOURCE=clusters.postgresql.cnpg.io
NAMESPACE=oppostgres

wait_for_secret() {
  local context="$1" secret="$2" deadline=$((SECONDS + 900))
  until kubectl --context "${context}" -n "${NAMESPACE}" get secret "${secret}" >/dev/null 2>&1; do
    (( SECONDS < deadline )) || die "Timed out waiting for ${context}/${NAMESPACE}/${secret}."
    sleep 5
  done
}

validate_context_access "${PRIMARY_CONTEXT}"
validate_context_access "${SECONDARY_CONTEXT}"
kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" wait --for=condition=Ready "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" --timeout=15m
wait_for_secret "${PRIMARY_CONTEXT}" "${CLUSTER_NAME}-ca"
wait_for_secret "${PRIMARY_CONTEXT}" "${CLUSTER_NAME}-replication"

primary_lb="$(kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get service oppostgres-replication-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
expected_primary_lb="${IDENTITY_PRIMARY_REPLICATION_IP:-1.0.0.216}"
[[ "${primary_lb}" == "${expected_primary_lb}" ]] || die "Primary PostgreSQL replication Service has IP '${primary_lb:-unset}', expected ${expected_primary_lb}."

tmp_dir="$(mktemp -d)"
chmod 700 "${tmp_dir}"
trap 'rm -rf "${tmp_dir}"' EXIT

kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get secret "${CLUSTER_NAME}-ca" -o jsonpath='{.data.ca\.crt}' | base64 -d >"${tmp_dir}/ca.crt"
kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get secret "${CLUSTER_NAME}-replication" -o jsonpath='{.data.tls\.crt}' | base64 -d >"${tmp_dir}/tls.crt"
kubectl --context "${PRIMARY_CONTEXT}" -n "${NAMESPACE}" get secret "${CLUSTER_NAME}-replication" -o jsonpath='{.data.tls\.key}' | base64 -d >"${tmp_dir}/tls.key"
chmod 600 "${tmp_dir}"/*

kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" create secret generic oppostgres-j64-ca \
  --from-file=ca.crt="${tmp_dir}/ca.crt" --dry-run=client -o yaml | \
  kubectl --context "${SECONDARY_CONTEXT}" apply -f - >/dev/null
kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" create secret tls oppostgres-j64-replication \
  --cert="${tmp_dir}/tls.crt" --key="${tmp_dir}/tls.key" --dry-run=client -o yaml | \
  kubectl --context "${SECONDARY_CONTEXT}" apply -f - >/dev/null

secondary_resource="$(fleet_cluster_resource fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default label cluster.fleet.cattle.io "${secondary_resource}" --overwrite \
  kmm.dev/identity=secondary \
  kmm.dev/identity-active=false \
  kmm.dev/keycloak-instances=0 \
  kmm.dev/postgres-hibernation=off \
  kmm.dev/postgres-replica-enabled=true >/dev/null

log "Replication TLS material copied to ${SECONDARY_CONTEXT}; Fleet secondary deployment enabled."
deadline=$((SECONDS + 300))
until kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" get "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" >/dev/null 2>&1; do
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to create the j52 PostgreSQL replica."
  sleep 5
done
kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" wait --for=condition=Ready "${CNPG_CLUSTER_RESOURCE}/${CLUSTER_NAME}" --timeout=30m

secondary_pod="$(kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" get pods -l "cnpg.io/cluster=${CLUSTER_NAME},role=primary" -o jsonpath='{.items[0].metadata.name}')"
in_recovery="$(kubectl --context "${SECONDARY_CONTEXT}" -n "${NAMESPACE}" exec "${secondary_pod}" -- psql -U postgres -d postgres -Atqc 'select pg_is_in_recovery()')"
[[ "${in_recovery}" == "t" ]] || die "Secondary PostgreSQL is not in recovery mode."
log "Warm identity secondary is Ready on ${SECONDARY_CONTEXT}; Keycloak remains scaled to zero until failover."
