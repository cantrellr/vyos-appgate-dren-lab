#!/usr/bin/env bash
# shellcheck shell=bash

resolve_kmm_runtime_config() {
  local versioned_default="${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env"
  local compatibility_default="${RUNTIME_DIR}/fleet-bootstrap.env"

  if [[ -n "${KMM_FLEET_CONFIG:-}" ]]; then
    printf '%s\n' "${KMM_FLEET_CONFIG}"
    return 0
  fi

  if [[ -f "${versioned_default}" && -f "${compatibility_default}" ]]; then
    die "Both runtime configs exist: ${versioned_default} and ${compatibility_default}. Set KMM_FLEET_CONFIG explicitly to remove ambiguity."
  fi
  if [[ -f "${versioned_default}" ]]; then
    printf '%s\n' "${versioned_default}"
  elif [[ -f "${compatibility_default}" ]]; then
    printf '%s\n' "${compatibility_default}"
  else
    printf '%s\n' "${versioned_default}"
  fi
}

load_kmm_runtime_config() {
  local config_file="${1:?runtime config path is required}"
  [[ -f "${config_file}" ]] || die "Runtime config not found: ${config_file}"

  local mode
  mode="$(stat -c '%a' "${config_file}")"
  (( (8#${mode} & 8#077) == 0 )) || die "Runtime config must not be group/world accessible: ${config_file} (mode ${mode})"

  set -a
  # shellcheck disable=SC1090
  source "${config_file}"
  set +a
}

read_required_secret_file() {
  local variable_name="${1:?variable name is required}"
  local path="${!variable_name:-}"
  [[ -n "${path}" ]] || die "Set ${variable_name} in the runtime config."
  [[ -f "${path}" ]] || die "Secret file referenced by ${variable_name} does not exist: ${path}"
  [[ -s "${path}" ]] || die "Secret file referenced by ${variable_name} is empty: ${path}"
  cat "${path}"
}

require_runtime_file() {
  local variable_name="${1:?variable name is required}"
  local path="${!variable_name:-}"
  [[ -n "${path}" ]] || die "Set ${variable_name} in the runtime config."
  ensure_file "${path}"
}
