#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../_lib/common.sh
source "${SCRIPT_DIR}/../_lib/common.sh"
# shellcheck source=../_lib/runtime-config.sh
source "${SCRIPT_DIR}/../_lib/runtime-config.sh"

CONFIG_FILE="$(resolve_kmm_runtime_config)"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi

init_site_cluster "$@"
NAMESPACE="kube-system"
COREDNS_CONFIG_TEMPLATE="${YAML_DIR}/resources/coredns-configmap-rke2-patch-v1.yaml"
COREDNS_DEPLOYMENT="rke2-coredns-rke2-coredns"
DNS_PROBE_NAME="kmm-coredns-registry-probe-$(date +%s)-$$"
DNS_PROBE_IMAGE="${COREDNS_DNS_PROBE_IMAGE:-${REGISTRY_HOST}/rancher/shell:v0.7.0}"
DNS_PROBE_TIMEOUT_SECONDS="${COREDNS_DNS_PROBE_TIMEOUT_SECONDS:-180}"

require_kubectl
require_cmd python3
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"
ensure_registry_secret "${NAMESPACE}"
ensure_file "${COREDNS_CONFIG_TEMPLATE}"

normalize_dns_servers() {
  local variable_name="$1" raw="${!1:-}" token
  local -a servers=()

  raw="${raw//,/ }"
  for token in ${raw}; do
    [[ "${token}" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}(:[0-9]{1,5})?$ ]] || \
      die "${variable_name} contains an invalid DNS upstream '${token}'. Use space- or comma-separated IPv4 addresses."
    servers+=("${token}")
  done
  (( ${#servers[@]} > 0 )) || die "${variable_name} must contain at least one DNS server."
  printf '%s' "${servers[*]}"
}

DEV_KUBE_DNS_SERVERS="$(normalize_dns_servers DEV_KUBE_DNS_SERVERS)"
JDE_DNS_SERVERS="$(normalize_dns_servers JDE_DNS_SERVERS)"
JCP_DNS_SERVERS="$(normalize_dns_servers JCP_DNS_SERVERS)"

rendered_config="$(mktemp)"
cleanup_rendered_config() {
  rm -f "${rendered_config}"
}
trap cleanup_rendered_config EXIT

python3 - "${COREDNS_CONFIG_TEMPLATE}" "${rendered_config}" \
  "${DEV_KUBE_DNS_SERVERS}" "${JDE_DNS_SERVERS}" "${JCP_DNS_SERVERS}" <<'PY'
from pathlib import Path
import re
import sys

template_path, output_path, dev_dns, jde_dns, jcp_dns = sys.argv[1:]
text = Path(template_path).read_text(encoding="utf-8")
replacements = {
    "__DEV_KUBE_DNS_SERVERS__": dev_dns,
    "__JDE_DNS_SERVERS__": jde_dns,
    "__JCP_DNS_SERVERS__": jcp_dns,
}
for token, value in replacements.items():
    if token not in text:
        raise SystemExit(f"CoreDNS template is missing token {token}")
    text = text.replace(token, value)

unresolved = sorted(set(re.findall(r'__[A-Z][A-Z0-9_]*__', text)))
if unresolved:
    raise SystemExit(
        "CoreDNS template contains unresolved placeholder(s): "
        + ", ".join(unresolved)
    )

Path(output_path).write_text(text, encoding="utf-8")
PY

log "Applying CoreDNS private-zone forwarding (dev.kube -> ${DEV_KUBE_DNS_SERVERS})..."
apply_file_in_namespace "${NAMESPACE}" "${rendered_config}"

log "Restarting CoreDNS deployment so the forwarding configuration is active..."
kubectl rollout restart deployment/"${COREDNS_DEPLOYMENT}" -n "${NAMESPACE}" >/dev/null
wait_for_deployment_rollout "${NAMESPACE}" "${COREDNS_DEPLOYMENT}" "${KUBECTL_TIMEOUT}"

cleanup_probe() {
  kubectl -n "${NAMESPACE}" delete pod "${DNS_PROBE_NAME}" --ignore-not-found --wait=false >/dev/null 2>&1 || true
}
cleanup_probe
trap 'cleanup_probe; cleanup_rendered_config' EXIT

cat <<YAML | kubectl apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: ${DNS_PROBE_NAME}
  namespace: ${NAMESPACE}
spec:
  automountServiceAccountToken: false
  restartPolicy: Never
  containers:
    - name: dns-probe
      image: ${DNS_PROBE_IMAGE}
      imagePullPolicy: IfNotPresent
      env:
        - name: REGISTRY_HOST
          value: ${REGISTRY_HOST}
      command: ["sh", "-ec"]
      args:
        - |
          if command -v getent >/dev/null 2>&1; then
            getent hosts "${REGISTRY_HOST}"
          elif command -v nslookup >/dev/null 2>&1; then
            nslookup "${REGISTRY_HOST}"
          elif command -v dig >/dev/null 2>&1; then
            dig +short "${REGISTRY_HOST}" | grep -q .
          else
            echo "No DNS lookup utility is present in the probe image" >&2
            exit 127
          fi
YAML

deadline=$((SECONDS + DNS_PROBE_TIMEOUT_SECONDS))
while true; do
  phase="$(kubectl -n "${NAMESPACE}" get pod "${DNS_PROBE_NAME}" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  case "${phase}" in
    Succeeded)
      break
      ;;
    Failed)
      kubectl -n "${NAMESPACE}" logs "${DNS_PROBE_NAME}" >&2 2>/dev/null || true
      kubectl -n "${NAMESPACE}" describe pod "${DNS_PROBE_NAME}" >&2 2>/dev/null || true
      die "CoreDNS cannot resolve ${REGISTRY_HOST} from a cluster Pod. Verify DEV_KUBE_DNS_SERVERS and upstream DNS zone data."
      ;;
  esac
  if (( SECONDS >= deadline )); then
    kubectl -n "${NAMESPACE}" get pod "${DNS_PROBE_NAME}" -o wide >&2 2>/dev/null || true
    kubectl -n "${NAMESPACE}" describe pod "${DNS_PROBE_NAME}" >&2 2>/dev/null || true
    kubectl -n "${NAMESPACE}" logs deployment/"${COREDNS_DEPLOYMENT}" --tail=120 >&2 2>/dev/null || true
    die "Timed out validating in-cluster DNS resolution for ${REGISTRY_HOST}."
  fi
  sleep 3
done

probe_result="$(kubectl -n "${NAMESPACE}" logs "${DNS_PROBE_NAME}" 2>/dev/null | head -1 || true)"
cleanup_probe
trap cleanup_rendered_config EXIT
log "CoreDNS patched and in-cluster resolution validated for ${REGISTRY_HOST}${probe_result:+ (${probe_result})}."
