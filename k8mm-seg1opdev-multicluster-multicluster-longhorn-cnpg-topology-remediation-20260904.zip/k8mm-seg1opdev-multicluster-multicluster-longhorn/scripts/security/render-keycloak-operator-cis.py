#!/usr/bin/env python3
"""Rename and harden the vendored Keycloak operator manifest for opkeycloak."""
from __future__ import annotations
import sys
from pathlib import Path
from typing import Any
try:
    import yaml
except ImportError as exc:
    raise SystemExit("PyYAML is required (install python3-yaml).") from exc

def rewrite(value: Any) -> Any:
    if isinstance(value, str):
        value = value.replace("devlocal-keycloak", "opkeycloak")
        value = value.replace("keycloak-operator", "opkeycloak-operator")
        value = value.replace("kubeharbor.dev.kube/cantrellcloud/dhi-keycloak:26.3.3-debian13", "kubeharbor.dev.kube/cantrellcloud/dhi-keycloak:26.6.3-debian13")
        return value
    if isinstance(value, list): return [rewrite(item) for item in value]
    if isinstance(value, dict): return {key: rewrite(item) for key, item in value.items()}
    return value

def main() -> int:
    if len(sys.argv) != 2: raise SystemExit(f"Usage: {Path(sys.argv[0]).name} <operator-manifest.yaml>")
    source = Path(sys.argv[1])
    docs = [rewrite(doc) if isinstance(doc, dict) else doc for doc in yaml.safe_load_all(source.read_text())]
    found = False
    for doc in docs:
        if not isinstance(doc, dict) or doc.get("kind") != "Deployment": continue
        if (doc.get("metadata") or {}).get("name") != "opkeycloak-operator": continue
        found = True
        # Upstream Keycloak Operator is a singleton controller. Running multiple
        # replicas without explicit leader election makes each replica reconcile the
        # same Keycloak CR and produces resourceVersion/status 409 conflicts.
        doc["spec"]["replicas"] = 1
        pod = doc["spec"]["template"]["spec"]
        pod["automountServiceAccountToken"] = True
        pod["securityContext"] = {"runAsNonRoot": True, "seccompProfile": {"type": "RuntimeDefault"}}
        for container in pod.get("containers", []):
            if container.get("name") == "opkeycloak-operator":
                container["image"] = "kubeharbor.dev.kube/keycloak/keycloak-operator:26.5.5"
                container["imagePullPolicy"] = "IfNotPresent"
                container["securityContext"] = {"allowPrivilegeEscalation": False, "runAsNonRoot": True, "privileged": False, "capabilities": {"drop": ["ALL"]}, "seccompProfile": {"type": "RuntimeDefault"}}
    if not found: raise SystemExit("Deployment/opkeycloak-operator was not found after manifest rewrite.")
    yaml.safe_dump_all(docs, sys.stdout, explicit_start=True, sort_keys=False)
    return 0
if __name__ == "__main__": raise SystemExit(main())
