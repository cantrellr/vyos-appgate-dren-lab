#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export IDENTITY_SWITCHOVER_CONFIRM="${IDENTITY_SWITCHOVER_CONFIRM:-${IDENTITY_FAILBACK_CONFIRM:-}}"
exec "${SCRIPT_DIR}/switchover-identity.sh" j64seg1opdev
