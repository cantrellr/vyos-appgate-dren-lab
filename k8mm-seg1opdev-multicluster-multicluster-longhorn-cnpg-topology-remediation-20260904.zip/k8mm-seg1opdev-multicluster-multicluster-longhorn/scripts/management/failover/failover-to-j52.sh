#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export IDENTITY_SWITCHOVER_CONFIRM="${IDENTITY_SWITCHOVER_CONFIRM:-${IDENTITY_FAILOVER_CONFIRM:-}}"
exec "${SCRIPT_DIR}/switchover-identity.sh" j52seg1opdev
