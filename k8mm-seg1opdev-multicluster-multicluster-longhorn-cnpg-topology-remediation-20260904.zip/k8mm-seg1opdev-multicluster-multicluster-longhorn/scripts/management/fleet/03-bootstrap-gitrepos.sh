#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
use_context "${RANCHER_CONTEXT:-j64seg1opman}"

# The management bootstrap installs MetalLB and Segment1 Contour before Rancher/Fleet exists.
# Older repository revisions also targeted those same Helm releases from fleet-local. Before
# removing those paths, pause the local GitRepo and delete only the obsolete BundleDeployments
# with keepResources=true so Fleet cannot uninstall the bootstrap-owned releases/resources.
preserve_bootstrap_owned_network_from_legacy_fleet() {
  local repo="k8mm-seg1opdev-multicluster-local"
  local cluster_namespace bundle
  local -a legacy_bundles=(metallb metallb-config contour-segment1)

  kubectl -n fleet-local get gitrepo "${repo}" >/dev/null 2>&1 || return 0

  cluster_namespace="$(kubectl -n fleet-local get clusters.fleet.cattle.io local -o jsonpath='{.status.namespace}' 2>/dev/null || true)"
  [[ -n "${cluster_namespace}" ]] || die "Unable to resolve fleet-local/local BundleDeployment namespace for bootstrap ownership migration."

  local found=false
  for bundle in "${legacy_bundles[@]}"; do
    if kubectl -n "${cluster_namespace}" get bundledeployment.fleet.cattle.io "${bundle}" >/dev/null 2>&1; then
      found=true
      break
    fi
  done
  [[ "${found}" == "true" ]] || return 0

  log "Migrating management MetalLB/Contour from legacy Fleet ownership back to bootstrap-management..."
  kubectl -n fleet-local patch gitrepo "${repo}" --type=merge -p '{"spec":{"paused":true}}' >/dev/null

  for bundle in "${legacy_bundles[@]}"; do
    if ! kubectl -n "${cluster_namespace}" get bundledeployment.fleet.cattle.io "${bundle}" >/dev/null 2>&1; then
      continue
    fi
    kubectl -n "${cluster_namespace}" patch bundledeployment.fleet.cattle.io "${bundle}" --type=merge \
      -p '{"spec":{"options":{"keepResources":true},"stagedOptions":{"keepResources":true}}}' >/dev/null
    [[ "$(kubectl -n "${cluster_namespace}" get bundledeployment.fleet.cattle.io "${bundle}" -o jsonpath='{.spec.options.keepResources}')" == "true" ]] || \
      die "Failed to arm keepResources on legacy fleet-local BundleDeployment ${bundle}."
    kubectl -n "${cluster_namespace}" delete bundledeployment.fleet.cattle.io "${bundle}" --wait=false >/dev/null
  done

  for bundle in "${legacy_bundles[@]}"; do
    if kubectl -n "${cluster_namespace}" get bundledeployment.fleet.cattle.io "${bundle}" >/dev/null 2>&1; then
      kubectl -n "${cluster_namespace}" wait --for=delete --timeout="${KUBECTL_TIMEOUT}" \
        "bundledeployment.fleet.cattle.io/${bundle}" >/dev/null || \
        die "Timed out retiring legacy fleet-local BundleDeployment ${bundle}; GitRepo remains paused for safety."
    fi
  done
  log "Legacy fleet-local network BundleDeployments retired with bootstrap resources preserved."
}

# The management cluster owns cert-manager, MetalLB, and Segment1 Contour through
# bootstrap-management because Rancher/Fleet depends on that network/certificate
# substrate before Fleet exists. Publish only readiness-contract markers locally.
"${INSTALL_DIR}/core/02-validate-cert-manager-bootstrap.sh" j64 seg1opman
preserve_bootstrap_owned_network_from_legacy_fleet
"${INSTALL_DIR}/core/05-validate-network-bootstrap.sh" j64 seg1opman

# Fail before creating GitRepo objects if the GitJob execution environment
# cannot resolve, trust, or authenticate to the private OCI chart registry.
"${INSTALL_DIR}/management/fleet/02-validate-fleet-oci.sh"

fleet_git_username="$(read_required_secret_file FLEET_GIT_USERNAME_FILE)"
fleet_git_password="$(read_required_secret_file FLEET_GIT_PASSWORD_FILE)"
fleet_helm_username="$(read_required_secret_file FLEET_HELM_USERNAME_FILE)"
fleet_helm_password="$(read_required_secret_file FLEET_HELM_PASSWORD_FILE)"

for workspace in fleet-local fleet-default; do
  kubectl get namespace "${workspace}" >/dev/null 2>&1 || \
    die "Fleet workspace namespace ${workspace} does not exist. Rancher/Fleet is not ready."
  kubectl -n "${workspace}" create secret generic kmm-git-credentials \
    --type=kubernetes.io/basic-auth \
    --from-literal=username="${fleet_git_username}" \
    --from-literal=password="${fleet_git_password}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n "${workspace}" create secret generic kmm-helm-credentials \
    --from-literal=username="${fleet_helm_username}" \
    --from-literal=password="${fleet_helm_password}" \
    --from-file=cacerts="${FLEET_HELM_CA_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
done

cat <<YAML | kubectl apply -f -
apiVersion: fleet.cattle.io/v1alpha1
kind: GitRepo
metadata:
  name: k8mm-seg1opdev-multicluster-local
  namespace: fleet-local
spec:
  repo: ${FLEET_REPO_URL}
  branch: ${FLEET_REPO_BRANCH}
  pollingInterval: ${FLEET_POLLING_INTERVAL:-60s}
  paused: false
  clientSecretName: kmm-git-credentials
  helmSecretName: kmm-helm-credentials
  helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'
  paths:
    - fleet/local-bundles/10-bootstrap-cert-manager-ready
    - fleet/local-bundles/11-bootstrap-cert-manager-config-ready
    - fleet/local-bundles/20-bootstrap-metallb-ready
    - fleet/local-bundles/21-bootstrap-metallb-config-ready
    - fleet/local-bundles/31-bootstrap-contour-segment1-ready
    - fleet/bundles/32-contour-segment1-policies
    - fleet/bundles/40-longhorn
    - fleet/bundles/41-longhorn-config
    - fleet/bundles/42-longhorn-ui
    - fleet/bundles/60-istio-base
    - fleet/bundles/61-istio-cni
    - fleet/bundles/62-istiod
    - fleet/bundles/63-eastwest-gateway
    - fleet/bundles/63-eastwest-gateway-config
    - fleet/bundles/64-kiali-operator
    - fleet/bundles/65-kiali-server
    - fleet/bundles/66-kiali-resources
    - fleet/bundles/70-kube-state-metrics
    - fleet/bundles/70-kube-state-metrics-alias
    - fleet/bundles/71-elastic-agent
    - fleet/bundles/72-gitlab-runner
  targets:
    - name: management-cluster
      clusterSelector:
        matchLabels:
          kmm.dev/context: j64seg1opman
---
apiVersion: fleet.cattle.io/v1alpha1
kind: GitRepo
metadata:
  name: k8mm-seg1opdev-multicluster-downstream
  namespace: fleet-default
spec:
  repo: ${FLEET_REPO_URL}
  branch: ${FLEET_REPO_BRANCH}
  pollingInterval: ${FLEET_POLLING_INTERVAL:-60s}
  paused: false
  clientSecretName: kmm-git-credentials
  helmSecretName: kmm-helm-credentials
  helmRepoURLRegex: '^oci://kubeharbor\.dev\.kube(/|$)'
  paths:
    - fleet/bundles/10-cert-manager
    - fleet/bundles/11-cert-manager-config
    - fleet/bundles/20-metallb
    - fleet/bundles/21-metallb-config
    - fleet/bundles/31-contour-segment1
    - fleet/bundles/32-contour-segment1-policies
    - fleet/bundles/40-longhorn
    - fleet/bundles/41-longhorn-config
    - fleet/bundles/42-longhorn-ui
    - fleet/bundles/50-cnpg-operator
    - fleet/bundles/51-postgresql-ha
    - fleet/bundles/51-postgresql-ha-resources
    - fleet/bundles/51-postgresql-replica
    - fleet/bundles/52-keycloak-operator
    - fleet/bundles/53-keycloak
    - fleet/bundles/54-keycloak-secondary
    - fleet/bundles/60-istio-base
    - fleet/bundles/61-istio-cni
    - fleet/bundles/62-istiod
    - fleet/bundles/63-eastwest-gateway
    - fleet/bundles/63-eastwest-gateway-config
    - fleet/bundles/64-kiali-operator
    - fleet/bundles/65-kiali-server
    - fleet/bundles/66-kiali-resources
    - fleet/bundles/70-kube-state-metrics
    - fleet/bundles/70-kube-state-metrics-alias
    - fleet/bundles/71-elastic-agent
  targets:
    - name: seg1opdev-platform
      clusterSelector:
        matchLabels:
          kmm.dev/platform: seg1opdev
YAML

# Increment forceSyncGeneration so credential, branch, and path corrections are
# picked up immediately instead of waiting for the next polling interval.
for repo in \
  fleet-local/k8mm-seg1opdev-multicluster-local \
  fleet-default/k8mm-seg1opdev-multicluster-downstream
do
  namespace="${repo%%/*}"
  name="${repo##*/}"
  current="$(kubectl -n "${namespace}" get gitrepo "${name}" -o jsonpath='{.spec.forceSyncGeneration}' 2>/dev/null || true)"
  current="${current:-0}"
  kubectl -n "${namespace}" patch gitrepo "${name}" --type=merge \
    -p "{\"spec\":{\"forceSyncGeneration\":$((current + 1))}}" >/dev/null
done

unset fleet_git_username fleet_git_password fleet_helm_username fleet_helm_password
log "Fleet GitRepo resources created or updated and queued for immediate synchronization."
