#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd base64

management_context="${RANCHER_CONTEXT:-j64seg1opman}"
primary_site=j64seg1opdev
secondary_site=j52seg1opdev

validate_context_access "${primary_site}"
validate_context_access "${secondary_site}"
identity_wait_cluster_ready "${primary_site}" 15m

primary_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${primary_site}")" "${management_context}")"
secondary_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${secondary_site}")" "${management_context}")"

distributed_topology_is_healthy() {
  local j64_self j64_primary j52_self j52_primary j52_recovery
  kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1 || return 1
  kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" wait \
    --for=condition=Ready "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --timeout=5s >/dev/null 2>&1 || return 1
  kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" wait \
    --for=condition=Ready "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --timeout=5s >/dev/null 2>&1 || return 1

  j64_self="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j64_primary="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  j52_self="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j52_primary="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  j52_recovery="$(identity_sql "${secondary_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"

  [[ "${j64_self}" == "${primary_site}" && "${j64_primary}" == "${primary_site}" && \
     "${j52_self}" == "${secondary_site}" && "${j52_primary}" == "${primary_site}" && \
     "${j52_recovery}" == t ]]
}

if distributed_topology_is_healthy; then
  log "Identity distributed topology is already enrolled and Ready; running replication verification only."
  "${SCRIPT_DIR}/../failover/verify-database-replication.sh" "${primary_site}" "${secondary_site}"
  log "Warm identity secondary is already healthy on ${secondary_site}."
  exit 0
fi

primary_lb="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get service oppostgres-replication-lb -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
expected_primary_lb="$(identity_replication_ip "${primary_site}")"
[[ "${primary_lb}" == "${expected_primary_lb}" ]] || \
  die "Primary PostgreSQL replication Service has IP '${primary_lb:-unset}', expected ${expected_primary_lb}."

# The secondary may be absent or may be left in a partially enrolled state by a
# prior failed Fleet reconciliation. Always establish J64 trust on J52 first.
identity_sync_replication_tls "${primary_site}" "${secondary_site}"

# Phase 1: normalize into a safe one-way streaming topology. This is also the
# recovery path for the CloudNativePG admission failure where replica.self or
# replica.primary referenced site IDs missing from externalClusters.
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${primary_resource}" --overwrite \
  kmm.dev/postgres-primary-site="${primary_site}" \
  kmm.dev/postgres-distributed-topology=false >/dev/null
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${secondary_resource}" --overwrite \
  kmm.dev/identity=secondary \
  kmm.dev/identity-active=false \
  kmm.dev/keycloak-instances=0 \
  kmm.dev/postgres-hibernation=off \
  kmm.dev/postgres-primary-site="${primary_site}" \
  kmm.dev/postgres-distributed-topology=false >/dev/null

log "Normalized identity labels to standalone streaming mode; waiting for J52 pg_basebackup/WAL recovery."
deadline=$((SECONDS + 300))
until kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
  get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; do
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to create the j52 PostgreSQL replica."
  sleep 5
done
identity_wait_cluster_ready "${secondary_site}" 30m
[[ "$(identity_sql "${secondary_site}" 'select pg_is_in_recovery()')" == "t" ]] || \
  die "Secondary PostgreSQL is not in recovery mode."

# Phase 2: the J52 Cluster now exists, so its operator-managed replication TLS
# Secrets also exist. Copy those to J64 before either Cluster references J52 as
# an external member of the distributed topology.
identity_sync_replication_tls "${secondary_site}" "${primary_site}"

topology_enrollment_started=false
rollback_partial_enrollment() {
  local rc="${1:-1}"
  [[ "${topology_enrollment_started}" == true ]] || return 0
  set +e
  warn "Distributed-topology enrollment did not complete; reverting Fleet labels to safe standalone streaming mode."
  kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${primary_resource}" --overwrite \
    kmm.dev/postgres-primary-site="${primary_site}" \
    kmm.dev/postgres-distributed-topology=false >/dev/null 2>&1
  kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${secondary_resource}" --overwrite \
    kmm.dev/postgres-primary-site="${primary_site}" \
    kmm.dev/postgres-distributed-topology=false >/dev/null 2>&1
  warn "J64 remains the writable primary and J52 remains a one-way streaming replica. Re-run enable-identity-secondary after correcting the reported issue."
  return "${rc}"
}
trap 'rc=$?; if (( rc != 0 )); then rollback_partial_enrollment "${rc}" || true; fi; exit "${rc}"' EXIT

topology_enrollment_started=true
for resource in "${primary_resource}" "${secondary_resource}"; do
  kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${resource}" --overwrite \
    kmm.dev/postgres-primary-site="${primary_site}" \
    kmm.dev/postgres-distributed-topology=true >/dev/null
done

# CloudNativePG requires every value used by replica.self/replica.primary to be
# represented in externalClusters. The Helm adapters now supply both site IDs;
# wait until Fleet has applied that valid topology on both Kubernetes clusters.
deadline=$((SECONDS + 900))
while :; do
  j64_self="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j64_primary="$(kubectl --context "${primary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  j52_self="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)"
  j52_primary="$(kubectl --context "${secondary_site}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  [[ "${j64_self}" == "${primary_site}" && "${j52_self}" == "${secondary_site}" && \
     "${j64_primary}" == "${primary_site}" && "${j52_primary}" == "${primary_site}" ]] && break
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to enroll both PostgreSQL clusters in the distributed topology."
  sleep 5
done

identity_wait_cluster_ready "${primary_site}" 15m
identity_wait_cluster_ready "${secondary_site}" 15m
"${SCRIPT_DIR}/../failover/verify-database-replication.sh" "${primary_site}" "${secondary_site}"
topology_enrollment_started=false
trap - EXIT
log "Warm identity secondary is Ready on ${secondary_site}; distributed replication is healthy and Keycloak remains scaled to zero."
