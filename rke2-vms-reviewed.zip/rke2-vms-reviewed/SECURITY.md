# Security Guidance

This repository automates infrastructure creation, so treat it like production-grade deployment code. The blast radius is real: a bad CSV, exposed private key, or accidental ISO commit can compromise an RKE2 cluster before the first node joins.

## Do not commit sensitive artifacts

Never commit these items:

- CA private keys, node private keys, or any `*key*.pem` file.
- Generated boot/seed ISO files.
- RKE2 join tokens, bootstrap token files, kubeconfigs, or kubelet client certs.
- vCenter credentials, service-account passwords, `.env` files, or PowerShell transcripts containing secrets.
- Internal-only production inventory exports unless sanitized.

The reviewed `.gitignore` blocks common secret and generated-artifact patterns, but `.gitignore` is a guardrail, not a control. Use secret scanning before every push.

## Required secret handling model

Use a two-lane model:

1. **Source lane:** scripts, templates, docs, non-sensitive YAML, CSV schemas, and examples.
2. **Operations lane:** CA keys, generated ISOs, tokens, kubeconfigs, production IP inventories, and operator-specific runtime files.

For the operations lane, use a controlled share, encrypted vault, or release artifact store with access logging and retention. Do not rely on Git branch permissions as your only safeguard.

## vCenter authentication

- Use a dedicated vCenter service account with least privilege.
- Avoid using personal administrator accounts for repeatable automation.
- Store credentials in an enterprise password vault or prompt with `Get-Credential`.
- Do not hard-code vCenter usernames or passwords in scripts.
- Use `-AllowInvalidCertificate` only in lab environments. Production should trust the vCenter CA chain.

## PowerShell execution controls

Recommended enterprise controls:

- Sign production scripts.
- Use PowerShell 7 where operationally possible.
- Run with constrained, audited operator accounts.
- Capture transcripts only in protected locations because transcripts may contain inventory and error context.
- Pin and validate VMware PowerCLI versions in a build workstation baseline.

## RKE2 node and CA material

The current RKE2 config examples reference `rootKey` paths. That may be operationally required, but the private key files should be injected at build time from a protected location, not tracked in Git.

Recommended pattern:

```text
repo/configs/<env>/certs/*.crt        # public CA certs may be tracked
secure-store/<env>/*key*.pem          # private keys outside Git
build workstation mounts secure-store read-only during ISO generation
```

## Network and IP hygiene

Several example node files use `1.0.0.0/24`-style addressing for a segment network. That is public address space, not RFC1918. For lab-only closed routing it may work, but it creates future interoperability and audit friction. Use private or formally assigned ranges for internal lab segments.

## Preflight checklist before running clone automation

- Confirm CSV target folders, resource pools, datastores, networks, and hosts exist.
- Confirm boot ISO files are already uploaded to the target datastore folder.
- Run with `-WhatIf` first.
- Run with `-SkipExisting` for reruns.
- Confirm source image/template is patched, powered off when appropriate, and intentionally versioned.
- Confirm vCenter certificate trust posture.
- Confirm DRS is enabled before expecting DRS rules to matter.
