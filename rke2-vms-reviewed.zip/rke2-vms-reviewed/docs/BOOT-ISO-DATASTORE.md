# Boot ISO Datastore Attachment

## Problem addressed

The original clone script accepted an `IsoFolder` value as if ISO files were local files, then tried to attach the selected ISO using this vSphere path pattern:

```text
[VM datastore] iso-file-name.iso
```

That fails in normal vSphere operations when the ISO is stored in a datastore folder such as:

```text
[nfs_nvme] boot-isos/j64manager-ctrl01.iso
```

It also gave the operator no clean way to enter the datastore and datastore folder where the boot ISOs live.

## Implemented behavior

`Clone-VMsFromCSV.ps1` now supports these parameters:

| Parameter | Purpose |
|---|---|
| `-AttachBootIso` | Enables ISO attachment. |
| `-BootIsoDatastore` | Datastore containing ISO files, for example `nfs_nvme`. |
| `-BootIsoFolder` | Datastore folder containing ISO files, for example `boot-isos` or `rke2/devlocal/boot-isos`. |
| `-PromptForBootIsoLocation` | Prompts the operator for datastore/folder at runtime. |
| `-ValidateBootIsoPath` | Best-effort pre-validation before attaching the ISO. |

## CSV columns

The clone CSV schema now supports these optional ISO columns:

| Column | Purpose |
|---|---|
| `BootIsoDatastore` | Per-row datastore override. |
| `BootIsoFolder` | Per-row datastore folder override. |
| `IsoName` | Per-row ISO filename override. Defaults to `<VMName>.iso`. |
| `BootIsoPath` | Full vSphere path override. Highest precedence. |

## Path resolution order

The script resolves the ISO path in this order:

1. `BootIsoPath` from CSV.
2. `BootIsoDatastore`, `BootIsoFolder`, and `IsoName` from CSV.
3. Global `-BootIsoDatastore`, `-BootIsoFolder`, and default filename `<VMName>.iso`.

## Examples

### Global datastore and folder

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos `
  -PowerOn
```

A row with `VMName` of `j64manager-ctrl01` resolves to:

```text
[nfs_nvme] boot-isos/j64manager-ctrl01.iso
```

### Interactive prompt

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -PromptForBootIsoLocation
```

### Per-row full path

```csv
VMName,SourceVM,Cluster,Datastore,PowerOn,BootIsoPath
j64manager-ctrl01,rke2image-devlocal,R01_Infrastructure,nfs_nvme,TRUE,[nfs_nvme] boot-isos/j64manager-ctrl01.iso
```

## Operational notes

- Upload ISO files to the datastore before cloning.
- Keep ISO filenames aligned to VM names unless there is a compelling reason not to.
- Do not commit generated ISO files to Git; they often contain node-specific metadata and sometimes sensitive bootstrap data.
- Attach the ISO before first power-on so the guest sees it during initial boot/configuration.
