# CSV Schema

## Clone workflow CSV

Used by `scripts/Clone-VMsFromCSV.ps1`.

| Column | Required | Description |
|---|---:|---|
| `VMName` | Yes | Name of the VM to create. Also used as the default ISO filename stem. |
| `SourceVM` | Yes | Name of source VM or template. The script checks both. |
| `Cluster` | No | Target vSphere cluster. Used for host selection and root resource pool fallback. |
| `VMHost` | No | Specific ESXi host. If blank and `Cluster` is set, the script picks a connected non-maintenance host with lowest current CPU usage. |
| `ResourcePool` | No | Target resource pool. If blank and `Cluster` is set, the cluster root pool is used. |
| `Datastore` | No | Datastore for VM placement. Recommended for deterministic builds. |
| `Folder` | No | VM folder. Recommended for RKE2 cluster grouping. |
| `Network` | No | Port group/network name for the first VM NIC. |
| `CpuCount` | No | Desired vCPU count. Blank keeps source setting. |
| `MemoryGB` | No | Desired memory in GB. Blank keeps source setting. |
| `DiskGB` | No | Desired primary disk size. Expands only; never shrinks. |
| `OSCustomizationSpec` | No | vSphere OS customization spec. Usually blank for image-init workflows. |
| `PowerOn` | No | TRUE/FALSE per-row override. If blank, global `-PowerOn` controls behavior. |
| `BootIsoDatastore` | No | Per-row ISO datastore override. |
| `BootIsoFolder` | No | Per-row ISO folder override. |
| `IsoName` | No | Per-row ISO filename. Defaults to `<VMName>.iso`. |
| `BootIsoPath` | No | Full vSphere ISO path. Highest precedence. |

## Recommended clone CSV pattern

Keep common settings in global parameters and leave per-row ISO columns blank unless a VM is an exception.

```csv
VMName,SourceVM,Cluster,VMHost,ResourcePool,Datastore,Folder,Network,CpuCount,MemoryGB,DiskGB,OSCustomizationSpec,PowerOn,BootIsoDatastore,BootIsoFolder,IsoName,BootIsoPath
j64manager-ctrl01,rke2image-devlocal,R01_Infrastructure,r01ex241.dev.local,j64manager,nfs_nvme,j64manager,kubes-domain,4,16,128,,TRUE,,,,
```

Run with:

```powershell
.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential (Get-Credential) `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos
```

## Generic VM creation CSV

Used by `scripts/New-VMsFromCSV.ps1`.

| Column | Required | Description |
|---|---:|---|
| `VMName` | Yes | Name of the VM to create. |
| `Cluster` | No | Cluster used to resolve root resource pool. |
| `Datastore` | Required when not using a template | Target datastore. |
| `Network` | No | VM network/port group. |
| `CpuCount` | No | Defaults to 2. |
| `MemoryGB` | No | Defaults to 4. |
| `DiskGB` | No | Defaults to 40 for scratch VMs. |
| `Template` | No | Template name. If blank, script creates a scratch VM. |
| `Folder` | No | VM folder. |
| `ResourcePool` | No | Resource pool. |
| `GuestId` | No | vSphere guest ID. |
| `OSCustomizationSpec` | No | vSphere customization spec. |
| `CpuReservationMHz` | No | Optional CPU reservation. |
| `MemoryReservationGB` | No | Optional memory reservation. |

## CSV quality gates

Before running automation, validate:

- VM names are unique.
- Source image/template exists.
- Datastore, folder, resource pool, network, cluster, and host names match vCenter exactly.
- Requested disk size is not smaller than the source disk.
- `PowerOn` values are only `TRUE`, `FALSE`, or blank.
- ISO filenames match VM names when using global datastore/folder defaults.
