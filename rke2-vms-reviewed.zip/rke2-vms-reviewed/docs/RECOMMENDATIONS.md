# Recommendations, Best Practices, and Security Findings

## Executive summary

The repo has a solid operational concept: CSV-driven vSphere VM provisioning for RKE2 clusters. The core gap was that the implementation was still in lab-script posture: empty README, generated artifacts in source, private key material in the repo, hard-coded assumptions, weak idempotency around DRS rules, and an ISO attachment path that did not correctly model datastore folders.

The reviewed version moves the repo toward an engineering baseline: documented workflows, safer PowerCLI defaults, clearer CSV schema, datastore/folder ISO attachment support, secret-exclusion guardrails, and more maintainable scripts.

## High-priority findings

### 1. Private CA keys were present in the repo

Private key files were found under `configs/*/certs/`. That is a red-line issue. If this were a production repository, those keys should be treated as exposed and rotated.

Recommended action:

- Remove private keys from Git history if this repo was ever pushed.
- Rotate the affected CA/private keys if there is any chance of exposure.
- Store private keys in a vault or controlled operations share.
- Inject keys only during ISO/image generation.

### 2. Generated ISO files were present in source control

Generated boot/seed ISO files were checked into the tree. These can contain node-specific details and sometimes bootstrap material. They also create unnecessary repo bloat.

Recommended action:

- Keep generated ISOs out of Git.
- Store them in a release artifact location or upload directly to the vSphere datastore.
- Track only manifests/checksums if needed.

### 3. ISO attachment logic did not support datastore folders correctly

The original script accepted `IsoFolder` as a local filesystem path and then generated this kind of path:

```text
[VM datastore] vm-name.iso
```

That does not work when ISOs are staged under a datastore folder such as:

```text
[nfs_nvme] boot-isos/vm-name.iso
```

Implemented action:

- Added `-AttachBootIso`.
- Added `-BootIsoDatastore`.
- Added `-BootIsoFolder`.
- Added `-PromptForBootIsoLocation`.
- Added per-row CSV overrides: `BootIsoDatastore`, `BootIsoFolder`, `IsoName`, and `BootIsoPath`.

### 4. PowerCLI invalid certificate bypass was unconditional

The scripts previously ignored invalid vCenter TLS certificates by default. That is acceptable for a disposable lab, but wrong as a standing default.

Implemented action:

- Certificate bypass is now opt-in with `-AllowInvalidCertificate`.

Recommended action:

- Trust the vCenter issuing CA on the automation workstation.
- Use `-AllowInvalidCertificate` only for lab troubleshooting.

### 5. Documentation was not sufficient for repeatable operations

`README.md` was effectively empty. That makes the repo tribal knowledge. Tribal knowledge does not scale, and it absolutely does not survive audit pressure.

Implemented action:

- Added README with workflow, layout, examples, and links.
- Added security guidance.
- Added CSV schema documentation.
- Added boot ISO datastore documentation.
- Added operator runbook.

## Script-level recommendations

### Clone workflow

Implemented improvements:

- Added strict mode and safer error handling.
- Added source resolution for both VM and template objects.
- Added boot ISO datastore/folder support.
- Added `-WhatIf` support around clone and DRS changes.
- Added connected/non-maintenance host filtering for auto-placement.
- Added per-run summary of created, skipped, and failed VMs.
- Added optional `-FailOnError` for CI/CD style execution.
- Added idempotent DRS rule creation.
- Added comments explaining operational intent, not just syntax.

Future improvements:

- Add a `Test-CloneCsv.ps1` preflight script that validates all referenced vSphere objects before cloning.
- Add structured JSON logging for CI/CD runs.
- Add explicit multi-NIC CSV support if you intend to move beyond template-baked NIC layout.
- Add Pester tests for CSV parsing, ISO path formatting, and safety checks.
- Add PSScriptAnalyzer to a CI job.

### New VM workflow

Implemented improvements:

- Added comments and strict mode.
- Made certificate bypass opt-in.
- Improved optional CSV column handling.
- Added `SupportsShouldProcess` for safer dry runs.

Future improvements:

- Decide whether this script belongs in the same repo. If the repo is specifically RKE2-image cloning, keep this as a utility or move it to a generic vSphere automation repo.

### Resource-pool workflow

Implemented improvements:

- Added corrected script name: `New-RKE2vSphereResourcePools.ps1`.
- Retained typo wrapper: `rke2-vshpere-resource-pools.ps1`.
- Converted hard-coded workflow into parameterized, idempotent logic.
- Documented reservation data as a reviewable object list.

Future improvements:

- Externalize the resource-pool definitions to YAML or CSV.
- Pull actual VM sizing from the clone CSV and calculate recommended reservations automatically.
- Decide whether reservations are actually desired or whether shares/limits are a better fit for the lab.

## RKE2 configuration recommendations

### Version consistency

Some file names and manifests reference different RKE2 image versions. That creates drift.

Recommended action:

- Establish one source of truth for RKE2 version per environment.
- Add a simple validation script that checks config file names, manifest paths, and image YAML values for version mismatch.

### Air-gap DNS

One image config uses `defaultDns: [4.2.2.2]`. That is not appropriate for a true air-gapped environment.

Recommended action:

- Use internal DNS only.
- Document DNS per environment.
- Fail preflight if public resolvers are found in air-gapped configs.

### Public IP space in internal lab segments

Some node configs use `1.0.0.0/24`-style addressing. That is public address space.

Recommended action:

- Move internal-only lab segments to RFC1918, CGNAT, or formally assigned ranges.
- Update diagrams, DNS, firewall rules, and YAML together.

### CA private key handling

The YAML references `rootKey` paths. That may be required by your image-generation workflow, but it should be injected from protected storage.

Recommended action:

- Track public certs and references in Git.
- Keep private keys outside Git.
- Add build-time checks that private key paths exist locally but are ignored by Git.

## vSphere best practices

- Use templates or content-library items for source images instead of mutable source VMs where possible.
- Keep source images versioned and immutable.
- Use deterministic VM folders and resource pools per cluster/environment.
- Use DRS anti-affinity for control-plane VMs at minimum.
- Validate target datastores have enough free capacity before clone execution.
- Avoid hard-pinning every VM to a host unless you have an explicit placement reason; let DRS do its job where available.
- Keep the vCenter service account least-privileged and auditable.

## Security backlog

| Priority | Item | Why it matters |
|---:|---|---|
| P0 | Remove and rotate committed private keys | Prevent trust-chain compromise. |
| P0 | Remove generated ISOs from Git | Prevent metadata/secret leakage and repo bloat. |
| P1 | Add secret scanning to CI | Prevent regression. |
| P1 | Add CSV preflight validation | Reduce failed partial builds. |
| P1 | Trust vCenter CA instead of ignoring cert validation | Prevent MITM-friendly operating posture. |
| P2 | Add Pester tests | Keep future changes from breaking clone behavior. |
| P2 | Externalize environment definitions | Reduce hard-coded script drift. |
| P2 | Add version drift validation | Keep image/config/manifest versioning aligned. |

## Engineering posture

The direction is right, but this needs to move from “works in my lab” to “repeatable infrastructure product.” The strategic play is to treat CSVs and YAML as contracts, scripts as controlled release assets, and generated ISOs/keys as operational artifacts with a separate custody chain.
