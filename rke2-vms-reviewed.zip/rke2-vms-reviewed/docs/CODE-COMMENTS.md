# Code Commenting Standard

The scripts now use comments to document operational intent, not just what PowerShell already says.

## Good comments explain

- Why a safety check exists.
- Why an order of operations matters.
- What operational assumption is being made.
- What should not be changed casually.
- Where lab behavior differs from production behavior.

## Avoid comments that only repeat syntax

Bad:

```powershell
# Set variable to true
$enabled = $true
```

Good:

```powershell
# Attach the ISO before first boot so node-init can consume the seed data.
Attach-BootIsoToVm -Vm $newVm -IsoPath $isoPath
```

## Comment density target

- Public script header: comprehensive.
- Public functions: comment-based synopsis/description.
- Dense logic blocks: short operational comments.
- Simple assignments: no comment unless the value encodes a business decision.
