# Operations Runbook

## 1. Prepare vSphere

1. Confirm the source RKE2 image/template exists and is intentionally versioned.
2. Confirm target datastores, networks, VM folders, and resource pools exist.
3. Confirm DRS is enabled if you expect anti-affinity rules to be enforced.
4. Upload generated boot/seed ISOs to the selected datastore folder.
5. Confirm ISO naming matches the VM naming convention: `<VMName>.iso`.

## 2. Prepare the CSV

Use one of the existing clone CSV files or `csv/clone-rkeimage-template.csv`.

Minimum required columns:

```csv
VMName,SourceVM
```

Recommended production/lab columns:

```csv
VMName,SourceVM,Cluster,VMHost,ResourcePool,Datastore,Folder,Network,CpuCount,MemoryGB,DiskGB,OSCustomizationSpec,PowerOn,BootIsoDatastore,BootIsoFolder,IsoName,BootIsoPath
```

## 3. Dry run

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos `
  -WhatIf
```

## 4. Execute clone

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos `
  -SkipExisting `
  -PowerOn
```

## 5. Validate after clone

Validate in vCenter:

- VM exists in the expected folder.
- VM is on the expected datastore/resource pool.
- CPU, memory, and primary disk match the CSV.
- First NIC is attached to the expected port group.
- CD/DVD drive is attached to the expected ISO path.
- CD/DVD drive is configured to connect at power-on.
- VM power state matches the requested behavior.
- DRS rules exist and are enabled when expected.

Validate in guest/RKE2 flow:

- Node boots and reads the ISO configuration.
- Hostname and static IPs match node YAML.
- RKE2 service starts successfully.
- Server nodes use the expected token/custom CA files.
- Agent nodes join the expected cluster.

## 6. Rerun strategy

For safe reruns:

```powershell
-SkipExisting
```

Do not manually delete partially created VMs until you review what completed. If the clone succeeded but post-clone customization failed, decide whether to remediate the VM or delete/recreate it.

## 7. Rollback strategy

A practical rollback is inventory-level cleanup:

1. Power off failed VMs.
2. Remove failed VMs from inventory and datastore.
3. Remove stale DRS rules only if they reference deleted VMs.
4. Correct CSV/script/input issue.
5. Rerun with `-SkipExisting`.

## 8. Troubleshooting

| Symptom | Likely cause | Action |
|---|---|---|
| ISO does not attach | Wrong datastore/folder/path | Use full `BootIsoPath` for one row and retry. |
| `SourceVM` not found | Source is named differently or in another vCenter | Confirm template/source name in vCenter. |
| DRS rules not created | DRS disabled, folder empty, or fewer than two matching VMs | Confirm VM folder and naming convention. |
| Network assignment fails | Ambiguous or missing port group | Confirm port group name and vSwitch/VDS visibility. |
| Disk not resized smaller | Shrink is intentionally blocked | Rebuild source image or create a new disk plan. |
| Certificate error connecting to vCenter | vCenter CA not trusted | Trust the CA, or use `-AllowInvalidCertificate` only in lab. |
