# Review Change Log

## Added

- Comprehensive `README.md`.
- `SECURITY.md` with source-control and secret-handling requirements.
- `docs/BOOT-ISO-DATASTORE.md`.
- `docs/CSV-SCHEMA.md`.
- `docs/OPERATIONS-RUNBOOK.md`.
- `docs/RECOMMENDATIONS.md`.
- `docs/CODE-COMMENTS.md`.
- `csv/clone-rkeimage-template.csv`.
- `scripts/New-RKE2vSphereResourcePools.ps1`.

## Changed

- Reworked `scripts/Clone-VMsFromCSV.ps1` with strict mode, safer certificate behavior, source VM/template support, datastore/folder ISO attachment, idempotent DRS rules, and stronger comments.
- Reworked `scripts/New-VMsFromCSV.ps1` with strict mode, safer certificate behavior, optional column handling, and comments.
- Updated clone CSV files with optional boot ISO columns.
- Replaced the misspelled resource-pool script with a compatibility wrapper.
- Expanded `.gitignore` for generated artifacts and secrets.

## Removed from reviewed package

- Generated `.iso` files.
- Private key files matching `*key*.pem`.

These should be handled through the operations lane, not source control.
