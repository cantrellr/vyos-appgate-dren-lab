# Config Directory Guidance

This directory contains RKE2 image and node configuration examples.

Operationally sensitive inputs should not live in Git:

- Private CA keys.
- Bootstrap token files.
- Generated boot/seed ISOs.
- Kubeconfigs.
- Environment-specific production inventory exports.

Public CA certificates and non-sensitive templates may be tracked when useful. Private keys referenced by `rootKey` should be supplied from protected storage during the ISO/image generation process.
