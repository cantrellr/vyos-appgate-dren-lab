<#
.SYNOPSIS
  Create new VMware vSphere VMs from a CSV definition.

.DESCRIPTION
  This script provisions VMs from either templates or scratch definitions. It is
  intended for generic VM creation. For RKE2 node cloning from an image/template
  with optional seed/boot ISO attachment, use Clone-VMsFromCSV.ps1 instead.

  The script keeps CSV parsing strict enough to catch invalid input while still
  supporting optional columns. It also makes invalid vCenter TLS bypass opt-in,
  which is the right production posture.

.PARAMETER CsvPath
  Path to the VM definition CSV.

.PARAMETER VCenter
  vCenter FQDN or IP address.

.PARAMETER Credential
  Credential used for vCenter authentication.

.PARAMETER SkipExisting
  Skip VMs that already exist.

.PARAMETER AllowInvalidCertificate
  Ignore invalid vCenter TLS certificates for this PowerCLI session. Use this in
  lab environments only; production automation should trust the vCenter CA.

.EXAMPLE
  $cred = Get-Credential
  .\New-VMsFromCSV.ps1 -CsvPath .\csv\new-vms-from-csv-template.csv `
                       -VCenter vcsa.dev.local `
                       -Credential $cred
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$CsvPath,

  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$VCenter,

  [Parameter(Mandatory = $true)]
  [ValidateNotNull()]
  [pscredential]$Credential,

  [Parameter()]
  [switch]$SkipExisting,

  [Parameter()]
  [switch]$AllowInvalidCertificate
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-StringOrNull {
  <# Return a trimmed string, or $null when the CSV field is empty. #>
  param([AllowNull()][string]$Value)
  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  return $Value.Trim()
}

function Get-RowValue {
  <# Safely read optional CSV columns under StrictMode. #>
  param(
    [Parameter(Mandatory = $true)][psobject]$Row,
    [Parameter(Mandatory = $true)][string]$Name
  )
  if ($Row.PSObject.Properties.Name -contains $Name) { return $Row.$Name }
  return $null
}

function Get-IntOrDefault {
  <# Parse an integer or return the caller-provided default. #>
  param(
    [AllowNull()][string]$Value,
    [Parameter(Mandatory = $true)][int]$Default
  )

  if ([string]::IsNullOrWhiteSpace($Value)) { return $Default }

  $parsed = 0
  if ([int]::TryParse($Value, [ref]$parsed)) { return $parsed }

  throw "Value '$Value' is not a valid integer."
}

function Get-ClusterRootResourcePool {
  <# Resolve the hidden root resource pool backing a vSphere cluster. #>
  param([AllowNull()]$Cluster)

  if (-not $Cluster) { return $null }
  if (-not $Cluster.ExtensionData -or -not $Cluster.ExtensionData.ResourcePool) { return $null }

  return Get-ResourcePool -Id $Cluster.ExtensionData.ResourcePool -ErrorAction Stop
}

function Resolve-TemplateOrNull {
  <# Resolve a template name when provided; return $null for scratch VM creation. #>
  param([AllowNull()][string]$TemplateName)

  if (-not $TemplateName) { return $null }
  return Get-Template -Name $TemplateName -ErrorAction Stop
}

# --- Main execution -----------------------------------------------------------
if (-not (Test-Path -Path $CsvPath -PathType Leaf)) {
  throw "CSV file not found at '$CsvPath'."
}

Import-Module VMware.PowerCLI -ErrorAction Stop
if ($AllowInvalidCertificate) {
  Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
}

$viServer = Get-VIServer -Server $VCenter -ErrorAction SilentlyContinue
if (-not $viServer) {
  $viServer = Connect-VIServer -Server $VCenter -Credential $Credential -ErrorAction Stop
}

try {
  $vmDefinitions = @(Import-Csv -Path $CsvPath)
  if ($vmDefinitions.Count -eq 0) {
    throw "CSV '$CsvPath' is empty or unreadable."
  }

  foreach ($vmRow in $vmDefinitions) {
    $vmName = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'VMName')
    if (-not $vmName) {
      Write-Warning 'Skipping row with blank VMName.'
      continue
    }

    if ($SkipExisting -and (Get-VM -Name $vmName -ErrorAction SilentlyContinue)) {
      Write-Host "VM '$vmName' already exists; skipping." -ForegroundColor Yellow
      continue
    }

    try {
      # Resolve placement and optional build inputs from the CSV row.
      $clusterName   = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'Cluster')
      $datastoreName = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'Datastore')
      $networkName   = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'Network')
      $templateName  = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'Template')
      $folderName    = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'Folder')
      $poolName      = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'ResourcePool')
      $guestId       = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'GuestId')
      $oscSpecName   = Get-StringOrNull (Get-RowValue -Row $vmRow -Name 'OSCustomizationSpec')

      $cpuCount      = Get-IntOrDefault (Get-RowValue -Row $vmRow -Name 'CpuCount') 2
      $memoryGb      = Get-IntOrDefault (Get-RowValue -Row $vmRow -Name 'MemoryGB') 4
      $diskGb        = Get-IntOrDefault (Get-RowValue -Row $vmRow -Name 'DiskGB') 40
      $cpuResMhz     = Get-IntOrDefault (Get-RowValue -Row $vmRow -Name 'CpuReservationMHz') 0
      $memResGb      = Get-IntOrDefault (Get-RowValue -Row $vmRow -Name 'MemoryReservationGB') 0

      $cluster      = if ($clusterName)   { Get-Cluster -Name $clusterName -ErrorAction Stop } else { $null }
      $datastore    = if ($datastoreName) { Get-Datastore -Name $datastoreName -ErrorAction Stop } else { $null }
      $folder       = if ($folderName)    { Get-Folder -Name $folderName -ErrorAction Stop } else { $null }
      $resourcePool = if ($poolName)      { Get-ResourcePool -Name $poolName -ErrorAction Stop } else { $null }
      $template     = Resolve-TemplateOrNull -TemplateName $templateName
      $oscSpec      = if ($oscSpecName)   { Get-OSCustomizationSpec -Name $oscSpecName -ErrorAction Stop } else { $null }

      if (-not $resourcePool -and $cluster) {
        $resourcePool = Get-ClusterRootResourcePool -Cluster $cluster
      }

      if (-not $template -and -not $datastore) {
        throw "Datastore is required when creating VM '$vmName' without a template."
      }

      $params = @{
        Name     = $vmName
        NumCPU   = $cpuCount
        MemoryMB = $memoryGb * 1024
      }

      if ($template) {
        $params['Template'] = $template
        if ($datastore) { $params['Datastore'] = $datastore }
      }
      else {
        $params['Datastore'] = $datastore
        $params['DiskGB'] = $diskGb
      }

      if ($folder)       { $params['Location'] = $folder }
      if ($resourcePool) { $params['ResourcePool'] = $resourcePool }
      if ($guestId)      { $params['GuestId'] = $guestId }
      if ($oscSpec)      { $params['OSCustomizationSpec'] = $oscSpec }
      if ($networkName)  { $params['NetworkName'] = $networkName }

      if ($PSCmdlet.ShouldProcess($vmName, 'Create VM')) {
        Write-Host "Creating VM '$vmName'..." -ForegroundColor Cyan
        $newVm = New-VM @params -ErrorAction Stop

        if (-not $template) {
          $primaryDisk = Get-HardDisk -VM $newVm | Select-Object -First 1
          if ($primaryDisk -and [int]$primaryDisk.CapacityGB -ne $diskGb) {
            Set-HardDisk -HardDisk $primaryDisk -CapacityGB $diskGb -Expand -Confirm:$false -ErrorAction Stop | Out-Null
          }
        }

        if ($cpuResMhz -gt 0 -or $memResGb -gt 0) {
          $resourceParams = @{}
          if ($cpuResMhz -gt 0) { $resourceParams['CpuReservationMhz'] = $cpuResMhz }
          if ($memResGb -gt 0)  { $resourceParams['MemReservationGB']  = $memResGb }
          Set-VMResourceConfiguration -VM $newVm @resourceParams -Confirm:$false -ErrorAction Stop | Out-Null
        }

        Write-Host "VM '$vmName' created successfully." -ForegroundColor Green
      }
    }
    catch {
      Write-Error -Message "Failed to create VM '$vmName': $_" -ErrorAction Continue
    }
  }
}
finally {
  if ($viServer) {
    Disconnect-VIServer -Server $viServer -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
  }
}
