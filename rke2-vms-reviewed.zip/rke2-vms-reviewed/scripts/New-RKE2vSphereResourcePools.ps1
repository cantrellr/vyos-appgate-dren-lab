<#
.SYNOPSIS
  Create the vSphere folder and resource-pool layout used by the RKE2 VM build workflow.

.DESCRIPTION
  Builds an idempotent vSphere inventory structure for RKE2 clusters. The script
  creates folders under a top-level VM folder and resource pools under a top-level
  resource pool. Existing folders and pools are reused instead of recreated.

  The default layout matches the repository's current cluster names:
    Kube.Sites/j64/j64manager
    Kube.Sites/j64/j64domain
    Kube.Sites/j52/j52domain
    Kube.Sites/r01/r01domain
    Kube.Sites/r01/r01preprod
    Kube.Sites/r01/r01gitops

  Resource reservations are intentionally expressed as data in $ClusterPools so
  the engineering decision is easy to review and change without hunting through
  imperative logic.

.PARAMETER VCenter
  vCenter FQDN or IP address.

.PARAMETER Credential
  PSCredential used to authenticate to vCenter.

.PARAMETER DatacenterName
  Target vSphere datacenter that contains the VM folder hierarchy.

.PARAMETER ClusterName
  Target vSphere cluster that contains the resource pool hierarchy.

.PARAMETER TopLevelName
  Name of the top-level VM folder and top-level resource pool. Defaults to Kube.Sites.

.PARAMETER AllowInvalidCertificate
  Ignore invalid vCenter TLS certificates for this PowerCLI session. Lab-only convenience.

.EXAMPLE
  $cred = Get-Credential
  .\New-RKE2vSphereResourcePools.ps1 -VCenter vcsa.dev.local `
                                     -Credential $cred `
                                     -DatacenterName Datacenter `
                                     -ClusterName R01_Infrastructure
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$VCenter,

  [Parameter(Mandatory = $true)]
  [ValidateNotNull()]
  [pscredential]$Credential,

  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$DatacenterName,

  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$ClusterName,

  [Parameter()]
  [ValidateNotNullOrEmpty()]
  [string]$TopLevelName = 'Kube.Sites',

  [Parameter()]
  [switch]$AllowInvalidCertificate
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Declarative source of truth for folders and resource-pool reservations.
# CpuReservationMHz and MemReservationMB are conservative lab defaults from the
# original design notes. Right-size these with real utilization data before
# treating them as production reservations.
$ClusterPools = @(
  [pscustomobject]@{ Site = 'j64'; Name = 'j64manager'; CpuReservationMHz = 28600; MemReservationMB = [math]::Round(114 * 1024) }
  [pscustomobject]@{ Site = 'j64'; Name = 'j64domain';  CpuReservationMHz = 23400; MemReservationMB = [math]::Round(94  * 1024) }
  [pscustomobject]@{ Site = 'j52'; Name = 'j52domain';  CpuReservationMHz = 23400; MemReservationMB = [math]::Round(94  * 1024) }
  [pscustomobject]@{ Site = 'r01'; Name = 'r01domain';  CpuReservationMHz = 23400; MemReservationMB = [math]::Round(94  * 1024) }
  [pscustomobject]@{ Site = 'r01'; Name = 'r01preprod'; CpuReservationMHz = 23400; MemReservationMB = [math]::Round(94  * 1024) }
  [pscustomobject]@{ Site = 'r01'; Name = 'r01gitops';  CpuReservationMHz = 28600; MemReservationMB = [math]::Round(114 * 1024) }
)

function Get-OrCreateFolder {
  <# Reuse an existing VM folder, or create it under the requested parent. #>
  param(
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)]$Location
  )

  $folder = Get-Folder -Name $Name -Location $Location -ErrorAction SilentlyContinue
  if ($folder) { return $folder }

  if ($PSCmdlet.ShouldProcess($Name, 'Create vSphere folder')) {
    return New-Folder -Name $Name -Location $Location -ErrorAction Stop
  }
}

function Get-OrCreateResourcePool {
  <# Reuse an existing resource pool, or create it with the desired reservation. #>
  param(
    [Parameter(Mandatory = $true)][string]$Name,
    [Parameter(Mandatory = $true)]$Location,
    [Parameter()][int]$CpuReservationMHz = 0,
    [Parameter()][int]$MemReservationMB = 0
  )

  $pool = Get-ResourcePool -Name $Name -Location $Location -ErrorAction SilentlyContinue
  if ($pool) { return $pool }

  $params = @{
    Name        = $Name
    Location    = $Location
    ErrorAction = 'Stop'
  }

  if ($CpuReservationMHz -gt 0) { $params['CpuReservationMHz'] = $CpuReservationMHz }
  if ($MemReservationMB -gt 0)  { $params['MemReservationMB']  = $MemReservationMB }

  if ($PSCmdlet.ShouldProcess($Name, 'Create vSphere resource pool')) {
    return New-ResourcePool @params
  }
}

Import-Module VMware.PowerCLI -ErrorAction Stop
if ($AllowInvalidCertificate) {
  Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
}

$viServer = Get-VIServer -Server $VCenter -ErrorAction SilentlyContinue
if (-not $viServer) {
  $viServer = Connect-VIServer -Server $VCenter -Credential $Credential -ErrorAction Stop
}

try {
  $datacenter = Get-Datacenter -Name $DatacenterName -ErrorAction Stop
  $cluster = Get-Cluster -Name $ClusterName -ErrorAction Stop

  $topFolder = Get-OrCreateFolder -Name $TopLevelName -Location $datacenter
  $topResourcePool = Get-ResourcePool -Name $TopLevelName -Location $cluster -ErrorAction SilentlyContinue

  if (-not $topResourcePool) {
    throw "Top-level Resource Pool '$TopLevelName' was not found in cluster '$ClusterName'. Create it intentionally first, then rerun this script."
  }

  $siteFolders = @{}
  $sitePools = @{}
  foreach ($siteName in @($ClusterPools.Site | Select-Object -Unique)) {
    $siteFolders[$siteName] = Get-OrCreateFolder -Name $siteName -Location $topFolder
    $sitePools[$siteName] = Get-OrCreateResourcePool -Name $siteName -Location $topResourcePool
  }

  foreach ($clusterPool in $ClusterPools) {
    $clusterFolder = Get-OrCreateFolder -Name $clusterPool.Name -Location $siteFolders[$clusterPool.Site]
    $null = $clusterFolder

    $null = Get-OrCreateResourcePool -Name $clusterPool.Name `
                                      -Location $sitePools[$clusterPool.Site] `
                                      -CpuReservationMHz $clusterPool.CpuReservationMHz `
                                      -MemReservationMB $clusterPool.MemReservationMB
  }

  Write-Host "RKE2 vSphere folder and resource-pool layout verified." -ForegroundColor Green
}
finally {
  if ($viServer) {
    Disconnect-VIServer -Server $viServer -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
  }
}
