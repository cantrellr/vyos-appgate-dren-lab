<#
.SYNOPSIS
  Clone VMware vSphere VMs from a CSV definition and optionally attach RKE2 boot/seed ISO files from a datastore path.

.DESCRIPTION
  CSV-driven VM cloning workflow for RKE2 nodes in vSphere. The script resolves
  vCenter inventory objects, clones from a template or source VM, applies CPU,
  memory, disk, network, and OS customization overrides, optionally attaches a
  per-node ISO from a datastore folder, optionally powers on each VM, and can
  create idempotent DRS anti-affinity rules for controller and worker placement.

  The boot ISO workflow supports two operating models:
    1. Global ISO location entered once at runtime:
       -BootIsoDatastore nfs_nvme -BootIsoFolder boot-isos
       The script defaults to an ISO filename of <VMName>.iso.

    2. Per-row CSV overrides:
       BootIsoDatastore, BootIsoFolder, IsoName, or BootIsoPath.
       BootIsoPath has highest precedence and should be the full vSphere path:
       [datastore-name] folder-name/vm-name.iso

  This keeps generated ISO artifacts out of Git while still making the clone
  process deterministic and repeatable.

.PARAMETER CsvPath
  Path to the clone CSV. Required.

.PARAMETER VCenter
  vCenter FQDN or IP address. Required.

.PARAMETER Credential
  PSCredential used to authenticate to vCenter. Required. Do not hard-code this
  value in scripts or checked-in files.

.PARAMETER BootIsoDatastore
  Datastore that contains the boot/seed ISO files. Used when the CSV row does
  not specify BootIsoDatastore or BootIsoPath.

.PARAMETER BootIsoFolder
  Datastore folder that contains the boot/seed ISO files. Examples: boot-isos,
  rke2/devlocal/boot-isos, ISO/RKE2. Used when the CSV row does not specify
  BootIsoFolder or BootIsoPath. Leave blank if ISOs are stored at datastore root.

.PARAMETER PromptForBootIsoLocation
  Prompt for BootIsoDatastore and BootIsoFolder when ISO attachment is enabled
  and global values were not provided. This is useful for interactive cloning.

.PARAMETER AttachBootIso
  Attach a per-VM ISO. The ISO filename defaults to <VMName>.iso unless the CSV
  row provides IsoName or BootIsoPath.

.PARAMETER ValidateBootIsoPath
  Attempt to validate that the datastore ISO path exists before attaching it.
  This relies on the PowerCLI vmstore provider and may be slower in large
  datastores. Attachment itself still fails fast if the ISO path is wrong.

.PARAMETER AllowInvalidCertificate
  Sets PowerCLI InvalidCertificateAction to Ignore for this session. This is
  convenient for labs, but should not be the production default.

.PARAMETER SkipExisting
  Skip existing VMs instead of treating them as failures.

.PARAMETER PowerOn
  Power on VMs after post-clone customization. Per-row PowerOn values override
  this global switch.

.PARAMETER SkipDrsRules
  Do not create/update DRS anti-affinity rules after cloning.

.PARAMETER DrsFolderNames
  VM folder names to inspect when creating DRS anti-affinity rules. Defaults to
  the known RKE2 cluster folders used in this repository.

.PARAMETER FailOnError
  Throw at the end when one or more rows fail. Without this switch, the script
  reports errors and continues, then exits normally after the summary.

.EXAMPLE
  $cred = Get-Credential
  .\Clone-VMsFromCSV.ps1 -CsvPath .\csv\clone-rkeimage-devlocal.csv `
                         -VCenter vcsa.dev.local `
                         -Credential $cred `
                         -AttachBootIso `
                         -BootIsoDatastore nfs_nvme `
                         -BootIsoFolder boot-isos `
                         -PowerOn

.EXAMPLE
  # Prompt once for the datastore and folder where boot ISO files are stored.
  $cred = Get-Credential
  .\Clone-VMsFromCSV.ps1 -CsvPath .\csv\clone-rkeimage-devlocal.csv `
                         -VCenter vcsa.dev.local `
                         -Credential $cred `
                         -AttachBootIso `
                         -PromptForBootIsoLocation `
                         -SkipExisting

.EXAMPLE
  # Safe dry run. WhatIf suppresses the clone and DRS rule changes.
  $cred = Get-Credential
  .\Clone-VMsFromCSV.ps1 -CsvPath .\csv\clone-rkeimage-devlocal.csv `
                         -VCenter vcsa.dev.local `
                         -Credential $cred `
                         -AttachBootIso `
                         -BootIsoDatastore nfs_nvme `
                         -BootIsoFolder boot-isos `
                         -WhatIf

.NOTES
  Recommended CSV columns:
    VMName, SourceVM, Cluster, VMHost, ResourcePool, Datastore, Folder, Network,
    CpuCount, MemoryGB, DiskGB, OSCustomizationSpec, PowerOn, BootIsoDatastore,
    BootIsoFolder, IsoName, BootIsoPath
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$CsvPath,

  [Parameter(Mandatory = $true)]
  [ValidateNotNullOrEmpty()]
  [string]$VCenter,

  [Parameter(Mandatory = $true)]
  [ValidateNotNull()]
  [pscredential]$Credential,

  [Parameter()]
  [string]$BootIsoDatastore,

  [Parameter()]
  [AllowEmptyString()]
  [string]$BootIsoFolder,

  [Parameter()]
  [switch]$PromptForBootIsoLocation,

  [Parameter()]
  [switch]$AttachBootIso,

  [Parameter()]
  [switch]$ValidateBootIsoPath,

  [Parameter()]
  [switch]$AllowInvalidCertificate,

  [Parameter()]
  [switch]$SkipExisting,

  [Parameter()]
  [switch]$PowerOn,

  [Parameter()]
  [switch]$SkipDrsRules,

  [Parameter()]
  [string[]]$DrsFolderNames = @(
    'j64manager',
    'j64domain',
    'j52domain',
    'r01domain',
    'r01preprod',
    'r01gitops'
  ),

  [Parameter()]
  [switch]$FailOnError
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Track outcome counts so CI/CD and operators get a usable end-of-run summary.
$script:CloneResults = [ordered]@{
  Created = 0
  Skipped = 0
  Failed  = 0
}

function Initialize-PowerCLI {
  <#
  .SYNOPSIS
    Load PowerCLI and apply session-scoped certificate behavior.
  .DESCRIPTION
    Invalid certificate bypass is intentionally opt-in. Lab vCenters often use
    private PKI, but production automation should validate the vCenter TLS chain
    instead of globally ignoring certificate failures.
  #>
  Import-Module VMware.PowerCLI -ErrorAction Stop

  if ($AllowInvalidCertificate) {
    Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction Ignore -Confirm:$false | Out-Null
  }
}

function Connect-VCenterIfNeeded {
  <#
  .SYNOPSIS
    Reuse an existing VIServer connection or establish a new one.
  #>
  $existingServer = Get-VIServer -Server $VCenter -ErrorAction SilentlyContinue
  if ($existingServer) {
    Write-Verbose "Using existing vCenter connection to '$VCenter'."
    return $existingServer
  }

  Write-Verbose "Connecting to vCenter '$VCenter'."
  return Connect-VIServer -Server $VCenter -Credential $Credential -ErrorAction Stop
}

function Get-StringOrNull {
  <#
  .SYNOPSIS
    Normalize a possibly blank CSV value into either a trimmed string or $null.
  #>
  param([AllowNull()][string]$Value)

  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }
  return $Value.Trim()
}

function Get-RowValue {
  <#
  .SYNOPSIS
    Read a CSV property only when the column exists.
  .DESCRIPTION
    Import-Csv creates note properties for columns. Referencing a missing column
    under StrictMode raises an exception, so this helper keeps optional columns
    optional and safe.
  #>
  param(
    [Parameter(Mandatory = $true)]
    [psobject]$Row,

    [Parameter(Mandatory = $true)]
    [string]$Name
  )

  if ($Row.PSObject.Properties.Name -contains $Name) {
    return $Row.$Name
  }

  return $null
}

function Get-IntOrNull {
  <#
  .SYNOPSIS
    Parse an optional integer CSV value and fail closed on invalid data.
  #>
  param([AllowNull()][string]$Value)

  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }

  $parsed = 0
  if ([int]::TryParse($Value, [ref]$parsed)) { return $parsed }

  throw "Value '$Value' is not a valid integer."
}

function Get-BoolOrNull {
  <#
  .SYNOPSIS
    Parse an optional boolean CSV value and fail closed on invalid data.
  #>
  param([AllowNull()][string]$Value)

  if ([string]::IsNullOrWhiteSpace($Value)) { return $null }

  $parsed = $false
  if ([bool]::TryParse($Value, [ref]$parsed)) { return $parsed }

  throw "Value '$Value' is not a valid boolean. Use TRUE or FALSE."
}

function Assert-RequiredCsvColumns {
  <#
  .SYNOPSIS
    Validate that the CSV contains the minimum columns needed to clone VMs.
  #>
  param(
    [Parameter(Mandatory = $true)]
    [object[]]$Rows,

    [Parameter(Mandatory = $true)]
    [string[]]$RequiredColumns
  )

  $actualColumns = @($Rows[0].PSObject.Properties.Name)
  $missingColumns = @($RequiredColumns | Where-Object { $actualColumns -notcontains $_ })

  if ($missingColumns.Count -gt 0) {
    throw "CSV '$CsvPath' is missing required column(s): $($missingColumns -join ', ')."
  }
}

function Resolve-SourceObject {
  <#
  .SYNOPSIS
    Resolve SourceVM as either a VM or a template.
  .DESCRIPTION
    The original script documentation said templates were supported, but the
    implementation only called Get-VM. This function makes that behavior real.
  #>
  param([Parameter(Mandatory = $true)][string]$SourceName)

  $sourceVm = Get-VM -Name $SourceName -ErrorAction SilentlyContinue
  if ($sourceVm) {
    return [pscustomobject]@{
      Type   = 'VM'
      Object = $sourceVm
    }
  }

  $sourceTemplate = Get-Template -Name $SourceName -ErrorAction SilentlyContinue
  if ($sourceTemplate) {
    return [pscustomobject]@{
      Type   = 'Template'
      Object = $sourceTemplate
    }
  }

  throw "SourceVM '$SourceName' was not found as a VM or template."
}

function Resolve-ResourcePool {
  <#
  .SYNOPSIS
    Resolve an explicit resource pool, or fall back to the cluster root pool.
  #>
  param(
    [AllowNull()][string]$PoolName,
    [AllowNull()]$Cluster
  )

  if ($PoolName) {
    return Get-ResourcePool -Name $PoolName -ErrorAction Stop
  }

  if ($Cluster -and $Cluster.ExtensionData -and $Cluster.ExtensionData.ResourcePool) {
    return Get-ResourcePool -Id $Cluster.ExtensionData.ResourcePool -ErrorAction Stop
  }

  return $null
}

function Resolve-TargetHost {
  <#
  .SYNOPSIS
    Resolve a specific ESXi host or choose the least CPU-utilized host in a cluster.
  .DESCRIPTION
    Host auto-placement ignores disconnected hosts and hosts in maintenance mode.
    This is not a replacement for DRS, but it gives deterministic initial
    placement when the CSV does not pin VMHost.
  #>
  param(
    [AllowNull()][string]$HostName,
    [AllowNull()]$Cluster
  )

  if ($HostName) {
    return Get-VMHost -Name $HostName -ErrorAction Stop
  }

  if (-not $Cluster) { return $null }

  $candidateHosts = @(Get-VMHost -Location $Cluster | Where-Object {
    $_.ConnectionState -eq 'Connected' -and -not $_.ExtensionData.Runtime.InMaintenanceMode
  })

  if ($candidateHosts.Count -eq 0) {
    throw "No connected non-maintenance ESXi hosts were found in cluster '$($Cluster.Name)'."
  }

  return $candidateHosts |
    Sort-Object -Property @{ Expression = { $_.ExtensionData.Summary.QuickStats.OverallCpuUsage }; Descending = $false } |
    Select-Object -First 1
}

function Format-DatastoreIsoPath {
  <#
  .SYNOPSIS
    Build the vSphere ISO path consumed by Set-CDDrive -IsoPath.
  .EXAMPLE
    Format-DatastoreIsoPath -DatastoreName nfs_nvme -Folder boot-isos -FileName j64manager-ctrl01.iso
    Returns: [nfs_nvme] boot-isos/j64manager-ctrl01.iso
  #>
  param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$DatastoreName,

    [Parameter()]
    [AllowEmptyString()]
    [string]$Folder,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$FileName
  )

  $normalizedFile = $FileName.Trim().TrimStart('/').TrimStart('\\')
  $normalizedFolder = (Get-StringOrNull $Folder)

  if ($normalizedFolder) {
    $normalizedFolder = $normalizedFolder.Trim('/').Trim('\\') -replace '\\', '/'
    return "[$DatastoreName] $normalizedFolder/$normalizedFile"
  }

  return "[$DatastoreName] $normalizedFile"
}

function Resolve-BootIsoPath {
  <#
  .SYNOPSIS
    Determine the ISO path for one VM using CSV overrides and global defaults.
  .DESCRIPTION
    Precedence:
      1. BootIsoPath CSV column: full vSphere datastore path.
      2. Row BootIsoDatastore/BootIsoFolder/IsoName values.
      3. Global -BootIsoDatastore/-BootIsoFolder and default <VMName>.iso.
  #>
  param(
    [Parameter(Mandatory = $true)]
    [psobject]$Row,

    [Parameter(Mandatory = $true)]
    [string]$VmName
  )

  $explicitPath = Get-StringOrNull (Get-RowValue -Row $Row -Name 'BootIsoPath')
  if ($explicitPath) { return $explicitPath }

  $rowIsoDatastore = Get-StringOrNull (Get-RowValue -Row $Row -Name 'BootIsoDatastore')
  $rowIsoFolder    = Get-StringOrNull (Get-RowValue -Row $Row -Name 'BootIsoFolder')
  $rowIsoName      = Get-StringOrNull (Get-RowValue -Row $Row -Name 'IsoName')

  $resolvedDatastore = if ($rowIsoDatastore) { $rowIsoDatastore } else { Get-StringOrNull $BootIsoDatastore }
  $resolvedFolder    = if ($rowIsoFolder)    { $rowIsoFolder    } else { Get-StringOrNull $BootIsoFolder }
  $resolvedIsoName   = if ($rowIsoName)      { $rowIsoName      } else { "$VmName.iso" }

  if (-not $resolvedDatastore) {
    throw "Boot ISO attachment requested for '$VmName', but no BootIsoDatastore was provided globally or in the CSV row."
  }

  return Format-DatastoreIsoPath -DatastoreName $resolvedDatastore -Folder $resolvedFolder -FileName $resolvedIsoName
}

function Test-DatastoreIsoPath {
  <#
  .SYNOPSIS
    Best-effort validation of a vSphere datastore ISO path.
  .DESCRIPTION
    PowerCLI datastore-provider paths vary by inventory layout, so this function
    intentionally returns $true when validation cannot be completed. Set-CDDrive
    remains the source of truth and will fail if the path is wrong.
  #>
  param([Parameter(Mandatory = $true)][string]$IsoPath)

  if ($IsoPath -notmatch '^\[(?<datastore>[^\]]+)\]\s*(?<path>.*)$') {
    throw "Boot ISO path '$IsoPath' is not a valid vSphere datastore path. Expected '[datastore] folder/file.iso'."
  }

  $datastoreName = $Matches.datastore
  $relativePath = $Matches.path.Trim().TrimStart('/')
  $datastore = Get-Datastore -Name $datastoreName -ErrorAction Stop

  try {
    $driveName = "iso$([guid]::NewGuid().ToString('N').Substring(0, 8))"
    $null = New-PSDrive -Name $driveName -PSProvider VimDatastore -Root '\' -Location $datastore -ErrorAction Stop
    $providerPath = "$driveName`:\$($relativePath -replace '/', '\')"
    return Test-Path -Path $providerPath -PathType Leaf
  }
  catch {
    Write-Verbose "Datastore path pre-validation skipped for '$IsoPath': $_"
    return $true
  }
  finally {
    if (Get-PSDrive -Name $driveName -ErrorAction SilentlyContinue) {
      Remove-PSDrive -Name $driveName -Force -ErrorAction SilentlyContinue
    }
  }
}

function Attach-BootIsoToVm {
  <#
  .SYNOPSIS
    Attach an ISO to the VM CD/DVD drive and set it to connect at boot.
  .DESCRIPTION
    The VM should still be powered off when this runs. The clone workflow calls
    this before Start-VM so the node sees the seed/boot ISO on first boot.
  #>
  param(
    [Parameter(Mandatory = $true)]
    $Vm,

    [Parameter(Mandatory = $true)]
    [string]$IsoPath
  )

  if ($ValidateBootIsoPath) {
    if (-not (Test-DatastoreIsoPath -IsoPath $IsoPath)) {
      throw "Boot ISO path '$IsoPath' does not exist."
    }
  }

  $cdDrive = Get-CDDrive -VM $Vm -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $cdDrive) {
    $cdDrive = New-CDDrive -VM $Vm -StartConnected:$true -ErrorAction Stop
  }

  Set-CDDrive -CD $cdDrive -IsoPath $IsoPath -StartConnected:$true -Confirm:$false -ErrorAction Stop | Out-Null
  Write-Host "Attached boot ISO '$IsoPath' to VM '$($Vm.Name)'." -ForegroundColor DarkCyan
}

function Set-PrimaryNetworkAdapter {
  <#
  .SYNOPSIS
    Move the first VM network adapter to the requested port group.
  .NOTES
    This intentionally changes only the first adapter. Multi-NIC node layouts
    should either be baked into the template or handled by an explicit future
    CSV schema for NIC1/NIC2/NIC3 mappings.
  #>
  param(
    [Parameter(Mandatory = $true)]
    $Vm,

    [Parameter(Mandatory = $true)]
    [string]$NetworkName
  )

  $adapter = Get-NetworkAdapter -VM $Vm | Select-Object -First 1
  if (-not $adapter) {
    throw "VM '$($Vm.Name)' does not have a network adapter to reconfigure."
  }

  if ($adapter.NetworkName -eq $NetworkName) {
    return
  }

  Set-NetworkAdapter -NetworkAdapter $adapter -NetworkName $NetworkName -Confirm:$false -ErrorAction Stop | Out-Null
}

function Resize-PrimaryDiskIfNeeded {
  <#
  .SYNOPSIS
    Expand the first hard disk when the requested size is larger than current.
  .DESCRIPTION
    vSphere cannot safely shrink disks with this workflow, so smaller requested
    values are treated as warnings instead of destructive changes.
  #>
  param(
    [Parameter(Mandatory = $true)]
    $Vm,

    [AllowNull()]
    [Nullable[int]]$RequestedDiskGB
  )

  if (-not $RequestedDiskGB -or $RequestedDiskGB -le 0) { return }

  $primaryDisk = Get-HardDisk -VM $Vm | Select-Object -First 1
  if (-not $primaryDisk) {
    throw "VM '$($Vm.Name)' does not have a primary disk."
  }

  $currentGb = [int][math]::Round($primaryDisk.CapacityGB)
  if ($currentGb -lt $RequestedDiskGB) {
    Set-HardDisk -HardDisk $primaryDisk -CapacityGB $RequestedDiskGB -Expand -Confirm:$false -ErrorAction Stop | Out-Null
    return
  }

  if ($currentGb -gt $RequestedDiskGB) {
    Write-Warning "VM '$($Vm.Name)' primary disk is $currentGb GB; requested $RequestedDiskGB GB. Shrink skipped."
  }
}

function New-CloneFromRow {
  <#
  .SYNOPSIS
    Clone and configure one VM from one CSV row.
  #>
  param([Parameter(Mandatory = $true)][psobject]$Row)

  $vmName = Get-StringOrNull (Get-RowValue -Row $Row -Name 'VMName')
  if (-not $vmName) {
    Write-Warning 'Skipping row with blank VMName.'
    $script:CloneResults.Skipped++
    return
  }

  if ($SkipExisting -and (Get-VM -Name $vmName -ErrorAction SilentlyContinue)) {
    Write-Host "VM '$vmName' already exists; skipping." -ForegroundColor Yellow
    $script:CloneResults.Skipped++
    return
  }

  try {
    $sourceName = Get-StringOrNull (Get-RowValue -Row $Row -Name 'SourceVM')
    if (-not $sourceName) { throw "SourceVM column is required for '$vmName'." }

    $clusterName   = Get-StringOrNull (Get-RowValue -Row $Row -Name 'Cluster')
    $hostName      = Get-StringOrNull (Get-RowValue -Row $Row -Name 'VMHost')
    $poolName      = Get-StringOrNull (Get-RowValue -Row $Row -Name 'ResourcePool')
    $datastoreName = Get-StringOrNull (Get-RowValue -Row $Row -Name 'Datastore')
    $folderName    = Get-StringOrNull (Get-RowValue -Row $Row -Name 'Folder')
    $networkName   = Get-StringOrNull (Get-RowValue -Row $Row -Name 'Network')
    $oscSpecName   = Get-StringOrNull (Get-RowValue -Row $Row -Name 'OSCustomizationSpec')

    $cpuCount   = Get-IntOrNull  (Get-RowValue -Row $Row -Name 'CpuCount')
    $memoryGb   = Get-IntOrNull  (Get-RowValue -Row $Row -Name 'MemoryGB')
    $diskGb     = Get-IntOrNull  (Get-RowValue -Row $Row -Name 'DiskGB')
    $powerOnRow = Get-BoolOrNull (Get-RowValue -Row $Row -Name 'PowerOn')

    $source     = Resolve-SourceObject -SourceName $sourceName
    $cluster    = if ($clusterName)   { Get-Cluster -Name $clusterName -ErrorAction Stop } else { $null }
    $vmHost     = Resolve-TargetHost -HostName $hostName -Cluster $cluster
    $datastore  = if ($datastoreName) { Get-Datastore -Name $datastoreName -ErrorAction Stop } else { $null }
    $folder     = if ($folderName)    { Get-Folder -Name $folderName -ErrorAction Stop } else { $null }
    $oscSpec    = if ($oscSpecName)   { Get-OSCustomizationSpec -Name $oscSpecName -ErrorAction Stop } else { $null }
    $pool       = Resolve-ResourcePool -PoolName $poolName -Cluster $cluster

    $cloneParams = @{
      Name        = $vmName
      ErrorAction = 'Stop'
    }

    if ($source.Type -eq 'Template') { $cloneParams['Template'] = $source.Object }
    else                            { $cloneParams['VM']       = $source.Object }

    if ($vmHost)    { $cloneParams['VMHost'] = $vmHost }
    if ($pool)      { $cloneParams['ResourcePool'] = $pool }
    if ($datastore) { $cloneParams['Datastore'] = $datastore }
    if ($folder)    { $cloneParams['Location'] = $folder }
    if ($oscSpec)   { $cloneParams['OSCustomizationSpec'] = $oscSpec }

    if ($PSCmdlet.ShouldProcess($vmName, "Clone from $($source.Type) '$sourceName'")) {
      Write-Host "Cloning VM '$vmName' from '$sourceName'..." -ForegroundColor Cyan
      $newVm = New-VM @cloneParams

      if ($cpuCount -and $cpuCount -ne $newVm.NumCPU) {
        Set-VM -VM $newVm -NumCpu $cpuCount -Confirm:$false -ErrorAction Stop | Out-Null
      }

      if ($memoryGb -and $memoryGb -ne [math]::Ceiling($newVm.MemoryMB / 1024)) {
        Set-VM -VM $newVm -MemoryGB $memoryGb -Confirm:$false -ErrorAction Stop | Out-Null
      }

      Resize-PrimaryDiskIfNeeded -Vm $newVm -RequestedDiskGB $diskGb

      if ($networkName) {
        Set-PrimaryNetworkAdapter -Vm $newVm -NetworkName $networkName
      }

      if ($AttachBootIso) {
        $isoPath = Resolve-BootIsoPath -Row $Row -VmName $vmName
        Attach-BootIsoToVm -Vm $newVm -IsoPath $isoPath
      }

      $finalPowerOn = if ($null -ne $powerOnRow) { $powerOnRow } else { [bool]$PowerOn }
      if ($finalPowerOn) {
        Start-VM -VM $newVm -Confirm:$false -ErrorAction Stop | Out-Null
        Write-Host "VM '$vmName' powered on." -ForegroundColor Yellow
      }

      Write-Host "VM '$vmName' cloned successfully." -ForegroundColor Green
      $script:CloneResults.Created++
    }
  }
  catch {
    $script:CloneResults.Failed++
    Write-Error -Message "Failed to clone VM '$vmName': $_" -ErrorAction Continue
  }
}

function New-DrsAntiAffinityRuleIfMissing {
  <#
  .SYNOPSIS
    Create an idempotent VM anti-affinity rule when enough VMs exist.
  #>
  param(
    [Parameter(Mandatory = $true)]
    [string]$RuleName,

    [Parameter()]
    [AllowEmptyCollection()]
    [object[]]$VMs = @(),

    [Parameter(Mandatory = $true)]
    $Cluster
  )

  if ($VMs.Count -lt 2) {
    Write-Verbose "Skipping DRS rule '$RuleName'; at least two VMs are required."
    return
  }

  $existingRule = Get-DrsRule -Cluster $Cluster -Name $RuleName -ErrorAction SilentlyContinue
  if ($existingRule) {
    Write-Verbose "DRS rule '$RuleName' already exists; leaving it unchanged."
    return
  }

  if ($PSCmdlet.ShouldProcess($RuleName, 'Create DRS anti-affinity rule')) {
    New-DrsRule -Name $RuleName -VM $VMs -Cluster $Cluster -KeepTogether:$false -Enabled:$true -ErrorAction Stop | Out-Null
    Write-Host "Created DRS anti-affinity rule '$RuleName'." -ForegroundColor Green
  }
}

function New-DrsRulesForFolder {
  <#
  .SYNOPSIS
    Create controller and worker DRS separation rules for a VM folder.
  .DESCRIPTION
    VMs are classified by name. Controllers match 'ctrl'; workers match 'work'.
    This preserves the current naming convention without requiring another CSV.
  #>
  param([Parameter(Mandatory = $true)][string]$FolderName)

  $folder = Get-Folder -Name $FolderName -ErrorAction SilentlyContinue
  if (-not $folder) {
    Write-Verbose "Folder '$FolderName' was not found. DRS rule creation skipped."
    return
  }

  $ctrlVMs = @(Get-VM -Location $folder -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'ctrl' })
  $workVMs = @(Get-VM -Location $folder -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'work' })

  $allRuleVMs = @($ctrlVMs + $workVMs)
  if ($allRuleVMs.Count -lt 2) {
    Write-Verbose "Folder '$FolderName' does not contain enough controller/worker VMs for DRS rules."
    return
  }

  $cluster = $allRuleVMs[0].VMHost.Parent
  New-DrsAntiAffinityRuleIfMissing -RuleName "${FolderName}_Controllers" -VMs $ctrlVMs -Cluster $cluster
  New-DrsAntiAffinityRuleIfMissing -RuleName "${FolderName}_Workers"     -VMs $workVMs -Cluster $cluster
}

# --- Main execution -----------------------------------------------------------
if (-not (Test-Path -Path $CsvPath -PathType Leaf)) {
  throw "CSV file not found at '$CsvPath'."
}

if ($AttachBootIso -and $PromptForBootIsoLocation) {
  if (-not (Get-StringOrNull $BootIsoDatastore)) {
    $BootIsoDatastore = Read-Host 'Enter datastore containing boot ISO files, for example nfs_nvme'
  }

  if ($null -eq $BootIsoFolder) {
    $BootIsoFolder = Read-Host 'Enter datastore folder containing boot ISO files, for example boot-isos. Leave blank for datastore root'
  }
}

Initialize-PowerCLI
$viServer = Connect-VCenterIfNeeded

try {
  $vmDefinitions = @(Import-Csv -Path $CsvPath)
  if ($vmDefinitions.Count -eq 0) {
    throw "CSV '$CsvPath' is empty or unreadable."
  }

  Assert-RequiredCsvColumns -Rows $vmDefinitions -RequiredColumns @('VMName', 'SourceVM')

  foreach ($vmRow in $vmDefinitions) {
    New-CloneFromRow -Row $vmRow
  }

  if (-not $SkipDrsRules) {
    foreach ($folderName in $DrsFolderNames) {
      New-DrsRulesForFolder -FolderName $folderName
    }
  }
}
finally {
  if ($viServer) {
    Disconnect-VIServer -Server $viServer -Confirm:$false -ErrorAction SilentlyContinue | Out-Null
  }
}

Write-Host "Clone summary: Created=$($script:CloneResults.Created), Skipped=$($script:CloneResults.Skipped), Failed=$($script:CloneResults.Failed)." -ForegroundColor Cyan

if ($FailOnError -and $script:CloneResults.Failed -gt 0) {
  throw "$($script:CloneResults.Failed) VM clone operation(s) failed."
}
