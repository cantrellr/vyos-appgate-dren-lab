<#
.SYNOPSIS
  Backward-compatible wrapper for the corrected resource-pool script name.
.DESCRIPTION
  The original file name contained a typo: vshpere. Keep this wrapper for older
  runbooks, but use New-RKE2vSphereResourcePools.ps1 going forward.
#>
Write-Warning "This wrapper is deprecated. Use .\New-RKE2vSphereResourcePools.ps1 instead."
& "$PSScriptRoot\New-RKE2vSphereResourcePools.ps1" @args
