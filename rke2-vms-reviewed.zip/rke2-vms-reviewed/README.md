# RKE2 vSphere VM Automation

This repository contains PowerCLI automation and configuration artifacts for building RKE2 virtual machines on VMware vSphere. The primary workflow is CSV-driven cloning from an RKE2 image/template, optional per-node boot/seed ISO attachment, VM resource customization, network placement, and optional DRS anti-affinity rule creation.

## What this repo does

- Clones RKE2 nodes from a vSphere template or source VM.
- Uses CSV files as the deployment contract for VM name, source image, cluster, host, resource pool, datastore, folder, network, CPU, memory, disk, and power state.
- Supports boot/seed ISO attachment from a vSphere datastore path.
- Supports interactive entry of the ISO datastore and datastore folder.
- Creates/reuses vSphere folder and resource-pool structures for the RKE2 cluster layout.
- Provides documentation for operations, security, CSV schema, and improvement backlog.

## Repository layout

```text
.
├── configs/                         # RKE2 node/image configuration examples
├── csv/                             # VM clone/create CSV inputs
├── docs/                            # Operator and engineering documentation
├── scripts/
│   ├── Clone-VMsFromCSV.ps1          # Main RKE2 clone workflow
│   ├── New-VMsFromCSV.ps1            # Generic VM creation workflow
│   ├── New-RKE2vSphereResourcePools.ps1
│   └── rke2-vshpere-resource-pools.ps1 # Deprecated typo wrapper
├── README.md
├── SECURITY.md
└── RKE2-vSphere-Resource-Pools.md
```

## Main workflow

Use `scripts/Clone-VMsFromCSV.ps1` for RKE2 node cloning.

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos `
  -PowerOn
```

For an interactive run where the operator enters the ISO datastore and datastore folder:

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -PromptForBootIsoLocation `
  -SkipExisting
```

The script builds the vSphere ISO path like this:

```text
[<BootIsoDatastore>] <BootIsoFolder>/<VMName>.iso
```

Example:

```text
[nfs_nvme] boot-isos/j64manager-ctrl01.iso
```

## Boot ISO path precedence

When `-AttachBootIso` is used, ISO path resolution follows this order:

1. `BootIsoPath` CSV column, full vSphere path. Example: `[nfs_nvme] boot-isos/j64manager-ctrl01.iso`.
2. CSV row values: `BootIsoDatastore`, `BootIsoFolder`, and `IsoName`.
3. Global parameters: `-BootIsoDatastore`, `-BootIsoFolder`, and default filename `<VMName>.iso`.

This gives you both fleet-level defaults and per-VM override capability without hard-coding datastore locations in the script.

## Safe dry run

Use `-WhatIf` before touching vSphere inventory.

```powershell
$cred = Get-Credential

.\scripts\Clone-VMsFromCSV.ps1 `
  -CsvPath .\csv\clone-rkeimage-devlocal.csv `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -AttachBootIso `
  -BootIsoDatastore nfs_nvme `
  -BootIsoFolder boot-isos `
  -WhatIf
```

## Resource-pool and folder setup

Use the corrected script name going forward:

```powershell
$cred = Get-Credential

.\scripts\New-RKE2vSphereResourcePools.ps1 `
  -VCenter vcsa.dev.local `
  -Credential $cred `
  -DatacenterName Datacenter `
  -ClusterName R01_Infrastructure
```

The older `scripts/rke2-vshpere-resource-pools.ps1` file is retained only as a compatibility wrapper.

## Security posture

This reviewed package intentionally excludes generated ISO files and private key material. Generated boot ISOs and CA private keys should be staged through controlled operational channels, not committed to source control.

See [SECURITY.md](SECURITY.md) for required handling guidance.

## Start here

- [docs/OPERATIONS-RUNBOOK.md](docs/OPERATIONS-RUNBOOK.md) — operator execution flow.
- [docs/CSV-SCHEMA.md](docs/CSV-SCHEMA.md) — CSV columns and examples.
- [docs/BOOT-ISO-DATASTORE.md](docs/BOOT-ISO-DATASTORE.md) — ISO datastore attachment model.
- [docs/RECOMMENDATIONS.md](docs/RECOMMENDATIONS.md) — findings, best practices, and improvement backlog.
