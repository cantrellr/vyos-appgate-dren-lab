# Post-Prometheus Metrics Integration Refactor — 2026-05-18

## Purpose
This package refactors the deployment order so that platform applications are installed **before** the Prometheus Operator CRDs exist, without creating `ServiceMonitor`/`PodMonitor` resources too early.

The new deployment model is:

1. Patch CoreDNS
2. Install cert-manager
3. Install MetalLB
4. Install Contour/Envoy ingresses
5. Install kube-prometheus-stack / Grafana
6. Run the new post-monitoring enablement script

## Why this is the right pattern
Several Helm charts can create Prometheus Operator CRs such as `ServiceMonitor`. Those CRs require the Prometheus Operator CRDs to exist first. Installing core platform charts with monitor CR creation enabled before kube-prometheus-stack is installed can lead to failed installs or fragile ordering.

This package keeps metrics endpoints available where useful, but delays creation of Prometheus Operator monitoring objects until after monitoring is present.

## New script

```bash
build/install/monitoring/03-enable-platform-metrics-after-prometheus.sh
```

Usage:

```bash
./build/install/monitoring/03-enable-platform-metrics-after-prometheus.sh j64 manager
./build/install/monitoring/03-enable-platform-metrics-after-prometheus.sh j64 domain
./build/install/monitoring/03-enable-platform-metrics-after-prometheus.sh j52 domain
./build/install/monitoring/03-enable-platform-metrics-after-prometheus.sh r01 domain
```

The script:

- Validates the monitoring namespace and ServiceMonitor CRD exist
- Validates the Prometheus Helm release exists
- Validates that the earlier CoreDNS patch exposes metrics on `0.0.0.0:9153`
- Enables cert-manager `ServiceMonitor` integration via Helm upgrade
- Enables MetalLB `ServiceMonitor` integration via Helm upgrade
- Discovers the Prometheus ServiceAccount for MetalLB RBAC binding
- Enables Contour/Envoy `ServiceMonitor` integration for installed ingress releases
- Lists relevant ServiceMonitor objects at the end

## Values files changed for sequencing

### cert-manager
`build/sites/all/values/bitnami-cert-manager-values-v1514-v1.yaml`

- `metrics.enabled` remains `true`
- `metrics.serviceMonitor.enabled` changed from `true` to `false`

This preserves metrics endpoint behavior while preventing premature ServiceMonitor creation.

### MetalLB
`build/sites/all/values/metallb-metallb-values-v0152-v1.yaml`

Added explicit disabled monitor CR defaults:

```yaml
prometheus:
  podMonitor:
    enabled: false
  serviceMonitor:
    enabled: false
```

The post-monitoring script enables ServiceMonitor mode and supplies the Prometheus namespace/service account needed for RBAC.

### Contour / Envoy ingresses
All repo ingress values files now set:

```yaml
metrics:
  serviceMonitor:
    enabled: false
```

The post-monitoring script re-enables these objects after kube-prometheus-stack exists.

Files updated:

- `build/sites/j52/domain-cluster/values/ingress-j52domain-values-v5.yaml`
- `build/sites/j52/domain-cluster/values/ingress-j52domain-seg1-values-v5.yaml`
- `build/sites/j64/domain-cluster/values/ingress-j64domain-values-v5.yaml`
- `build/sites/j64/domain-cluster/values/ingress-j64domain-seg1-values-v5.yaml`
- `build/sites/j64/manager-cluster/values/ingress-j64manager-values-v5.yaml`
- `build/sites/j64/manager-cluster/values/ingress-j64manager-seg1-values-v5.yaml`
- `build/sites/r01/domain-cluster/values/ingress-r01domain-values-v5.yaml`
- `build/sites/r01/domain-cluster/values/ingress-r01domain-seg1-values-v5.yaml`
- `build/sites/r01/preprod-cluster/values/devlocal-ingress-values-v5.yaml`
- `build/sites/r01/preprod-cluster/values/hypermute-ingress-values-v5.yaml`
- `build/sites/r01/preprod-cluster/values/onprem-ingress-values-v5.yaml`

## CoreDNS handling
No CoreDNS values file exists in this repository. The existing CoreDNS patch is intentionally retained because it exposes the metrics listener before Prometheus is installed. kube-prometheus-stack is responsible for creating the CoreDNS scrape objects when monitoring is deployed.

## Included prior fixes
This package is cumulative. It also carries forward the fixes from the earlier monitoring/Rocket.Chat remediation pack:

- j64manager monitoring NetworkPolicy corrected to allow Contour-to-Prometheus receiver traffic
- j64manager Prometheus resource requests corrected
- Istio `meshNetworks` east-west gateway addresses corrected
- MongoDB NetworkPolicy enhanced for east-west gateway VIP egress on TCP/15443

## Validation status
- Bash syntax for the new script was validated with `bash -n`
- File modifications were diffed against the original uploaded repository
- Helm rendering was not executed in the analysis container because `helm` is not installed there; the script and values are aligned to the exact chart paths and patterns already used by the repository's existing install scripts
