#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/_lib/common.sh"
require_cmd python3

python3 - "${ROOT_DIR}" <<'PY2'
from pathlib import Path
import ipaddress
import re
import sys
try:
    import yaml
except ImportError:
    raise SystemExit('PyYAML is required for Fleet layout validation')

root = Path(sys.argv[1])
bundle_root = root / 'fleet' / 'bundles'
fleet_files = sorted(bundle_root.glob('*/fleet.yaml'))
expected = {
    'cert-manager', 'cert-manager-config', 'metallb', 'metallb-config', 'contour-segment1',
    'trident-operator', 'trident-config', 'trident-protect',
    'oppostgres-operator', 'oppostgres', 'oppostgres-replica',
    'opkeycloak-operator', 'opkeycloak', 'opkeycloak-secondary',
    'istio-base', 'istio-cni', 'istiod', 'istio-eastwestgateway',
    'kiali-operator', 'kiali', 'kube-state-metrics', 'elastic-agent',
}
if len(fleet_files) != len(expected):
    raise SystemExit(f'Expected {len(expected)} Fleet bundles; found {len(fleet_files)}')

bundle_labels = set()
bundle_names = set()
parsed = {}
for path in list((root/'fleet').rglob('*.yaml')) + list((root/'fleet').rglob('*.yml')):
    try:
        list(yaml.safe_load_all(path.read_text(encoding='utf-8')))
    except Exception as exc:
        raise SystemExit(f'Invalid YAML {path.relative_to(root)}: {exc}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    parsed[path.parent.name] = data
    name = data.get('name')
    label = (data.get('labels') or {}).get('kmm.dev/bundle')
    if not name or not label:
        raise SystemExit(f'{path.relative_to(root)}: missing bundle name or kmm.dev/bundle label')
    if 'overrideTargets' in data:
        raise SystemExit(f'{path.relative_to(root)}: overrideTargets is not a Fleet field; use targetCustomizations')
    if '${ get .ClusterLabels' in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{path.relative_to(root)}: cluster-label templates belong in values/manifests, not fleet.yaml fields')
    bundle_names.add(name)
    bundle_labels.add(label)
    helm = data.get('helm') or {}
    repo = helm.get('repo')
    if repo and not str(repo).startswith('oci://kubeharbor.dev.kube/k8mm-charts/'):
        raise SystemExit(f'{path.relative_to(root)}: unapproved Helm repository {repo}')

if bundle_names != expected:
    raise SystemExit(f'Fleet bundle name mismatch. Missing={sorted(expected-bundle_names)} extra={sorted(bundle_names-expected)}')

for path in fleet_files:
    data = yaml.safe_load(path.read_text(encoding='utf-8')) or {}
    for dep in data.get('dependsOn') or []:
        label = (((dep or {}).get('selector') or {}).get('matchLabels') or {}).get('kmm.dev/bundle')
        if not label or label not in bundle_labels:
            raise SystemExit(f'{path.relative_to(root)}: unresolved dependsOn label {label!r}')

def has_target(directory, key, value):
    custom = parsed[directory].get('targetCustomizations') or []
    return any((((x.get('clusterSelector') or {}).get('matchLabels') or {}).get(key) == value) for x in custom)

def has_deny(directory):
    custom = parsed[directory].get('targetCustomizations') or []
    return any(x.get('clusterSelector') == {} and x.get('doNotDeploy') is True for x in custom)

for directory in ('50-cnpg-operator', '52-keycloak-operator'):
    if not (has_target(directory, 'kmm.dev/identity-site', 'true') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: dual-site operator guard is incomplete')
for directory in ('51-postgresql-ha', '53-keycloak'):
    if not (has_target(directory, 'kmm.dev/identity', 'primary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: primary identity guard is incomplete')
for directory in ('51-postgresql-replica', '54-keycloak-secondary'):
    if not (has_target(directory, 'kmm.dev/identity', 'secondary') and has_deny(directory)):
        raise SystemExit(f'{directory}/fleet.yaml: secondary identity guard is incomplete')

primary_values = (bundle_root/'51-postgresql-ha'/'values.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-hibernation', 'dataDurability: required', 'failoverQuorum: true'):
    if token not in primary_values:
        raise SystemExit(f'Primary PostgreSQL values missing HA token: {token}')
secondary_cluster = (bundle_root/'51-postgresql-replica'/'cluster.yaml').read_text(encoding='utf-8')
for token in ('kmm.dev/postgres-replica-enabled', 'opkeycloak-postgres-j64.dev.kube', 'pg_basebackup:', 'streaming_replica'):
    if token not in secondary_cluster:
        raise SystemExit(f'Secondary PostgreSQL manifest missing token: {token}')
for path in (bundle_root/'53-keycloak'/'keycloak.yaml', bundle_root/'54-keycloak-secondary'/'keycloak.yaml'):
    if 'kmm.dev/keycloak-instances' not in path.read_text(encoding='utf-8'):
        raise SystemExit(f'{path.relative_to(root)} does not derive instances from the Fleet cluster label')

cni_values = (bundle_root/'61-istio-cni'/'values.yaml').read_text(encoding='utf-8')
for token in ('/opt/cni/bin', '/etc/cni/net.d'):
    if token not in cni_values:
        raise SystemExit(f'Istio CNI values missing RKE2 path: {token}')
istiod_values = (bundle_root/'62-istiod'/'values.yaml').read_text(encoding='utf-8')
if 'pilot:' not in istiod_values or 'enabled: true' not in istiod_values:
    raise SystemExit('Istiod values do not enable pilot.cni')
for address in ('1.0.0.210', '1.0.0.220', '1.0.0.230', '1.0.0.240'):
    if address not in istiod_values:
        raise SystemExit(f'Istiod meshNetworks missing Segment1 east-west address: {address}')

pool_manifest = (bundle_root/'21-metallb-config'/'address-pools.yaml').read_text(encoding='utf-8')
if pool_manifest.count('kind: IPAddressPool') != 1 or 'name: segment1' not in pool_manifest:
    raise SystemExit('MetalLB must expose exactly one Segment1 IPAddressPool')
if 'name: regular' in pool_manifest or 'metallb-' + 'regular-pool' in pool_manifest:
    raise SystemExit('A non-Segment1 MetalLB pool remains in the Fleet bundle')

segment_values = (bundle_root/'31-contour-segment1'/'values.yaml').read_text(encoding='utf-8')
for token in ('manageCRDs: true', 'name: segment1', 'default: true', 'kmm.dev/segment1-lb-ip'):
    if token not in segment_values:
        raise SystemExit(f'Segment1 Contour values missing single-ingress token: {token}')
if not (bundle_root/'31-contour-segment1'/'backend-egress.yaml').is_file():
    raise SystemExit('Segment1 backend egress policy is missing')

monitoring_values = (bundle_root/'71-elastic-agent'/'values.yaml').read_text(encoding='utf-8')
for token in (
    'kubeharbor.dev.kube/elastic-agent/elastic-agent',
    'elastic-agent-fleet-enrollment',
    'devlocal-ca-bundle-secret',
    'preset: perNode',
    'kubernetes_leaderelection:',
    'enabled: true',
    'kube-state-metrics:',
):
    if token not in monitoring_values:
        raise SystemExit(f'Elastic Agent values missing token: {token}')
ksm_values = (bundle_root/'70-kube-state-metrics'/'values.yaml').read_text(encoding='utf-8')
for token in ('kubeharbor.dev.kube', 'kube-state-metrics/kube-state-metrics', 'tag: v2.16.0'):
    if token not in ksm_values:
        raise SystemExit(f'kube-state-metrics values missing token: {token}')
if (bundle_root/'00-namespaces').exists():
    raise SystemExit('fleet/bundles/00-namespaces must not exist; runtime preflight owns namespace lifecycle and PSA labels')

seed_script = (root/'scripts'/'management'/'fleet'/'01-seed-runtime-secrets.sh').read_text(encoding='utf-8')
for token in (
    'cert-manager segment1 metallb-system trident-system trident-protect istio-system elastic-agent-system elastic-monitoring',
    'for namespace in oppostgres opkeycloak',
    'k8mm.dev/monitoring-agent=true',
):
    if token not in seed_script:
        raise SystemExit(f'Runtime namespace provisioning is missing required token: {token}')

anchor_bundles = {
    '10-cert-manager': 'cert-manager',
    '11-cert-manager-config': 'cert-manager-config',
    '20-metallb': 'metallb',
    '21-metallb-config': 'metallb-config',
    '40-trident-operator': 'trident-operator',
    '42-trident-protect': 'trident-protect',
    '50-cnpg-operator': 'cnpg-operator',
    '60-istio-base': 'istio-base',
    '61-istio-cni': 'istio-cni',
    '62-istiod': 'istiod',
    '64-kiali-operator': 'kiali-operator',
    '70-kube-state-metrics': 'kube-state-metrics',
}
anchor_namespaces = {
    '10-cert-manager': 'cert-manager',
    '11-cert-manager-config': 'cert-manager',
    '20-metallb': 'metallb-system',
    '21-metallb-config': 'metallb-system',
    '40-trident-operator': 'trident-system',
    '42-trident-protect': 'trident-protect',
    '50-cnpg-operator': 'oppostgres',
    '60-istio-base': 'istio-system',
    '61-istio-cni': 'istio-system',
    '62-istiod': 'istio-system',
    '64-kiali-operator': 'istio-system',
    '70-kube-state-metrics': 'elastic-monitoring',
}
for directory, label in anchor_bundles.items():
    anchor = bundle_root/directory/'bundle-anchor.yaml'
    if not anchor.is_file():
        raise SystemExit(f'{anchor.relative_to(root)} is required so Fleet discovers the external-Helm bundle')
    anchor_text = anchor.read_text(encoding='utf-8')
    for token in (
        f'name: kmm-fleet-anchor-{label}',
        'app.kubernetes.io/managed-by: Fleet',
        f'kmm.dev/fleet-bundle-anchor: {label}',
    ):
        if token not in anchor_text:
            raise SystemExit(f'{anchor.relative_to(root)} is missing token: {token}')
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    for token in (
        'diff:',
        'comparePatches:',
        f'name: kmm-fleet-anchor-{label}',
        f'namespace: {anchor_namespaces[directory]}',
        'path: /metadata/labels/app.kubernetes.io~1managed-by',
    ):
        if token not in fleet_text:
            raise SystemExit(f'{directory}/fleet.yaml is missing anchor drift token: {token}')
for path in (
    bundle_root/'31-contour-segment1'/'monitoring-networkpolicy.yaml',
    bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-ha'/'monitoring-networkpolicy.yaml',
    bundle_root/'51-postgresql-replica'/'monitoring-networkpolicy.yaml',
):
    text = path.read_text(encoding='utf-8')
    if 'k8mm.dev/monitoring-agent' not in text:
        raise SystemExit(f'{path.relative_to(root)} lacks the monitoring namespace selector')

monitoring_source_pairs = (
    (root/'yaml'/'monitoring'/'elastic-agent-per-node-9.4.2-values.yaml', bundle_root/'71-elastic-agent'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-6.1.0-values.yaml', bundle_root/'70-kube-state-metrics'/'values.yaml'),
    (root/'yaml'/'monitoring'/'kube-state-metrics-agent-alias.yaml', bundle_root/'71-elastic-agent'/'kube-state-metrics-alias.yaml'),
    (root/'yaml'/'monitoring'/'segment1-elastic-agent-networkpolicy.yaml', bundle_root/'31-contour-segment1'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'opkeycloak-ingress-from-monitoring.yaml', bundle_root/'52-keycloak-operator'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-ha'/'monitoring-networkpolicy.yaml'),
    (root/'yaml'/'monitoring'/'oppostgres-ingress-from-monitoring.yaml', bundle_root/'51-postgresql-replica'/'monitoring-networkpolicy.yaml'),
)
for source, managed in monitoring_source_pairs:
    if source.read_text(encoding='utf-8') != managed.read_text(encoding='utf-8'):
        raise SystemExit(f'Monitoring source drift: {source.relative_to(root)} != {managed.relative_to(root)}')

failover_script = (root/'scripts'/'management'/'failover'/'failover-to-j52.sh').read_text(encoding='utf-8')
for token in ('../../_lib/common.sh', '../../_lib/runtime-config.sh'):
    if token not in failover_script:
        raise SystemExit(f'Identity failover script does not resolve moved library path: {token}')
deploy_script = (root/'scripts'/'deploy-platform.sh').read_text(encoding='utf-8')
if 'management/failover/failover-to-j52.sh' not in deploy_script:
    raise SystemExit('Deployment orchestrator does not reference the moved failover script')

gitrepo_script = (root/'scripts'/'management'/'fleet'/'03-bootstrap-gitrepos.sh').read_text(encoding='utf-8')
if 'fleet/bundles/00-namespaces' in gitrepo_script:
    raise SystemExit('GitRepo bootstrap still references the retired namespace bundle')
for bundle_path in ('fleet/bundles/10-cert-manager', 'fleet/bundles/11-cert-manager-config', 'fleet/bundles/20-metallb', 'fleet/bundles/21-metallb-config'):
    if gitrepo_script.count(bundle_path) != 2:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} in local and downstream scopes')

cert_chart_dir = bundle_root/'10-cert-manager'
for candidate in cert_chart_dir.glob('*.yaml'):
    if candidate.name in {'fleet.yaml', 'values.yaml'}:
        continue
    text = candidate.read_text(encoding='utf-8')
    if 'apiVersion: cert-manager.io/' in text:
        raise SystemExit(f'{candidate.relative_to(root)} must not contain cert-manager custom resources; use 11-cert-manager-config')
config_fleet = (bundle_root/'11-cert-manager-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: cert-manager-config',
    'kmm.dev/bundle: cert-manager',
    'releaseName: cert-manager-config',
    'takeOwnership: true',
):
    if token not in config_fleet:
        raise SystemExit(f'11-cert-manager-config/fleet.yaml is missing token: {token}')
issuer_manifest = bundle_root/'11-cert-manager-config'/'segment1-ca-clusterissuer.yaml'
if not issuer_manifest.is_file():
    raise SystemExit('11-cert-manager-config/segment1-ca-clusterissuer.yaml is missing')
issuer_text = issuer_manifest.read_text(encoding='utf-8')
for token in ('kind: ClusterIssuer', 'name: segment1-ca-clusterissuer', 'secretName: segment1-ca-bundle-secret'):
    if token not in issuer_text:
        raise SystemExit(f'cert-manager config manifest is missing token: {token}')

metallb_chart_dir = bundle_root/'20-metallb'
if (metallb_chart_dir/'address-pools.yaml').exists():
    raise SystemExit('20-metallb must contain only the chart and discovery anchor; move MetalLB custom resources to 21-metallb-config')
metallb_config_fleet = (bundle_root/'21-metallb-config'/'fleet.yaml').read_text(encoding='utf-8')
for token in (
    'kmm.dev/bundle: metallb-config',
    'kmm.dev/bundle: metallb',
    'releaseName: metallb-config',
    'takeOwnership: true',
):
    if token not in metallb_config_fleet:
        raise SystemExit(f'21-metallb-config/fleet.yaml is missing token: {token}')
metallb_config_manifest = bundle_root/'21-metallb-config'/'address-pools.yaml'
if not metallb_config_manifest.is_file():
    raise SystemExit('21-metallb-config/address-pools.yaml is missing')
for token in ('kind: IPAddressPool', 'name: segment1', 'kind: L2Advertisement', 'name: platform'):
    if token not in metallb_config_manifest.read_text(encoding='utf-8'):
        raise SystemExit(f'MetalLB config manifest is missing token: {token}')
for directory in ('31-contour-segment1', '63-eastwest-gateway'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: metallb-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on metallb-config')
for directory in ('53-keycloak', '54-keycloak-secondary', '62-istiod', '65-kiali-server'):
    fleet_text = (bundle_root/directory/'fleet.yaml').read_text(encoding='utf-8')
    if 'kmm.dev/bundle: cert-manager-config' not in fleet_text:
        raise SystemExit(f'{directory}/fleet.yaml must depend on cert-manager-config')
for bundle_path in ('fleet/bundles/70-kube-state-metrics', 'fleet/bundles/71-elastic-agent'):
    if gitrepo_script.count(bundle_path) != 2:
        raise SystemExit(f'GitRepo bootstrap must include {bundle_path} in local and downstream scopes')

label_script = (root/'scripts'/'management'/'fleet'/'02-label-fleet-clusters.sh').read_text(encoding='utf-8')
required_network_tokens = (
    '1.0.0.201-210', '1.0.0.205', '1.0.0.210',
    '1.0.0.211-220', '1.0.0.215', '1.0.0.216', '1.0.0.220',
    '1.0.0.221-230', '1.0.0.225', '1.0.0.226', '1.0.0.230',
    '1.0.0.231-240', '1.0.0.235', '1.0.0.240',
)
for token in required_network_tokens:
    if token not in label_script:
        raise SystemExit(f'Fleet label script missing Segment1 allocation: {token}')
segment_network = ipaddress.ip_network('1.0.0.0/23')
for literal in set(re.findall(r'\b1\.0\.[01]\.\d{1,3}\b', label_script)):
    if ipaddress.ip_address(literal) not in segment_network:
        raise SystemExit(f'Fleet label script contains an address outside Segment1: {literal}')

forbidden_patterns = (
    re.compile(r'\b10\.0\.4\.'),
    re.compile(r'kmm\.dev/metallb-regular-pool', re.IGNORECASE),
    re.compile(r'\b(devlocal-argocd|contour-devlocal|ingress-devlocal)\b', re.IGNORECASE),
)
for relative in ('config', 'fleet', 'scripts', 'yaml'):
    directory = root / relative
    if not directory.exists():
        continue
    for path in directory.rglob('*'):
        if path == root/'scripts'/'validate-fleet-layout.sh':
            continue
        if not path.is_file() or path.suffix in {'.tgz', '.gz', '.zip'}:
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        for pattern in forbidden_patterns:
            if pattern.search(text):
                raise SystemExit(f'{path.relative_to(root)} contains retired deployment token matching {pattern.pattern}')

for path in (root/'README.md', root/'docs'/'Fleet-Operations.md', root/'docs'/'Rancher-Fleet-Architecture.md'):
    text = path.read_text(encoding='utf-8').lower()
    for retired in ('devlocal-argocd', 'contour-devlocal', 'ingress-devlocal'):
        if retired in text:
            raise SystemExit(f'{path.relative_to(root)} still describes retired component {retired}')

for context, address in {'j64seg1opman':'1.0.0.210','j64seg1opdev':'1.0.0.220','j52seg1opdev':'1.0.0.230','r01seg1opdev':'1.0.0.240'}.items():
    site = context[:3]
    cluster = context[3:]
    source = root/'yaml'/site/f'{cluster}-cluster'/'values'/'istio-istiod-values-v1.yaml'
    text = source.read_text(encoding='utf-8')
    if address not in text or 'segment1-ca-clusterissuer' not in text:
        raise SystemExit(f'{source.relative_to(root)} is not aligned with Segment1 mesh addressing and CA')

print('Fleet YAML, dependencies, monitoring, two-site identity, RKE2 CNI, and Segment1-only network checks passed.')
PY2

if grep -RIl --exclude='*.md' -i 'argocd' \
  "${ROOT_DIR}/fleet" "${ROOT_DIR}/scripts/deploy-platform.sh" "${ROOT_DIR}/scripts/management/fleet"; then
  die "Argo CD references remain in active Fleet code."
fi

log "Fleet layout validation passed."
