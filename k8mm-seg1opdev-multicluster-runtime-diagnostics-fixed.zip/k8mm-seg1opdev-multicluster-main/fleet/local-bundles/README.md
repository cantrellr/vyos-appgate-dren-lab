# Management bootstrap contract bundles

These bundles exist only in the `fleet-local` workspace. They publish dependency
labels for platform components that must already exist before Rancher/Fleet can
manage the management cluster.

`bootstrap-management` is the sole lifecycle owner on `j64seg1opman` of:

- `onprem-cert-manager` and `segment1-ca-clusterissuer`;
- `metallb` plus the `segment1` `IPAddressPool` / `platform` `L2Advertisement`;
- `ingress-segment1` (Segment1 Contour/Envoy).

Before the local GitRepo is created, `03-bootstrap-gitrepos.sh` validates those
live contracts. The lightweight bundles in this directory then publish the same
`kmm.dev/bundle` labels used by downstream real bundles so Istio, Kiali and other
dependencies can sequence normally without Fleet adopting bootstrap-owned Helm
releases.

The one-time migration logic in `03-bootstrap-gitrepos.sh` pauses an existing
legacy local GitRepo, marks the old MetalLB/Contour BundleDeployments with
`keepResources`, deletes those BundleDeployments, verifies that the bootstrap
resources remain, and then switches the local GitRepo to these marker paths.

The `fleet-default` workspace continues to deploy the real cert-manager,
MetalLB/configuration, and Contour bundles to downstream clusters.
