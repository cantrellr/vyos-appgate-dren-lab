#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
source "${SCRIPT_DIR}/../../_lib/cis.sh"
CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap-seg1opdev-v2.15.0.env}"
load_kmm_runtime_config "${CONFIG_FILE}"

registry_username="$(read_required_secret_file REGISTRY_USERNAME_FILE)"
registry_password="$(read_required_secret_file REGISTRY_PASSWORD_FILE)"
trident_username="$(read_required_secret_file TRIDENT_USERNAME_FILE)"
trident_password="$(read_required_secret_file TRIDENT_PASSWORD_FILE)"
kiali_token="$(read_required_secret_file KIALI_GRAFANA_TOKEN_FILE)"
postgres_username="$(read_required_secret_file POSTGRES_APP_USERNAME_FILE)"
postgres_password="$(read_required_secret_file POSTGRES_APP_PASSWORD_FILE)"
keycloak_username="$(read_required_secret_file KEYCLOAK_BOOTSTRAP_USERNAME_FILE)"
keycloak_password="$(read_required_secret_file KEYCLOAK_BOOTSTRAP_PASSWORD_FILE)"

[[ -n "${ELASTIC_FLEET_URL:-}" ]] || die "Set ELASTIC_FLEET_URL in the runtime config."
require_runtime_file ELASTIC_FLEET_CA_FILE

seed_cluster() {
  local context="$1"
  validate_context_access "${context}"
  use_context "${context}"

  for namespace in kube-system cert-manager segment1 metallb-system trident-system trident-protect istio-system elastic-agent-system elastic-monitoring; do
    if [[ "${namespace}" != "kube-system" ]]; then
      psa_level=restricted
      [[ "${namespace}" =~ ^(metallb-system|trident-system|trident-protect|istio-system|elastic-agent-system)$ ]] && psa_level=privileged
      ensure_cis_namespace "${namespace}" true "${psa_level}"
    fi
    kubectl -n "${namespace}" create secret docker-registry regcred-kubeharbor \
      --docker-server="${REGISTRY_HOST:-kubeharbor.dev.kube}" \
      --docker-username="${registry_username}" \
      --docker-password="${registry_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  done

  kubectl -n cert-manager create secret tls segment1-ca-bundle-secret \
    --cert="${CA_CERT_FILE}" \
    --key="${CA_KEY_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  local cacerts_dir="${ISTIO_CACERTS_DIR}/${context}"
  for file in ca-cert.pem ca-key.pem root-cert.pem cert-chain.pem; do
    ensure_file "${cacerts_dir}/${file}"
  done
  kubectl -n istio-system create secret generic cacerts \
    --from-file=ca-cert.pem="${cacerts_dir}/ca-cert.pem" \
    --from-file=ca-key.pem="${cacerts_dir}/ca-key.pem" \
    --from-file=root-cert.pem="${cacerts_dir}/root-cert.pem" \
    --from-file=cert-chain.pem="${cacerts_dir}/cert-chain.pem" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  kubectl -n trident-system create secret generic tridentsvm-credentials-secret \
    --from-literal=username="${trident_username}" \
    --from-literal=password="${trident_password}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n istio-system create secret generic kiali-grafana-credentials \
    --from-literal=token="${kiali_token}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  kubectl label namespace elastic-agent-system \
    k8mm.dev/monitoring-agent=true \
    k8mm.dev/elastic-agent-topology=single \
    --overwrite >/dev/null

  local token_variable="ELASTIC_FLEET_TOKEN_${context^^}_FILE"
  local elastic_fleet_token=""
  local current_fleet_url_b64=""
  local current_fleet_token_b64=""
  local desired_fleet_url_b64=""
  local desired_fleet_token_b64=""
  local enrollment_secret_changed=false
  elastic_fleet_token="$(read_required_secret_file "${token_variable}")"

  # Secret-backed environment variables are fixed when a Pod is created. Detect
  # an enrollment URL/token rotation without printing either value, then restart
  # the existing per-node Agent DaemonSet after the Secret is updated.
  current_fleet_url_b64="$(kubectl -n elastic-agent-system get secret elastic-agent-fleet-enrollment \
    -o jsonpath='{.data.FLEET_URL}' 2>/dev/null || true)"
  current_fleet_token_b64="$(kubectl -n elastic-agent-system get secret elastic-agent-fleet-enrollment \
    -o jsonpath='{.data.FLEET_ENROLLMENT_TOKEN}' 2>/dev/null || true)"
  desired_fleet_url_b64="$(printf '%s' "${ELASTIC_FLEET_URL}" | base64 | tr -d '\n')"
  desired_fleet_token_b64="$(printf '%s' "${elastic_fleet_token}" | base64 | tr -d '\n')"
  if [[ "${current_fleet_url_b64}" != "${desired_fleet_url_b64}" || \
        "${current_fleet_token_b64}" != "${desired_fleet_token_b64}" ]]; then
    enrollment_secret_changed=true
  fi

  kubectl -n elastic-agent-system create secret generic devlocal-ca-bundle-secret \
    --from-file=ca.crt="${ELASTIC_FLEET_CA_FILE}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n elastic-agent-system create secret generic elastic-agent-fleet-enrollment \
    --from-literal=FLEET_URL="${ELASTIC_FLEET_URL}" \
    --from-literal=FLEET_ENROLLMENT_TOKEN="${elastic_fleet_token}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  if [[ "${enrollment_secret_changed}" == "true" ]] && \
     kubectl -n elastic-agent-system get daemonset agent-pernode-elastic-agent-node >/dev/null 2>&1; then
    log "Elastic Fleet enrollment Secret changed on ${context}; restarting the existing Agent DaemonSet."
    kubectl -n elastic-agent-system rollout restart daemonset/agent-pernode-elastic-agent-node >/dev/null
  fi

  unset elastic_fleet_token current_fleet_url_b64 current_fleet_token_b64
  unset desired_fleet_url_b64 desired_fleet_token_b64 enrollment_secret_changed
}

seed_identity_cluster() {
  local context="$1"
  use_context "${context}"
  for namespace in oppostgres opkeycloak; do
    ensure_cis_namespace "${namespace}" true restricted
    kubectl -n "${namespace}" create secret docker-registry regcred-kubeharbor \
      --docker-server="${REGISTRY_HOST:-kubeharbor.dev.kube}" \
      --docker-username="${registry_username}" \
      --docker-password="${registry_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
    kubectl -n "${namespace}" create secret generic opkeycloak-postgresql-credentials \
      --from-literal=username="${postgres_username}" \
      --from-literal=password="${postgres_password}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  done
  kubectl -n opkeycloak create secret generic opkeycloak-bootstrap-admin \
    --from-literal=username="${keycloak_username}" \
    --from-literal=password="${keycloak_password}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
}

for context in "${KMM_SUPPORTED_CONTEXTS[@]}"; do
  seed_cluster "${context}"
done
for context in j64seg1opdev j52seg1opdev; do
  seed_identity_cluster "${context}"
done

unset registry_username registry_password trident_username trident_password
unset kiali_token postgres_username postgres_password keycloak_username keycloak_password
unset ELASTIC_FLEET_URL
log "Runtime Secrets seeded across all four clusters and both identity sites. No credential values were printed or written to Git."
