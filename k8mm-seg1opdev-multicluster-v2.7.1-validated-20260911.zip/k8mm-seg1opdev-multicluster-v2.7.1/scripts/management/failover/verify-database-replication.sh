#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
ensure_executable_file "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd openssl
require_cmd base64
require_cmd awk
require_cmd sort
require_cmd grep
require_cmd cut

source_site="${1:-}"
target_site="${2:-}"

if [[ -z "${source_site}" && -z "${target_site}" ]]; then
  j64_json="$(fleet_cluster_json fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
  j52_json="$(fleet_cluster_json fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${RANCHER_CONTEXT:-j64seg1opman}")"
  j64_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j64_json}")"
  j52_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j52_json}")"
  [[ -n "${j64_primary}" && "${j64_primary}" == "${j52_primary}" ]] || \
    die "Fleet identity sites do not agree on kmm.dev/postgres-primary-site."
  source_site="${j64_primary}"
  target_site="$(identity_peer_site "${source_site}")"
elif [[ -z "${source_site}" || -z "${target_site}" ]]; then
  die "Specify both source and target sites, or neither for Fleet-label discovery."
fi

[[ "$(identity_peer_site "${source_site}")" == "${target_site}" ]] || \
  die "Source ${source_site} and target ${target_site} are not the supported identity-site pair."

max_lag_bytes="${IDENTITY_MAX_REPLICATION_LAG_BYTES:-16777216}"
max_message_age="${IDENTITY_MAX_REPLICATION_MESSAGE_AGE_SECONDS:-30}"
wait_seconds="${IDENTITY_REPLICATION_VERIFY_TIMEOUT_SECONDS:-300}"
poll_seconds="${IDENTITY_REPLICATION_VERIFY_POLL_SECONDS:-5}"
cert_min_validity="${IDENTITY_REPLICATION_CERT_MIN_VALIDITY_SECONDS:-604800}"
for value_name in max_lag_bytes max_message_age wait_seconds poll_seconds cert_min_validity; do
  value="${!value_name}"
  [[ "${value}" =~ ^[0-9]+$ ]] || die "${value_name} must be an integer; found ${value}."
done
(( wait_seconds > 0 )) || die "wait_seconds must be greater than zero."
(( poll_seconds > 0 )) || die "poll_seconds must be greater than zero."
(( cert_min_validity > 0 )) || die "cert_min_validity must be greater than zero."

expected_host="$(identity_replication_host "${source_site}")"
expected_ip="$(identity_replication_ip "${source_site}")"
source_alias="$(identity_secret_site_code "${source_site}")"
source_replication_secret="${IDENTITY_POSTGRES_CLUSTER}-replication"
source_ca_secret="${IDENTITY_POSTGRES_CLUSTER}-ca"
copied_replication_secret="oppostgres-${source_alias}-replication"
copied_ca_secret="oppostgres-${source_alias}-ca"

validate_dns_mapping() {
  local resolver_site="$1" host="$2" expected="$3" resolved
  resolved="$(identity_resolve_ipv4 "${resolver_site}" "${host}" 2>/dev/null || true)"
  [[ -n "${resolved}" ]] || die "${resolver_site}: unable to resolve ${host} from the current CNPG primary pod."
  while IFS= read -r ip; do
    [[ "${ip}" == "${expected}" ]] || \
      die "${resolver_site}: ${host} returned A record ${ip}; expected only ${expected}."
  done <<<"${resolved}"
  grep -Fxq "${expected}" <<<"${resolved}" || \
    die "${resolver_site}: ${host} did not resolve to required VIP ${expected}."
  log "${resolver_site}: ${host} resolves only to approved replication VIP ${expected}."
}

validate_replication_certificates() {
  local source_cert_fp copied_cert_fp source_ca_fp copied_ca_fp
  source_cert_fp="$(identity_secret_cert_fingerprint "${source_site}" "${source_replication_secret}" 'tls.crt' || true)"
  copied_cert_fp="$(identity_secret_cert_fingerprint "${target_site}" "${copied_replication_secret}" 'tls.crt' || true)"
  source_ca_fp="$(identity_secret_cert_fingerprint "${source_site}" "${source_ca_secret}" 'ca.crt' || true)"
  copied_ca_fp="$(identity_secret_cert_fingerprint "${target_site}" "${copied_ca_secret}" 'ca.crt' || true)"

  [[ -n "${source_cert_fp}" && -n "${copied_cert_fp}" ]] || \
    die "Replication client certificate is missing or unreadable for ${source_site} -> ${target_site}."
  [[ "${source_cert_fp}" == "${copied_cert_fp}" ]] || \
    die "Replication client certificate fingerprint mismatch between ${source_site} and copied ${target_site} Secret."
  [[ -n "${source_ca_fp}" && -n "${copied_ca_fp}" ]] || \
    die "Replication CA certificate is missing or unreadable for ${source_site} -> ${target_site}."
  [[ "${source_ca_fp}" == "${copied_ca_fp}" ]] || \
    die "Replication CA fingerprint mismatch between ${source_site} and copied ${target_site} Secret."

  identity_secret_cert_valid_for "${source_site}" "${source_replication_secret}" 'tls.crt' "${cert_min_validity}" || \
    die "${source_site}: replication client certificate expires within ${cert_min_validity}s."
  identity_secret_cert_valid_for "${target_site}" "${copied_replication_secret}" 'tls.crt' "${cert_min_validity}" || \
    die "${target_site}: copied replication client certificate expires within ${cert_min_validity}s."
  identity_secret_cert_valid_for "${source_site}" "${source_ca_secret}" 'ca.crt' "${cert_min_validity}" || \
    die "${source_site}: replication CA certificate expires within ${cert_min_validity}s."
  identity_secret_cert_valid_for "${target_site}" "${copied_ca_secret}" 'ca.crt' "${cert_min_validity}" || \
    die "${target_site}: copied replication CA certificate expires within ${cert_min_validity}s."

  log "Replication certificate fingerprints match and remain valid for at least ${cert_min_validity}s."
}

# DNS must be correct from both database sites. This closes the gap where the WAL
# receiver reports the configured hostname even while DNS points at a stale VIP.
validate_dns_mapping "${source_site}" "${expected_host}" "${expected_ip}"
validate_dns_mapping "${target_site}" "${expected_host}" "${expected_ip}"

# Prove the basic routed TCP path before interpreting SQL replication state.
identity_pg_isready "${target_site}" "${expected_host}" 5432 || \
  die "${target_site}: TCP/5432 probe to ${expected_host} (${expected_ip}) failed."
log "${target_site}: TCP/5432 is reachable at ${expected_host}."

# CNPG mounts these Secrets into the replica connection with sslmode=verify-ca;
# matching fingerprints and non-expired certificates prove the trust material
# used by the TLS WAL connection is the intended source material.
validate_replication_certificates

deadline=$((SECONDS + wait_seconds))
last_reason="initializing"

while (( SECONDS < deadline )); do
  source_recovery="$(identity_sql "${source_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"
  target_recovery="$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"
  if [[ "${source_recovery}" != "f" || "${target_recovery}" != "t" ]]; then
    last_reason="role state source=${source_recovery:-unavailable} target=${target_recovery:-unavailable}"
    sleep "${poll_seconds}"
    continue
  fi

  receiver="$(identity_sql "${target_site}" \
    "select concat_ws('|', status, sender_host, sender_port::text, coalesce(extract(epoch from (clock_timestamp()-last_msg_receipt_time))::bigint,999999)::text) from pg_stat_wal_receiver" \
    2>/dev/null || true)"
  IFS='|' read -r receiver_status sender_host sender_port message_age <<<"${receiver}"
  if [[ "${receiver_status}" != "streaming" ]]; then
    last_reason="target WAL receiver status=${receiver_status:-missing}"
    sleep "${poll_seconds}"
    continue
  fi
  if [[ "${sender_host}" != "${expected_host}" && "${sender_host}" != "${expected_ip}" ]]; then
    last_reason="target WAL receiver sender=${sender_host:-missing}, expected ${expected_host} or ${expected_ip}"
    sleep "${poll_seconds}"
    continue
  fi
  if [[ "${sender_port}" != "5432" ]]; then
    last_reason="target WAL receiver sender port=${sender_port:-missing}, expected 5432"
    sleep "${poll_seconds}"
    continue
  fi
  if [[ ! "${message_age}" =~ ^[0-9]+$ ]] || (( message_age > max_message_age )); then
    last_reason="WAL receiver message age=${message_age:-invalid}s, maximum ${max_message_age}s"
    sleep "${poll_seconds}"
    continue
  fi

  # Verify the source also reports at least one active streaming sender. The
  # target receiver establishes which remote source is in use; this source-side
  # check catches one-sided catalog/session anomalies.
  source_streaming_senders="$(identity_sql "${source_site}" \
    "select count(*)::text from pg_stat_replication where state='streaming'" 2>/dev/null || true)"
  if [[ ! "${source_streaming_senders}" =~ ^[0-9]+$ ]] || (( source_streaming_senders < 1 )); then
    last_reason="source pg_stat_replication has no streaming sender"
    sleep "${poll_seconds}"
    continue
  fi

  source_lsn="$(identity_sql "${source_site}" 'select pg_current_wal_lsn()' 2>/dev/null || true)"
  target_receive_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_receive_lsn()' 2>/dev/null || true)"
  target_replay_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_replay_lsn()' 2>/dev/null || true)"
  if [[ ! "${source_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ || \
        ! "${target_receive_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ || \
        ! "${target_replay_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ ]]; then
    last_reason="one or more WAL LSN values are unavailable"
    sleep "${poll_seconds}"
    continue
  fi

  source_lag_bytes="$(identity_sql "${source_site}" \
    "select greatest(pg_wal_lsn_diff('${source_lsn}'::pg_lsn,'${target_replay_lsn}'::pg_lsn),0)::bigint" 2>/dev/null || true)"
  replay_queue_bytes="$(identity_sql "${target_site}" \
    "select greatest(pg_wal_lsn_diff('${target_receive_lsn}'::pg_lsn,'${target_replay_lsn}'::pg_lsn),0)::bigint" 2>/dev/null || true)"
  if [[ ! "${source_lag_bytes}" =~ ^[0-9]+$ || ! "${replay_queue_bytes}" =~ ^[0-9]+$ ]]; then
    last_reason="unable to calculate replication lag"
    sleep "${poll_seconds}"
    continue
  fi
  if (( source_lag_bytes > max_lag_bytes || replay_queue_bytes > max_lag_bytes )); then
    last_reason="lag source-to-replay=${source_lag_bytes}B local-replay-queue=${replay_queue_bytes}B, maximum ${max_lag_bytes}B"
    sleep "${poll_seconds}"
    continue
  fi

  log "Database replication verified: ${source_site} -> ${target_site}, status=streaming, sender=${sender_host}:${sender_port}, source-senders=${source_streaming_senders}, source-to-replay=${source_lag_bytes}B, local-replay-queue=${replay_queue_bytes}B, message-age=${message_age}s."

  # Replication health and planned-switchover readiness are related but distinct.
  # A one-way pg_basebackup/WAL replica can be perfectly healthy while Fleet has
  # not yet rendered the promotion-capable distributed CNPG topology.
  source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${RANCHER_CONTEXT:-j64seg1opman}")"
  target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${RANCHER_CONTEXT:-j64seg1opman}")"
  source_topology="$(kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default get cluster.fleet.cattle.io "${source_resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/postgres-distributed-topology}' 2>/dev/null || true)"
  target_topology="$(kubectl --context "${RANCHER_CONTEXT:-j64seg1opman}" -n fleet-default get cluster.fleet.cattle.io "${target_resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/postgres-distributed-topology}' 2>/dev/null || true)"
  if [[ "${source_topology}" == true && "${target_topology}" == true ]]; then
    log "Planned-switchover readiness: distributed PostgreSQL topology is enrolled on both Fleet clusters."
  else
    warn "Replication is healthy, but planned-switchover topology is not yet enrolled (source=${source_topology:-unset}, target=${target_topology:-unset}). Run './scripts/deploy-platform.sh enable-identity-secondary'; planned J64->J52 failover can also auto-enroll it after confirmation."
  fi
  exit 0
done

die "Database replication verification timed out for ${source_site} -> ${target_site}: ${last_reason}."
