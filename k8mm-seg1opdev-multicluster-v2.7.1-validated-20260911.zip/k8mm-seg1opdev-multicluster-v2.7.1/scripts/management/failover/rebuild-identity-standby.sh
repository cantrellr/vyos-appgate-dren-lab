#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
ensure_executable_file "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd date

standby_site="${1:-}"
[[ "${standby_site}" == j64seg1opdev || "${standby_site}" == j52seg1opdev ]] || \
  die "Usage: $0 <j64seg1opdev|j52seg1opdev>"
[[ "${IDENTITY_REBUILD_CONFIRM:-}" == "${standby_site}" ]] || \
  die "Set IDENTITY_REBUILD_CONFIRM=${standby_site} to acknowledge standby recreation."
[[ "${IDENTITY_REBUILD_DELETE_STORAGE:-false}" == true ]] || \
  die "Standby rebuild deletes the old CNPG PVC objects. Set IDENTITY_REBUILD_DELETE_STORAGE=true after confirming the active site is healthy and backed up."

management_context="${RANCHER_CONTEXT:-j64seg1opman}"
standby_context="$(identity_context "${standby_site}")"
active_site="$(identity_peer_site "${standby_site}")"
active_context="$(identity_context "${active_site}")"
gitrepo_name="${IDENTITY_FLEET_GITREPO_NAME:-k8mm-seg1opdev-multicluster-downstream}"
probe_name="identity-repl-probe-$(date -u +%H%M%S)-$$"

active_json="$(fleet_cluster_json fleet-default "$(identity_display_name "${active_site}")" "${management_context}")"
standby_json="$(fleet_cluster_json fleet-default "$(identity_display_name "${standby_site}")" "${management_context}")"
[[ "$(jq -r '.metadata.labels["kmm.dev/identity-active"] // ""' <<<"${active_json}")" == true ]] || \
  die "${active_site} is not the Fleet-declared active identity site."
[[ "$(jq -r '.metadata.labels["kmm.dev/identity-active"] // ""' <<<"${standby_json}")" == false ]] || \
  die "${standby_site} is still marked active; refusing destructive standby rebuild."
[[ "$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${active_json}")" == "${active_site}" ]] || \
  die "Fleet primary-site label does not identify ${active_site} as writable."
[[ "$(identity_sql "${active_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == f ]] || \
  die "${active_site} is not a confirmed writable PostgreSQL primary."

standby_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${standby_site}")" "${management_context}")"
original_paused="$(kubectl --context "${management_context}" -n fleet-default get gitrepo "${gitrepo_name}" -o jsonpath='{.spec.paused}' 2>/dev/null || true)"
[[ "${original_paused}" == true ]] || original_paused=false

restore_pause() {
  kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" --type merge \
    -p "{\"spec\":{\"paused\":${original_paused}}}" >/dev/null 2>&1 || true
}
cleanup_probe() {
  kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" delete pod "${probe_name}" \
    --ignore-not-found --wait=false >/dev/null 2>&1 || true
}
trap 'cleanup_probe; restore_pause' EXIT

log "Synchronizing current ${active_site} replication certificate/CA material to ${standby_site}..."
identity_sync_replication_tls "${active_site}" "${standby_site}"

source_alias="$(identity_secret_site_code "${active_site}")"
source_host="$(identity_replication_host "${active_site}")"
source_ip="$(identity_replication_ip "${active_site}")"
postgres_image="${IDENTITY_POSTGRES_PROBE_IMAGE:-kubeharbor.dev.kube/cloudnative-pg/postgresql:17.6-system-trixie}"

log "Probing DNS, TCP, and certificate-authenticated TLS from ${standby_site} to ${source_host} before deleting standby data..."
cat <<YAML | kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: ${probe_name}
  labels:
    kmm.dev/component: identity-replication-probe
spec:
  restartPolicy: Never
  imagePullSecrets:
    - name: regcred-kubeharbor
  securityContext:
    runAsNonRoot: true
    runAsUser: 26
    runAsGroup: 26
    fsGroup: 26
    seccompProfile:
      type: RuntimeDefault
  containers:
    - name: probe
      image: ${postgres_image}
      imagePullPolicy: IfNotPresent
      securityContext:
        allowPrivilegeEscalation: false
        capabilities:
          drop: ["ALL"]
      command: ["/bin/sh", "-ec"]
      args:
        - |
          resolved="$(getent ahostsv4 '${source_host}' | awk '{print $1}' | sort -u)"
          test -n "$resolved"
          test "$resolved" = '${source_ip}'
          cp /client/tls.crt /work/tls.crt
          cp /client/tls.key /work/tls.key
          cp /ca/ca.crt /work/ca.crt
          chmod 0600 /work/tls.key
          psql "host=${source_host} port=5432 user=streaming_replica dbname=postgres connect_timeout=5 sslmode=verify-ca sslcert=/work/tls.crt sslkey=/work/tls.key sslrootcert=/work/ca.crt" -Atqc 'select 1' | grep -Fx 1
      volumeMounts:
        - {name: client, mountPath: /client, readOnly: true}
        - {name: ca, mountPath: /ca, readOnly: true}
        - {name: work, mountPath: /work}
  volumes:
    - name: client
      secret:
        secretName: oppostgres-${source_alias}-replication
    - name: ca
      secret:
        secretName: oppostgres-${source_alias}-ca
    - name: work
      emptyDir: {}
YAML
kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" wait \
  --for=jsonpath='{.status.phase}'=Succeeded pod/"${probe_name}" --timeout=2m || {
    kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" logs "${probe_name}" >&2 || true
    die "Replication DNS/TCP/TLS probe failed; standby data was not deleted."
  }
cleanup_probe

log "Pausing Fleet while ${standby_site} Cluster/PVC objects are removed and bootstrap mode is changed..."
kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" --type merge \
  -p '{"spec":{"paused":true}}' >/dev/null

# Rebuild in standalone streaming mode first. The new Cluster cannot safely
# reference its own distributed-topology ID until CNPG has created the new
# local replication TLS Secrets. The surviving primary remains enrolled and
# writable during this temporary degraded interval.
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${standby_resource}" --overwrite \
  kmm.dev/identity-active=false \
  kmm.dev/keycloak-instances=0 \
  kmm.dev/postgres-hibernation=off \
  kmm.dev/postgres-primary-site="${active_site}" \
  kmm.dev/postgres-distributed-topology=false \
  kmm.dev/postgres-bootstrap-mode=pg_basebackup >/dev/null

# The StorageClasses use Retain semantics. Deleting these PVC objects leaves the
# old PV/Longhorn data as a recovery artifact while allowing CNPG to provision
# fresh PVCs for the pg_basebackup clone. We intentionally do not delete retained
# PVs/Longhorn volumes here.
mapfile -t old_pvcs < <(kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get pvc \
  -l "cnpg.io/cluster=${IDENTITY_POSTGRES_CLUSTER}" -o name 2>/dev/null || true)
log "Deleting standby CNPG Cluster ${IDENTITY_POSTGRES_CLUSTER}; retained PV data is not deleted."
kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" delete \
  "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --ignore-not-found --wait=true
if ((${#old_pvcs[@]})); then
  printf '%s\n' "${old_pvcs[@]}" | xargs -r kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" delete --wait=true
fi

# Temporarily unpause even when the operator had Fleet paused before this task;
# the original state is restored after the rebuilt Cluster is healthy.
kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" --type merge \
  -p '{"spec":{"paused":false}}' >/dev/null

log "Waiting for Fleet to recreate ${standby_site} with pg_basebackup from ${active_site}..."
deadline=$((SECONDS + 1200))
until kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
  "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; do
  (( SECONDS < deadline )) || die "Timed out waiting for Fleet to recreate the standby Cluster."
  sleep 5
done
identity_wait_cluster_ready "${standby_site}" 20m
[[ "$(identity_sql "${standby_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == t ]] || \
  die "Rebuilt ${standby_site} is not a read-only replica."

# The rebuilt site now has fresh CNPG-managed TLS material. Publish that new
# replication identity back to the surviving site before re-enrolling the
# rebuilt Cluster in the distributed topology.
identity_sync_replication_tls "${standby_site}" "${active_site}"
kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${standby_resource}" --overwrite \
  kmm.dev/postgres-primary-site="${active_site}" \
  kmm.dev/postgres-distributed-topology=true >/dev/null

log "Waiting for ${standby_site} to rejoin the CloudNativePG distributed topology..."
deadline=$((SECONDS + 900))
until [[ "$(kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
  "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.self}' 2>/dev/null || true)" == "${standby_site}" && \
         "$(kubectl --context "${standby_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
  "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)" == "${active_site}" ]]; do
  (( SECONDS < deadline )) || die "Timed out waiting for ${standby_site} distributed-topology re-enrollment. The rebuilt database remains a standalone streaming replica; re-run the rebuild command after correcting Fleet reconciliation."
  sleep 5
done

identity_wait_cluster_ready "${standby_site}" 15m
"${SCRIPT_DIR}/verify-database-replication.sh" "${active_site}" "${standby_site}"
"${SCRIPT_DIR}/../fleet/06-validate-identity-ha.sh"

restore_pause
trap - EXIT
log "Standby rebuild completed: ${standby_site} was re-cloned from ${active_site} with pg_basebackup, re-enrolled in the distributed topology, and strict HA validation passed."
