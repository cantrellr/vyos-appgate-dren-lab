#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
export IDENTITY_SWITCHOVER_CONFIRM="${IDENTITY_SWITCHOVER_CONFIRM:-${IDENTITY_FAILBACK_CONFIRM:-}}"
ensure_executable_file "${SCRIPT_DIR}/switchover-identity.sh"
exec "${SCRIPT_DIR}/switchover-identity.sh" j64seg1opdev
