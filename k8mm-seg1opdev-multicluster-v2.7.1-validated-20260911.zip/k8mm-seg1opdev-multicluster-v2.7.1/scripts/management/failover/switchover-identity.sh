#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
ensure_executable_file "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd curl
require_cmd date
require_cmd paste
require_cmd timeout

management_context="${RANCHER_CONTEXT:-j64seg1opman}"
gitrepo_name="${IDENTITY_FLEET_GITREPO_NAME:-k8mm-seg1opdev-multicluster-downstream}"
journal_namespace="${IDENTITY_SWITCHOVER_JOURNAL_NAMESPACE:-fleet-default}"
journal_name="${IDENTITY_SWITCHOVER_JOURNAL_NAME:-kmm-identity-transition-journal}"
lock_name="${IDENTITY_SWITCHOVER_LOCK_NAME:-kmm-identity-transition-lock}"
traffic_timeout="${IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS:-600}"
health_path="${IDENTITY_OIDC_HEALTH_PATH:-/realms/master/.well-known/openid-configuration}"
auto_enroll_topology="${IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY:-true}"
traffic_cutover_mode_raw="${IDENTITY_TRAFFIC_CUTOVER_MODE:-dns-admin}"
case "${traffic_cutover_mode_raw}" in
  dns-admin|manual|dns) traffic_cutover_mode=dns-admin ;;
  controller-dns) traffic_cutover_mode=controller-dns ;;
  *) die "IDENTITY_TRAFFIC_CUTOVER_MODE must be dns-admin or controller-dns (legacy values manual/dns migrate to dns-admin)." ;;
esac
kubectl_request_timeout="${IDENTITY_KUBECTL_REQUEST_TIMEOUT:-10s}"
dns_lookup_timeout="${IDENTITY_DNS_LOOKUP_TIMEOUT_SECONDS:-5}"
dns_ttl_seconds="${IDENTITY_DNS_TTL_SECONDS:-30}"
dns_convergence_grace="${IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS:-90}"
dns_admin_validation_timeout="${IDENTITY_DNS_ADMIN_VALIDATION_TIMEOUT_SECONDS:-180}"
identity_dns_require_all="${IDENTITY_DNS_REQUIRE_ALL_SERVERS:-true}"
identity_dns_servers_raw="${IDENTITY_DNS_SERVERS:-${JDE_DNS_SERVERS:-${DEV_KUBE_DNS_SERVERS:-}}}"
identity_dns_servers_raw="${identity_dns_servers_raw//,/ }"
read -r -a identity_dns_servers <<<"${identity_dns_servers_raw}"
poll_interval="${IDENTITY_FAILOVER_POLL_INTERVAL_SECONDS:-5}"
diagnostic_interval="${IDENTITY_FAILOVER_DIAGNOSTIC_INTERVAL_SECONDS:-30}"
target_exposure_timeout="${IDENTITY_TARGET_EXPOSURE_TIMEOUT_SECONDS:-900}"
fleet_reconcile_timeout="${IDENTITY_FLEET_RECONCILE_TIMEOUT_SECONDS:-900}"
database_transition_timeout="${IDENTITY_DATABASE_TRANSITION_TIMEOUT_SECONDS:-900}"

[[ "${traffic_timeout}" =~ ^[0-9]+$ ]] && (( traffic_timeout > 0 )) || \
  die "IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS must be greater than zero."
[[ "${auto_enroll_topology}" == true || "${auto_enroll_topology}" == false ]] || \
  die "IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY must be true or false."
for value_name in dns_lookup_timeout dns_ttl_seconds dns_convergence_grace dns_admin_validation_timeout poll_interval diagnostic_interval target_exposure_timeout fleet_reconcile_timeout database_transition_timeout; do
  value="${!value_name}"
  [[ "${value}" =~ ^[0-9]+$ ]] && (( value > 0 )) || die "${value_name} must be a positive integer number of seconds."
done
(( dns_convergence_grace >= dns_ttl_seconds )) || \
  die "IDENTITY_DNS_CONVERGENCE_GRACE_SECONDS must be greater than or equal to IDENTITY_DNS_TTL_SECONDS."
[[ "${identity_dns_require_all}" == true || "${identity_dns_require_all}" == false ]] || \
  die "IDENTITY_DNS_REQUIRE_ALL_SERVERS must be true or false."
((${#identity_dns_servers[@]} > 0)) || \
  die "IDENTITY_DNS_SERVERS must contain at least one Segment1 DNS server."

kctl() {
  kubectl --request-timeout="${kubectl_request_timeout}" "$@"
}

bounded_controller_resolve_ipv4() {
  # The controller resolver is diagnostic only. Its absence or inability to
  # resolve the enterprise zone must never block a Segment1 traffic cutover.
  command -v getent >/dev/null 2>&1 || return 0
  timeout "${dns_lookup_timeout}s" getent ahostsv4 "${IDENTITY_CANONICAL_HOST}" 2>/dev/null | \
    awk '{print $1}' | sort -u || true
}

controller_resolved_ipv4_csv() {
  bounded_controller_resolve_ipv4 | paste -sd, -
}

normalize_dns_name() {
  local value="${1:-}"
  value="${value%.}"
  printf '%s\n' "${value,,}"
}

dns_cname_query_tool() {
  if command -v dig >/dev/null 2>&1; then
    echo dig
  elif command -v host >/dev/null 2>&1; then
    echo host
  elif command -v nslookup >/dev/null 2>&1; then
    echo nslookup
  else
    echo unavailable
  fi
}

dns_server_resolve_cname() {
  local server="${1:?DNS server is required}" tool result=""
  tool="$(dns_cname_query_tool)"
  case "${tool}" in
    dig)
      result="$(timeout "${dns_lookup_timeout}s" dig @"${server}" +time="${dns_lookup_timeout}" +tries=1 +short CNAME "${IDENTITY_CANONICAL_HOST}" 2>/dev/null | head -1 || true)"
      ;;
    host)
      result="$(timeout "${dns_lookup_timeout}s" host -W "${dns_lookup_timeout}" -t CNAME "${IDENTITY_CANONICAL_HOST}" "${server}" 2>/dev/null | sed -n 's/.* is an alias for \([^ ]*\).*/\1/p' | head -1 || true)"
      ;;
    nslookup)
      result="$(timeout "${dns_lookup_timeout}s" nslookup -timeout="${dns_lookup_timeout}" -retry=1 -type=CNAME "${IDENTITY_CANONICAL_HOST}" "${server}" 2>/dev/null | awk -F' = ' '/canonical name =/ {print $2; exit}' || true)"
      ;;
  esac
  normalize_dns_name "${result}"
}

dns_server_resolve_ipv4() {
  local server="${1:?DNS server is required}" tool
  tool="$(dns_cname_query_tool)"
  case "${tool}" in
    dig)
      timeout "${dns_lookup_timeout}s" dig @"${server}" +time="${dns_lookup_timeout}" +tries=1 +short A "${IDENTITY_CANONICAL_HOST}" 2>/dev/null | \
        awk '/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {print}' | sort -u || true
      ;;
    host)
      timeout "${dns_lookup_timeout}s" host -W "${dns_lookup_timeout}" -t A "${IDENTITY_CANONICAL_HOST}" "${server}" 2>/dev/null | \
        awk '/ has address / {print $4}' | sort -u || true
      ;;
    nslookup)
      # Ignore the resolver's own `Address:` line and emit only answer records
      # that appear after the canonical `Name:` section.
      timeout "${dns_lookup_timeout}s" nslookup -timeout="${dns_lookup_timeout}" -retry=1 -type=A "${IDENTITY_CANONICAL_HOST}" "${server}" 2>/dev/null | \
        awk '/^Name:/ {answer=1; next} answer && /^Address: / {print $2}' | \
        sed 's/#.*//' | awk '/^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$/ {print}' | sort -u || true
      ;;
  esac
}

dns_cname_matches_expected() {
  local actual expected
  actual="$(normalize_dns_name "${1:-}")"
  expected="$(normalize_dns_name "${2:-}")"
  [[ -n "${actual}" && -n "${expected}" ]] || return 1
  if [[ "${expected}" == *.* ]]; then
    [[ "${actual}" == "${expected}" ]]
  else
    [[ "${actual%%.*}" == "${expected}" ]]
  fi
}

segment1_dns_evaluate() {
  local expected_cname="${1:?expected CNAME is required}" expected_ip="${2:?expected IP is required}"
  local server cname resolved resolved_csv server_match cname_match ip_match ip bad_ip
  SEGMENT1_DNS_DETAILS=""
  SEGMENT1_DNS_MATCH_COUNT=0
  SEGMENT1_DNS_TOTAL_COUNT=${#identity_dns_servers[@]}
  SEGMENT1_DNS_OVERALL=match

  if [[ "$(dns_cname_query_tool)" == unavailable ]]; then
    SEGMENT1_DNS_OVERALL=unavailable
    SEGMENT1_DNS_DETAILS="query-tool-unavailable"
    return 1
  fi

  for server in "${identity_dns_servers[@]}"; do
    cname="$(dns_server_resolve_cname "${server}")"
    resolved="$(dns_server_resolve_ipv4 "${server}")"
    resolved_csv="$(paste -sd, - <<<"${resolved}")"
    cname_match=mismatch
    ip_match=mismatch
    server_match=false

    if dns_cname_matches_expected "${cname}" "${expected_cname}"; then
      cname_match=match
    fi

    bad_ip=false
    if [[ -n "${resolved}" ]] && grep -Fxq "${expected_ip}" <<<"${resolved}"; then
      while IFS= read -r ip; do
        [[ -z "${ip}" || "${ip}" == "${expected_ip}" ]] || bad_ip=true
      done <<<"${resolved}"
      [[ "${bad_ip}" == false ]] && ip_match=match
    fi

    if [[ "${cname_match}" == match && "${ip_match}" == match ]]; then
      server_match=true
      SEGMENT1_DNS_MATCH_COUNT=$((SEGMENT1_DNS_MATCH_COUNT + 1))
    fi

    SEGMENT1_DNS_DETAILS+="resolver=${server} cname=${cname:-unresolved} cnameMatch=${cname_match} ipv4=${resolved_csv:-unresolved} ipMatch=${ip_match} status=$([[ "${server_match}" == true ]] && echo match || echo mismatch); "
  done

  if [[ "${identity_dns_require_all}" == true ]]; then
    (( SEGMENT1_DNS_MATCH_COUNT == SEGMENT1_DNS_TOTAL_COUNT )) || SEGMENT1_DNS_OVERALL=mismatch
  else
    (( SEGMENT1_DNS_MATCH_COUNT > 0 )) || SEGMENT1_DNS_OVERALL=mismatch
  fi
  [[ "${SEGMENT1_DNS_OVERALL}" == match ]]
}

print_segment1_dns_matrix() {
  local expected_cname="${1:?expected CNAME is required}" expected_ip="${2:?expected IP is required}"
  local server cname resolved resolved_csv cname_state ip_state ip bad_ip status
  for server in "${identity_dns_servers[@]}"; do
    cname="$(dns_server_resolve_cname "${server}")"
    resolved="$(dns_server_resolve_ipv4 "${server}")"
    resolved_csv="$(paste -sd, - <<<"${resolved}")"
    cname_state=mismatch
    ip_state=mismatch
    status=mismatch
    dns_cname_matches_expected "${cname}" "${expected_cname}" && cname_state=match
    bad_ip=false
    if [[ -n "${resolved}" ]] && grep -Fxq "${expected_ip}" <<<"${resolved}"; then
      while IFS= read -r ip; do
        [[ -z "${ip}" || "${ip}" == "${expected_ip}" ]] || bad_ip=true
      done <<<"${resolved}"
      [[ "${bad_ip}" == false ]] && ip_state=match
    fi
    [[ "${cname_state}" == match && "${ip_state}" == match ]] && status=match
    echo "dnsServer=${server} observedCNAME=${cname:-unresolved} resolvedIPv4=${resolved_csv:-unresolved} cnameMatch=${cname_state} ingressIPMatch=${ip_state} status=${status}"
  done
}

identity_canonical_https_health() {
  [[ -f "${CA_CERT_FILE}" ]] || return 1
  curl --fail --silent --show-error --max-time 10 \
    --cacert "${CA_CERT_FILE}" \
    "https://${IDENTITY_CANONICAL_HOST}${health_path}" >/dev/null 2>&1
}

show_dns_status() {
  local requested="${1:-active}" site expected_ip expected_cname tool controller_resolved controller_state direct_state dns_overall
  if [[ "${requested}" == active ]]; then
    site="$(fleet_active_site)"
  else
    site="$(normalize_identity_site "${requested}")" || die "DNS status target must be active, j64, j52, j64seg1opdev, or j52seg1opdev."
  fi
  expected_ip="$(identity_ingress_ip "${site}")"
  expected_cname="$(identity_ingress_cname "${site}")"
  tool="$(dns_cname_query_tool)"
  controller_resolved="$(controller_resolved_ipv4_csv)"
  if identity_canonical_https_health; then controller_state=healthy; else controller_state=unhealthy; fi
  if identity_direct_https_health "${site}"; then direct_state=healthy; else direct_state=unhealthy; fi
  if segment1_dns_evaluate "${expected_cname}" "${expected_ip}"; then dns_overall=match; else dns_overall="${SEGMENT1_DNS_OVERALL}"; fi

  echo "canonicalHost=${IDENTITY_CANONICAL_HOST}"
  echo "expectedSite=${site}"
  echo "expectedCNAME=${expected_cname}"
  echo "expectedIngressIP=${expected_ip}"
  echo "dnsValidationScope=segment1"
  echo "dnsServers=$(IFS=,; echo "${identity_dns_servers[*]}")"
  echo "dnsRequireAllServers=${identity_dns_require_all}"
  echo "dnsQueryTool=${tool}"
  print_segment1_dns_matrix "${expected_cname}" "${expected_ip}"
  echo "segment1DnsConsensus=${dns_overall}"
  echo "directTargetOIDC=${direct_state}"
  echo "controllerResolvedIPv4=${controller_resolved:-unresolved}"
  echo "controllerCanonicalOIDC=${controller_state}"
  echo "controllerResolverNote=informational-only; failover DNS gating uses the configured Segment1 DNS servers directly"
  echo "dnsTTLSeconds=${dns_ttl_seconds}"
  echo "dnsConvergenceGraceSeconds=${dns_convergence_grace}"
  echo "dnsAdminValidationTimeoutSeconds=${dns_admin_validation_timeout}"
}
print_dns_admin_action() {
  local source_cname target_cname target_ip controller_resolved
  source_cname="$(identity_ingress_cname "${source_site}")"
  target_cname="$(identity_ingress_cname "${target_site}")"
  target_ip="$(identity_ingress_ip "${target_site}")"
  controller_resolved="$(controller_resolved_ipv4_csv)"
  cat <<DNSACTION

================ DNS ADMIN ACTION REQUIRED ================
Canonical record : ${IDENTITY_CANONICAL_HOST}
Change CNAME from: ${source_cname}
Change CNAME to  : ${target_cname}
Target ingress   : ${target_ip}
Configured TTL   : ${dns_ttl_seconds} seconds
Validation DNS   : $(IFS=', '; echo "${identity_dns_servers[*]}")
Controller DNS   : ${controller_resolved:-unresolved} (informational only)

The database and target Keycloak traffic plane are ready. DNS is an external
change-management gate and is NOT modified by this repository. Have the DNS
Admins change the CNAME, then verify the Segment1 DNS view with:

  ./scripts/deploy-platform.sh identity-dns-status ${target_site}

After the Segment1 resolvers show the target CNAME and only ${target_ip}, resume
this SAME journal with:

  export IDENTITY_SWITCHOVER_CONFIRM=${target_site}
  export IDENTITY_TRAFFIC_CUTOVER_CONFIRM=${target_site}
  ./scripts/deploy-platform.sh resume-identity-transition

The resume operation queries the configured Segment1 DNS servers directly. The
deployment controller's local resolver is not a failover gate. Every configured
resolver must agree by default so partial DNS replication cannot split clients
between sites. With a ${dns_ttl_seconds}s TTL, normal convergence should typically
occur within about ${dns_convergence_grace}s. If it does not converge within
${dns_admin_validation_timeout}s after acknowledgement, the journal returns to
waiting-external and releases the transition lock so diagnostics can continue.
===========================================================
DNSACTION
}
cnpg_spec_promotion_token() {
  local site="${1:?identity site is required}" context
  context="$(identity_context "${site}")"
  kctl --context "${context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" \
    -o jsonpath='{.spec.replica.promotionToken}' 2>/dev/null || true
}

cnpg_last_promotion_token() {
  local site="${1:?identity site is required}" context
  context="$(identity_context "${site}")"
  kctl --context "${context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" \
    -o jsonpath='{.status.lastPromotionToken}' 2>/dev/null || true
}

clear_consumed_promotion_token() {
  local site="${1:?identity site is required}" context token
  context="$(identity_context "${site}")"
  token="$(cnpg_spec_promotion_token "${site}")"
  [[ -n "${token}" ]] || return 0

  # promotionToken is a one-shot handoff artifact in a controlled CNPG
  # distributed-topology switchover. Leaving it in the now-primary Cluster spec
  # makes the *next* demotion invalid because CNPG only permits promotionToken
  # while replica.primary points at self. Remove it immediately after the
  # operator records/consumes it so planned switchback remains reversible.
  kctl --context "${context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
    "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge \
    -p '{"spec":{"replica":{"promotionToken":null}}}' >/dev/null
  token="$(cnpg_spec_promotion_token "${site}")"
  [[ -z "${token}" ]] || die "${site}: consumed CloudNativePG promotionToken could not be cleared from the Cluster spec."
  log "${site}: consumed CloudNativePG promotion token removed from the steady-state primary spec."
}

wait_progress() {
  local gate="$1" started="$2" deadline="$3" detail="${4:-}"
  local elapsed=$((SECONDS - started)) remaining=$((deadline - SECONDS))
  (( remaining < 0 )) && remaining=0
  log "WAIT gate=${gate} elapsed=${elapsed}s remaining=${remaining}s${detail:+ ${detail}}"
}

usage() {
  cat <<USAGE
Usage:
  $0 <j64|j52|j64seg1opdev|j52seg1opdev>
  $0 active
  $0 exposure [all|j64|j52|j64seg1opdev|j52seg1opdev]
  $0 dns-status [active|j64|j52|j64seg1opdev|j52seg1opdev]
  $0 status
  $0 diagnose
  $0 resume
  $0 rollback

New transitions require IDENTITY_SWITCHOVER_CONFIRM=<target-site>.
Unplanned promotion additionally requires:
  IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
  IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
  an executable IDENTITY_HARD_FENCE_SOURCE_HOOK or legacy IDENTITY_SWITCHOVER_HOOK

active   Show the Fleet-declared active/writable identity site.
exposure Show per-site Keycloak Service/EndpointSlice/Certificate/HTTPProxy/direct OIDC state.
dns-status Show the canonical CNAME/A chain and direct/canonical OIDC state for a site.
status   Show the persistent Kubernetes operation journal and the next safe action (bounded/no-hang).
diagnose Print a bounded failover snapshot for Fleet, CNPG, Keycloak exposure, DNS, and OIDC.

Traffic cutover modes:
  dns-admin      Default. DNS Admins manually change the canonical CNAME between the J64/J52
                 ingress aliases. The workflow pauses at dns-cutover-pending and resumes only
                 after IDENTITY_TRAFFIC_CUTOVER_CONFIRM=<target>, then validates CNAME/A/OIDC.
  controller-dns Legacy/automation mode. The controller waits for canonical DNS to converge
                 without pausing for an external DNS-admin acknowledgement.
  manual/dns     Legacy values that both migrate to dns-admin. Use controller-dns explicitly for automation.
resume   Continue the last incomplete transition from its recorded stage.
rollback Restore the source only when the journal is still before database demotion.
USAGE
}

stage_rank() {
  case "${1:-}" in
    initialized) echo 0 ;;
    fleet-paused) echo 10 ;;
    source-traffic-quiesced) echo 20 ;;
    source-wal-fenced) echo 30 ;;
    source-hard-fenced) echo 35 ;;
    source-demoted) echo 40 ;;
    target-promoted) echo 50 ;;
    fleet-labels-switched) echo 60 ;;
    fleet-target-reconciled) echo 65 ;;
    target-keycloak-ready) echo 70 ;;
    dns-cutover-pending) echo 75 ;;
    traffic-activated) echo 80 ;;
    fleet-restored) echo 90 ;;
    verified) echo 100 ;;
    complete|complete-degraded|rolled-back) echo 110 ;;
    *) echo -1 ;;
  esac
}

journal_exists() {
  kctl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" >/dev/null 2>&1
}

journal_get() {
  local key="$1"
  kctl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" \
    -o "jsonpath={.data.${key}}" 2>/dev/null || true
}

normalize_identity_site() {
  case "${1:-}" in
    j64|j64seg1opdev) echo j64seg1opdev ;;
    j52|j52seg1opdev) echo j52seg1opdev ;;
    *) return 1 ;;
  esac
}

journal_status_is_terminal() {
  case "${1:-}" in
    complete|complete-degraded|rolled-back) return 0 ;;
    *) return 1 ;;
  esac
}

fleet_active_site() {
  local j64_json j52_json j64_primary j52_primary j64_active j52_active
  j64_json="$(fleet_cluster_json fleet-default "${FLEET_J64_APP_DISPLAY_NAME}" "${management_context}")"
  j52_json="$(fleet_cluster_json fleet-default "${FLEET_J52_APP_DISPLAY_NAME}" "${management_context}")"
  j64_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j64_json}")"
  j52_primary="$(jq -r '.metadata.labels["kmm.dev/postgres-primary-site"] // ""' <<<"${j52_json}")"
  j64_active="$(jq -r '.metadata.labels["kmm.dev/identity-active"] // "false"' <<<"${j64_json}")"
  j52_active="$(jq -r '.metadata.labels["kmm.dev/identity-active"] // "false"' <<<"${j52_json}")"

  [[ -n "${j64_primary}" && "${j64_primary}" == "${j52_primary}" ]] || \
    die "Fleet identity sites disagree on kmm.dev/postgres-primary-site (J64=${j64_primary:-unset}, J52=${j52_primary:-unset})."
  [[ "${j64_primary}" == j64seg1opdev || "${j64_primary}" == j52seg1opdev ]] || \
    die "Fleet reports unsupported identity primary site ${j64_primary:-unset}."
  if [[ "${j64_primary}" == j64seg1opdev ]]; then
    [[ "${j64_active}" == true && "${j52_active}" != true ]] || \
      die "Fleet role labels are inconsistent: primary=${j64_primary}, J64 active=${j64_active}, J52 active=${j52_active}."
  else
    [[ "${j52_active}" == true && "${j64_active}" != true ]] || \
      die "Fleet role labels are inconsistent: primary=${j64_primary}, J64 active=${j64_active}, J52 active=${j52_active}."
  fi
  printf '%s\n' "${j64_primary}"
}

show_active_site() {
  local active peer
  active="$(fleet_active_site)"
  peer="$(identity_peer_site "${active}")"
  echo "activeSite=${active}"
  echo "standbySite=${peer}"
  echo "activeIngressIP=$(identity_ingress_ip "${active}")"
  echo "activeIngressCNAME=$(identity_ingress_cname "${active}")"
  echo "standbyIngressIP=$(identity_ingress_ip "${peer}")"
  echo "standbyIngressCNAME=$(identity_ingress_cname "${peer}")"
  if journal_exists; then
    echo "journalStatus=$(journal_get status)"
    echo "journalStage=$(journal_get stage)"
    echo "journalTarget=$(journal_get targetSite)"
  else
    echo "journalStatus=none"
  fi
}

identity_ready_endpoint_count() {
  local site="${1:?identity site is required}" context
  context="$(identity_context "${site}")"
  kctl --context "${context}" -n opkeycloak get endpointslices.discovery.k8s.io \
    -l kubernetes.io/service-name=opkeycloak-service -o json 2>/dev/null | \
    jq -r '[.items[].endpoints[]? | select((.conditions.ready // true) == true)] | length' 2>/dev/null || echo 0
}

identity_direct_https_health() {
  local site="${1:?identity site is required}" expected_ip
  expected_ip="$(identity_ingress_ip "${site}")"
  [[ -f "${CA_CERT_FILE}" ]] || return 1
  curl --fail --silent --show-error --max-time 10 \
    --resolve "${IDENTITY_CANONICAL_HOST}:443:${expected_ip}" \
    --cacert "${CA_CERT_FILE}" \
    "https://${IDENTITY_CANONICAL_HOST}${health_path}" >/dev/null 2>&1
}

show_exposure_site() {
  local site="${1:?identity site is required}" context resource instances service_port endpoint_count cert_ready proxy_status proxy_ip direct_health
  context="$(identity_context "${site}")"
  resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${site}")" "${management_context}")"
  instances="$(kctl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/keycloak-instances}' 2>/dev/null || true)"
  service_port="$(kctl --context "${context}" -n opkeycloak get service opkeycloak-service \
    -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
  endpoint_count="$(identity_ready_endpoint_count "${site}")"
  cert_ready="$(kctl --context "${context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
  proxy_status="$(kctl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
  proxy_ip="$(kctl --context "${context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  if identity_direct_https_health "${site}"; then direct_health=healthy; else direct_health=unhealthy; fi

  echo "site=${site}"
  echo "ingressIP=$(identity_ingress_ip "${site}")"
  echo "fleetKeycloakInstances=${instances:-unset}"
  echo "service8080=$([[ "${service_port}" == 8080 ]] && echo present || echo missing)"
  echo "readyEndpoints=${endpoint_count:-0}"
  echo "certificateReady=${cert_ready:-missing}"
  echo "httpProxyStatus=${proxy_status:-missing}"
  echo "httpProxyVIP=${proxy_ip:-missing}"
  echo "directOIDC=${direct_health}"
  echo "probe=curl --resolve ${IDENTITY_CANONICAL_HOST}:443:$(identity_ingress_ip "${site}") --cacert ${CA_CERT_FILE} https://${IDENTITY_CANONICAL_HOST}${health_path}"
  echo "rawIPNote=Do not browse https://$(identity_ingress_ip "${site}") as a Keycloak health test; HTTPProxy routing/TLS is FQDN+SNI based."
}

show_exposure_status() {
  local requested="${1:-all}" site
  case "${requested}" in
    all)
      show_exposure_site j64seg1opdev
      echo
      show_exposure_site j52seg1opdev
      ;;
    *)
      site="$(normalize_identity_site "${requested}")" || die "Exposure target must be all, j64, j52, j64seg1opdev, or j52seg1opdev."
      show_exposure_site "${site}"
      ;;
  esac
}

guard_new_operation_against_journal() {
  local requested_target="$1" existing_status existing_stage existing_source existing_target existing_operation holder
  journal_exists || return 0
  existing_status="$(journal_get status)"
  existing_stage="$(journal_get stage)"
  existing_source="$(journal_get sourceSite)"
  existing_target="$(journal_get targetSite)"
  existing_operation="$(journal_get operationId)"

  if ! journal_status_is_terminal "${existing_status}"; then
    die "Cannot start a new identity switch to ${requested_target}: existing transition ${existing_operation:-unknown} is ${existing_status:-unknown} at stage ${existing_stage:-unknown} (${existing_source:-unknown} -> ${existing_target:-unknown}). Complete it first with: export IDENTITY_SWITCHOVER_CONFIRM=${existing_target}; ./scripts/deploy-platform.sh resume-identity-transition"
  fi

  # A terminal journal should not retain the transition Lease. If a prior
  # process exited after journaling completion but before deleting its Lease,
  # clean only the Lease owned by that terminal operation.
  holder="$(lock_holder)"
  if [[ -n "${holder}" && "${holder}" == "${existing_operation}" ]]; then
    kctl --context "${management_context}" -n "${journal_namespace}" delete \
      lease.coordination.k8s.io "${lock_name}" --ignore-not-found >/dev/null
    log "Removed stale transition Lease for terminal operation ${existing_operation}."
  fi
}

write_journal() {
  kctl --context "${management_context}" -n "${journal_namespace}" create configmap "${journal_name}" \
    --from-literal=operationId="${operation_id}" \
    --from-literal=status="${operation_status}" \
    --from-literal=stage="${current_stage}" \
    --from-literal=mode="${mode}" \
    --from-literal=trafficCutoverMode="${traffic_cutover_mode}" \
    --from-literal=dnsTTLSeconds="${dns_ttl_seconds}" \
    --from-literal=sourceSite="${source_site}" \
    --from-literal=targetSite="${target_site}" \
    --from-literal=originalFleetPaused="${original_fleet_paused}" \
    --from-literal=sourceKeycloakInstances="${source_keycloak_instances}" \
    --from-literal=updatedAt="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --dry-run=client -o yaml | \
    kctl --context "${management_context}" -n "${journal_namespace}" apply -f - >/dev/null
}

set_stage() {
  current_stage="$1"
  operation_status="${2:-running}"
  write_journal
  log "Identity transition journal: stage=${current_stage} status=${operation_status}."
}

transition_diagnostic_snapshot() {
  local label="${1:-snapshot}" expected_ip source_phase target_phase source_primary target_primary
  local target_endpoints cert_ready proxy_status proxy_ip direct_health controller_resolved paused active
  local expected_cname cname_tool controller_health dns_overall
  local source_promotion_token target_promotion_token source_last_promotion_token target_last_promotion_token
  expected_ip="$(identity_ingress_ip "${target_site}")"
  expected_cname="$(identity_ingress_cname "${target_site}")"
  cname_tool="$(dns_cname_query_tool)"
  controller_resolved="$(controller_resolved_ipv4_csv)"
  paused="$(fleet_is_paused 2>/dev/null || echo unknown)"
  active="$(fleet_active_site 2>/dev/null || echo unknown)"
  source_phase="$(kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  target_phase="$(kctl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  source_primary="$(kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  target_primary="$(kctl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}' 2>/dev/null || true)"
  target_endpoints="$(identity_ready_endpoint_count "${target_site}" 2>/dev/null || echo 0)"
  cert_ready="$(kctl --context "${target_context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
  proxy_status="$(kctl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
  proxy_ip="$(kctl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || true)"
  if identity_direct_https_health "${target_site}"; then direct_health=healthy; else direct_health=unhealthy; fi
  if identity_canonical_https_health; then controller_health=healthy; else controller_health=unhealthy; fi
  if segment1_dns_evaluate "${expected_cname}" "${expected_ip}"; then dns_overall=match; else dns_overall="${SEGMENT1_DNS_OVERALL}"; fi

  echo "--- Identity transition diagnostic: ${label} ---"
  echo "operationId=${operation_id:-none} status=${operation_status:-none} stage=${current_stage:-none} mode=${mode:-unknown}"
  echo "source=${source_site} target=${target_site} activeFleetSite=${active} fleetPaused=${paused}"
  source_promotion_token="$(cnpg_spec_promotion_token "${source_site}")"
  target_promotion_token="$(cnpg_spec_promotion_token "${target_site}")"
  source_last_promotion_token="$(cnpg_last_promotion_token "${source_site}")"
  target_last_promotion_token="$(cnpg_last_promotion_token "${target_site}")"
  echo "sourceCNPGPhase=${source_phase:-missing} sourceReplicaPrimary=${source_primary:-unset} sourcePromotionToken=$([[ -n "${source_promotion_token}" ]] && echo present || echo absent) sourceLastPromotionToken=$([[ -n "${source_last_promotion_token}" ]] && echo present || echo absent)"
  echo "targetCNPGPhase=${target_phase:-missing} targetReplicaPrimary=${target_primary:-unset} targetPromotionToken=$([[ -n "${target_promotion_token}" ]] && echo present || echo absent) targetLastPromotionToken=$([[ -n "${target_last_promotion_token}" ]] && echo present || echo absent)"
  echo "targetIngressIP=${expected_ip} targetIngressCNAME=${expected_cname} targetReadyEndpoints=${target_endpoints:-0} certificateReady=${cert_ready:-missing} httpProxyStatus=${proxy_status:-missing} httpProxyVIP=${proxy_ip:-missing} directOIDC=${direct_health}"
  echo "segment1DNS=${dns_overall} dnsServers=$(IFS=,; echo "${identity_dns_servers[*]}") dnsRequireAll=${identity_dns_require_all} dnsQueryTool=${cname_tool} dnsTTL=${dns_ttl_seconds}s dnsGrace=${dns_convergence_grace}s dnsAdminTimeout=${dns_admin_validation_timeout}s trafficMode=${traffic_cutover_mode}"
  echo "segment1DNSDetail=${SEGMENT1_DNS_DETAILS:-none}"
  echo "controllerDNS=${controller_resolved:-unresolved} controllerCanonicalOIDC=${controller_health} controllerResolverGate=false"
}
show_diagnostics() {
  if journal_exists; then
    load_journal
  else
    target_site="$(identity_peer_site "$(fleet_active_site)")"
    source_site="$(identity_peer_site "${target_site}")"
    source_context="$(identity_context "${source_site}")"
    target_context="$(identity_context "${target_site}")"
    operation_id=none
    operation_status=none
    current_stage=none
    mode="${IDENTITY_SWITCHOVER_MODE:-planned}"
    original_fleet_paused="$(fleet_is_paused)"
  fi
  transition_diagnostic_snapshot operator-requested
  echo
  show_exposure_status all
  echo
  show_dns_status "${target_site}"
}

show_status() {
  local status stage target expected_ip
  if ! journal_exists; then
    echo "No identity transition journal exists in ${journal_namespace}/${journal_name}."
    show_active_site
    return 0
  fi
  kctl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" \
    -o go-template='operationId={{index .data "operationId"}}{{"\n"}}status={{index .data "status"}}{{"\n"}}stage={{index .data "stage"}}{{"\n"}}mode={{index .data "mode"}}{{"\n"}}trafficCutoverMode={{index .data "trafficCutoverMode"}}{{"\n"}}source={{index .data "sourceSite"}}{{"\n"}}target={{index .data "targetSite"}}{{"\n"}}originalFleetPaused={{index .data "originalFleetPaused"}}{{"\n"}}updatedAt={{index .data "updatedAt"}}{{"\n"}}'
  status="$(journal_get status)"
  stage="$(journal_get stage)"
  target="$(journal_get targetSite)"
  if ! journal_status_is_terminal "${status}"; then
    echo "nextAction=resume"
    echo "resumeCommand=export IDENTITY_SWITCHOVER_CONFIRM=${target}; ./scripts/deploy-platform.sh resume-identity-transition"
    if [[ "${stage}" == target-keycloak-ready || "$(stage_rank "${stage}")" -ge "$(stage_rank target-keycloak-ready)" ]]; then
      expected_ip="$(identity_ingress_ip "${target}")"
      echo "trafficTarget=${IDENTITY_CANONICAL_HOST}"
      echo "trafficTargetCNAME=$(identity_ingress_cname "${target}")"
      echo "trafficTargetIP=${expected_ip}"
      echo "trafficCutoverMode=${traffic_cutover_mode}"
      echo "trafficNote=DNS is a manually administered CNAME gate. Segment1 DNS servers are authoritative for validation; the controller local resolver is informational only. Raw-IP browser requests are not valid HTTPProxy tests."
      show_dns_status "${target}"
      echo "dnsAdminResume=export IDENTITY_SWITCHOVER_CONFIRM=${target} IDENTITY_TRAFFIC_CUTOVER_CONFIRM=${target}; ./scripts/deploy-platform.sh resume-identity-transition"
      if [[ "${stage}" == dns-cutover-pending || "${status}" == waiting-external ]]; then
        echo "nextExternalAction=DNS Admin changes ${IDENTITY_CANONICAL_HOST} CNAME to $(identity_ingress_cname "${target}") and verifies all configured Segment1 DNS servers"
      fi
    fi
  fi
}
lock_holder() {
  kctl --context "${management_context}" -n "${journal_namespace}" get lease.coordination.k8s.io "${lock_name}" \
    -o jsonpath='{.spec.holderIdentity}' 2>/dev/null || true
}

# coordination.k8s.io/v1 Lease timestamps are metav1.MicroTime values.  The
# Kubernetes API decoder expects six fractional digits, so a plain RFC3339
# value such as 2026-09-08T16:55:29Z is rejected.  Millisecond/nanosecond
# precision is unnecessary for this operator lock; fixed microsecond zeroes
# provide the canonical wire format portably on the Ubuntu administration
# host without depending on GNU date %N support.
k8s_microtime_now() {
  date -u +%Y-%m-%dT%H:%M:%S.000000Z
}

acquire_lock() {
  local existing
  existing="$(lock_holder)"
  if [[ -n "${existing}" ]]; then
    [[ "${existing}" == "${operation_id}" ]] || \
      die "Identity transition lock ${journal_namespace}/${lock_name} is held by ${existing}. Run '$0 status'."
    return 0
  fi
  cat <<YAML | kctl --context "${management_context}" -n "${journal_namespace}" create -f - >/dev/null
apiVersion: coordination.k8s.io/v1
kind: Lease
metadata:
  name: ${lock_name}
  namespace: ${journal_namespace}
spec:
  holderIdentity: ${operation_id}
  leaseDurationSeconds: 3600
  acquireTime: "$(k8s_microtime_now)"
  renewTime: "$(k8s_microtime_now)"
YAML
}

release_lock() {
  local existing
  existing="$(lock_holder)"
  if [[ -n "${existing}" && "${existing}" == "${operation_id}" ]]; then
    kctl --context "${management_context}" -n "${journal_namespace}" delete \
      lease.coordination.k8s.io "${lock_name}" --ignore-not-found >/dev/null
  fi
}

renew_lock() {
  kctl --context "${management_context}" -n "${journal_namespace}" patch \
    lease.coordination.k8s.io "${lock_name}" --type merge \
    -p "{\"spec\":{\"holderIdentity\":\"${operation_id}\",\"renewTime\":\"$(k8s_microtime_now)\"}}" >/dev/null
}

fleet_is_paused() {
  local value
  value="$(kctl --context "${management_context}" -n fleet-default get gitrepo "${gitrepo_name}" \
    -o jsonpath='{.spec.paused}' 2>/dev/null || true)"
  [[ "${value}" == "true" ]] && echo true || echo false
}

pause_fleet() {
  kctl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p '{"spec":{"paused":true}}' >/dev/null
}

restore_fleet_pause_state() {
  kctl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p "{\"spec\":{\"paused\":${original_fleet_paused}}}" >/dev/null
}

wait_for_no_pods() {
  local context="$1" namespace="$2" selector="$3" started=${SECONDS} deadline=$((SECONDS + 600)) next_report=${SECONDS} count
  while :; do
    count="$(kctl --context "${context}" -n "${namespace}" get pods -l "${selector}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${count}" == "0" ]] && { log "${context}/${namespace}: source Keycloak pods are stopped."; return 0; }
    (( SECONDS < deadline )) || die "Timed out waiting for ${context}/${namespace} pods to stop (${selector})."
    if (( SECONDS >= next_report )); then
      wait_progress source-keycloak-quiesce "${started}" "${deadline}" "podsRemaining=${count}"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done
}
run_phase_hook() {
  # With `set -u`, Bash expands every RHS in a `local` command before the
  # assignments from that same command are guaranteed to be visible.  Keep
  # dependent locals on separate statements so legacy_phase never reads an
  # unbound phase during resume/new transitions.
  local phase="$1"
  local hook=""
  local legacy_phase="${phase}"
  case "${phase}" in
    quiesce-source-traffic)
      hook="${IDENTITY_QUIESCE_SOURCE_HOOK:-}"
      ;;
    hard-fence-source)
      hook="${IDENTITY_HARD_FENCE_SOURCE_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}"
      legacy_phase=fence-source
      ;;
    activate-target)
      hook="${IDENTITY_ACTIVATE_TARGET_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}"
      legacy_phase=activate-target
      ;;
    restore-source-traffic)
      hook="${IDENTITY_RESTORE_SOURCE_HOOK:-}"
      ;;
    *) die "Unsupported identity traffic hook phase: ${phase}" ;;
  esac

  [[ -n "${hook}" ]] || return 0
  [[ -x "${hook}" ]] || die "Identity ${phase} hook is not executable: ${hook}"

  IDENTITY_SWITCHOVER_PHASE="${phase}" \
  IDENTITY_FAILOVER_PHASE="${legacy_phase}" \
  IDENTITY_SWITCHOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_FAILOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_SWITCHOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_FAILOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_SWITCHOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_FAILOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_SWITCHOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_FAILOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_SWITCHOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST}" \
  IDENTITY_FAILOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST}" \
    "${hook}"
}

validate_target_exposure() {
  local cert_ready proxy_status proxy_description service_port
  service_port="$(kctl --context "${target_context}" -n opkeycloak get service opkeycloak-service \
    -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
  [[ "${service_port}" == "8080" ]] || die "${target_site}: active Keycloak Service is missing TCP/8080."
  cert_ready="$(kctl --context "${target_context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
  [[ "${cert_ready}" == "True" ]] || die "${target_site}: Keycloak TLS Certificate is not Ready."
  proxy_status="$(kctl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
  proxy_description="$(kctl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.description}' 2>/dev/null || true)"
  [[ "${proxy_status,,}" == "valid" ]] || \
    die "${target_site}: Keycloak HTTPProxy status=${proxy_status:-missing}: ${proxy_description:-no description}."
}

wait_for_target_exposure() {
  local started=${SECONDS} deadline=$((SECONDS + target_exposure_timeout)) next_report=${SECONDS}
  local cert_ready proxy_status service_port endpoint_count
  log "Waiting for target Keycloak exposure on ${target_site}; timeout=${target_exposure_timeout}s."
  while (( SECONDS < deadline )); do
    service_port="$(kctl --context "${target_context}" -n opkeycloak get service opkeycloak-service \
      -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
    cert_ready="$(kctl --context "${target_context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
      -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
    proxy_status="$(kctl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
      -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
    endpoint_count="$(identity_ready_endpoint_count "${target_site}")"
    if [[ "${service_port}" == "8080" && "${cert_ready}" == "True" && "${proxy_status,,}" == "valid" && "${endpoint_count:-0}" -gt 0 ]]; then
      log "${target_site}: target Keycloak Service, endpoints, TLS Certificate, and HTTPProxy are Ready."
      return 0
    fi
    if (( SECONDS >= next_report )); then
      wait_progress target-exposure "${started}" "${deadline}" "service8080=${service_port:-missing} endpoints=${endpoint_count:-0} cert=${cert_ready:-missing} httpproxy=${proxy_status:-missing}"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done
  transition_diagnostic_snapshot target-exposure-timeout >&2 || true
  validate_target_exposure
}
wait_for_target_https_health() {
  local expected_ip started=${SECONDS} deadline=$((SECONDS + traffic_timeout)) next_report=${SECONDS}
  expected_ip="$(identity_ingress_ip "${target_site}")"
  log "Waiting for direct target TLS/OIDC health using canonical SNI; target=${target_site} vip=${expected_ip} timeout=${traffic_timeout}s."
  while (( SECONDS < deadline )); do
    if identity_direct_https_health "${target_site}"; then
      log "Target identity HTTPS/OIDC pre-cutover gate passed: ${IDENTITY_CANONICAL_HOST} via ${target_site} (${expected_ip})."
      return 0
    fi
    if (( SECONDS >= next_report )); then
      wait_progress target-oidc "${started}" "${deadline}" "vip=${expected_ip} directOIDC=unhealthy"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done
  transition_diagnostic_snapshot target-oidc-timeout >&2 || true
  die "${target_site}: target HTTPS/OIDC endpoint did not become healthy on ${expected_ip} within ${traffic_timeout}s; DNS/hosts must not be cut over yet."
}
wait_for_traffic_cutover() {
  local expected_ip expected_cname deadline confirmed_site started next_report direct_state controller_state dns_overall
  local grace_warned=false effective_timeout
  expected_ip="$(identity_ingress_ip "${target_site}")"
  expected_cname="$(identity_ingress_cname "${target_site}")"

  if [[ "${traffic_cutover_mode}" == dns-admin ]]; then
    confirmed_site="$(normalize_identity_site "${IDENTITY_TRAFFIC_CUTOVER_CONFIRM:-}" 2>/dev/null || true)"
    [[ "${confirmed_site}" == "${target_site}" ]] || \
      die "DNS-admin traffic cutover requires IDENTITY_TRAFFIC_CUTOVER_CONFIRM=${target_site} after the DNS Admin changes ${IDENTITY_CANONICAL_HOST} CNAME to ${expected_cname}."
    identity_direct_https_health "${target_site}" || {
      transition_diagnostic_snapshot dns-admin-target-failed >&2 || true
      die "DNS cutover was acknowledged, but the target HTTPS/OIDC path is not healthy on ${expected_ip}. Do not change DNS again; repair target exposure and resume the same journal."
    }
    effective_timeout="${dns_admin_validation_timeout}"
    log "DNS Admin change acknowledged for ${target_site}; validating ${IDENTITY_CANONICAL_HOST} directly against Segment1 DNS servers $(IFS=,; echo "${identity_dns_servers[*]}"). TTL=${dns_ttl_seconds}s grace=${dns_convergence_grace}s timeout=${effective_timeout}s."
  else
    effective_timeout="${traffic_timeout}"
    log "Controller-DNS mode: waiting for canonical DNS/TLS/OIDC convergence to ${target_site}; timeout=${effective_timeout}s."
  fi

  started=${SECONDS}
  deadline=$((SECONDS + effective_timeout))
  next_report=${SECONDS}
  transition_diagnostic_snapshot dns-traffic-precheck
  while (( SECONDS < deadline )); do
    direct_state=unhealthy
    controller_state=unhealthy
    identity_direct_https_health "${target_site}" && direct_state=healthy
    identity_canonical_https_health && controller_state=healthy
    if segment1_dns_evaluate "${expected_cname}" "${expected_ip}"; then
      dns_overall=match
    else
      dns_overall="${SEGMENT1_DNS_OVERALL}"
    fi

    if [[ "${dns_overall}" == match && "${direct_state}" == healthy ]]; then
      log "Identity traffic DNS gate passed: all required Segment1 DNS views resolve ${IDENTITY_CANONICAL_HOST} through ${expected_cname} to ${expected_ip}; target OIDC is healthy."
      [[ "${controller_state}" == healthy ]] || warn "The deployment controller's local resolver still cannot use the canonical hostname. This is informational only; Segment1 DNS validation passed."
      return 0
    fi

    if [[ "${traffic_cutover_mode}" == dns-admin && "${grace_warned}" == false && $((SECONDS - started)) -ge ${dns_convergence_grace} ]]; then
      warn "Segment1 DNS convergence exceeded the expected ${dns_convergence_grace}s window (${dns_ttl_seconds}s TTL). Expected CNAME=${expected_cname} and IP=${expected_ip}. ${SEGMENT1_DNS_DETAILS}"
      grace_warned=true
    fi

    if (( SECONDS >= next_report )); then
      wait_progress dns-cname-tls-oidc "${started}" "${deadline}" "segment1DNS=${dns_overall} expectedCNAME=${expected_cname} expectedIP=${expected_ip} directTargetOIDC=${direct_state} controllerCanonicalOIDC=${controller_state} details=${SEGMENT1_DNS_DETAILS}"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done

  if [[ "${traffic_cutover_mode}" == dns-admin ]]; then
    operation_status=waiting-external
    current_stage=dns-cutover-pending
    write_journal
    transition_diagnostic_snapshot dns-traffic-waiting-external >&2 || true
    warn "Segment1 DNS did not converge within ${effective_timeout}s after acknowledgement. The database and target Keycloak remain in the promoted state; the journal is back at waiting-external. Correct DNS and resume the same transition."
    return 2
  fi

  transition_diagnostic_snapshot dns-traffic-timeout >&2 || true
  die "Canonical identity traffic did not converge within ${effective_timeout}s. Expected ${IDENTITY_CANONICAL_HOST} CNAME=${expected_cname} and target-only resolution ${expected_ip}."
}
wait_for_fleet_identity_reconciliation() {
  local started=${SECONDS} deadline=$((SECONDS + fleet_reconcile_timeout)) next_report=${SECONDS}
  local bundle state all_ready states=""
  [[ "${original_fleet_paused}" == "false" ]] || {
    warn "Fleet was already paused before the transition; preserving that state and skipping Fleet reconciliation gating."
    return 0
  }
  log "Waiting for Fleet identity bundles to reconcile; timeout=${fleet_reconcile_timeout}s."
  while (( SECONDS < deadline )); do
    all_ready=true
    states=""
    for bundle in oppostgres oppostgres-replica opkeycloak opkeycloak-secondary; do
      state="$(kctl --context "${management_context}" -n fleet-default get bundle "${bundle}" -o json 2>/dev/null | \
        jq -r '[.status.conditions[]? | select(.type == "Ready")][0].status // "Unknown"' 2>/dev/null || true)"
      states+="${bundle}=${state:-Unknown} "
      [[ "${state}" == "True" ]] || all_ready=false
    done
    [[ "${all_ready}" == true ]] && { log "Fleet identity bundles are reconciled: ${states}"; return 0; }
    if (( SECONDS >= next_report )); then
      wait_progress fleet-reconcile "${started}" "${deadline}" "${states}"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done
  transition_diagnostic_snapshot fleet-reconcile-timeout >&2 || true
  die "Fleet identity bundles did not reconcile within ${fleet_reconcile_timeout}s after the post-promotion role-label switch."
}

wait_for_keycloak_ready() {
  local started=${SECONDS} deadline=$((SECONDS + target_exposure_timeout)) next_report=${SECONDS}
  local ready endpoint_count
  log "Waiting for ${target_site} Keycloak CR Ready; timeout=${target_exposure_timeout}s."
  while (( SECONDS < deadline )); do
    ready="$(kctl --context "${target_context}" -n opkeycloak get keycloak opkeycloak -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
    endpoint_count="$(identity_ready_endpoint_count "${target_site}" 2>/dev/null || echo 0)"
    if [[ "${ready}" == True && "${endpoint_count:-0}" -gt 0 ]]; then
      log "${target_site}: Keycloak CR is Ready with ${endpoint_count} ready endpoint(s)."
      return 0
    fi
    if (( SECONDS >= next_report )); then
      wait_progress keycloak-ready "${started}" "${deadline}" "condition=${ready:-missing} endpoints=${endpoint_count:-0}"
      next_report=$((SECONDS + diagnostic_interval))
    fi
    sleep "${poll_interval}"
  done
  transition_diagnostic_snapshot keycloak-ready-timeout >&2 || true
  die "Timed out waiting for ${target_site} Keycloak Ready after ${target_exposure_timeout}s."
}

load_journal() {
  journal_exists || die "No identity transition journal exists."
  operation_id="$(journal_get operationId)"
  operation_status="$(journal_get status)"
  current_stage="$(journal_get stage)"
  mode="$(journal_get mode)"
  journal_traffic_cutover_mode="$(journal_get trafficCutoverMode)"
  if [[ -z "${IDENTITY_TRAFFIC_CUTOVER_MODE:-}" && -n "${journal_traffic_cutover_mode}" ]]; then
    case "${journal_traffic_cutover_mode}" in
      dns-admin|manual|dns) traffic_cutover_mode=dns-admin ;;
      controller-dns) traffic_cutover_mode=controller-dns ;;
    esac
  fi
  source_site="$(journal_get sourceSite)"
  target_site="$(journal_get targetSite)"
  original_fleet_paused="$(journal_get originalFleetPaused)"
  source_keycloak_instances="$(journal_get sourceKeycloakInstances)"
  [[ -n "${operation_id}" && -n "${current_stage}" && -n "${source_site}" && -n "${target_site}" ]] || \
    die "Identity transition journal is incomplete/corrupt."
  source_context="$(identity_context "${source_site}")"
  target_context="$(identity_context "${target_site}")"
}

fleet_topology_label() {
  local resource="${1:?Fleet cluster resource is required}"
  kctl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/postgres-distributed-topology}' 2>/dev/null || true
}

topology_labels_enrolled() {
  [[ "$(fleet_topology_label "${source_resource}")" == true && \
     "$(fleet_topology_label "${target_resource}")" == true ]]
}

ensure_planned_topology_enrolled() {
  [[ "${mode}" == planned ]] || return 0
  topology_labels_enrolled && return 0

  if [[ "${source_site}" == j64seg1opdev && "${target_site}" == j52seg1opdev ]]; then
    [[ "${auto_enroll_topology}" == true ]] || \
      die "Planned J64->J52 switchover requires distributed PostgreSQL enrollment. Run './scripts/deploy-platform.sh enable-identity-secondary' or set IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY=true."
    warn "Streaming replication is available but Fleet distributed-topology enrollment is incomplete; enrolling J64/J52 before the planned switchover."
    "${SCRIPT_DIR}/../fleet/05-enable-identity-secondary.sh"
    source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${management_context}")"
    target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${management_context}")"
    topology_labels_enrolled || \
      die "Automatic distributed-topology enrollment completed without setting both Fleet topology labels. Re-run './scripts/deploy-platform.sh enable-identity-secondary' and inspect Fleet reconciliation."
    log "Distributed PostgreSQL topology is enrolled and ready for planned switchover."
    return 0
  fi

  die "Distributed PostgreSQL topology is not enrolled for ${source_site} -> ${target_site}. Restore/rebuild the warm standby before failback; automatic enrollment is only safe for the initial planned J64->J52 transition."
}

validate_topology_preconditions() {
  local allow_already_promoted="${1:-false}" source_topology target_topology target_primary
  source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${management_context}")"
  target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${management_context}")"

  ensure_planned_topology_enrolled
  source_topology="$(fleet_topology_label "${source_resource}")"
  target_topology="$(fleet_topology_label "${target_resource}")"
  [[ "${source_topology}" == true ]] || \
    die "${source_site} (Fleet ${source_resource}) is not enrolled in the distributed PostgreSQL topology."
  [[ "${target_topology}" == true ]] || \
    die "${target_site} (Fleet ${target_resource}) is not enrolled in the distributed PostgreSQL topology."

  target_primary="$(kctl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}')"
  if [[ "${target_primary}" == "${target_site}" && "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == "f" ]]; then
    [[ "${allow_already_promoted}" == true ]] && return 0
    die "${target_site} is already the writable identity database site."
  fi
  [[ "${target_primary}" == "${source_site}" ]] || \
    die "Target database reports distributed primary ${target_primary:-unset}; expected ${source_site}."
}

initialize_new_operation() {
  local confirmed_site declared_active_site
  target_site="$(normalize_identity_site "$1")" || { usage; exit 2; }
  guard_new_operation_against_journal "${target_site}"
  source_site="$(identity_peer_site "${target_site}")"
  source_context="$(identity_context "${source_site}")"
  target_context="$(identity_context "${target_site}")"
  declared_active_site="$(fleet_active_site)"
  [[ "${declared_active_site}" != "${target_site}" ]] || \
    die "${target_site} is already the Fleet-declared active identity site; no switch is required."
  [[ "${declared_active_site}" == "${source_site}" ]] || \
    die "Fleet declares ${declared_active_site} active, but a switch to ${target_site} expects source ${source_site}. Resolve role-label drift before continuing."
  confirmed_site="$(normalize_identity_site "${IDENTITY_SWITCHOVER_CONFIRM:-}" 2>/dev/null || true)"
  [[ "${confirmed_site}" == "${target_site}" ]] || \
    die "Set IDENTITY_SWITCHOVER_CONFIRM=${target_site} to acknowledge this identity role transition."

  source_available=false
  if kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
    source_available=true
  fi

  mode="${IDENTITY_SWITCHOVER_MODE:-${IDENTITY_FAILOVER_MODE:-auto}}"
  if [[ "${mode}" == "auto" ]]; then
    [[ "${source_available}" == true ]] && mode=planned || mode=unplanned
  fi
  [[ "${mode}" == planned || "${mode}" == unplanned ]] || \
    die "IDENTITY_SWITCHOVER_MODE must be auto, planned, or unplanned."
  [[ "${mode}" != planned || "${source_available}" == true ]] || \
    die "Planned switchover requires the current primary site to be reachable."

  if [[ "${mode}" == unplanned ]]; then
    [[ "${IDENTITY_ALLOW_UNPLANNED_FAILOVER:-false}" == true ]] || \
      die "Unplanned failover can lose transactions. Set IDENTITY_ALLOW_UNPLANNED_FAILOVER=true to proceed."
    [[ "${IDENTITY_UNPLANNED_RPO_ACK:-}" == "I_ACCEPT_POSSIBLE_DATA_LOSS" ]] || \
      die "Set IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS after reviewing the standby replay position."
    [[ -n "${IDENTITY_HARD_FENCE_SOURCE_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}" ]] || \
      die "Unplanned failover requires an executable hard-fence hook before target promotion."
  fi

  validate_topology_preconditions
  original_fleet_paused="$(fleet_is_paused)"
  if [[ "${mode}" == planned && "${original_fleet_paused}" == true ]]; then
    die "Planned switchover requires downstream Fleet to be active before the transition. Unpause ${gitrepo_name}, wait for reconciliation, then retry."
  fi
  if [[ "${mode}" == planned ]]; then
    # The warm site must already own a valid canonical TLS certificate and
    # HTTPProxy before we quiesce the source. Exposure resources are staged on
    # both identity sites even when Keycloak instances=0.
    validate_target_exposure
  fi
  operation_id="identity-$(date -u +%Y%m%dT%H%M%SZ)-$$"
  source_keycloak_instances="$(kctl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${source_resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/keycloak-instances}' 2>/dev/null || true)"
  source_keycloak_instances="${source_keycloak_instances:-3}"
  current_stage=initialized
  operation_status=running
  acquire_lock
  write_journal
  transition_diagnostic_snapshot new-transition-preflight
}

prepare_resume() {
  local confirmed_site
  load_journal
  case "${operation_status}" in
    complete|complete-degraded|rolled-back) die "Journal status is ${operation_status}; there is no incomplete transition to resume." ;;
  esac
  confirmed_site="$(normalize_identity_site "${IDENTITY_SWITCHOVER_CONFIRM:-}" 2>/dev/null || true)"
  [[ "${confirmed_site}" == "${target_site}" ]] || \
    die "Set IDENTITY_SWITCHOVER_CONFIRM=${target_site} before resuming this transition."
  acquire_lock
  operation_status=running
  write_journal
  # A resume at/after target promotion must accept the target already being
  # writable. Before that point, enforce the original source->target topology.
  if (( $(stage_rank "${current_stage}") >= $(stage_rank target-promoted) )); then
    validate_topology_preconditions true
  else
    validate_topology_preconditions false
  fi
  transition_diagnostic_snapshot resume-preflight
}

rollback_operation() {
  load_journal
  local rank
  rank="$(stage_rank "${current_stage}")"
  (( rank >= 0 && rank < $(stage_rank source-demoted) )) || \
    die "Rollback is only supported before source database demotion; journal stage is ${current_stage}."
  [[ "${mode}" == planned ]] || \
    die "Automatic source rollback is not permitted for an unplanned failover/fence operation."
  acquire_lock

  if kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
    identity_sql "${source_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true' >/dev/null || true
    kctl --context "${source_context}" -n opkeycloak patch keycloak opkeycloak --type merge \
      -p "{\"spec\":{\"instances\":${source_keycloak_instances}}}" >/dev/null || true
  fi
  run_phase_hook restore-source-traffic || warn "restore-source-traffic hook failed; inspect external routing before returning service."
  restore_fleet_pause_state
  current_stage=rolled-back
  operation_status=rolled-back
  write_journal
  release_lock
  log "Pre-demotion identity transition rollback completed; Fleet pause state restored to ${original_fleet_paused}."
}

# ----- Stage execution -------------------------------------------------------
run_transition() {
  local rank target_lsn demotion_token promotion_patch source_demotion_patch replay_lsn receiver_snapshot confirmed_site
  local target_already_promoted recovery_state token_state traffic_rc
  rank="$(stage_rank "${current_stage}")"

  if (( rank < $(stage_rank fleet-paused) )); then
    if [[ "${mode}" == planned ]]; then
      "${SCRIPT_DIR}/verify-database-replication.sh" "${source_site}" "${target_site}"
      identity_sync_replication_tls "${target_site}" "${source_site}"
    else
      replay_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_replay_lsn()' 2>/dev/null || true)"
      [[ "${replay_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ ]] || \
        die "Unplanned failover target has no trustworthy last replay LSN."
      receiver_snapshot="$(identity_sql "${target_site}" \
        "select concat_ws('|', coalesce(status,'missing'), coalesce(sender_host,'missing'), coalesce(extract(epoch from (clock_timestamp()-last_msg_receipt_time))::bigint::text,'unknown')) from pg_stat_wal_receiver" \
        2>/dev/null || true)"
      warn "UNPLANNED RPO checkpoint: target replay LSN=${replay_lsn}; receiver=${receiver_snapshot:-not currently connected}."
    fi
    pause_fleet
    set_stage fleet-paused
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank source-traffic-quiesced) )); then
    if [[ "${mode}" == planned ]]; then
      run_phase_hook quiesce-source-traffic
    fi
    if kctl --context "${source_context}" -n opkeycloak get keycloak opkeycloak >/dev/null 2>&1; then
      kctl --context "${source_context}" -n opkeycloak patch keycloak opkeycloak \
        --type merge -p '{"spec":{"instances":0}}' >/dev/null || true
      wait_for_no_pods "${source_context}" opkeycloak 'app.kubernetes.io/instance=opkeycloak'
    fi
    set_stage source-traffic-quiesced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == planned && ${rank} -lt $(stage_rank source-wal-fenced) ]]; then
    identity_sql "${source_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS false'
    identity_sql "${source_site}" \
      "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='opkeycloak' AND pid <> pg_backend_pid()"
    identity_sql "${source_site}" 'CHECKPOINT'
    target_lsn="$(identity_sql "${source_site}" 'select pg_current_wal_lsn()')"
    started=${SECONDS}; deadline=$((SECONDS + database_transition_timeout)); next_report=${SECONDS}
    log "Waiting for ${target_site} to replay final source WAL ${target_lsn}; timeout=${database_transition_timeout}s."
    until [[ "$(identity_sql "${target_site}" "select pg_wal_lsn_diff(pg_last_wal_replay_lsn(), '${target_lsn}'::pg_lsn) >= 0" 2>/dev/null || true)" == t ]]; do
      (( SECONDS < deadline )) || { transition_diagnostic_snapshot wal-replay-timeout >&2 || true; die "Target did not replay through ${target_lsn} before timeout."; }
      if (( SECONDS >= next_report )); then
        replay_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_replay_lsn()' 2>/dev/null || true)"
        wait_progress wal-replay "${started}" "${deadline}" "targetLSN=${target_lsn} replayLSN=${replay_lsn:-unknown}"
        next_report=$((SECONDS + diagnostic_interval))
      fi
      sleep "${poll_interval}"
    done
    log "Target replay reached the final source WAL position ${target_lsn}."
    set_stage source-wal-fenced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == unplanned && ${rank} -lt $(stage_rank source-hard-fenced) ]]; then
    run_phase_hook hard-fence-source
    set_stage source-hard-fenced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == planned && ${rank} -lt $(stage_rank source-demoted) ]]; then
    # A site promoted during the previous switchover can still carry the
    # one-shot promotionToken in spec.replica because it was injected out of
    # band while Fleet was paused. A JSON merge patch that only changes
    # replica.primary would retain that token and CNPG rejects the resulting
    # replica spec ("promotionToken is only allowed for primary clusters").
    # Remove the stale token in the SAME atomic API patch that demotes the site.
    source_demotion_patch="$(jq -nc \
      --arg self "${source_site}" --arg primary "${target_site}" --arg source "${target_site}" \
      '{spec:{replica:{self:$self,primary:$primary,source:$source,promotionToken:null}}}')"
    if [[ -n "$(cnpg_spec_promotion_token "${source_site}")" ]]; then
      log "${source_site}: clearing the previously consumed promotion token as part of source demotion."
    fi
    kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
      "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge \
      -p "${source_demotion_patch}" >/dev/null
    started=${SECONDS}; deadline=$((SECONDS + database_transition_timeout)); next_report=${SECONDS}
    demotion_token=''
    log "Waiting for CNPG source demotion token on ${source_site}; timeout=${database_transition_timeout}s."
    until [[ -n "${demotion_token}" ]]; do
      demotion_token="$(kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
        "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.demotionToken}' 2>/dev/null || true)"
      (( SECONDS < deadline )) || { transition_diagnostic_snapshot source-demotion-timeout >&2 || true; die "Timed out waiting for the source demotion token."; }
      if [[ -z "${demotion_token}" && ${SECONDS} -ge ${next_report} ]]; then
        wait_progress source-demotion "${started}" "${deadline}" "demotionToken=missing"
        next_report=$((SECONDS + diagnostic_interval))
      fi
      [[ -n "${demotion_token}" ]] || sleep "${poll_interval}"
    done
    log "CNPG source demotion token is available."
    set_stage source-demoted
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank target-promoted) )); then
    if [[ "${mode}" == planned ]]; then
      demotion_token="$(kctl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
        "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.demotionToken}' 2>/dev/null || true)"
      [[ -n "${demotion_token}" ]] || die "Source demotion token is unavailable while resuming target promotion."
      promotion_patch="$(jq -nc \
        --arg self "${target_site}" --arg primary "${target_site}" --arg source "${source_site}" --arg token "${demotion_token}" \
        '{spec:{replica:{self:$self,primary:$primary,source:$source,promotionToken:$token}}}')"
    else
      promotion_patch="$(jq -nc \
        --arg self "${target_site}" --arg primary "${target_site}" --arg source "${source_site}" \
        '{spec:{replica:{self:$self,primary:$primary,source:$source,promotionToken:null}}}')"
    fi

    # Resume-safe behavior: if CNPG already promoted the target before a prior
    # shell/API interruption, do not force an unnecessary second transition.
    # For planned mode, status.lastPromotionToken proves that the exact source
    # demotion token was already consumed.
    target_already_promoted=false
    if [[ "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == f ]]; then
      if [[ "${mode}" == planned ]]; then
        [[ "$(cnpg_last_promotion_token "${target_site}")" == "${demotion_token}" ]] && target_already_promoted=true
      else
        target_already_promoted=true
      fi
    fi

    if [[ "${target_already_promoted}" != true ]]; then
      kctl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
        "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge -p "${promotion_patch}" >/dev/null
    else
      log "${target_site}: promotion was already completed before resume; continuing with token cleanup."
    fi

    started=${SECONDS}; deadline=$((SECONDS + database_transition_timeout)); next_report=${SECONDS}
    log "Waiting for ${target_site} PostgreSQL promotion; timeout=${database_transition_timeout}s."
    while :; do
      recovery_state="$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)"
      token_state=match
      if [[ "${mode}" == planned ]]; then
        [[ "$(cnpg_last_promotion_token "${target_site}")" == "${demotion_token}" ]] || token_state=pending
      fi
      [[ "${recovery_state}" == f && "${token_state}" == match ]] && break
      (( SECONDS < deadline )) || { transition_diagnostic_snapshot target-promotion-timeout >&2 || true; die "Timed out waiting for ${target_site} PostgreSQL promotion/token consumption."; }
      if (( SECONDS >= next_report )); then
        wait_progress target-promotion "${started}" "${deadline}" "pg_is_in_recovery=${recovery_state:-unknown} promotionTokenConsumption=${token_state}"
        next_report=$((SECONDS + diagnostic_interval))
      fi
      sleep "${poll_interval}"
    done
    log "${target_site}: PostgreSQL promotion completed."
    # Keep the steady-state Cluster spec token-free in both modes. Planned
    # mode has just consumed the demotion token; unplanned mode defensively
    # removes any residue left by an earlier/manual transition.
    clear_consumed_promotion_token "${target_site}"
    identity_sql "${target_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true'
    set_stage target-promoted
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank fleet-labels-switched) )); then
    source_hibernation=off
    [[ "${mode}" == unplanned ]] && source_hibernation=on
    kctl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${source_resource}" --overwrite \
      kmm.dev/identity-active=false \
      kmm.dev/keycloak-instances=0 \
      kmm.dev/postgres-hibernation="${source_hibernation}" \
      kmm.dev/postgres-primary-site="${target_site}" \
      kmm.dev/postgres-distributed-topology=true >/dev/null
    kctl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${target_resource}" --overwrite \
      kmm.dev/identity-active=true \
      kmm.dev/keycloak-instances=3 \
      kmm.dev/postgres-hibernation=off \
      kmm.dev/postgres-primary-site="${target_site}" \
      kmm.dev/postgres-distributed-topology=true >/dev/null
    set_stage fleet-labels-switched
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank fleet-target-reconciled) )); then
    if [[ "${original_fleet_paused}" == "false" ]]; then
      # Labels now describe the post-promotion state. Re-enable Fleet here,
      # before exposure validation, so the target Certificate/HTTPProxy and
      # the desired CNPG/Keycloak specs can converge. Waiting until after
      # traffic activation creates a deadlock: the target exposure is owned by
      # Fleet but Fleet is paused.
      restore_fleet_pause_state
      wait_for_fleet_identity_reconciliation
      log "Fleet reconciled the post-promotion identity role labels before target traffic activation."
    elif [[ "${mode}" == planned ]]; then
      die "Planned switchover cannot continue because Fleet was paused before the operation and target role resources cannot reconcile."
    fi
    set_stage fleet-target-reconciled
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank target-keycloak-ready) )); then
    kctl --context "${target_context}" -n opkeycloak patch keycloak opkeycloak \
      --type merge -p '{"spec":{"instances":3}}' >/dev/null
    wait_for_keycloak_ready
    wait_for_target_exposure
    wait_for_target_https_health
    set_stage target-keycloak-ready
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank traffic-activated) )); then
    if (( rank < $(stage_rank dns-cutover-pending) )); then
      run_phase_hook activate-target
      if [[ "${traffic_cutover_mode}" == dns-admin ]]; then
        set_stage dns-cutover-pending waiting-external
        rank="$(stage_rank "${current_stage}")"
      fi
    fi

    if [[ "${traffic_cutover_mode}" == dns-admin ]]; then
      confirmed_site="$(normalize_identity_site "${IDENTITY_TRAFFIC_CUTOVER_CONFIRM:-}" 2>/dev/null || true)"
      if [[ "${confirmed_site}" != "${target_site}" ]]; then
        operation_status=waiting-external
        write_journal
        print_dns_admin_action
        log "Transition is safely paused at dns-cutover-pending. No database rollback is required. Resume this same journal after the DNS Admin CNAME change."
        release_lock
        trap - EXIT
        exit 0
      fi
    elif [[ -z "${IDENTITY_ACTIVATE_TARGET_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}" ]]; then
      log "Controller-DNS mode is waiting for ${IDENTITY_CANONICAL_HOST} to converge to $(identity_ingress_ip "${target_site}")."
    fi

    if wait_for_traffic_cutover; then
      set_stage traffic-activated
      rank="$(stage_rank "${current_stage}")"
    else
      traffic_rc=$?
      if (( traffic_rc == 2 )) && [[ "${traffic_cutover_mode}" == dns-admin ]]; then
        log "Transition remains safely paused at dns-cutover-pending while Segment1 DNS is corrected."
        release_lock
        trap - EXIT
        exit 0
      fi
      return "${traffic_rc}"
    fi
  fi

  if (( rank < $(stage_rank fleet-restored) )); then
    restore_fleet_pause_state
    wait_for_fleet_identity_reconciliation
    set_stage fleet-restored
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank verified) )); then
    if [[ "${mode}" == planned ]]; then
      identity_wait_cluster_ready "${source_site}" 15m
      "${SCRIPT_DIR}/verify-database-replication.sh" "${target_site}" "${source_site}"
      "${SCRIPT_DIR}/../fleet/06-validate-identity-ha.sh"
    else
      "${SCRIPT_DIR}/../fleet/06-validate-identity-ha.sh" --allow-degraded
    fi
    set_stage verified
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank complete) )); then
    if [[ "${mode}" == planned ]]; then
      current_stage=complete
      operation_status=complete
      write_journal
      log "Identity transition completed: ${target_site} is active/writable and ${source_site} is a verified warm replica."
    else
      current_stage=complete-degraded
      operation_status=complete-degraded
      write_journal
      warn "Unplanned promotion completed in DEGRADED mode: ${source_site} remains fenced/hibernated. Rebuild it with './scripts/deploy-platform.sh rebuild-identity-standby ${source_site}' before failback."
    fi
    release_lock
  fi
}

command="${1:-}"
case "${command}" in
  active)
    show_active_site
    exit 0
    ;;
  exposure)
    show_exposure_status "${2:-all}"
    exit 0
    ;;
  dns-status)
    show_dns_status "${2:-active}"
    exit 0
    ;;
  status)
    show_status
    exit 0
    ;;
  diagnose)
    show_diagnostics
    exit 0
    ;;
  rollback)
    rollback_operation
    exit 0
    ;;
  resume)
    prepare_resume
    ;;
  j64|j52|j64seg1opdev|j52seg1opdev)
    initialize_new_operation "${command}"
    ;;
  -h|--help|help|"")
    usage
    exit 0
    ;;
  *)
    usage >&2
    exit 2
    ;;
esac

trap 'rc=$?; if (( rc != 0 )); then operation_status=failed; write_journal >/dev/null 2>&1 || true; warn "Identity transition stopped at stage ${current_stage}. Fleet/lock state was intentionally preserved. Run $0 status, then $0 resume or (pre-demotion planned only) $0 rollback."; fi; exit $rc' EXIT
renew_lock
run_transition
trap - EXIT
