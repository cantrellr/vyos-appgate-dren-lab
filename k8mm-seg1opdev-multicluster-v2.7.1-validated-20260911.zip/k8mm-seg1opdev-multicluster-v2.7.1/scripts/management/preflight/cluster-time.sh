#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../_lib/common.sh
source "${SCRIPT_DIR}/../../_lib/common.sh"
# shellcheck source=../../_lib/runtime-config.sh
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

# Preserve an explicitly exported NTP_SERVERS value as the highest-precedence
# operator override. Otherwise load the protected runtime configuration when it
# exists so cluster-time follows KMM_FLEET_CONFIG like other deployment phases.
NTP_SERVERS_ENV_OVERRIDE="${NTP_SERVERS:-}"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
if [[ -f "${CONFIG_FILE}" ]]; then
  load_kmm_runtime_config "${CONFIG_FILE}"
fi
if [[ -n "${NTP_SERVERS_ENV_OVERRIDE}" ]]; then
  NTP_SERVERS="${NTP_SERVERS_ENV_OVERRIDE}"
fi

MANIFEST="${YAML_DIR}/resources/segment1-chrony-daemonset.yaml"
RESTORE_MANIFEST="${YAML_DIR}/resources/segment1-chrony-restore-timesyncd-daemonset.yaml"
NTP_SERVERS="${NTP_SERVERS:-1.0.1.34}"
CHRONY_WAITSYNC_TRIES="${CHRONY_WAITSYNC_TRIES:-12}"
CHRONY_POD_START_TIMEOUT_SECONDS="${CHRONY_POD_START_TIMEOUT_SECONDS:-120}"
WAIT_FOR_SYNC=true
RESTORE_TIMESYNCD=true
ACTION=install
CONTEXTS=()

usage() {
  cat <<USAGE
Usage: $0 [--all | --context <kubectl-context> ...] [options]

Deploys and validates the kube-system/chrony-client DaemonSet on selected RKE2
clusters. The default target is all four supported contexts.

Installation does not report success until every Chrony pod reports a selected
NTP source, a positive stratum, and "Leap status: Normal".

Options:
  --all                         Target all supported contexts (default)
  --context <context>           Target one context; may be repeated
  --ntp-servers <list>          Space- or comma-separated NTP servers
                                (default: ${NTP_SERVERS})
  --sync-tries <count>          chronyc waitsync attempts per node
                                (default: ${CHRONY_WAITSYNC_TRIES}; chronyc
                                normally waits 10 seconds between attempts)
  --verify-only                 Validate the currently deployed Chrony pods
                                without changing the DaemonSet
  --uninstall                   Remove Chrony and restore systemd-timesyncd
  --no-restore-timesyncd        With --uninstall, leave host time service state
                                unchanged after removing Chrony
  --no-wait                     Apply Chrony without waiting for synchronization
  -h, --help                    Show this help

Examples:
  $0 --all --ntp-servers '1.0.0.1 1.0.0.2'
  $0 --context j64seg1opman
  $0 --context j64seg1opdev --verify-only
  $0 --all --uninstall
USAGE
}

append_context() {
  local candidate="$1" existing
  for existing in "${CONTEXTS[@]:-}"; do
    [[ "${existing}" == "${candidate}" ]] && return 0
  done
  CONTEXTS+=("${candidate}")
}

while (($#)); do
  case "$1" in
    --all)
      CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
      shift
      ;;
    --context)
      [[ $# -ge 2 ]] || die "--context requires a value."
      append_context "$2"
      shift 2
      ;;
    --ntp-servers)
      [[ $# -ge 2 ]] || die "--ntp-servers requires a value."
      NTP_SERVERS="$2"
      shift 2
      ;;
    --sync-tries)
      [[ $# -ge 2 ]] || die "--sync-tries requires a value."
      CHRONY_WAITSYNC_TRIES="$2"
      shift 2
      ;;
    --verify-only)
      ACTION=verify
      shift
      ;;
    --uninstall)
      ACTION=uninstall
      shift
      ;;
    --no-restore-timesyncd)
      RESTORE_TIMESYNCD=false
      shift
      ;;
    --no-wait)
      WAIT_FOR_SYNC=false
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      usage >&2
      die "Unknown argument: $1"
      ;;
  esac
done

((${#CONTEXTS[@]})) || CONTEXTS=("${KMM_SUPPORTED_CONTEXTS[@]}")
[[ "${CHRONY_WAITSYNC_TRIES}" =~ ^[1-9][0-9]*$ ]] || die "--sync-tries must be a positive integer."
[[ "${CHRONY_POD_START_TIMEOUT_SECONDS}" =~ ^[1-9][0-9]*$ ]] || die "CHRONY_POD_START_TIMEOUT_SECONDS must be a positive integer."
if [[ "${ACTION}" != uninstall ]]; then
  [[ -n "${NTP_SERVERS//[[:space:],]/}" ]] || die "NTP server list must not be empty."
fi

require_cmd kubectl
require_cmd python3
ensure_file "${MANIFEST}"
ensure_file "${RESTORE_MANIFEST}"

render_manifest() {
  local output="$1"
  NTP_SERVERS_VALUE="${NTP_SERVERS}" python3 - "${MANIFEST}" "${output}" <<'PY'
from pathlib import Path
import os
import sys
import yaml

source = Path(sys.argv[1])
target = Path(sys.argv[2])
documents = list(yaml.safe_load_all(source.read_text(encoding="utf-8")))
for document in documents:
    if not isinstance(document, dict) or document.get("kind") != "DaemonSet":
        continue
    containers = document["spec"]["template"]["spec"].get("containers", [])
    for container in containers:
        if container.get("name") != "chrony":
            continue
        for item in container.setdefault("env", []):
            if item.get("name") == "NTP_SERVERS":
                item["value"] = os.environ["NTP_SERVERS_VALUE"]
                break
        else:
            container["env"].append({"name": "NTP_SERVERS", "value": os.environ["NTP_SERVERS_VALUE"]})
target.write_text(yaml.safe_dump_all(documents, sort_keys=False, explicit_start=True), encoding="utf-8")
PY
}

normalize_ntp_servers() {
  printf '%s\n' "${NTP_SERVERS}" | tr ',' ' ' | xargs -n1
}

chrony_pods() {
  local context="$1"
  kubectl --context "${context}" -n kube-system get pods \
    -l app=chrony-client \
    -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | sort
}

wait_for_chrony_pods_running() {
  local context="$1" deadline desired running phases
  deadline=$((SECONDS + CHRONY_POD_START_TIMEOUT_SECONDS))
  while ((SECONDS < deadline)); do
    desired="$(kubectl --context "${context}" -n kube-system get daemonset chrony-client \
      -o jsonpath='{.status.desiredNumberScheduled}' 2>/dev/null || true)"
    phases="$(kubectl --context "${context}" -n kube-system get pods -l app=chrony-client \
      -o jsonpath='{range .items[*]}{.status.phase}{"\n"}{end}' 2>/dev/null || true)"
    running="$(printf '%s\n' "${phases}" | awk '$1 == "Running" {n++} END {print n+0}')"
    if [[ "${desired}" =~ ^[1-9][0-9]*$ ]] && ((running >= desired)); then
      return 0
    fi
    sleep 3
  done

  warn "${context}: Chrony pods did not all reach Running within ${CHRONY_POD_START_TIMEOUT_SECONDS}s."
  kubectl --context "${context}" -n kube-system get daemonset chrony-client -o wide >&2 || true
  kubectl --context "${context}" -n kube-system get pods -l app=chrony-client -o wide >&2 || true
  return 1
}

dump_pod_diagnostics() {
  local context="$1" pod="$2" server
  warn "${context}/${pod}: Chrony synchronization diagnostics follow."
  printf '\n--- chronyc tracking ---\n' >&2
  kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- chronyc -n tracking >&2 || true
  printf '\n--- chronyc sources -v ---\n' >&2
  kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- chronyc -n sources -v >&2 || true
  while IFS= read -r server; do
    [[ -n "${server}" ]] || continue
    printf '\n--- chronyc ntpdata %s ---\n' "${server}" >&2
    kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- \
      chronyc -n ntpdata "${server}" >&2 || true
  done < <(normalize_ntp_servers)
  printf '\n--- chrony container logs ---\n' >&2
  kubectl --context "${context}" -n kube-system logs "${pod}" -c chrony --tail=100 >&2 || true
  printf '\n--- chrony-status telemetry logs ---\n' >&2
  kubectl --context "${context}" -n kube-system logs "${pod}" -c chrony-status --tail=100 >&2 || true
  printf '\n--- pod events ---\n' >&2
  kubectl --context "${context}" -n kube-system describe pod "${pod}" \
    | sed -n '/Events:/,$p' >&2 || true
}

validate_chrony_pod() {
  local context="$1" pod="$2" tracking sources leap stratum selected node
  node="$(kubectl --context "${context}" -n kube-system get pod "${pod}" -o jsonpath='{.spec.nodeName}')"
  log "${context}/${node}: waiting for Chrony synchronization (${CHRONY_WAITSYNC_TRIES} attempts)..."

  if ! kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- \
      chronyc waitsync "${CHRONY_WAITSYNC_TRIES}" >/dev/null; then
    warn "${context}/${node}: chronyc waitsync did not reach synchronized state."
    dump_pod_diagnostics "${context}" "${pod}"
    return 1
  fi

  tracking="$(kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- chronyc -n tracking)"
  sources="$(kubectl --context "${context}" -n kube-system exec "${pod}" -c chrony -- chronyc -n sources)"
  leap="$(printf '%s\n' "${tracking}" | awk -F: '/^Leap status/ {sub(/^[[:space:]]+/, "", $2); print $2; exit}')"
  stratum="$(printf '%s\n' "${tracking}" | awk -F: '/^Stratum/ {gsub(/[[:space:]]/, "", $2); print $2; exit}')"
  selected="$(printf '%s\n' "${sources}" | awk '$1 == "^*" {print $2; exit}')"

  if [[ "${leap}" != "Normal" ]] || [[ ! "${stratum}" =~ ^[1-9][0-9]*$ ]] || [[ -z "${selected}" ]]; then
    warn "${context}/${node}: invalid Chrony state: leap=${leap:-unknown} stratum=${stratum:-unknown} selected=${selected:-none}."
    dump_pod_diagnostics "${context}" "${pod}"
    return 1
  fi

  log "${context}/${node}: SYNCED source=${selected} stratum=${stratum} leap=${leap}."
  printf '%s\n' "${tracking}" | sed 's/^/[TRACKING] /'
  printf '%s\n' "${sources}" | sed 's/^/[SOURCES]  /'
}

validate_chrony_pods_current() {
  local context="$1" pod failures=0
  while IFS= read -r pod; do
    [[ -n "${pod}" ]] || continue
    validate_chrony_pod "${context}" "${pod}" || failures=$((failures + 1))
  done < <(chrony_pods "${context}")
  ((failures == 0))
}

validate_chrony_context() {
  local context="$1"
  kubectl --context "${context}" -n kube-system get daemonset chrony-client >/dev/null 2>&1 \
    || die "${context}: kube-system/chrony-client is not installed."

  # Validate the currently Running pods first. During a rolling update this
  # catches a newly created unsynchronized pod before waiting for the entire
  # DaemonSet rollout timeout.
  wait_for_chrony_pods_running "${context}" || return 1
  if ! validate_chrony_pods_current "${context}"; then
    warn "${context}: Chrony synchronization failed before rollout completion."
    return 1
  fi

  kubectl --context "${context}" -n kube-system rollout status daemonset/chrony-client \
    --timeout="${KUBECTL_TIMEOUT}" || {
      warn "${context}: Chrony DaemonSet rollout did not complete."
      kubectl --context "${context}" -n kube-system get pods -l app=chrony-client -o wide >&2 || true
      return 1
    }

  # The rolling update may have replaced additional nodes after the first
  # validation pass. Revalidate the final pod set so every current node is
  # proven synchronized.
  wait_for_chrony_pods_running "${context}" || return 1
  if ! validate_chrony_pods_current "${context}"; then
    warn "${context}: final Chrony synchronization validation failed."
    return 1
  fi

  kubectl --context "${context}" -n kube-system get daemonset/chrony-client -o wide
  return 0
}

restore_timesyncd_context() {
  local context="$1" pod
  kubectl --context "${context}" -n kube-system get secret "${REGISTRY_SECRET}" >/dev/null 2>&1 \
    || die "${context}: missing kube-system/${REGISTRY_SECRET}; cannot run host time-service restore helper."

  log "${context}: restoring the pre-Chrony systemd-timesyncd state on every node..."
  kubectl --context "${context}" -n kube-system delete daemonset chrony-restore-timesyncd --ignore-not-found >/dev/null 2>&1 || true
  kubectl --context "${context}" apply -f "${RESTORE_MANIFEST}"
  if ! kubectl --context "${context}" -n kube-system rollout status daemonset/chrony-restore-timesyncd \
      --timeout="${KUBECTL_TIMEOUT}"; then
    warn "${context}: timesyncd restore helper did not become Ready; leaving it in place for troubleshooting."
    kubectl --context "${context}" -n kube-system get pods -l app=chrony-restore-timesyncd -o wide >&2 || true
    return 1
  fi

  while IFS= read -r pod; do
    [[ -n "${pod}" ]] || continue
    kubectl --context "${context}" -n kube-system logs "${pod}" -c restore-timesyncd --tail=100
  done < <(kubectl --context "${context}" -n kube-system get pods -l app=chrony-restore-timesyncd \
    -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}')

  kubectl --context "${context}" -n kube-system delete daemonset chrony-restore-timesyncd --wait=true
  log "${context}: systemd-timesyncd restore completed."
}

failures=0
for context in "${CONTEXTS[@]}"; do
  validate_supported_context "${context}"
  validate_context_access "${context}"

  if [[ "${ACTION}" == uninstall ]]; then
    log "Removing Chrony DaemonSet from ${context}..."
    kubectl --context "${context}" -n kube-system delete daemonset chrony-client --ignore-not-found --wait=true
    if [[ "${RESTORE_TIMESYNCD}" == true ]]; then
      restore_timesyncd_context "${context}" || failures=$((failures + 1))
    else
      warn "${context}: Chrony removed without restoring systemd-timesyncd (--no-restore-timesyncd)."
    fi
    continue
  fi

  if [[ "${ACTION}" == verify ]]; then
    log "Validating Chrony synchronization on ${context}..."
    validate_chrony_context "${context}" || failures=$((failures + 1))
    continue
  fi

  kubectl --context "${context}" -n kube-system get secret "${REGISTRY_SECRET}" >/dev/null 2>&1 \
    || die "${context}: missing kube-system/${REGISTRY_SECRET}; seed registry credentials first."

  rendered="$(mktemp)"
  trap 'rm -f "${rendered:-}"' EXIT
  render_manifest "${rendered}"

  log "Installing Chrony on ${context} with NTP servers: ${NTP_SERVERS}"
  kubectl --context "${context}" apply -f "${rendered}"
  rm -f "${rendered}"
  trap - EXIT

  if [[ "${WAIT_FOR_SYNC}" == true ]]; then
    validate_chrony_context "${context}" || failures=$((failures + 1))
  else
    warn "${context}: synchronization validation skipped because --no-wait was specified."
    kubectl --context "${context}" -n kube-system get daemonset/chrony-client -o wide
  fi
done

if ((failures > 0)); then
  die "Chrony ${ACTION} failed validation for ${failures} cluster context(s)."
fi

log "Chrony ${ACTION} completed successfully for ${#CONTEXTS[@]} cluster context(s)."
