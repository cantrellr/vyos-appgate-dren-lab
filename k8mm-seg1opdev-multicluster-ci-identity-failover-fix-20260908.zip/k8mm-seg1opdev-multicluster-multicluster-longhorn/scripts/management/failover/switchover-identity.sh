#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/fleet-clusters.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"
CONFIG_FILE="$(resolve_kmm_runtime_config)"
load_kmm_runtime_config "${CONFIG_FILE}"
source "${SCRIPT_DIR}/../../_lib/identity-postgres.sh"

require_cmd kubectl
require_cmd jq
require_cmd curl
require_cmd getent
require_cmd date

management_context="${RANCHER_CONTEXT:-j64seg1opman}"
gitrepo_name="${IDENTITY_FLEET_GITREPO_NAME:-k8mm-seg1opdev-multicluster-downstream}"
journal_namespace="${IDENTITY_SWITCHOVER_JOURNAL_NAMESPACE:-fleet-default}"
journal_name="${IDENTITY_SWITCHOVER_JOURNAL_NAME:-kmm-identity-transition-journal}"
lock_name="${IDENTITY_SWITCHOVER_LOCK_NAME:-kmm-identity-transition-lock}"
traffic_timeout="${IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS:-600}"
health_path="${IDENTITY_OIDC_HEALTH_PATH:-/realms/master/.well-known/openid-configuration}"
auto_enroll_topology="${IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY:-true}"

[[ "${traffic_timeout}" =~ ^[0-9]+$ ]] && (( traffic_timeout > 0 )) || \
  die "IDENTITY_TRAFFIC_CUTOVER_TIMEOUT_SECONDS must be greater than zero."
[[ "${auto_enroll_topology}" == true || "${auto_enroll_topology}" == false ]] || \
  die "IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY must be true or false."

usage() {
  cat <<USAGE
Usage:
  $0 <j64seg1opdev|j52seg1opdev>
  $0 status
  $0 resume
  $0 rollback

New transitions require IDENTITY_SWITCHOVER_CONFIRM=<target-site>.
Unplanned promotion additionally requires:
  IDENTITY_ALLOW_UNPLANNED_FAILOVER=true
  IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS
  an executable IDENTITY_HARD_FENCE_SOURCE_HOOK or legacy IDENTITY_SWITCHOVER_HOOK

status   Show the persistent Kubernetes operation journal.
resume   Continue the last incomplete transition from its recorded stage.
rollback Restore the source only when the journal is still before database demotion.
USAGE
}

stage_rank() {
  case "${1:-}" in
    initialized) echo 0 ;;
    fleet-paused) echo 10 ;;
    source-traffic-quiesced) echo 20 ;;
    source-wal-fenced) echo 30 ;;
    source-hard-fenced) echo 35 ;;
    source-demoted) echo 40 ;;
    target-promoted) echo 50 ;;
    fleet-labels-switched) echo 60 ;;
    target-keycloak-ready) echo 70 ;;
    traffic-activated) echo 80 ;;
    fleet-restored) echo 90 ;;
    verified) echo 100 ;;
    complete|complete-degraded|rolled-back) echo 110 ;;
    *) echo -1 ;;
  esac
}

journal_exists() {
  kubectl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" >/dev/null 2>&1
}

journal_get() {
  local key="$1"
  kubectl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" \
    -o "jsonpath={.data.${key}}" 2>/dev/null || true
}

write_journal() {
  kubectl --context "${management_context}" -n "${journal_namespace}" create configmap "${journal_name}" \
    --from-literal=operationId="${operation_id}" \
    --from-literal=status="${operation_status}" \
    --from-literal=stage="${current_stage}" \
    --from-literal=mode="${mode}" \
    --from-literal=sourceSite="${source_site}" \
    --from-literal=targetSite="${target_site}" \
    --from-literal=originalFleetPaused="${original_fleet_paused}" \
    --from-literal=sourceKeycloakInstances="${source_keycloak_instances}" \
    --from-literal=updatedAt="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --dry-run=client -o yaml | \
    kubectl --context "${management_context}" -n "${journal_namespace}" apply -f - >/dev/null
}

set_stage() {
  current_stage="$1"
  operation_status="${2:-running}"
  write_journal
  log "Identity transition journal: stage=${current_stage} status=${operation_status}."
}

show_status() {
  if ! journal_exists; then
    echo "No identity transition journal exists in ${journal_namespace}/${journal_name}."
    return 0
  fi
  kubectl --context "${management_context}" -n "${journal_namespace}" get configmap "${journal_name}" \
    -o go-template='operationId={{index .data "operationId"}}{{"\n"}}status={{index .data "status"}}{{"\n"}}stage={{index .data "stage"}}{{"\n"}}mode={{index .data "mode"}}{{"\n"}}source={{index .data "sourceSite"}}{{"\n"}}target={{index .data "targetSite"}}{{"\n"}}originalFleetPaused={{index .data "originalFleetPaused"}}{{"\n"}}updatedAt={{index .data "updatedAt"}}{{"\n"}}'
}

lock_holder() {
  kubectl --context "${management_context}" -n "${journal_namespace}" get lease.coordination.k8s.io "${lock_name}" \
    -o jsonpath='{.spec.holderIdentity}' 2>/dev/null || true
}

acquire_lock() {
  local existing
  existing="$(lock_holder)"
  if [[ -n "${existing}" ]]; then
    [[ "${existing}" == "${operation_id}" ]] || \
      die "Identity transition lock ${journal_namespace}/${lock_name} is held by ${existing}. Run '$0 status'."
    return 0
  fi
  cat <<YAML | kubectl --context "${management_context}" -n "${journal_namespace}" create -f - >/dev/null
apiVersion: coordination.k8s.io/v1
kind: Lease
metadata:
  name: ${lock_name}
  namespace: ${journal_namespace}
spec:
  holderIdentity: ${operation_id}
  leaseDurationSeconds: 3600
  acquireTime: "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  renewTime: "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
YAML
}

release_lock() {
  local existing
  existing="$(lock_holder)"
  if [[ -n "${existing}" && "${existing}" == "${operation_id}" ]]; then
    kubectl --context "${management_context}" -n "${journal_namespace}" delete \
      lease.coordination.k8s.io "${lock_name}" --ignore-not-found >/dev/null
  fi
}

renew_lock() {
  kubectl --context "${management_context}" -n "${journal_namespace}" patch \
    lease.coordination.k8s.io "${lock_name}" --type merge \
    -p "{\"spec\":{\"holderIdentity\":\"${operation_id}\",\"renewTime\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}}" >/dev/null
}

fleet_is_paused() {
  local value
  value="$(kubectl --context "${management_context}" -n fleet-default get gitrepo "${gitrepo_name}" \
    -o jsonpath='{.spec.paused}' 2>/dev/null || true)"
  [[ "${value}" == "true" ]] && echo true || echo false
}

pause_fleet() {
  kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p '{"spec":{"paused":true}}' >/dev/null
}

restore_fleet_pause_state() {
  kubectl --context "${management_context}" -n fleet-default patch gitrepo "${gitrepo_name}" \
    --type merge -p "{\"spec\":{\"paused\":${original_fleet_paused}}}" >/dev/null
}

wait_for_no_pods() {
  local context="$1" namespace="$2" selector="$3" deadline=$((SECONDS + 600)) count
  while :; do
    count="$(kubectl --context "${context}" -n "${namespace}" get pods -l "${selector}" --no-headers 2>/dev/null | wc -l | tr -d ' ')"
    [[ "${count}" == "0" ]] && return 0
    (( SECONDS < deadline )) || die "Timed out waiting for ${context}/${namespace} pods to stop (${selector})."
    sleep 5
  done
}

run_phase_hook() {
  local phase="$1" hook="" legacy_phase="${phase}"
  case "${phase}" in
    quiesce-source-traffic)
      hook="${IDENTITY_QUIESCE_SOURCE_HOOK:-}"
      ;;
    hard-fence-source)
      hook="${IDENTITY_HARD_FENCE_SOURCE_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}"
      legacy_phase=fence-source
      ;;
    activate-target)
      hook="${IDENTITY_ACTIVATE_TARGET_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}"
      legacy_phase=activate-target
      ;;
    restore-source-traffic)
      hook="${IDENTITY_RESTORE_SOURCE_HOOK:-}"
      ;;
    *) die "Unsupported identity traffic hook phase: ${phase}" ;;
  esac

  [[ -n "${hook}" ]] || return 0
  [[ -x "${hook}" ]] || die "Identity ${phase} hook is not executable: ${hook}"

  IDENTITY_SWITCHOVER_PHASE="${phase}" \
  IDENTITY_FAILOVER_PHASE="${legacy_phase}" \
  IDENTITY_SWITCHOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_FAILOVER_SOURCE_CONTEXT="${source_context}" \
  IDENTITY_SWITCHOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_FAILOVER_SOURCE_IP="$(identity_ingress_ip "${source_site}")" \
  IDENTITY_SWITCHOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_FAILOVER_TARGET_CONTEXT="${target_context}" \
  IDENTITY_SWITCHOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_FAILOVER_TARGET_IP="$(identity_ingress_ip "${target_site}")" \
  IDENTITY_SWITCHOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST}" \
  IDENTITY_FAILOVER_CANONICAL_HOST="${IDENTITY_CANONICAL_HOST}" \
    "${hook}"
}

validate_target_exposure() {
  local cert_ready proxy_status proxy_description service_port
  service_port="$(kubectl --context "${target_context}" -n opkeycloak get service opkeycloak-service \
    -o jsonpath='{range .spec.ports[*]}{.port}{"\n"}{end}' 2>/dev/null | grep -Fx '8080' | head -1 || true)"
  [[ "${service_port}" == "8080" ]] || die "${target_site}: active Keycloak Service is missing TCP/8080."
  cert_ready="$(kubectl --context "${target_context}" -n opkeycloak get certificate opkeycloak-dev-jde-cybercom-ic-gov-tls-cert \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null || true)"
  [[ "${cert_ready}" == "True" ]] || die "${target_site}: Keycloak TLS Certificate is not Ready."
  proxy_status="$(kubectl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.currentStatus}' 2>/dev/null || true)"
  proxy_description="$(kubectl --context "${target_context}" -n opkeycloak get httpproxy.projectcontour.io opkeycloak-httpproxy \
    -o jsonpath='{.status.description}' 2>/dev/null || true)"
  [[ "${proxy_status,,}" == "valid" ]] || \
    die "${target_site}: Keycloak HTTPProxy status=${proxy_status:-missing}: ${proxy_description:-no description}."
}

wait_for_traffic_cutover() {
  local expected_ip resolved deadline=$((SECONDS + traffic_timeout))
  expected_ip="$(identity_ingress_ip "${target_site}")"
  while (( SECONDS < deadline )); do
    resolved="$(getent ahostsv4 "${IDENTITY_CANONICAL_HOST}" 2>/dev/null | awk '{print $1}' | sort -u || true)"
    if [[ -n "${resolved}" ]] && grep -Fxq "${expected_ip}" <<<"${resolved}"; then
      bad=false
      while IFS= read -r ip; do
        [[ "${ip}" == "${expected_ip}" ]] || bad=true
      done <<<"${resolved}"
      if [[ "${bad}" == false ]]; then
        if curl --fail --silent --show-error --max-time 10 --cacert "${CA_CERT_FILE}" \
          "https://${IDENTITY_CANONICAL_HOST}${health_path}" >/dev/null; then
          log "Canonical identity DNS/TLS/OIDC gate passed: ${IDENTITY_CANONICAL_HOST} -> ${expected_ip}."
          return 0
        fi
      fi
    fi
    sleep 5
  done
  die "Canonical identity traffic did not converge to ${target_site} (${expected_ip}) with a healthy HTTPS/OIDC endpoint within ${traffic_timeout}s."
}

wait_for_fleet_identity_reconciliation() {
  local deadline=$((SECONDS + 900)) bundle state all_ready
  [[ "${original_fleet_paused}" == "false" ]] || {
    warn "Fleet was already paused before the transition; preserving that state and skipping Fleet reconciliation gating."
    return 0
  }
  while (( SECONDS < deadline )); do
    all_ready=true
    for bundle in oppostgres oppostgres-replica opkeycloak opkeycloak-secondary; do
      state="$(kubectl --context "${management_context}" -n fleet-default get bundle "${bundle}" -o json 2>/dev/null | \
        jq -r '[.status.conditions[]? | select(.type == "Ready")][0].status // "Unknown"' 2>/dev/null || true)"
      [[ "${state}" == "True" ]] || all_ready=false
    done
    [[ "${all_ready}" == true ]] && return 0
    sleep 5
  done
  die "Fleet identity bundles did not reconcile within 15 minutes after traffic cutover."
}

load_journal() {
  journal_exists || die "No identity transition journal exists."
  operation_id="$(journal_get operationId)"
  operation_status="$(journal_get status)"
  current_stage="$(journal_get stage)"
  mode="$(journal_get mode)"
  source_site="$(journal_get sourceSite)"
  target_site="$(journal_get targetSite)"
  original_fleet_paused="$(journal_get originalFleetPaused)"
  source_keycloak_instances="$(journal_get sourceKeycloakInstances)"
  [[ -n "${operation_id}" && -n "${current_stage}" && -n "${source_site}" && -n "${target_site}" ]] || \
    die "Identity transition journal is incomplete/corrupt."
  source_context="$(identity_context "${source_site}")"
  target_context="$(identity_context "${target_site}")"
}

fleet_topology_label() {
  local resource="${1:?Fleet cluster resource is required}"
  kubectl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/postgres-distributed-topology}' 2>/dev/null || true
}

topology_labels_enrolled() {
  [[ "$(fleet_topology_label "${source_resource}")" == true && \
     "$(fleet_topology_label "${target_resource}")" == true ]]
}

ensure_planned_topology_enrolled() {
  [[ "${mode}" == planned ]] || return 0
  topology_labels_enrolled && return 0

  if [[ "${source_site}" == j64seg1opdev && "${target_site}" == j52seg1opdev ]]; then
    [[ "${auto_enroll_topology}" == true ]] || \
      die "Planned J64->J52 switchover requires distributed PostgreSQL enrollment. Run './scripts/deploy-platform.sh enable-identity-secondary' or set IDENTITY_AUTO_ENROLL_DISTRIBUTED_TOPOLOGY=true."
    warn "Streaming replication is available but Fleet distributed-topology enrollment is incomplete; enrolling J64/J52 before the planned switchover."
    "${SCRIPT_DIR}/../fleet/05-enable-identity-secondary.sh"
    source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${management_context}")"
    target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${management_context}")"
    topology_labels_enrolled || \
      die "Automatic distributed-topology enrollment completed without setting both Fleet topology labels. Re-run './scripts/deploy-platform.sh enable-identity-secondary' and inspect Fleet reconciliation."
    log "Distributed PostgreSQL topology is enrolled and ready for planned switchover."
    return 0
  fi

  die "Distributed PostgreSQL topology is not enrolled for ${source_site} -> ${target_site}. Restore/rebuild the warm standby before failback; automatic enrollment is only safe for the initial planned J64->J52 transition."
}

validate_topology_preconditions() {
  local allow_already_promoted="${1:-false}" source_topology target_topology target_primary
  source_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${source_site}")" "${management_context}")"
  target_resource="$(fleet_cluster_resource fleet-default "$(identity_display_name "${target_site}")" "${management_context}")"

  ensure_planned_topology_enrolled
  source_topology="$(fleet_topology_label "${source_resource}")"
  target_topology="$(fleet_topology_label "${target_resource}")"
  [[ "${source_topology}" == true ]] || \
    die "${source_site} (Fleet ${source_resource}) is not enrolled in the distributed PostgreSQL topology."
  [[ "${target_topology}" == true ]] || \
    die "${target_site} (Fleet ${target_resource}) is not enrolled in the distributed PostgreSQL topology."

  target_primary="$(kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.spec.replica.primary}')"
  if [[ "${target_primary}" == "${target_site}" && "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == "f" ]]; then
    [[ "${allow_already_promoted}" == true ]] && return 0
    die "${target_site} is already the writable identity database site."
  fi
  [[ "${target_primary}" == "${source_site}" ]] || \
    die "Target database reports distributed primary ${target_primary:-unset}; expected ${source_site}."
}

initialize_new_operation() {
  target_site="$1"
  [[ "${target_site}" == "j64seg1opdev" || "${target_site}" == "j52seg1opdev" ]] || { usage; exit 2; }
  source_site="$(identity_peer_site "${target_site}")"
  source_context="$(identity_context "${source_site}")"
  target_context="$(identity_context "${target_site}")"
  [[ "${IDENTITY_SWITCHOVER_CONFIRM:-}" == "${target_site}" ]] || \
    die "Set IDENTITY_SWITCHOVER_CONFIRM=${target_site} to acknowledge this identity role transition."

  source_available=false
  if kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
    source_available=true
  fi

  mode="${IDENTITY_SWITCHOVER_MODE:-${IDENTITY_FAILOVER_MODE:-auto}}"
  if [[ "${mode}" == "auto" ]]; then
    [[ "${source_available}" == true ]] && mode=planned || mode=unplanned
  fi
  [[ "${mode}" == planned || "${mode}" == unplanned ]] || \
    die "IDENTITY_SWITCHOVER_MODE must be auto, planned, or unplanned."
  [[ "${mode}" != planned || "${source_available}" == true ]] || \
    die "Planned switchover requires the current primary site to be reachable."

  if [[ "${mode}" == unplanned ]]; then
    [[ "${IDENTITY_ALLOW_UNPLANNED_FAILOVER:-false}" == true ]] || \
      die "Unplanned failover can lose transactions. Set IDENTITY_ALLOW_UNPLANNED_FAILOVER=true to proceed."
    [[ "${IDENTITY_UNPLANNED_RPO_ACK:-}" == "I_ACCEPT_POSSIBLE_DATA_LOSS" ]] || \
      die "Set IDENTITY_UNPLANNED_RPO_ACK=I_ACCEPT_POSSIBLE_DATA_LOSS after reviewing the standby replay position."
    [[ -n "${IDENTITY_HARD_FENCE_SOURCE_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}" ]] || \
      die "Unplanned failover requires an executable hard-fence hook before target promotion."
  fi

  validate_topology_preconditions
  operation_id="identity-$(date -u +%Y%m%dT%H%M%SZ)-$$"
  original_fleet_paused="$(fleet_is_paused)"
  source_keycloak_instances="$(kubectl --context "${management_context}" -n fleet-default get cluster.fleet.cattle.io "${source_resource}" \
    -o jsonpath='{.metadata.labels.kmm\.dev/keycloak-instances}' 2>/dev/null || true)"
  source_keycloak_instances="${source_keycloak_instances:-3}"
  current_stage=initialized
  operation_status=running
  acquire_lock
  write_journal
}

prepare_resume() {
  load_journal
  case "${operation_status}" in
    complete|complete-degraded|rolled-back) die "Journal status is ${operation_status}; there is no incomplete transition to resume." ;;
  esac
  [[ "${IDENTITY_SWITCHOVER_CONFIRM:-}" == "${target_site}" ]] || \
    die "Set IDENTITY_SWITCHOVER_CONFIRM=${target_site} before resuming this transition."
  acquire_lock
  operation_status=running
  write_journal
  # A resume at/after target promotion must accept the target already being
  # writable. Before that point, enforce the original source->target topology.
  if (( $(stage_rank "${current_stage}") >= $(stage_rank target-promoted) )); then
    validate_topology_preconditions true
  else
    validate_topology_preconditions false
  fi
}

rollback_operation() {
  load_journal
  local rank
  rank="$(stage_rank "${current_stage}")"
  (( rank >= 0 && rank < $(stage_rank source-demoted) )) || \
    die "Rollback is only supported before source database demotion; journal stage is ${current_stage}."
  [[ "${mode}" == planned ]] || \
    die "Automatic source rollback is not permitted for an unplanned failover/fence operation."
  acquire_lock

  if kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" \
    get "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" >/dev/null 2>&1; then
    identity_sql "${source_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true' >/dev/null || true
    kubectl --context "${source_context}" -n opkeycloak patch keycloak opkeycloak --type merge \
      -p "{\"spec\":{\"instances\":${source_keycloak_instances}}}" >/dev/null || true
  fi
  run_phase_hook restore-source-traffic || warn "restore-source-traffic hook failed; inspect external routing before returning service."
  restore_fleet_pause_state
  current_stage=rolled-back
  operation_status=rolled-back
  write_journal
  release_lock
  log "Pre-demotion identity transition rollback completed; Fleet pause state restored to ${original_fleet_paused}."
}

# ----- Stage execution -------------------------------------------------------
run_transition() {
  local rank target_lsn demotion_token promotion_patch replay_lsn receiver_snapshot
  rank="$(stage_rank "${current_stage}")"

  if (( rank < $(stage_rank fleet-paused) )); then
    if [[ "${mode}" == planned ]]; then
      "${SCRIPT_DIR}/verify-database-replication.sh" "${source_site}" "${target_site}"
      identity_sync_replication_tls "${target_site}" "${source_site}"
    else
      replay_lsn="$(identity_sql "${target_site}" 'select pg_last_wal_replay_lsn()' 2>/dev/null || true)"
      [[ "${replay_lsn}" =~ ^[0-9A-F]+/[0-9A-F]+$ ]] || \
        die "Unplanned failover target has no trustworthy last replay LSN."
      receiver_snapshot="$(identity_sql "${target_site}" \
        "select concat_ws('|', coalesce(status,'missing'), coalesce(sender_host,'missing'), coalesce(extract(epoch from (clock_timestamp()-last_msg_receipt_time))::bigint::text,'unknown')) from pg_stat_wal_receiver" \
        2>/dev/null || true)"
      warn "UNPLANNED RPO checkpoint: target replay LSN=${replay_lsn}; receiver=${receiver_snapshot:-not currently connected}."
    fi
    pause_fleet
    set_stage fleet-paused
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank source-traffic-quiesced) )); then
    if [[ "${mode}" == planned ]]; then
      run_phase_hook quiesce-source-traffic
    fi
    if kubectl --context "${source_context}" -n opkeycloak get keycloak opkeycloak >/dev/null 2>&1; then
      kubectl --context "${source_context}" -n opkeycloak patch keycloak opkeycloak \
        --type merge -p '{"spec":{"instances":0}}' >/dev/null || true
      wait_for_no_pods "${source_context}" opkeycloak 'app.kubernetes.io/instance=opkeycloak'
    fi
    set_stage source-traffic-quiesced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == planned && ${rank} -lt $(stage_rank source-wal-fenced) ]]; then
    identity_sql "${source_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS false'
    identity_sql "${source_site}" \
      "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname='opkeycloak' AND pid <> pg_backend_pid()"
    identity_sql "${source_site}" 'CHECKPOINT'
    target_lsn="$(identity_sql "${source_site}" 'select pg_current_wal_lsn()')"
    deadline=$((SECONDS + 900))
    until [[ "$(identity_sql "${target_site}" "select pg_wal_lsn_diff(pg_last_wal_replay_lsn(), '${target_lsn}'::pg_lsn) >= 0" 2>/dev/null || true)" == t ]]; do
      (( SECONDS < deadline )) || die "Target did not replay through ${target_lsn} before timeout."
      sleep 5
    done
    log "Target replay reached the final source WAL position ${target_lsn}."
    set_stage source-wal-fenced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == unplanned && ${rank} -lt $(stage_rank source-hard-fenced) ]]; then
    run_phase_hook hard-fence-source
    set_stage source-hard-fenced
    rank="$(stage_rank "${current_stage}")"
  fi

  if [[ "${mode}" == planned && ${rank} -lt $(stage_rank source-demoted) ]]; then
    kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
      "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge \
      -p "{\"spec\":{\"replica\":{\"self\":\"${source_site}\",\"primary\":\"${target_site}\",\"source\":\"${target_site}\"}}}" >/dev/null
    deadline=$((SECONDS + 900))
    demotion_token=''
    until [[ -n "${demotion_token}" ]]; do
      demotion_token="$(kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
        "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.demotionToken}' 2>/dev/null || true)"
      (( SECONDS < deadline )) || die "Timed out waiting for the source demotion token."
      [[ -n "${demotion_token}" ]] || sleep 5
    done
    set_stage source-demoted
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank target-promoted) )); then
    if [[ "${mode}" == planned ]]; then
      demotion_token="$(kubectl --context "${source_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" get \
        "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" -o jsonpath='{.status.demotionToken}' 2>/dev/null || true)"
      [[ -n "${demotion_token}" ]] || die "Source demotion token is unavailable while resuming target promotion."
      promotion_patch="{\"spec\":{\"replica\":{\"self\":\"${target_site}\",\"primary\":\"${target_site}\",\"source\":\"${source_site}\",\"promotionToken\":\"${demotion_token}\"}}}"
    else
      promotion_patch="{\"spec\":{\"replica\":{\"self\":\"${target_site}\",\"primary\":\"${target_site}\",\"source\":\"${source_site}\"}}}"
    fi
    kubectl --context "${target_context}" -n "${IDENTITY_POSTGRES_NAMESPACE}" patch \
      "${IDENTITY_CNPG_RESOURCE}/${IDENTITY_POSTGRES_CLUSTER}" --type merge -p "${promotion_patch}" >/dev/null
    deadline=$((SECONDS + 900))
    until [[ "$(identity_sql "${target_site}" 'select pg_is_in_recovery()' 2>/dev/null || true)" == f ]]; do
      (( SECONDS < deadline )) || die "Timed out waiting for ${target_site} PostgreSQL promotion."
      sleep 5
    done
    identity_sql "${target_site}" 'ALTER DATABASE opkeycloak WITH ALLOW_CONNECTIONS true'
    set_stage target-promoted
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank fleet-labels-switched) )); then
    source_hibernation=off
    [[ "${mode}" == unplanned ]] && source_hibernation=on
    kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${source_resource}" --overwrite \
      kmm.dev/identity-active=false \
      kmm.dev/keycloak-instances=0 \
      kmm.dev/postgres-hibernation="${source_hibernation}" \
      kmm.dev/postgres-primary-site="${target_site}" \
      kmm.dev/postgres-distributed-topology=true >/dev/null
    kubectl --context "${management_context}" -n fleet-default label cluster.fleet.cattle.io "${target_resource}" --overwrite \
      kmm.dev/identity-active=true \
      kmm.dev/keycloak-instances=3 \
      kmm.dev/postgres-hibernation=off \
      kmm.dev/postgres-primary-site="${target_site}" \
      kmm.dev/postgres-distributed-topology=true >/dev/null
    set_stage fleet-labels-switched
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank target-keycloak-ready) )); then
    kubectl --context "${target_context}" -n opkeycloak patch keycloak opkeycloak \
      --type merge -p '{"spec":{"instances":3}}' >/dev/null
    kubectl --context "${target_context}" -n opkeycloak wait --for=condition=Ready keycloak/opkeycloak --timeout=15m
    validate_target_exposure
    set_stage target-keycloak-ready
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank traffic-activated) )); then
    run_phase_hook activate-target
    if [[ -z "${IDENTITY_ACTIVATE_TARGET_HOOK:-${IDENTITY_SWITCHOVER_HOOK:-${IDENTITY_FAILOVER_HOOK:-}}}" ]]; then
      log "Update ${IDENTITY_CANONICAL_HOST} to $(identity_ingress_ip "${target_site}"); this operation will wait for DNS/TLS/OIDC convergence."
    fi
    wait_for_traffic_cutover
    set_stage traffic-activated
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank fleet-restored) )); then
    restore_fleet_pause_state
    wait_for_fleet_identity_reconciliation
    set_stage fleet-restored
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank verified) )); then
    if [[ "${mode}" == planned ]]; then
      identity_wait_cluster_ready "${source_site}" 15m
      "${SCRIPT_DIR}/verify-database-replication.sh" "${target_site}" "${source_site}"
      "${SCRIPT_DIR}/../fleet/06-validate-identity-ha.sh"
    else
      "${SCRIPT_DIR}/../fleet/06-validate-identity-ha.sh" --allow-degraded
    fi
    set_stage verified
    rank="$(stage_rank "${current_stage}")"
  fi

  if (( rank < $(stage_rank complete) )); then
    if [[ "${mode}" == planned ]]; then
      current_stage=complete
      operation_status=complete
      write_journal
      log "Identity transition completed: ${target_site} is active/writable and ${source_site} is a verified warm replica."
    else
      current_stage=complete-degraded
      operation_status=complete-degraded
      write_journal
      warn "Unplanned promotion completed in DEGRADED mode: ${source_site} remains fenced/hibernated. Rebuild it with './scripts/deploy-platform.sh rebuild-identity-standby ${source_site}' before failback."
    fi
    release_lock
  fi
}

command="${1:-}"
case "${command}" in
  status)
    show_status
    exit 0
    ;;
  rollback)
    rollback_operation
    exit 0
    ;;
  resume)
    prepare_resume
    ;;
  j64seg1opdev|j52seg1opdev)
    initialize_new_operation "${command}"
    ;;
  -h|--help|help|"")
    usage
    exit 0
    ;;
  *)
    usage >&2
    exit 2
    ;;
esac

trap 'rc=$?; if (( rc != 0 )); then operation_status=failed; write_journal >/dev/null 2>&1 || true; warn "Identity transition stopped at stage ${current_stage}. Fleet/lock state was intentionally preserved. Run $0 status, then $0 resume or (pre-demotion planned only) $0 rollback."; fi; exit $rc' EXIT
renew_lock
run_transition
trap - EXIT
