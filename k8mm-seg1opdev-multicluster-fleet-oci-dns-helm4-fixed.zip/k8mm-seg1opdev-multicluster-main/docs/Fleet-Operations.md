# Fleet operations

## Control model

Rancher Fleet is the sole reconciler for `fleet/bundles`. Two GitRepo resources split management and downstream scope:

| Workspace | GitRepo | Targets |
| --- | --- | --- |
| `fleet-local` | `k8mm-seg1opdev-multicluster-local` | `j64seg1opman` |
| `fleet-default` | `k8mm-seg1opdev-multicluster-downstream` | the three application clusters |

Bundle ordering is expressed with `kmm.dev/bundle` labels and `dependsOn` selectors. Cluster-specific values are rendered from Fleet cluster labels.

## Operational commands

```bash
scripts/deploy-platform.sh preflight-fleet
scripts/deploy-platform.sh seed-secrets
scripts/deploy-platform.sh fleet
scripts/deploy-platform.sh validate
```

Inspect reconciliation:

```bash
kubectl --context j64seg1opman -n fleet-local get gitrepo,bundle,bundledeployment
kubectl --context j64seg1opman -n fleet-default get gitrepo,bundle,bundledeployment
kubectl --context j64seg1opman -n fleet-default get clusters.fleet.cattle.io --show-labels
```

## Bundle sequence

Namespaces and CIS/PSA labels are created before Fleet by `seed-secrets` and the related preflight scripts. Fleet does not own namespace objects because Helm cannot safely adopt namespaces that already exist without matching release-ownership metadata.

1. cert-manager chart and cert-manager `ClusterIssuer` configuration;
2. MetalLB chart and Segment1 pool/advertisement configuration;
3. Segment1 Contour;
4. Trident operator/config/Protect;
5. identity operators and role-selected identity resources;
6. Istio base, CNI, istiod, east-west gateway, and Kiali;
7. kube-state-metrics;
8. Elastic Agent;
9. future application bundles.

On downstream clusters, the cert-manager chart is intentionally separate from `11-cert-manager-config`: Fleet first establishes the cert-manager CRDs and webhook, then applies `segment1-ca-clusterissuer`. On `j64seg1opman`, cert-manager is a bootstrap-owned prerequisite for Rancher and is not reinstalled or adopted by Fleet. Before the `fleet-local` GitRepo is created, `03-bootstrap-gitrepos.sh` validates the real Helm release, deployments, CRDs, CA Secret, and ready ClusterIssuer; two lightweight bundles under `fleet/local-bundles` then publish the `cert-manager` and `cert-manager-config` dependency labels. MetalLB is split: `20-metallb` establishes the controller, speaker, and CRDs, then `21-metallb-config` applies the Segment1 `IPAddressPool` and `L2Advertisement`. Bundles that create `Certificate` resources, plus Istiod which references the signer, depend on `cert-manager-config`; Contour and the east-west gateway depend on `metallb-config`. The monitoring bundle depends on kube-state-metrics. Identity resources use target customizations and a final catch-all `doNotDeploy` guard. All external OCI Helm bundles use `helm.chart: oci://kubeharbor.dev.kube/k8mm-charts/<chart>` for the Rancher-bundled Fleet `v0.15.2` runtime. That release only schedules remote-chart loading when `helm.chart` is populated; using an OCI URL only under `helm.repo` creates a manifest-only Bundle, can report false readiness, and can prune an existing bootstrap Helm release during an upgrade. Bundle-anchor ConfigMaps are therefore prohibited.

## Runtime Secrets

Fleet expects, but does not create, these categories:

- Git and OCI credentials in Fleet workspaces;
- registry pull Secrets in workload namespaces;
- cert-manager CA keypair;
- Trident credentials;
- Kiali Grafana token;
- Istio `cacerts` and remote-cluster Secrets;
- PostgreSQL/Keycloak credentials and CNPG replication TLS;
- Elastic Fleet URL/token and Fleet Server CA.

Run `scripts/deploy-platform.sh seed-secrets` after credential rotation. Fleet will then reconcile workloads against the updated Secrets.

## Drift policy

- Do not use direct Helm commands for normal changes.
- Do not patch Fleet-owned resources as a permanent fix.
- Record desired-state changes in the relevant bundle and run package validation before pushing.
- Emergency patches must be back-ported into Git or reverted after the incident.
- The identity failover procedure intentionally pauses the downstream GitRepo while it changes dynamic role labels.

## Monitoring operations

```bash
scripts/deploy-platform.sh validate-monitoring
```

Expected per cluster:

- namespace `elastic-agent-system` labeled `k8mm.dev/monitoring-agent=true`;
- Secret `elastic-agent-fleet-enrollment` with URL/token;
- Secret `devlocal-ca-bundle-secret` with `ca.crt`;
- DaemonSet `agent-pernode-elastic-agent-node` Ready on every node;
- Deployment/Service `kube-state-metrics` in `elastic-monitoring`;
- ExternalName alias `elastic-agent-system/kube-state-metrics`;
- no `elastic-agent-cluster-system` namespace.

## Rollback

For declarative changes, revert the Git commit. For a bad chart package, restore the previous immutable archive and OCI version; do not overwrite a version tag with different content. For secret failures, restore the protected source file and reseed. For identity failures, use the identity runbook and preserve the paused state until database role safety is understood.

## Rancher display-name handling

`deploy-platform.sh fleet` accepts the visible Rancher names from
`fleet-bootstrap.env`, even when Rancher creates the underlying Fleet objects
with internal names such as `c-xxxxx`. The scripts correlate the Fleet,
management, and provisioning cluster resources before applying labels.

If a cluster is genuinely missing or assigned to the wrong Fleet workspace, the
command now prints the Fleet inventory and a specific remediation message. The
three application clusters must already be imported into Rancher and represented
in `fleet-default`; the management cluster must be in `fleet-local`.

```bash
kubectl --context j64seg1opman get clusters.fleet.cattle.io -A \
  -L management.cattle.io/cluster-display-name,management.cattle.io/cluster-name
```



## Reconciliation gates

Before GitRepo creation, `deploy-platform.sh fleet` runs `02-validate-fleet-oci.sh`. The probe executes inside `cattle-fleet-system` and must resolve `kubeharbor.dev.kube`, validate the private CA, and authenticate to the Harbor `/v2/` endpoint. This catches the common split-brain condition where the management host and RKE2 nodes can reach Harbor but CoreDNS forwards `dev.kube` to obsolete or unreachable resolvers. Run the checks independently with:

```bash
./scripts/deploy-platform.sh configure-management-dns
./scripts/deploy-platform.sh validate-fleet-oci
```

`deploy-platform.sh validate` waits for both managed GitRepo resources to fetch a commit, generate Bundles, create BundleDeployments, and report those deployments Ready. The timeout defaults to 1200 seconds and can be changed with `FLEET_RECONCILE_TIMEOUT_SECONDS`. GitRepo bootstrap also increments `spec.forceSyncGeneration` so corrected credentials, DNS, or repository content are scanned immediately.

Identity enablement must run only after the first Fleet validation succeeds. This guarantees that the primary CloudNativePG resource and its replication secrets exist before the j52 secondary workflow begins.
