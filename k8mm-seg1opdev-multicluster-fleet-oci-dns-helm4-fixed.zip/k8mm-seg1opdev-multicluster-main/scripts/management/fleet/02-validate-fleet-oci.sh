#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
load_kmm_runtime_config "${CONFIG_FILE}"

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
NAMESPACE="cattle-fleet-system"
PROBE_NAME="kmm-fleet-oci-preflight-$(date +%s)-$$"
PROBE_SECRET="${PROBE_NAME}"
PROBE_IMAGE="${FLEET_OCI_PROBE_IMAGE:-${REGISTRY_HOST}/rancher/shell:v0.7.0}"
PROBE_TIMEOUT_SECONDS="${FLEET_OCI_PROBE_TIMEOUT_SECONDS:-180}"

require_cmd kubectl
validate_context_access "${RANCHER_CONTEXT}"
require_runtime_file FLEET_HELM_CA_FILE
fleet_helm_username="$(read_required_secret_file FLEET_HELM_USERNAME_FILE)"
fleet_helm_password="$(read_required_secret_file FLEET_HELM_PASSWORD_FILE)"

kubectl --context "${RANCHER_CONTEXT}" get namespace "${NAMESPACE}" >/dev/null 2>&1 || \
  die "${NAMESPACE} does not exist; Rancher/Fleet is not ready."

cleanup_probe() {
  kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" delete pod "${PROBE_NAME}" \
    --ignore-not-found --wait=false >/dev/null 2>&1 || true
  kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" delete secret "${PROBE_SECRET}" \
    --ignore-not-found --wait=false >/dev/null 2>&1 || true
}
cleanup_probe
trap cleanup_probe EXIT

kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" create secret generic "${PROBE_SECRET}" \
  --from-literal=username="${fleet_helm_username}" \
  --from-literal=password="${fleet_helm_password}" \
  --from-file=cacerts="${FLEET_HELM_CA_FILE}" \
  --dry-run=client -o yaml | \
  kubectl --context "${RANCHER_CONTEXT}" apply -f - >/dev/null
unset fleet_helm_username fleet_helm_password

cat <<YAML | kubectl --context "${RANCHER_CONTEXT}" apply -f - >/dev/null
apiVersion: v1
kind: Pod
metadata:
  name: ${PROBE_NAME}
  namespace: ${NAMESPACE}
spec:
  automountServiceAccountToken: false
  restartPolicy: Never
  containers:
    - name: registry-probe
      image: ${PROBE_IMAGE}
      imagePullPolicy: IfNotPresent
      env:
        - name: REGISTRY_HOST
          value: ${REGISTRY_HOST}
        - name: HELM_USERNAME
          valueFrom:
            secretKeyRef:
              name: ${PROBE_SECRET}
              key: username
        - name: HELM_PASSWORD
          valueFrom:
            secretKeyRef:
              name: ${PROBE_SECRET}
              key: password
      volumeMounts:
        - name: harbor-ca
          mountPath: /etc/kmm-harbor-ca
          readOnly: true
      command: ["sh", "-ec"]
      args:
        - |
          if command -v getent >/dev/null 2>&1; then
            getent hosts "${REGISTRY_HOST}"
          elif command -v nslookup >/dev/null 2>&1; then
            nslookup "${REGISTRY_HOST}"
          else
            echo "No DNS lookup utility is present in the probe image" >&2
            exit 127
          fi
          command -v curl >/dev/null 2>&1 || {
            echo "curl is not present in the probe image" >&2
            exit 127
          }
          curl --fail --silent --show-error \
            --cacert /etc/kmm-harbor-ca/cacerts \
            --user "\${HELM_USERNAME}:\${HELM_PASSWORD}" \
            "https://${REGISTRY_HOST}/v2/" >/dev/null
  volumes:
    - name: harbor-ca
      secret:
        secretName: ${PROBE_SECRET}
        items:
          - key: cacerts
            path: cacerts
YAML

deadline=$((SECONDS + PROBE_TIMEOUT_SECONDS))
while true; do
  phase="$(kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" get pod "${PROBE_NAME}" \
    -o jsonpath='{.status.phase}' 2>/dev/null || true)"
  case "${phase}" in
    Succeeded)
      break
      ;;
    Failed)
      kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" logs "${PROBE_NAME}" >&2 2>/dev/null || true
      kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" describe pod "${PROBE_NAME}" >&2 2>/dev/null || true
      kubectl --context "${RANCHER_CONTEXT}" -n kube-system logs deployment/rke2-coredns-rke2-coredns \
        --tail=120 >&2 2>/dev/null || true
      die "Fleet OCI preflight failed. Verify in-cluster DNS for ${REGISTRY_HOST}, Harbor CA trust, and Helm credentials."
      ;;
  esac
  if (( SECONDS >= deadline )); then
    kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" get pod "${PROBE_NAME}" -o wide >&2 2>/dev/null || true
    kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" describe pod "${PROBE_NAME}" >&2 2>/dev/null || true
    kubectl --context "${RANCHER_CONTEXT}" -n kube-system logs deployment/rke2-coredns-rke2-coredns \
      --tail=120 >&2 2>/dev/null || true
    die "Timed out validating Fleet access to https://${REGISTRY_HOST}/v2/."
  fi
  sleep 3
done

resolution="$(kubectl --context "${RANCHER_CONTEXT}" -n "${NAMESPACE}" logs "${PROBE_NAME}" 2>/dev/null | head -1 || true)"
cleanup_probe
trap - EXIT
log "Fleet OCI preflight passed: cluster DNS, Harbor TLS, and Helm authentication are operational${resolution:+ (${resolution})}."
