#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"

init_site_cluster "$@"

NAMESPACE="cattle-system"
OPTIONS="$(site_cluster_options_dir "${SITE}" "${CLUSTER}")"
RELEASE="rancher"
CHART="rancher-2.14.2.tgz"
[[ "${K8_CONTEXT}" == "j64seg1opman" ]] || die "Rancher is centralized on j64seg1opman."
VALUES="rancher-j64manager-values-v1.yaml"
RESOURCES="rancher-j64manager-resources-v1.yaml"
LOCAL_CLUSTER_DISPLAY_NAME="${RANCHER_LOCAL_CLUSTER_DISPLAY_NAME:-j64seg1opman}"

require_kubernetes_tools
require_cmd jq
# Helm version compatibility is enforced centrally by require_helm.
: "${RANCHER_BOOTSTRAP_PASSWORD:?Set RANCHER_BOOTSTRAP_PASSWORD for the initial Rancher admin login}"
RANCHER_CA_FILE="${RANCHER_CA_FILE:-${CA_CERT_FILE:-}}"
[[ -n "${RANCHER_CA_FILE}" ]] || die "Set RANCHER_CA_FILE or CA_CERT_FILE to the trusted CA PEM file."
ensure_file "${RANCHER_CA_FILE}"
validate_context_access "${K8_CONTEXT}"
use_context "${K8_CONTEXT}"

ensure_dir "${OPTIONS}"
ensure_file "${OPTIONS}/values/${VALUES}"
ensure_file "${OPTIONS}/resources/${RESOURCES}"
ensure_chart_package "${HELM_PACKAGES_DIR}/${CHART}"

log "Preparing Rancher/Fleet namespaces with privileged PSA labels..."
"${INSTALL_DIR}/management/rancher/00-prepare-rancher-psa.sh" "${SITE}" "${CLUSTER}"
kubectl label namespace "${NAMESPACE}" --overwrite segment1.ingress/allow-backend=true >/dev/null
ensure_registry_secret "${NAMESPACE}"

log "Creating/updating cattle-system/tls-ca from runtime CA material..."
kubectl -n "${NAMESPACE}" create secret generic tls-ca \
  --from-file=cacerts.pem="${RANCHER_CA_FILE}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

log "Creating release-specific ${RELEASE} resources..."
apply_file "${OPTIONS}/resources/${RESOURCES}"

helm_upgrade_install \
  "${RELEASE}" \
  "${HELM_PACKAGES_DIR}/${CHART}" \
  "${NAMESPACE}" \
  "${OPTIONS}/values/${VALUES}" \
  --set-string "bootstrapPassword=${RANCHER_BOOTSTRAP_PASSWORD}"

log "Waiting for ${RELEASE} to be ready..."
wait_for_deployment_rollout "${NAMESPACE}" "${RELEASE}"

log "Waiting for Rancher local cluster object..."
until kubectl get clusters.management.cattle.io local >/dev/null 2>&1; do
  sleep 5
done

log "Patching Rancher local cluster displayName to ${LOCAL_CLUSTER_DISPLAY_NAME}..."
kubectl patch clusters.management.cattle.io local \
  --type=merge \
  -p "{\"spec\":{\"displayName\":\"${LOCAL_CLUSTER_DISPLAY_NAME}\"}}"

# Rancher creates additional namespaces such as cattle-turtles-system during
# startup. Reconcile PSA labels again after installation so validation does not
# race namespace creation.
log "Reconciling privileged PSA labels on Rancher/Fleet namespaces created during startup..."
"${INSTALL_DIR}/management/rancher/00-prepare-rancher-psa.sh" "${SITE}" "${CLUSTER}"

log "Applying supplemental GitJob event-writer RBAC..."
apply_file "${YAML_DIR}/resources/fleet-gitjob-events-rbac-v1.yaml"

log "Applying the RKE2/Kubernetes 1.35 Fleet WatchListClient compatibility configuration..."
"${INSTALL_DIR}/management/rancher/04-configure-fleet-watchlist.sh" --management-only --wait

log "Validating Rancher-managed webhook and Fleet system components..."
"${INSTALL_DIR}/management/rancher/02-validate-rancher-system.sh"

log "${RELEASE} and required Rancher/Fleet system components installed."
