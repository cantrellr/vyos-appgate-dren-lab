#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/../../_lib/common.sh"
source "${SCRIPT_DIR}/../../_lib/runtime-config.sh"

CONFIG_FILE="${KMM_FLEET_CONFIG:-${RUNTIME_DIR}/fleet-bootstrap.env}"
load_kmm_runtime_config "${CONFIG_FILE}"

RANCHER_CONTEXT="${RANCHER_CONTEXT:-j64seg1opman}"
RANCHER_RESOURCES_FILE="${YAML_DIR}/j64/seg1opman-cluster/resources/rancher-j64manager-resources-v1.yaml"
require_cmd kubectl
require_cmd jq
validate_context_access "${RANCHER_CONTEXT}"
ensure_file "${RANCHER_RESOURCES_FILE}"

export REGISTRY_USERNAME REGISTRY_PASSWORD
REGISTRY_USERNAME="$(read_required_secret_file REGISTRY_USERNAME_FILE)"
REGISTRY_PASSWORD="$(read_required_secret_file REGISTRY_PASSWORD_FILE)"

log "Revalidating the external Rancher v2.14.2 inventory and management-node registry access..."
"${INSTALL_DIR}/management/preflight/validate-rancher-registry.sh" preflight

log "Reapplying and validating management-cluster private DNS forwarding..."
"${INSTALL_DIR}/core/01-patch-coredns.sh" j64 seg1opman

log "Refreshing ${REGISTRY_SECRET} in all existing Rancher namespaces..."
"${INSTALL_DIR}/core/00-bootstrap-kubeharbor-regcred.sh" j64 seg1opman --sync-existing-namespaces

mapfile -t rancher_namespaces < <(
  kubectl --context "${RANCHER_CONTEXT}" get namespaces -o jsonpath='{range .items[*]}{.metadata.name}{"\n"}{end}' | \
    grep -E '^(cattle-|fleet-)' || true
)
for namespace in "${rancher_namespaces[@]}"; do
  kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get serviceaccounts -o name 2>/dev/null | \
  while IFS= read -r serviceaccount; do
    [[ -n "${serviceaccount}" ]] || continue
    existing_pull_secrets="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get "${serviceaccount}" \
      -o jsonpath='{.imagePullSecrets[*].name}' 2>/dev/null || true)"
    if grep -qw "${REGISTRY_SECRET}" <<<"${existing_pull_secrets}"; then
      continue
    fi
    if [[ -n "${existing_pull_secrets}" ]]; then
      patch='[{"op":"add","path":"/imagePullSecrets/-","value":{"name":"'"${REGISTRY_SECRET}"'"}}]'
    else
      patch='[{"op":"add","path":"/imagePullSecrets","value":[{"name":"'"${REGISTRY_SECRET}"'"}]}]'
    fi
    kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" patch "${serviceaccount}" \
      --type json -p "${patch}" >/dev/null || true
  done
done

mapfile -t failed_pods < <(
  kubectl --context "${RANCHER_CONTEXT}" -n cattle-system get pods \
    --field-selector=status.phase=Failed -o name 2>/dev/null | grep '/helm-operation-' || true
)
for pod_ref in "${failed_pods[@]}"; do
  operation_name="${pod_ref#pod/}"
  log "Removing failed Rancher Helm operation ${operation_name} so reconciliation can retry..."
  kubectl --context "${RANCHER_CONTEXT}" -n cattle-system delete "${pod_ref}" --ignore-not-found >/dev/null || true
  kubectl --context "${RANCHER_CONTEXT}" -n cattle-system delete \
    operation.catalog.cattle.io "${operation_name}" --ignore-not-found >/dev/null 2>&1 || true
done

log "Reapplying the Rancher certificate and long-lived WebSocket-enabled Contour HTTPProxy..."
kubectl --context "${RANCHER_CONTEXT}" apply -f "${RANCHER_RESOURCES_FILE}" >/dev/null

log "Applying Rancher/Fleet privileged PSA profiles and restarting existing agents/controllers..."
"${INSTALL_DIR}/management/rancher/00-prepare-rancher-psa.sh" --all --restart

log "Applying supplemental GitJob event-writer RBAC..."
kubectl --context "${RANCHER_CONTEXT}" apply -f "${YAML_DIR}/resources/fleet-gitjob-events-rbac-v1.yaml" >/dev/null

log "Applying the Fleet WatchListClient compatibility setting to all currently imported clusters..."
"${INSTALL_DIR}/management/rancher/04-configure-fleet-watchlist.sh" --existing

"${INSTALL_DIR}/management/rancher/02-validate-rancher-system.sh"

log "Validating in-cluster Fleet access to the Harbor OCI endpoint..."
"${INSTALL_DIR}/management/fleet/02-validate-fleet-oci.sh"

# Existing stalled GitRepos need a new generation after DNS/registry repair.
for repo in \
  fleet-local/k8mm-seg1opdev-multicluster-local \
  fleet-default/k8mm-seg1opdev-multicluster-downstream
do
  namespace="${repo%%/*}"
  name="${repo##*/}"
  if kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get gitrepo "${name}" >/dev/null 2>&1; then
    current="$(kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" get gitrepo "${name}" -o jsonpath='{.spec.forceSyncGeneration}' 2>/dev/null || true)"
    current="${current:-0}"
    kubectl --context "${RANCHER_CONTEXT}" -n "${namespace}" patch gitrepo "${name}" --type=merge \
      -p "{\"spec\":{\"forceSyncGeneration\":$((current + 1))}}" >/dev/null
    log "Queued ${namespace}/${name} for reconciliation after DNS/OCI repair."
  fi
done

unset REGISTRY_USERNAME REGISTRY_PASSWORD
log "Rancher/Fleet system repair completed."
